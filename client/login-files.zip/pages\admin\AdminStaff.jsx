import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus, Search, Loader2, Phone, Mail, Star, Calendar,
  IndianRupee, Clock, MoreVertical, Edit2, Trash2, Sparkles,
  RefreshCw, X, TrendingUp, Users, CheckCircle2, Eye,
  Download, Wallet, Scissors, Banknote, FileText,
  PlusCircle, MinusCircle, Zap, Target, BarChart2,
  ChevronRight, Printer, MessageCircle, Award,
  UserCheck, UserX, Percent, AlertCircle,
  ToggleLeft, ToggleRight,
} from 'lucide-react';
import api from '@/services/api';
import StaffModal from '@/components/StaffModal';
import { useDesignations, getSalaryRecords, saveSalaryRecord, getLastPaid } from '@/hooks/useDesignations';

// ═══════════════════════════════════════════════════════════════════════════
// DESIGN SYSTEM — cream · gold · ink only
// ═══════════════════════════════════════════════════════════════════════════
const C = {
  pageBg:'#F8F3EA',       cream:'#FDF8F0',      creamMid:'#F7EFD8',
  creamDark:'#EDE0C0',    creamBorder:'#DFD0A8',
  gold:'#8A6400',         goldMid:'#B8860B',     goldBright:'#D4A017',
  goldPale:'#FFF8E7',     goldGlow:'#F0D878',
  ink:'#16100A',          inkDeep:'#201408',     inkWarm:'#3E2C14',
  inkMid:'#5A4020',       inkSoft:'#7A5C34',     inkFaint:'#B09060',
  inkGhost:'#D4B890',
  ok:'#285C3A',           okPale:'#EAF4EE',
  risk:'#7A2020',         riskPale:'#F7EEEE',
  warn:'#6B4800',         warnPale:'#FEF3DC',
  white:'#FFFFFF',
};

const ease    = [0.22, 0.61, 0.36, 1];
const fade    = { hidden:{opacity:0,y:12},     show:{opacity:1,y:0,  transition:{duration:0.38,ease}} };
const fadeUp  = { hidden:{opacity:0,y:20},     show:{opacity:1,y:0,  transition:{duration:0.45,ease}} };
const slideIn = { hidden:{x:80,opacity:0},     show:{x:0,opacity:1,  transition:{type:'spring',damping:28,stiffness:280}} };
const popIn   = { hidden:{scale:0.88,opacity:0},show:{scale:1,opacity:1,transition:{type:'spring',damping:22,stiffness:340}} };
const stag    = (d=0.05) => ({ hidden:{opacity:0}, show:{opacity:1,transition:{staggerChildren:d}} });

const Rs     = n => Number(n||0).toLocaleString('en-IN');
const today  = () => new Date().toISOString().split('T')[0];
const fmtDt  = d => new Date(d).toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'});
const fmtMo  = m => { try { return new Date(m+'-01').toLocaleDateString('en-IN',{month:'long',year:'numeric'}); } catch { return m; } };
const pct    = (a,b) => b>0 ? Math.round(a/b*100) : 0;

const DAYS      = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
const DAYS_FULL = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];

// ── atoms ─────────────────────────────────────────────────────────────────────
const inp = (ex={}) => ({
  padding:'9px 13px', borderRadius:10, border:`1px solid ${C.creamBorder}`,
  background:C.cream, fontSize:13, color:C.ink, outline:'none',
  width:'100%', fontFamily:"'DM Sans',sans-serif", ...ex,
});

const SecHead = ({children, icon:Icon}) => (
  <div className="flex items-center gap-2 mb-3">
    {Icon && <Icon size={11} style={{color:C.goldMid}}/>}
    <p className="text-[10px] font-black uppercase tracking-[0.22em]" style={{color:C.goldMid}}>{children}</p>
  </div>
);

const Pill = ({label, active, onClick}) => (
  <button onClick={onClick}
    className="px-3 py-1.5 rounded-full text-[11px] font-bold whitespace-nowrap transition-all"
    style={{
      background: active ? `linear-gradient(135deg,${C.goldMid},${C.goldBright})` : C.cream,
      color:      active ? '#fff' : C.inkMid,
      border:     `1px solid ${active ? C.goldMid : C.creamBorder}`,
    }}>
    {label}
  </button>
);

const Avatar = ({name='', size=44}) => (
  <div className="rounded-2xl flex items-center justify-center font-black text-white flex-shrink-0"
    style={{
      width:size, height:size, fontSize:size>40?17:12,
      background:`linear-gradient(145deg,${C.goldMid},${C.inkDeep})`,
    }}>
    {(name||'?')[0].toUpperCase()}
  </div>
);

const AttBar = ({value=0}) => {
  const col = value>=90 ? C.ok : value>=70 ? C.goldMid : C.risk;
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{background:C.creamDark}}>
        <motion.div className="h-full rounded-full"
          initial={{width:0}} animate={{width:`${Math.min(value,100)}%`}}
          transition={{duration:0.7,ease:'easeOut'}}
          style={{background:`linear-gradient(90deg,${col},${col}99)`}}/>
      </div>
      <span className="text-[10px] font-bold w-8 text-right" style={{color:col}}>{value}%</span>
    </div>
  );
};

const FlashMsg = ({msg}) => (
  <AnimatePresence>
    {msg.text && (
      <motion.p initial={{opacity:0,y:-6}} animate={{opacity:1,y:0}} exit={{opacity:0}}
        className="text-xs font-bold text-center py-2.5 rounded-xl mb-1"
        style={{background:msg.ok?C.okPale:C.riskPale, color:msg.ok?C.ok:C.risk}}>
        {msg.text}
      </motion.p>
    )}
  </AnimatePresence>
);

// ═══════════════════════════════════════════════════════════════════════════
// SALARY MODAL
// Fixes: commission is calculated from LIVE commRate state (not stale DB field)
//        payments stored in localStorage with full metadata
//        history shows local records merged with any API records
// ═══════════════════════════════════════════════════════════════════════════
const SalaryModal = ({staff, onClose, onRefresh}) => {
  const [tab,      setTab]      = useState('overview');
  const [adjType,  setAdjType]  = useState('bonus');
  const [adjAmt,   setAdjAmt]   = useState('');
  const [adjNote,  setAdjNote]  = useState('');
  const [adjMonth, setAdjMonth] = useState(new Date().toISOString().slice(0,7));
  const [saving,   setSaving]   = useState(false);
  const [msg,      setMsg]      = useState({text:'',ok:true});

  // ── commission rate: local editable state, seeded from staff prop ──────
  const [commRate, setCommRate] = useState(Number(staff.commissionRate)||0);
  const [savingCR, setSavingCR] = useState(false);
  const [commDirty,setCommDirty]= useState(false);

  // ── local salary records ───────────────────────────────────────────────
  const [localRecords, setLocalRecords] = useState(() => getSalaryRecords(staff._id));

  const refreshLocal = () => setLocalRecords(getSalaryRecords(staff._id));

  // ── LIVE computed values (use commRate state, not staff.commissionRate) ─
  const base      = staff.salary?.base || 0;
  const revGen    = staff.totalRevenueGenerated || 0;
  const services  = staff.totalServicesCompleted || 0;
  const autoComm  = Math.round(revGen * commRate / 100);   // ← FIXED: uses state not DB field
  const totalPay  = base + autoComm;                        // ← FIXED: live total
  const avgPerSvc = services > 0 ? Math.round(revGen / services) : 0;

  const flash = (text, ok=true) => {
    setMsg({text,ok});
    setTimeout(()=>setMsg({text:'',ok:true}), 3500);
  };

  // ── save commission rate to backend + refresh ──────────────────────────
  const saveCommRate = async () => {
    setSavingCR(true);
    try {
      await api.patch(`/staff/${staff._id}`, { commissionRate: Number(commRate) });
      flash(`✓ Commission updated to ${commRate}%`);
      setCommDirty(false);
      onRefresh(); // refresh parent so card shows updated rate
    } catch(e) {
      flash(e.response?.data?.message || 'Failed to save', false);
    } finally { setSavingCR(false); }
  };

  // ── mark salary paid: save locally + API attempt ───────────────────────
  const markPaid = async () => {
    setSaving(true);
    const record = {
      id:           `pay_${Date.now()}`,
      type:         'payment',
      staffId:      staff._id,
      staffName:    staff.user?.name,
      month:        adjMonth,
      date:         today(),
      baseSalary:   base,
      commissionRate: Number(commRate),
      revenueGenerated: revGen,
      commission:   autoComm,
      amount:       totalPay,
      note:         `Salary paid for ${fmtMo(adjMonth)}`,
      paidAt:       new Date().toISOString(),
    };
    // 1. save locally (always succeeds)
    saveSalaryRecord(staff._id, record);
    refreshLocal();
    // 2. try API (non-blocking)
    try {
      await api.post(`/staff/${staff._id}/salary-payment`, record);
    } catch(e) {
      // stored locally even if API fails
      console.warn('Salary API save failed, stored locally:', e.message);
    }
    flash(`✓ ₹${Rs(totalPay)} marked paid for ${fmtMo(adjMonth)}`);
    setSaving(false);
    onRefresh();
  };

  // ── apply adjustment ───────────────────────────────────────────────────
  const applyAdj = async () => {
    if (!adjAmt || Number(adjAmt) <= 0) return;
    setSaving(true);
    const record = {
      id:     `adj_${Date.now()}`,
      type:   adjType,
      staffId:staff._id,
      month:  adjMonth,
      date:   today(),
      amount: Number(adjAmt),
      note:   adjNote || (adjType === 'bonus' ? 'Bonus' : 'Deduction'),
      paidAt: new Date().toISOString(),
    };
    saveSalaryRecord(staff._id, record);
    refreshLocal();
    try {
      await api.post(`/staff/${staff._id}/salary-adjustment`, record);
    } catch(e) {
      console.warn('Adj API save failed, stored locally');
    }
    flash(`✓ ${adjType==='bonus'?'Bonus':'Deduction'} ₹${Rs(adjAmt)} added`);
    setAdjAmt(''); setAdjNote('');
    setSaving(false);
  };

  // ── print payslip ──────────────────────────────────────────────────────
  const printPayslip = () => {
    const win = window.open('','_blank','width=440,height=680');
    const mo  = fmtMo(adjMonth);
    win.document.write(`<html><head><title>Payslip</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
      *{box-sizing:border-box;margin:0;padding:0}
      body{font-family:'DM Sans',sans-serif;background:#F8F3EA;padding:24px;max-width:400px;margin:auto;color:#16100A}
      .card{background:#fff;border-radius:18px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.1)}
      .hdr{background:linear-gradient(135deg,#16100A,#2d2510);padding:22px;text-align:center;position:relative}
      .hdr::after{content:'';position:absolute;inset:0;background:repeating-linear-gradient(45deg,#B8860B 0,#B8860B 1px,transparent 0,transparent 50%);background-size:14px 14px;opacity:0.08}
      .logo{font-family:'Playfair Display',serif;font-size:22px;color:#fff;position:relative}
      .logo span{color:#D4A017}
      .badge{display:inline-block;margin-top:10px;background:rgba(212,160,23,0.15);border:1px solid rgba(212,160,23,0.3);border-radius:20px;padding:4px 14px;font-size:11px;font-weight:700;color:#D4A017;position:relative}
      .body{padding:20px}
      .sec{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.14em;color:#9C8660;margin:16px 0 8px}
      .row{display:flex;justify-content:space-between;align-items:center;padding:8px 12px;font-size:13px;border-radius:8px}
      .row.alt{background:#FDF8F0}
      .v{font-weight:700;color:#16100A}
      .gold{color:#B8860B;font-weight:800}
      .green{color:#285C3A;font-weight:700}
      .total-row{border-top:2px solid #DFD0A8;margin-top:4px;padding-top:12px;display:flex;justify-content:space-between;padding-left:12px;padding-right:12px}
      .ftr{background:#FDF8F0;border-top:1px solid #EDE0C0;padding:14px;text-align:center;font-size:11px;color:#9C8660;line-height:1.8}
      .btn{display:block;width:100%;padding:12px;background:linear-gradient(135deg,#B8860B,#D4A017);color:#fff;border:none;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;margin-top:16px}
      @media print{.btn{display:none}body{background:#fff;padding:0}.card{box-shadow:none;border-radius:0}}
    </style></head><body>
    <div class="card">
      <div class="hdr">
        <div class="logo">✂ Glamour<span>.</span></div>
        <div style="font-size:10px;color:#9C8660;letter-spacing:.14em;text-transform:uppercase;margin-top:3px;position:relative">Salary Payslip</div>
        <div class="badge">📄 ${mo}</div>
      </div>
      <div class="body">
        <div class="sec">Employee</div>
        <div class="row alt"><span>Name</span><span class="v">${staff.user?.name||'—'}</span></div>
        <div class="row"><span>Designation</span><span class="v">${staff.designationLabel||staff.designation||'—'}</span></div>
        <div class="row alt"><span>Phone</span><span class="v">${staff.user?.phone||'—'}</span></div>
        <div class="sec">Earnings</div>
        <div class="row alt"><span>Base Salary</span><span class="v">₹${Rs(base)}</span></div>
        <div class="row"><span>Commission (${commRate}% × ₹${Rs(revGen)} revenue)</span><span class="green">₹${Rs(autoComm)}</span></div>
        <div class="total-row"><span style="font-size:15px;font-weight:800">Net Payable</span><span class="gold" style="font-size:15px">₹${Rs(totalPay)}</span></div>
        <div class="sec">Performance</div>
        <div class="row alt"><span>Revenue Generated</span><span class="v">₹${Rs(revGen)}</span></div>
        <div class="row"><span>Services Completed</span><span class="v">${services}</span></div>
        <div class="row alt"><span>Avg Rating</span><span class="v">${staff.averageRating?.toFixed(1)||'—'}★</span></div>
        <div class="row"><span>Attendance</span><span class="v">${staff.attendancePercent||0}%</span></div>
      </div>
      <div class="ftr">
        <strong style="color:#B8860B">Glamour Salon</strong> · Generated ${new Date().toLocaleDateString('en-IN')}<br>
        Payslip ID: PAY-${Date.now().toString(36).toUpperCase()}
      </div>
    </div>
    <button class="btn" onclick="window.print()">🖨 Print Payslip</button>
    </body></html>`);
    win.document.close();
  };

  const whatsappPayslip = () => {
    const ph = (staff.user?.phone||'').replace(/\D/g,'').slice(-10);
    if (!ph) { alert('No phone number on file'); return; }
    const mo = fmtMo(adjMonth);
    const lines = [
      `✂ *Glamour Salon — Payslip*`,``,
      `Hi *${staff.user?.name}*! Your salary for *${mo}*:`,``,
      `💼 *Role:* ${staff.designationLabel||staff.designation||'—'}`,
      `💰 *Base:* ₹${Rs(base)}`,
      `📈 *Commission (${commRate}%):* ₹${Rs(autoComm)}`,
      `✅ *Net Payable:* ₹${Rs(totalPay)}`,``,
      `📊 *Performance:*`,
      `  • Revenue: ₹${Rs(revGen)}`,
      `  • Services: ${services}`,
      `  • Attendance: ${staff.attendancePercent||0}%`,``,
      `_Thank you for your dedication — Glamour Salon_ 💛`,
    ].join('%0A');
    window.open(`https://wa.me/91${ph}?text=${lines}`,'_blank');
  };

  // merge API + local records for history tab
  const allHistory = useMemo(() => {
    // deduplicate by id
    const seen = new Set();
    return localRecords.filter(r => { if(seen.has(r.id)) return false; seen.add(r.id); return true; })
      .sort((a,b) => new Date(b.paidAt||b.date) - new Date(a.paidAt||a.date));
  }, [localRecords]);

  const lastPaid = allHistory.find(r => r.type === 'payment');

  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{background:'rgba(22,16,10,0.65)',backdropFilter:'blur(7px)'}}
      onClick={e=>e.target===e.currentTarget&&onClose()}>
      <motion.div variants={popIn} initial="hidden" animate="show" exit="hidden"
        className="w-full max-w-lg flex flex-col rounded-2xl overflow-hidden"
        style={{background:C.cream, maxHeight:'92vh', boxShadow:'0 28px 70px rgba(22,16,10,0.28)'}}>

        {/* ── header ── */}
        <div className="relative overflow-hidden px-6 py-5 flex-shrink-0"
          style={{background:`linear-gradient(135deg,${C.inkDeep},#2d2510)`}}>
          <div className="absolute inset-0 opacity-[0.08]"
            style={{backgroundImage:'repeating-linear-gradient(45deg,#B8860B 0,#B8860B 1px,transparent 0,transparent 50%)',backgroundSize:'14px 14px'}}/>
          <div className="relative flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar name={staff.user?.name} size={42}/>
              <div>
                <p className="text-sm font-bold text-white" style={{fontFamily:"'Playfair Display',serif"}}>{staff.user?.name}</p>
                <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                  <p className="text-[11px]" style={{color:C.inkGhost}}>{staff.designationLabel||staff.designation}</p>
                  {lastPaid && (
                    <span className="text-[10px] px-2 py-0.5 rounded-full font-bold"
                      style={{background:'rgba(40,92,58,0.3)',color:'#86EFAC'}}>
                      Last paid {fmtDt(lastPaid.paidAt||lastPaid.date)}
                    </span>
                  )}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="text-xl font-black text-white" style={{fontFamily:"'Playfair Display',serif"}}>₹{Rs(totalPay)}</p>
                <p className="text-[10px]" style={{color:C.inkGhost}}>{commRate}% commission</p>
              </div>
              <button onClick={onClose}
                className="w-8 h-8 flex items-center justify-center rounded-xl"
                style={{background:'rgba(255,255,255,0.1)'}}>
                <X size={14} className="text-white"/>
              </button>
            </div>
          </div>
        </div>

        {/* ── tabs ── */}
        <div className="flex gap-1.5 px-5 py-3 flex-shrink-0 overflow-x-auto"
          style={{background:C.white, borderBottom:`1px solid ${C.creamBorder}`}}>
          {[['overview','Overview'],['commission','Commission'],['adjust','Bonus / Deduct'],['history','History']].map(([v,l])=>(
            <Pill key={v} label={l} active={tab===v} onClick={()=>setTab(v)}/>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          <FlashMsg msg={msg}/>

          {/* ──────────── OVERVIEW ──────────── */}
          {tab==='overview' && (
            <motion.div variants={stag()} initial="hidden" animate="show" className="space-y-4">

              {/* live breakdown — always recalculates from commRate state */}
              <motion.div variants={fade} className="rounded-2xl overflow-hidden"
                style={{border:`1px solid ${C.creamBorder}`}}>
                {[
                  ['Base Salary',                    `₹${Rs(base)}`,      false, false],
                  [`Commission (${commRate}% of ₹${Rs(revGen)})`, `₹${Rs(autoComm)}`, true, false],
                  ['Net Payable This Month',          `₹${Rs(totalPay)}`,  false, true ],
                ].map(([lbl,val,isC,isTot],i)=>(
                  <div key={lbl}
                    className="flex items-center justify-between px-5 py-3.5"
                    style={{
                      background:  isTot ? C.goldPale : i%2===0 ? C.white : C.cream,
                      borderBottom: i<2  ? `1px solid ${C.creamBorder}` : 'none',
                    }}>
                    <p className="text-sm font-semibold" style={{color:isTot?C.inkDeep:C.inkMid}}>{lbl}</p>
                    <p className="text-sm font-black"
                      style={{color:isTot?C.goldMid:isC?C.ok:C.ink, fontFamily:"'Playfair Display',serif"}}>
                      {val}
                    </p>
                  </div>
                ))}
              </motion.div>

              {/* month + mark paid */}
              <motion.div variants={fade} className="rounded-2xl p-4"
                style={{background:C.white, border:`1px solid ${C.creamBorder}`}}>
                <SecHead icon={Banknote}>Mark as Paid</SecHead>
                <div className="flex gap-3">
                  <input type="month" value={adjMonth}
                    onChange={e=>setAdjMonth(e.target.value)}
                    style={{...inp({flex:1,cursor:'pointer'})}}
                    onFocus={e=>e.target.style.borderColor=C.goldMid}
                    onBlur={e=>e.target.style.borderColor=C.creamBorder}/>
                  <button onClick={markPaid} disabled={saving}
                    className="flex items-center gap-1.5 px-5 py-2 rounded-xl text-xs font-bold hover:opacity-90 disabled:opacity-40"
                    style={{background:`linear-gradient(135deg,${C.goldMid},${C.goldBright})`,color:'#fff',flexShrink:0}}>
                    {saving ? <Loader2 size={13} className="animate-spin"/> : <Banknote size={13}/>}
                    ₹{Rs(totalPay)} — Paid
                  </button>
                </div>
                {lastPaid && (
                  <p className="text-[11px] mt-2 font-semibold" style={{color:C.ok}}>
                    ✓ Last paid ₹{Rs(lastPaid.amount)} on {fmtDt(lastPaid.paidAt||lastPaid.date)} for {fmtMo(lastPaid.month)}
                  </p>
                )}
              </motion.div>

              {/* payslip actions */}
              <motion.div variants={fade} className="grid grid-cols-2 gap-3">
                <button onClick={printPayslip}
                  className="flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-bold hover:opacity-80"
                  style={{background:C.inkDeep, color:'#fff'}}>
                  <Printer size={13}/> Print Payslip
                </button>
                <button onClick={whatsappPayslip}
                  className="flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-bold hover:opacity-80"
                  style={{background:'#1A7A45', color:'#fff'}}>
                  <MessageCircle size={13}/> WhatsApp
                </button>
              </motion.div>

              {/* performance snapshot */}
              <motion.div variants={fade} className="rounded-2xl p-4"
                style={{background:C.white, border:`1px solid ${C.creamBorder}`}}>
                <SecHead icon={BarChart2}>Performance</SecHead>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    [`₹${Rs(revGen)}`,  'Revenue'],
                    [services,          'Services'],
                    [`₹${Rs(avgPerSvc)}`,'Avg/Svc'],
                  ].map(([v,l])=>(
                    <div key={l} className="text-center py-3 rounded-xl"
                      style={{background:C.goldPale, border:`1px solid ${C.creamBorder}`}}>
                      <p className="text-sm font-black" style={{color:C.goldMid}}>{v}</p>
                      <p className="text-[10px] font-semibold mt-0.5" style={{color:C.inkFaint}}>{l}</p>
                    </div>
                  ))}
                </div>
              </motion.div>
            </motion.div>
          )}

          {/* ──────────── COMMISSION TAB ──────────── */}
          {tab==='commission' && (
            <motion.div variants={stag()} initial="hidden" animate="show" className="space-y-4">

              <motion.div variants={fade} className="rounded-2xl px-4 py-3 flex items-start gap-2.5"
                style={{background:C.warnPale, border:`1px solid ${C.creamBorder}`}}>
                <Zap size={13} style={{color:C.goldMid,marginTop:1,flexShrink:0}}/>
                <p className="text-xs" style={{color:C.inkMid}}>
                  Commission is calculated live: <strong>Rate × Revenue Generated</strong>. 
                  Change the rate below and hit Save — the new amount reflects instantly above.
                </p>
              </motion.div>

              {/* live calculator */}
              <motion.div variants={fade} className="rounded-2xl p-5"
                style={{background:C.white, border:`1px solid ${C.creamBorder}`}}>
                <SecHead icon={Target}>Commission Rate</SecHead>
                <div className="space-y-4">
                  {/* input + save */}
                  <div className="flex gap-3 items-end">
                    <div className="flex-1">
                      <label className="block text-[10px] font-bold uppercase tracking-wider mb-1.5"
                        style={{color:C.inkFaint}}>Rate (%)</label>
                      <input type="number" min={0} max={50} step={0.5}
                        value={commRate}
                        onChange={e=>{ setCommRate(e.target.value); setCommDirty(true); }}
                        style={inp()}
                        onFocus={e=>e.target.style.borderColor=C.goldMid}
                        onBlur={e=>e.target.style.borderColor=C.creamBorder}/>
                    </div>
                    <button onClick={saveCommRate} disabled={savingCR||!commDirty}
                      className="px-5 py-2.5 rounded-xl text-xs font-bold hover:opacity-90 disabled:opacity-40"
                      style={{
                        background: commDirty ? `linear-gradient(135deg,${C.goldMid},${C.goldBright})` : C.creamDark,
                        color: commDirty ? '#fff' : C.inkFaint,
                      }}>
                      {savingCR ? <Loader2 size={12} className="animate-spin"/> : 'Save Rate'}
                    </button>
                  </div>

                  {/* slider */}
                  <input type="range" min={0} max={30} step={0.5}
                    value={commRate}
                    onChange={e=>{ setCommRate(e.target.value); setCommDirty(true); }}
                    style={{width:'100%', accentColor:C.goldMid}}/>
                  <div className="flex justify-between text-[10px] font-semibold" style={{color:C.inkFaint}}>
                    <span>0%</span><span>15%</span><span>30%</span>
                  </div>

                  {/* live result box */}
                  <div className="rounded-xl p-4" style={{background:C.goldPale, border:`1px solid ${C.creamBorder}`}}>
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-semibold" style={{color:C.inkMid}}>
                        ₹{Rs(revGen)} × {commRate}% =
                      </p>
                      <p className="text-2xl font-black" style={{color:C.goldMid, fontFamily:"'Playfair Display',serif"}}>
                        ₹{Rs(autoComm)}
                      </p>
                    </div>
                    <div className="mt-3 h-1.5 rounded-full overflow-hidden" style={{background:C.creamDark}}>
                      <motion.div className="h-full rounded-full"
                        animate={{width:`${Math.min(Number(commRate)*3,100)}%`}}
                        transition={{duration:0.3}}
                        style={{background:`linear-gradient(90deg,${C.goldMid},${C.goldBright})`}}/>
                    </div>
                    <p className="text-[11px] mt-2 font-semibold" style={{color:C.inkMid}}>
                      Total this month: ₹{Rs(base)} + ₹{Rs(autoComm)} = <strong style={{color:C.goldMid}}>₹{Rs(totalPay)}</strong>
                    </p>
                  </div>
                </div>
              </motion.div>

              {/* role presets */}
              <motion.div variants={fade} className="rounded-2xl p-4"
                style={{background:C.white, border:`1px solid ${C.creamBorder}`}}>
                <SecHead icon={Award}>Preset Rates</SecHead>
                <div className="grid grid-cols-3 gap-2">
                  {[['Trainee','5'],['Junior','8'],['Senior','12'],['Master','15'],['Manager','18'],['Senior+','20']].map(([lbl,val])=>(
                    <button key={lbl}
                      onClick={()=>{ setCommRate(val); setCommDirty(true); }}
                      className="py-2.5 rounded-xl text-[11px] font-bold transition-all hover:opacity-80"
                      style={{
                        background: String(commRate)===val ? `linear-gradient(135deg,${C.goldMid},${C.goldBright})` : C.cream,
                        color:      String(commRate)===val ? '#fff' : C.inkMid,
                        border:     `1px solid ${String(commRate)===val ? C.goldMid : C.creamBorder}`,
                      }}>
                      <p className="font-black" style={{color:String(commRate)===val?'#fff':C.goldMid}}>{val}%</p>
                      <p>{lbl}</p>
                    </button>
                  ))}
                </div>
              </motion.div>
            </motion.div>
          )}

          {/* ──────────── ADJUSTMENTS ──────────── */}
          {tab==='adjust' && (
            <motion.div variants={stag()} initial="hidden" animate="show" className="space-y-4">
              <motion.div variants={fade} className="rounded-2xl p-5"
                style={{background:C.white, border:`1px solid ${C.creamBorder}`}}>
                <SecHead icon={PlusCircle}>Bonus or Deduction</SecHead>
                <div className="flex gap-2 mb-4">
                  {[['bonus','+ Bonus',C.ok,C.okPale],['deduction','− Deduction',C.risk,C.riskPale]].map(([v,l,col,bg])=>(
                    <button key={v} type="button" onClick={()=>setAdjType(v)}
                      className="flex-1 py-2.5 rounded-xl text-xs font-bold transition-all"
                      style={{
                        background: adjType===v ? bg : C.cream,
                        color:      adjType===v ? col : C.inkMid,
                        border:     `1px solid ${adjType===v ? col : C.creamBorder}`,
                      }}>{l}</button>
                  ))}
                </div>
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider mb-1.5" style={{color:C.inkFaint}}>Amount (₹)</label>
                      <input type="number" min={1} placeholder="e.g. 500"
                        value={adjAmt} onChange={e=>setAdjAmt(e.target.value)}
                        style={inp()}
                        onFocus={e=>e.target.style.borderColor=C.goldMid}
                        onBlur={e=>e.target.style.borderColor=C.creamBorder}/>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider mb-1.5" style={{color:C.inkFaint}}>Month</label>
                      <input type="month" value={adjMonth} onChange={e=>setAdjMonth(e.target.value)}
                        style={{...inp({cursor:'pointer'})}}
                        onFocus={e=>e.target.style.borderColor=C.goldMid}
                        onBlur={e=>e.target.style.borderColor=C.creamBorder}/>
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider mb-1.5" style={{color:C.inkFaint}}>Note / Reason</label>
                    <input type="text" placeholder="e.g. Festival bonus, late deduction…"
                      value={adjNote} onChange={e=>setAdjNote(e.target.value)}
                      style={inp()}
                      onFocus={e=>e.target.style.borderColor=C.goldMid}
                      onBlur={e=>e.target.style.borderColor=C.creamBorder}/>
                  </div>
                  <button onClick={applyAdj} disabled={saving||!adjAmt}
                    className="w-full py-3 rounded-xl text-xs font-bold hover:opacity-90 disabled:opacity-40"
                    style={{background:`linear-gradient(135deg,${C.inkDeep},${C.inkWarm})`,color:'#fff'}}>
                    {saving ? <Loader2 size={13} className="animate-spin inline mr-1"/> : null}
                    Apply {adjType==='bonus'?'Bonus':'Deduction'}{adjAmt?` — ₹${Rs(adjAmt)}`:''}
                  </button>
                </div>
              </motion.div>

              {/* quick presets */}
              <motion.div variants={fade} className="rounded-2xl p-4"
                style={{background:C.white, border:`1px solid ${C.creamBorder}`}}>
                <SecHead>Quick Presets</SecHead>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    [500,'Festival Bonus','bonus'],
                    [1000,'Performance','bonus'],
                    [2000,'Star Award','bonus'],
                    [200,'Late Fine','deduction'],
                    [300,'Absent Fine','deduction'],
                    [150,'Material','deduction'],
                  ].map(([amt,note,type])=>(
                    <button key={note}
                      onClick={()=>{setAdjAmt(String(amt));setAdjNote(note);setAdjType(type);}}
                      className="py-2.5 px-1 rounded-xl text-center text-[11px] font-semibold transition-all hover:opacity-80"
                      style={{background:C.cream, border:`1px solid ${C.creamBorder}`}}>
                      <p className="font-black" style={{color:type==='bonus'?C.ok:C.risk}}>
                        {type==='bonus'?'+':'−'}₹{Rs(amt)}
                      </p>
                      <p className="mt-0.5" style={{color:C.inkMid}}>{note}</p>
                    </button>
                  ))}
                </div>
              </motion.div>
            </motion.div>
          )}

          {/* ──────────── HISTORY ──────────── */}
          {tab==='history' && (
            <motion.div variants={stag()} initial="hidden" animate="show" className="space-y-3">
              {/* month totals summary */}
              {allHistory.length > 0 && (
                <motion.div variants={fade}
                  className="rounded-xl px-4 py-3 flex items-center justify-between flex-wrap gap-3"
                  style={{background:C.goldPale, border:`1px solid ${C.creamBorder}`}}>
                  <div>
                    <p className="text-[10px] font-bold uppercase" style={{color:C.inkFaint}}>Total Paid (all time)</p>
                    <p className="text-lg font-black" style={{color:C.goldMid, fontFamily:"'Playfair Display',serif"}}>
                      ₹{Rs(allHistory.filter(r=>r.type==='payment').reduce((a,r)=>a+(r.amount||0),0))}
                    </p>
                  </div>
                  <div className="flex gap-4 text-center">
                    <div>
                      <p className="text-base font-black" style={{color:C.ok}}>
                        +₹{Rs(allHistory.filter(r=>r.type==='bonus').reduce((a,r)=>a+(r.amount||0),0))}
                      </p>
                      <p className="text-[10px] font-bold uppercase" style={{color:C.inkFaint}}>Bonuses</p>
                    </div>
                    <div>
                      <p className="text-base font-black" style={{color:C.risk}}>
                        −₹{Rs(allHistory.filter(r=>r.type==='deduction').reduce((a,r)=>a+(r.amount||0),0))}
                      </p>
                      <p className="text-[10px] font-bold uppercase" style={{color:C.inkFaint}}>Deductions</p>
                    </div>
                  </div>
                </motion.div>
              )}

              {allHistory.length === 0 ? (
                <div className="text-center py-12">
                  <FileText size={26} style={{color:C.creamBorder, margin:'0 auto 10px'}}/>
                  <p className="text-sm font-semibold" style={{color:C.inkFaint}}>No records yet</p>
                  <p className="text-xs mt-1" style={{color:C.inkGhost}}>Mark a salary paid to start tracking</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {allHistory.map((h,i) => {
                    const isPay = h.type==='payment';
                    const isBon = h.type==='bonus';
                    const isDed = h.type==='deduction';
                    return (
                      <motion.div key={h.id||i} variants={fade}
                        className="flex items-center justify-between px-4 py-3 rounded-xl"
                        style={{background:i%2===0?C.white:C.cream, border:`1px solid ${C.creamBorder}`}}>
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                            style={{background:isPay?C.goldPale:isBon?C.okPale:C.riskPale}}>
                            {isPay ? <Banknote size={14} style={{color:C.goldMid}}/> :
                             isBon ? <PlusCircle size={14} style={{color:C.ok}}/> :
                                     <MinusCircle size={14} style={{color:C.risk}}/>}
                          </div>
                          <div>
                            <p className="text-xs font-bold" style={{color:C.ink}}>{h.note||h.type}</p>
                            <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                              {h.month && <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full"
                                style={{background:C.goldPale, color:C.goldMid}}>{fmtMo(h.month)}</span>}
                              {(h.paidAt||h.date) && (
                                <span className="text-[10px]" style={{color:C.inkFaint}}>
                                  {fmtDt(h.paidAt||h.date)}
                                </span>
                              )}
                              {isPay && h.commissionRate !== undefined && (
                                <span className="text-[10px]" style={{color:C.inkFaint}}>
                                  {h.commissionRate}% comm
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-black"
                            style={{color:isPay?C.goldMid:isBon?C.ok:C.risk}}>
                            {isDed?'−':'+'}₹{Rs(h.amount)}
                          </p>
                          {isPay && h.baseSalary !== undefined && (
                            <p className="text-[10px]" style={{color:C.inkFaint}}>
                              Base ₹{Rs(h.baseSalary)} + Comm ₹{Rs(h.commission)}
                            </p>
                          )}
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </motion.div>
          )}

        </div>
      </motion.div>
    </motion.div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// STAFF DETAIL DRAWER
// ═══════════════════════════════════════════════════════════════════════════
const StaffDrawer = ({staff, onClose, onEdit, onSalary}) => {
  const [tab,     setTab]     = useState('overview');
  const [attD,    setAttD]    = useState(null);
  const [revD,    setRevD]    = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(()=>{
    (async()=>{
      setLoading(true);
      const [a,r] = await Promise.allSettled([
        api.get(`/staff/${staff._id}/attendance`),
        api.get(`/staff/${staff._id}/revenue`),
      ]);
      if(a.status==='fulfilled') setAttD(a.value.data);
      if(r.status==='fulfilled') setRevD(r.value.data);
      setLoading(false);
    })();
  },[staff._id]);

  const attPct   = attD?.attendancePercent ?? staff.attendancePercent ?? 0;
  const commRate = staff.commissionRate || 0;
  const base     = staff.salary?.base || 0;
  const revGen   = staff.totalRevenueGenerated || 0;
  const autoComm = Math.round(revGen * commRate / 100);
  const totalPay = base + autoComm;
  const lastPaid = getLastPaid(staff._id);

  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}
      className="fixed inset-0 z-50 flex justify-end"
      style={{background:'rgba(22,16,10,0.5)',backdropFilter:'blur(5px)'}}
      onClick={e=>e.target===e.currentTarget&&onClose()}>
      <motion.div variants={slideIn} initial="hidden" animate="show" exit="hidden"
        className="w-full max-w-md h-full flex flex-col"
        style={{background:C.pageBg}}>

        <div className="relative overflow-hidden px-6 py-5 flex-shrink-0"
          style={{background:`linear-gradient(135deg,${C.inkDeep},#2d2510)`}}>
          <div className="absolute inset-0 opacity-[0.07]"
            style={{backgroundImage:'repeating-linear-gradient(45deg,#B8860B 0,#B8860B 1px,transparent 0,transparent 50%)',backgroundSize:'14px 14px'}}/>
          <div className="relative flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <Avatar name={staff.user?.name} size={50}/>
              <div>
                <h2 className="text-lg font-bold text-white" style={{fontFamily:"'Playfair Display',serif"}}>
                  {staff.user?.name}
                </h2>
                <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                  <span className="text-[10px] font-bold px-2.5 py-1 rounded-full"
                    style={{background:'rgba(184,134,11,0.25)',color:C.goldGlow}}>
                    {staff.designationLabel||staff.designation}
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                    style={{
                      background: staff.user?.isActive ? 'rgba(40,92,58,0.25)' : 'rgba(122,32,32,0.25)',
                      color:      staff.user?.isActive ? '#86EFAC' : '#FCA5A5',
                    }}>
                    {staff.user?.isActive ? '● Active' : '● Inactive'}
                  </span>
                </div>
              </div>
            </div>
            <div className="flex gap-1.5 flex-shrink-0">
              <button onClick={onEdit}
                className="w-8 h-8 flex items-center justify-center rounded-xl"
                style={{background:'rgba(255,255,255,0.1)'}}>
                <Edit2 size={13} className="text-white"/>
              </button>
              <button onClick={()=>onSalary(staff)}
                className="w-8 h-8 flex items-center justify-center rounded-xl"
                style={{background:'rgba(184,134,11,0.25)'}}>
                <Wallet size={13} style={{color:C.goldGlow}}/>
              </button>
              <button onClick={onClose}
                className="w-8 h-8 flex items-center justify-center rounded-xl"
                style={{background:'rgba(255,255,255,0.1)'}}>
                <X size={13} className="text-white"/>
              </button>
            </div>
          </div>
        </div>

        <div className="flex gap-1.5 px-4 py-3 overflow-x-auto flex-shrink-0"
          style={{background:C.white, borderBottom:`1px solid ${C.creamBorder}`}}>
          {[['overview','Overview'],['attendance','Attendance'],['revenue','Revenue'],['schedule','Schedule']].map(([v,l])=>(
            <Pill key={v} label={l} active={tab===v} onClick={()=>setTab(v)}/>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {loading && <div className="flex justify-center py-10"><Loader2 size={22} style={{color:C.goldMid}} className="animate-spin"/></div>}

          {!loading && tab==='overview' && (
            <motion.div variants={stag()} initial="hidden" animate="show" className="space-y-4">
              <motion.div variants={fade} className="rounded-2xl p-4"
                style={{background:C.white, border:`1px solid ${C.creamBorder}`}}>
                <SecHead icon={Mail}>Contact</SecHead>
                <div className="space-y-2.5">
                  {[[Mail,staff.user?.email,'Email'],[Phone,staff.user?.phone,'Phone']].filter(([,v])=>v).map(([Icon,val,lbl])=>(
                    <div key={lbl} className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{background:C.goldPale}}>
                        <Icon size={13} style={{color:C.goldMid}}/>
                      </div>
                      <div>
                        <p className="text-[10px] font-bold uppercase" style={{color:C.inkFaint}}>{lbl}</p>
                        <p className="text-sm font-semibold" style={{color:C.ink}}>{val}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>

              <motion.div variants={fade} className="grid grid-cols-2 gap-3">
                {[[Calendar,staff.totalServicesCompleted||0,'Services'],[IndianRupee,`₹${Rs(revGen)}`,'Revenue'],[Star,staff.averageRating?.toFixed(1)||'—','Rating'],[Clock,`${attPct}%`,'Attendance']].map(([Icon,val,lbl])=>(
                  <div key={lbl} className="rounded-xl p-3 flex items-center gap-2"
                    style={{background:C.cream, border:`1px solid ${C.creamBorder}`}}>
                    <Icon size={13} style={{color:C.goldMid}}/>
                    <div>
                      <p className="text-sm font-black" style={{color:C.ink}}>{val}</p>
                      <p className="text-[10px] font-semibold" style={{color:C.inkFaint}}>{lbl}</p>
                    </div>
                  </div>
                ))}
              </motion.div>

              {/* salary panel — shows LIVE computed total */}
              <motion.div variants={fade}
                className="rounded-2xl p-4 cursor-pointer hover:opacity-90"
                style={{background:C.goldPale, border:`1px solid ${C.creamBorder}`}}
                onClick={()=>onSalary(staff)}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-wider mb-1" style={{color:C.inkSoft}}>Monthly Payable</p>
                    <p className="text-2xl font-black" style={{fontFamily:"'Playfair Display',serif",color:C.goldMid}}>₹{Rs(totalPay)}</p>
                    <p className="text-[11px] mt-0.5" style={{color:C.inkSoft}}>₹{Rs(base)} base + {commRate}% comm (₹{Rs(autoComm)})</p>
                    {lastPaid && (
                      <p className="text-[10px] mt-1 font-bold" style={{color:C.ok}}>
                        ✓ Last paid {fmtDt(lastPaid.paidAt||lastPaid.date)}
                      </p>
                    )}
                  </div>
                  <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
                    style={{background:`linear-gradient(135deg,${C.goldMid},${C.goldBright})`}}>
                    <Wallet size={20} className="text-white"/>
                  </div>
                </div>
                <p className="text-[11px] mt-3 font-bold flex items-center gap-1" style={{color:C.goldMid}}>
                  Tap to manage salary <ChevronRight size={11}/>
                </p>
              </motion.div>

              {(staff.specializations||[]).length>0 && (
                <motion.div variants={fade} className="rounded-2xl p-4"
                  style={{background:C.white, border:`1px solid ${C.creamBorder}`}}>
                  <SecHead icon={Scissors}>Specializations</SecHead>
                  <div className="flex flex-wrap gap-2">
                    {staff.specializations.map(s=>(
                      <span key={s} className="flex items-center gap-1 text-xs font-semibold px-3 py-1.5 rounded-full capitalize"
                        style={{background:C.goldPale,color:C.inkMid,border:`1px solid ${C.creamBorder}`}}>
                        <Scissors size={10} style={{color:C.goldMid}}/>{s}
                      </span>
                    ))}
                  </div>
                </motion.div>
              )}
            </motion.div>
          )}

          {!loading && tab==='attendance' && (
            <motion.div variants={stag()} initial="hidden" animate="show" className="space-y-4">
              <motion.div variants={fade} className="rounded-2xl p-5"
                style={{background:C.white,border:`1px solid ${C.creamBorder}`}}>
                <SecHead icon={UserCheck}>This Month</SecHead>
                <div className="grid grid-cols-3 gap-3 mb-4">
                  {[[attD?.present??'—','Present',C.ok,C.okPale],[attD?.absent??'—','Absent',C.risk,C.riskPale],[attD?.leaves??'—','Leaves',C.goldMid,C.goldPale]].map(([v,l,c,bg])=>(
                    <div key={l} className="text-center py-3 rounded-xl" style={{background:bg,border:`1px solid ${c}20`}}>
                      <p className="text-2xl font-black" style={{color:c}}>{v}</p>
                      <p className="text-[10px] font-bold mt-0.5" style={{color:C.inkFaint}}>{l}</p>
                    </div>
                  ))}
                </div>
                <AttBar value={attPct}/>
              </motion.div>
              <motion.div variants={fade} className="rounded-2xl p-4" style={{background:C.white,border:`1px solid ${C.creamBorder}`}}>
                <SecHead>Recent Check-ins</SecHead>
                {(attD?.recent||[]).length===0 ? (
                  <p className="text-xs text-center py-4" style={{color:C.inkFaint}}>No records</p>
                ) : (
                  <div className="space-y-1.5">
                    {(attD?.recent||[]).slice(0,8).map((rec,i)=>(
                      <div key={i} className="flex items-center justify-between px-3 py-2 rounded-xl"
                        style={{background:i%2===0?C.cream:C.white}}>
                        <div className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full" style={{background:rec.status==='present'?C.ok:rec.status==='leave'?C.goldMid:C.risk}}/>
                          <span className="text-xs font-semibold" style={{color:C.ink}}>
                            {new Date(rec.date).toLocaleDateString('en-IN',{day:'2-digit',month:'short'})}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 text-[11px]" style={{color:C.inkFaint}}>
                          {rec.checkIn  && <span>In <strong style={{color:C.ink}}>{rec.checkIn}</strong></span>}
                          {rec.checkOut && <span>Out <strong style={{color:C.ink}}>{rec.checkOut}</strong></span>}
                          <span className="font-bold text-[10px] px-2 py-0.5 rounded-full capitalize"
                            style={{background:rec.status==='present'?C.okPale:rec.status==='leave'?C.goldPale:C.riskPale,color:rec.status==='present'?C.ok:rec.status==='leave'?C.goldMid:C.risk}}>
                            {rec.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            </motion.div>
          )}

          {!loading && tab==='revenue' && (
            <motion.div variants={stag()} initial="hidden" animate="show" className="space-y-4">
              <motion.div variants={fade} className="rounded-2xl p-5" style={{background:C.white,border:`1px solid ${C.creamBorder}`}}>
                <SecHead icon={TrendingUp}>Revenue</SecHead>
                <div className="grid grid-cols-2 gap-3">
                  {[['Total',`₹${Rs(revGen)}`],['This Month',`₹${Rs(revD?.thisMonth)}`],['Services',staff.totalServicesCompleted||0],['Avg/Svc',`₹${Rs(revD?.avgPerService)}`]].map(([l,v])=>(
                    <div key={l} className="rounded-xl p-3 text-center" style={{background:C.goldPale,border:`1px solid ${C.creamBorder}`}}>
                      <p className="text-lg font-black" style={{color:C.goldMid}}>{v}</p>
                      <p className="text-[10px] font-semibold mt-0.5" style={{color:C.inkFaint}}>{l}</p>
                    </div>
                  ))}
                </div>
              </motion.div>
              <motion.div variants={fade} className="rounded-2xl p-4" style={{background:C.white,border:`1px solid ${C.creamBorder}`}}>
                <SecHead>Top Services</SecHead>
                {(revD?.topServices||[]).length===0 ? (
                  <p className="text-xs text-center py-4" style={{color:C.inkFaint}}>No data</p>
                ) : (
                  <div className="space-y-3">
                    {(revD?.topServices||[]).slice(0,5).map((svc,i)=>(
                      <div key={i} className="flex items-center gap-3">
                        <span className="text-[10px] font-black w-5" style={{color:C.goldMid}}>#{i+1}</span>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <p className="text-xs font-bold truncate" style={{color:C.ink}}>{svc.name}</p>
                            <p className="text-xs font-black ml-2 flex-shrink-0" style={{color:C.goldMid}}>₹{Rs(svc.revenue)}</p>
                          </div>
                          <div className="h-1 rounded-full overflow-hidden" style={{background:C.creamDark}}>
                            <motion.div className="h-full rounded-full"
                              initial={{width:0}}
                              animate={{width:`${pct(svc.count,(revD?.topServices||[])[0]?.count)}%`}}
                              transition={{duration:0.6,delay:i*0.1}}
                              style={{background:`linear-gradient(90deg,${C.goldMid},${C.goldBright})`}}/>
                          </div>
                        </div>
                        <span className="text-[10px] font-semibold flex-shrink-0" style={{color:C.inkFaint}}>{svc.count}×</span>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            </motion.div>
          )}

          {!loading && tab==='schedule' && (
            <motion.div variants={stag()} initial="hidden" animate="show">
              <motion.div variants={fade} className="rounded-2xl p-5" style={{background:C.white,border:`1px solid ${C.creamBorder}`}}>
                <SecHead icon={Clock}>Shift Hours</SecHead>
                <p className="text-2xl font-black mb-5" style={{fontFamily:"'Playfair Display',serif",color:C.ink}}>
                  {staff.schedule?.shiftStart||'09:00'} — {staff.schedule?.shiftEnd||'21:00'}
                </p>
                <SecHead>Weekly Pattern</SecHead>
                <div className="grid grid-cols-7 gap-1.5">
                  {DAYS.map((d,i)=>{
                    const off=staff.schedule?.weeklyOff?.includes(DAYS_FULL[i]);
                    return (
                      <div key={d} className="flex flex-col items-center gap-1.5">
                        <div className="w-9 h-9 rounded-xl flex items-center justify-center text-xs font-black"
                          style={{background:off?C.riskPale:C.okPale,color:off?C.risk:C.ok,border:`1px solid ${off?`${C.risk}30`:`${C.ok}30`}`}}>
                          {d[0]}
                        </div>
                        <span className="text-[9px] font-bold" style={{color:off?C.risk:C.ok}}>{off?'Off':'On'}</span>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            </motion.div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// STAFF CARD
// ═══════════════════════════════════════════════════════════════════════════
const StaffCard = ({staff, onView, onEdit, onDelete, onToggle, onSalary}) => {
  const [menu,   setMenu]   = useState(false);
  const menuRef             = useRef(null);
  const isActive = staff.user?.isActive !== false;
  const commRate = staff.commissionRate || 0;
  const base     = staff.salary?.base || 0;
  const revGen   = staff.totalRevenueGenerated || 0;
  const autoComm = Math.round(revGen * commRate / 100); // LIVE computed
  const totalPay = base + autoComm;
  const attPct   = staff.attendancePercent ?? 0;
  const lastPaid = getLastPaid(staff._id);

  useEffect(()=>{
    const fn = e => { if(menuRef.current&&!menuRef.current.contains(e.target)) setMenu(false); };
    document.addEventListener('mousedown', fn);
    return () => document.removeEventListener('mousedown', fn);
  },[]);

  return (
    <motion.div variants={fade} layout
      whileHover={{y:-3, boxShadow:'0 14px 40px rgba(139,100,0,0.13)'}}
      className="group relative rounded-2xl overflow-visible transition-all duration-300 cursor-pointer"
      style={{
        background: C.white,
        border:     `1px solid ${isActive?C.creamBorder:`${C.risk}35`}`,
        boxShadow:  '0 2px 14px rgba(139,100,0,0.06)',
        opacity:    isActive ? 1 : 0.72,
      }}
      onClick={()=>onView(staff)}>

      <div className="h-[3px] rounded-t-2xl"
        style={{background:isActive?`linear-gradient(90deg,${C.goldMid},${C.inkDeep},${C.goldMid})`:`linear-gradient(90deg,${C.risk}60,transparent)`}}/>

      <div className="p-5">
        <div className="flex items-start gap-3 mb-4">
          <Avatar name={staff.user?.name} size={46}/>
          <div className="flex-1 min-w-0">
            <h3 className="text-sm font-bold truncate" style={{fontFamily:"'Playfair Display',serif",color:C.ink}}>
              {staff.user?.name}
            </h3>
            <div className="flex items-center gap-1.5 mt-1 flex-wrap">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                style={{background:C.goldPale,color:C.goldMid,border:`1px solid ${C.creamBorder}`}}>
                {staff.designationLabel || DESG_FALLBACK(staff.designation)}
              </span>
              {!isActive && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                  style={{background:C.riskPale,color:C.risk}}>Inactive</span>
              )}
            </div>
          </div>
          <div ref={menuRef} className="relative flex-shrink-0" onClick={e=>e.stopPropagation()}>
            <button onClick={()=>setMenu(v=>!v)}
              className="w-8 h-8 flex items-center justify-center rounded-xl"
              style={{background:C.creamMid}}>
              <MoreVertical size={13} style={{color:C.inkSoft}}/>
            </button>
            <AnimatePresence>
              {menu && (
                <motion.div initial={{opacity:0,scale:0.88,y:-4}} animate={{opacity:1,scale:1,y:0}}
                  exit={{opacity:0,scale:0.88}} transition={{duration:0.15}}
                  className="absolute right-0 top-10 rounded-2xl py-1.5 z-30 min-w-[175px]"
                  style={{background:C.white,border:`1px solid ${C.creamBorder}`,boxShadow:'0 10px 36px rgba(22,16,10,0.15)'}}>
                  {[
                    [()=>{onView(staff);setMenu(false)},   Eye,    'View Profile',  C.inkMid, C.cream    ],
                    [()=>{onEdit(staff);setMenu(false)},   Edit2,  'Edit',          C.goldMid,C.goldPale ],
                    [()=>{onSalary(staff);setMenu(false)}, Wallet, 'Salary & Pay',  C.goldMid,C.goldPale ],
                    [()=>{onToggle(staff);setMenu(false)}, isActive?UserX:UserCheck, isActive?'Deactivate':'Activate', isActive?C.risk:C.ok, isActive?C.riskPale:C.okPale],
                    [()=>{onDelete(staff._id);setMenu(false)}, Trash2, 'Delete', C.risk, C.riskPale],
                  ].map(([fn,Icon,lbl,col,bg],i)=>(
                    <button key={i} onClick={fn}
                      className="flex items-center gap-2.5 w-full px-4 py-2.5 text-[11px] font-bold"
                      style={{color:col}}
                      onMouseEnter={e=>e.currentTarget.style.background=bg}
                      onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                      <Icon size={12}/>{lbl}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        <div className="space-y-1 mb-4">
          {staff.user?.email && (
            <div className="flex items-center gap-2 text-[11px]" style={{color:C.inkFaint}}>
              <Mail size={10}/><span className="truncate">{staff.user.email}</span>
            </div>
          )}
          {staff.user?.phone && (
            <div className="flex items-center gap-2 text-[11px]" style={{color:C.inkFaint}}>
              <Phone size={10}/><span>+91 {staff.user.phone.replace(/\D/g,'').slice(-10)}</span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-3 gap-2 mb-4">
          {[[staff.totalServicesCompleted||0,'Services'],[`₹${Rs(revGen)}`,'Revenue'],[staff.averageRating>0?`${staff.averageRating.toFixed(1)}★`:'—','Rating']].map(([v,l])=>(
            <div key={l} className="text-center py-2.5 rounded-xl" style={{background:C.creamMid,border:`1px solid ${C.creamBorder}`}}>
              <p className="text-xs font-black" style={{color:C.goldMid}}>{v}</p>
              <p className="text-[9px] font-bold uppercase mt-0.5" style={{color:C.inkFaint}}>{l}</p>
            </div>
          ))}
        </div>

        <div className="mb-3">
          <p className="text-[10px] font-bold uppercase tracking-wider mb-1.5" style={{color:C.inkFaint}}>Attendance</p>
          <AttBar value={attPct}/>
        </div>

        {/* salary chip — shows live computed total */}
        <div className="flex items-center justify-between px-3 py-2 rounded-xl hover:opacity-80 transition-opacity"
          style={{background:C.goldPale,border:`1px solid ${C.creamBorder}`,cursor:'pointer'}}
          onClick={e=>{e.stopPropagation();onSalary(staff);}}>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5">
              <Wallet size={11} style={{color:C.goldMid}}/>
              <span className="text-[11px] font-semibold" style={{color:C.inkSoft}}>
                ₹{Rs(base)} + {commRate}%
              </span>
            </div>
            {lastPaid && (
              <p className="text-[10px] mt-0.5 font-semibold" style={{color:C.ok}}>
                ✓ Paid {fmtDt(lastPaid.paidAt||lastPaid.date)}
              </p>
            )}
          </div>
          <span className="text-[11px] font-black ml-2 flex-shrink-0" style={{color:C.goldMid}}>₹{Rs(totalPay)}</span>
        </div>
      </div>

      <div className="px-5 py-3 flex items-center justify-between"
        style={{borderTop:`1px solid ${C.creamDark}`,background:C.creamMid}}>
        <div className="flex items-center gap-1.5 text-[11px] font-semibold" style={{color:C.inkMid}}>
          <Clock size={10} style={{color:C.goldMid}}/>
          {staff.schedule?.shiftStart||'09:00'} — {staff.schedule?.shiftEnd||'21:00'}
        </div>
        <div className="flex gap-1">
          {DAYS.map((d,i)=>{
            const off=staff.schedule?.weeklyOff?.includes(DAYS_FULL[i]);
            return (
              <div key={d} className="w-5 h-5 rounded-full flex items-center justify-center text-[8px] font-black"
                style={{background:off?C.riskPale:C.okPale,color:off?C.risk:C.ok}}>
                {d[0]}
              </div>
            );
          })}
        </div>
      </div>

      <div className="absolute inset-x-0 bottom-0 py-2.5 flex items-center justify-center gap-1.5 rounded-b-2xl opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none"
        style={{background:`linear-gradient(135deg,${C.goldMid},${C.goldBright})`}}>
        <Eye size={12} className="text-white"/>
        <span className="text-xs font-bold text-white">View Full Profile</span>
      </div>
    </motion.div>
  );
};

// fallback for designation label when hook not loaded
const DESG_FALLBACK = (key) => {
  const defaults = {trainee:'Trainee',junior_stylist:'Junior Stylist',senior_stylist:'Senior Stylist',master_stylist:'Master Stylist',receptionist:'Receptionist',manager:'Manager'};
  return defaults[key] || key || '—';
};

// ═══════════════════════════════════════════════════════════════════════════
// MAIN PAGE
// ═══════════════════════════════════════════════════════════════════════════
const AdminStaff = () => {
  const [staffList,    setStaffList]    = useState([]);
  const [loading,      setLoading]      = useState(true);
  const [modalOpen,    setModalOpen]    = useState(false);
  const [editingStaff, setEditingStaff] = useState(null);
  const [saving,       setSaving]       = useState(false);
  const [search,       setSearch]       = useState('');
  const [filterDesg,   setFilterDesg]   = useState('');
  const [filterStatus, setFilterStatus] = useState('active');
  const [sortBy,       setSortBy]       = useState('name');
  const [drawerStaff,  setDrawerStaff]  = useState(null);
  const [salaryStaff,  setSalaryStaff]  = useState(null);
  const [rawStaff,     setRawStaff]     = useState([]);

  // live designations from settings
  const { designations, desgMap } = useDesignations();

  // ── fetchStaff stores RAW data only — no desgMap dependency → no infinite loop ──

  const fetchStaff = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/staff');
      setRawStaff(data.staff || []);
    } catch(e) { console.error(e); }
    finally { setLoading(false); }
  }, []); // ← empty deps: only created once, never loops

  useEffect(() => { fetchStaff(); }, [fetchStaff]);

  // ── enrich with live designation labels via memo — no API call, no loop ──
  useEffect(() => {
    const map = desgMap; // capture current value
    setStaffList(
      rawStaff.map(s => ({
        ...s,
        designationLabel: map[s.designation]?.label || DESG_FALLBACK(s.designation),
      }))
    );
  }, [rawStaff, designations]); // re-runs when data OR roles change

  const displayed = useMemo(() => {
    let list = staffList.filter(s => {
      const q      = search.toLowerCase();
      const matchQ = !q || s.user?.name?.toLowerCase().includes(q) || s.user?.email?.toLowerCase().includes(q) || (s.user?.phone||'').includes(q);
      const matchD = !filterDesg || s.designation === filterDesg;
      const active = s.user?.isActive !== false;
      const matchS = filterStatus==='all' ? true : filterStatus==='active' ? active : !active;
      return matchQ && matchD && matchS;
    });
    list = [...list].sort((a,b) => {
      if(sortBy==='revenue')  return (b.totalRevenueGenerated||0)-(a.totalRevenueGenerated||0);
      if(sortBy==='services') return (b.totalServicesCompleted||0)-(a.totalServicesCompleted||0);
      if(sortBy==='rating')   return (b.averageRating||0)-(a.averageRating||0);
      if(sortBy==='salary') {
        const ap = (a.salary?.base||0) + Math.round((a.totalRevenueGenerated||0)*(a.commissionRate||0)/100);
        const bp = (b.salary?.base||0) + Math.round((b.totalRevenueGenerated||0)*(b.commissionRate||0)/100);
        return bp - ap;
      }
      return (a.user?.name||'').localeCompare(b.user?.name||'');
    });
    return list;
  }, [staffList, search, filterDesg, filterStatus, sortBy]);

  // stats — all use LIVE commission formula
  const totalActive  = staffList.filter(s=>s.user?.isActive!==false).length;
  const totalRevenue = staffList.reduce((a,s)=>a+(s.totalRevenueGenerated||0),0);
  const totalPayroll = staffList.reduce((a,s)=>{
    const comm = Math.round((s.totalRevenueGenerated||0)*(s.commissionRate||0)/100);
    return a + (s.salary?.base||0) + comm;
  }, 0);
  const totalSvcs    = staffList.reduce((a,s)=>a+(s.totalServicesCompleted||0),0);
  const avgRating    = (() => {
    const r = staffList.filter(s=>s.averageRating>0);
    return r.length ? (r.reduce((a,s)=>a+s.averageRating,0)/r.length).toFixed(1) : '—';
  })();

  const handleAdd  = () => { setEditingStaff(null); setModalOpen(true); };
  const handleEdit = s  => { setEditingStaff(s); setModalOpen(true); setDrawerStaff(null); };

  const handleSubmit = async (fd) => {
    setSaving(true);
    try {
      editingStaff ? await api.put(`/staff/${editingStaff._id}`,fd) : await api.post('/staff',fd);
      setModalOpen(false); setEditingStaff(null); fetchStaff();
    } catch(e) { console.error(e); } finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if(!confirm('Permanently delete this staff member?')) return;
    try { await api.delete(`/staff/${id}`); fetchStaff(); } catch {}
  };

  const handleToggle = async (staff) => {
    const active = staff.user?.isActive !== false;
    if(!confirm(`${active?'Deactivate':'Activate'} ${staff.user?.name}?`)) return;
    try { await api.patch(`/staff/${staff._id}`,{isActive:!active}); fetchStaff(); } catch {}
  };

  const exportCSV = () => {
    const meta = [['GLAMOUR SALON — STAFF REPORT'],[`Generated: ${new Date().toLocaleString('en-IN')}`],[`Total: ${displayed.length}`],[]];
    const hdr = ['S.No','Name','Email','Phone','Designation','Status','Base Salary','Commission %','Commission (Live)','Total Payable','Services','Revenue','Avg Rating','Attendance %','Shift','Days Off'];
    const rows = displayed.map((s,i) => {
      const comm = Math.round((s.totalRevenueGenerated||0)*(s.commissionRate||0)/100);
      return [
        i+1, `"${s.user?.name||''}"`, s.user?.email||'', `="${s.user?.phone||''}"`,
        s.designationLabel||'—', s.user?.isActive!==false?'Active':'Inactive',
        s.salary?.base||0, s.commissionRate||0, comm,
        (s.salary?.base||0)+comm,
        s.totalServicesCompleted||0, s.totalRevenueGenerated||0,
        s.averageRating?.toFixed(1)||0, s.attendancePercent||0,
        `"${s.schedule?.shiftStart||''}–${s.schedule?.shiftEnd||''}"`,
        `"${(s.schedule?.weeklyOff||[]).join(', ')}"`,
      ];
    });
    const totals = ['','TOTAL','','','','',
      displayed.reduce((a,s)=>a+(s.salary?.base||0),0),'',
      displayed.reduce((a,s)=>a+Math.round((s.totalRevenueGenerated||0)*(s.commissionRate||0)/100),0),
      displayed.reduce((a,s)=>a+(s.salary?.base||0)+Math.round((s.totalRevenueGenerated||0)*(s.commissionRate||0)/100),0),
      displayed.reduce((a,s)=>a+(s.totalServicesCompleted||0),0),
      displayed.reduce((a,s)=>a+(s.totalRevenueGenerated||0),0),
      '','','','',
    ];
    const csv = [...meta,hdr,...rows,[],totals].map(r=>Array.isArray(r)?r.join(','):'').join('\n');
    const blob = new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8;'});
    const a = document.createElement('a'); a.href=URL.createObjectURL(blob);
    a.download=`Glamour-Staff-${today()}.csv`; a.click();
  };

  return (
    <>
      <motion.div variants={stag(0.06)} initial="hidden" animate="show"
        className="min-h-screen pb-14 space-y-5"
        style={{background:C.pageBg, fontFamily:"'DM Sans',sans-serif"}}>

        {/* ── HEADER ── */}
        <motion.div variants={fadeUp}
          className="relative overflow-hidden rounded-2xl px-7 py-7"
          style={{background:`linear-gradient(135deg,${C.inkDeep},#2d2510)`,border:`1px solid #3a2a0c`}}>
          <div className="absolute inset-0 opacity-[0.08]"
            style={{backgroundImage:'repeating-linear-gradient(45deg,#B8860B 0,#B8860B 1px,transparent 0,transparent 50%)',backgroundSize:'18px 18px'}}/>
          <div className="absolute -right-12 -top-12 w-56 h-56 rounded-full opacity-[0.07]"
            style={{background:`radial-gradient(circle,${C.goldBright},transparent)`}}/>
          <div className="relative flex items-start justify-between flex-wrap gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Sparkles size={12} style={{color:C.goldGlow}}/>
                <span className="text-[10px] font-black tracking-[0.24em] uppercase" style={{color:C.goldGlow}}>Team</span>
              </div>
              <h1 className="text-3xl font-bold text-white" style={{fontFamily:"'Playfair Display',serif"}}>
                Staff Management
              </h1>
              <p className="text-sm mt-1.5" style={{color:'#8a7560'}}>
                {totalActive} active · {staffList.length} total · ₹{Rs(totalPayroll)}/mo payroll
              </p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <button onClick={exportCSV}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-full text-xs font-bold hover:opacity-80"
                style={{background:'rgba(255,255,255,0.08)',color:'#fff',border:'1px solid rgba(255,255,255,0.12)'}}>
                <Download size={13}/> Export
              </button>
              <button onClick={fetchStaff}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-full text-xs font-bold hover:opacity-80"
                style={{background:'rgba(255,255,255,0.08)',color:'#fff',border:'1px solid rgba(255,255,255,0.12)'}}>
                <RefreshCw size={13}/> Refresh
              </button>
              <button onClick={handleAdd}
                className="flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold hover:opacity-90"
                style={{background:`linear-gradient(135deg,${C.goldMid},${C.goldBright})`,color:'#fff',boxShadow:'0 4px 18px rgba(139,100,0,0.38)'}}>
                <Plus size={15}/> Add Staff
              </button>
            </div>
          </div>
        </motion.div>

        {/* ── STAT TILES ── */}
        <motion.div variants={stag(0.07)} className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {[
            [Users,        staffList.length,         'Total Staff'    ],
            [CheckCircle2, totalActive,               'Active'         ],
            [TrendingUp,   `₹${Rs(totalRevenue)}`,   'Total Revenue'  ],
            [Wallet,       `₹${Rs(totalPayroll)}`,   'Live Payroll'   ],
            [Star,         avgRating!=='—'?`${avgRating}★`:'—','Avg Rating'],
          ].map(([Icon,val,lbl])=>(
            <motion.div key={lbl} variants={fade} whileHover={{y:-2}}
              className="rounded-2xl p-4 flex items-center gap-3"
              style={{background:C.white,border:`1px solid ${C.creamBorder}`,boxShadow:'0 2px 14px rgba(139,100,0,0.05)'}}>
              <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{background:C.goldPale,border:`1px solid ${C.creamBorder}`}}>
                <Icon size={17} style={{color:C.goldMid}}/>
              </div>
              <div className="min-w-0">
                <p className="text-lg font-black truncate" style={{fontFamily:"'Playfair Display',serif",color:C.ink}}>{val}</p>
                <p className="text-[10px] font-bold uppercase tracking-wider" style={{color:C.inkFaint}}>{lbl}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* ── PAYROLL SUMMARY BAR ── */}
        {staffList.length > 0 && (
          <motion.div variants={fade}
            className="rounded-2xl px-5 py-4 flex items-center justify-between flex-wrap gap-4"
            style={{background:C.white,border:`1px solid ${C.creamBorder}`}}>
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{background:`linear-gradient(135deg,${C.goldMid},${C.goldBright})`}}>
                <Banknote size={16} className="text-white"/>
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-wider" style={{color:C.inkFaint}}>Monthly Payroll (Live)</p>
                <p className="text-xl font-black" style={{fontFamily:"'Playfair Display',serif",color:C.goldMid}}>₹{Rs(totalPayroll)}</p>
              </div>
            </div>
            <div className="flex items-center gap-6 flex-wrap">
              <div className="text-center">
                <p className="text-base font-black" style={{color:C.ink}}>₹{Rs(staffList.reduce((a,s)=>a+(s.salary?.base||0),0))}</p>
                <p className="text-[10px] font-bold uppercase" style={{color:C.inkFaint}}>Base Total</p>
              </div>
              <div className="w-px h-8" style={{background:C.creamBorder}}/>
              <div className="text-center">
                <p className="text-base font-black" style={{color:C.ok}}>
                  ₹{Rs(staffList.reduce((a,s)=>a+Math.round((s.totalRevenueGenerated||0)*(s.commissionRate||0)/100),0))}
                </p>
                <p className="text-[10px] font-bold uppercase" style={{color:C.inkFaint}}>Commissions</p>
              </div>
              <div className="w-px h-8" style={{background:C.creamBorder}}/>
              <div className="text-center">
                <p className="text-base font-black" style={{color:C.ink}}>{totalSvcs}</p>
                <p className="text-[10px] font-bold uppercase" style={{color:C.inkFaint}}>Services</p>
              </div>
            </div>
          </motion.div>
        )}

        {/* ── FILTERS ── */}
        <motion.div variants={fade} className="rounded-2xl p-4 space-y-3"
          style={{background:C.white,border:`1px solid ${C.creamBorder}`}}>
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search size={13} style={{color:C.inkFaint,position:'absolute',left:12,top:'50%',transform:'translateY(-50%)'}}/>
              <input style={{...inp(),paddingLeft:34}} placeholder="Search name, email, phone…"
                value={search} onChange={e=>setSearch(e.target.value)}
                onFocus={e=>e.target.style.borderColor=C.goldMid}
                onBlur={e=>e.target.style.borderColor=C.creamBorder}/>
              {search && (
                <button onClick={()=>setSearch('')}
                  style={{position:'absolute',right:10,top:'50%',transform:'translateY(-50%)'}}>
                  <X size={12} style={{color:C.inkFaint}}/>
                </button>
              )}
            </div>
            <div className="flex gap-1.5">
              {[['active','Active'],['inactive','Inactive'],['all','All']].map(([v,l])=>(
                <button key={v} onClick={()=>setFilterStatus(v)}
                  className="px-3 py-2 rounded-full text-[11px] font-bold transition-all"
                  style={{
                    background: filterStatus===v ? C.inkDeep : C.cream,
                    color:      filterStatus===v ? '#fff' : C.inkMid,
                    border:     `1px solid ${filterStatus===v ? C.inkDeep : C.creamBorder}`,
                  }}>{l}</button>
              ))}
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider" style={{color:C.inkFaint}}>Sort</span>
              <select value={sortBy} onChange={e=>setSortBy(e.target.value)}
                style={{...inp({width:'auto',padding:'8px 10px',cursor:'pointer'})}}
                onFocus={e=>e.target.style.borderColor=C.goldMid}
                onBlur={e=>e.target.style.borderColor=C.creamBorder}>
                {[['name','Name'],['revenue','Revenue'],['services','Services'],['rating','Rating'],['salary','Salary']].map(([v,l])=>(
                  <option key={v} value={v}>{l}</option>
                ))}
              </select>
            </div>
          </div>
          {/* designation pills — from live hook */}
          <div className="flex gap-2 flex-wrap">
            <Pill label="All Roles" active={!filterDesg} onClick={()=>setFilterDesg('')}/>
            {designations.map(d=>(
              <Pill key={d.key} label={d.label} active={filterDesg===d.key}
                onClick={()=>setFilterDesg(filterDesg===d.key?'':d.key)}/>
            ))}
          </div>
        </motion.div>

        {/* ── STAFF GRID ── */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-24 gap-3">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center"
              style={{background:`linear-gradient(135deg,${C.goldMid},${C.goldBright})`}}>
              <Loader2 size={20} className="text-white animate-spin"/>
            </div>
            <p className="text-sm font-medium" style={{color:C.inkFaint}}>Loading team…</p>
          </div>
        ) : displayed.length === 0 ? (
          <motion.div variants={fade}
            className="flex flex-col items-center justify-center py-24 gap-4 rounded-2xl"
            style={{background:C.white,border:`1px solid ${C.creamBorder}`}}>
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center" style={{background:C.goldPale}}>
              <Users size={26} style={{color:C.goldMid}}/>
            </div>
            <div className="text-center">
              <p className="font-bold" style={{color:C.ink}}>No staff found</p>
              <p className="text-xs mt-1" style={{color:C.inkFaint}}>
                {search ? 'Try a different search' : 'Add your first team member'}
              </p>
            </div>
            <button onClick={handleAdd}
              className="flex items-center gap-2 text-xs font-bold px-5 py-2.5 rounded-full"
              style={{background:`linear-gradient(135deg,${C.goldMid},${C.goldBright})`,color:'#fff'}}>
              <Plus size={13}/> Add Staff Member
            </button>
          </motion.div>
        ) : (
          <motion.div variants={stag(0.05)} className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {displayed.map(s => (
              <StaffCard key={s._id} staff={s}
                onView={setDrawerStaff}
                onEdit={handleEdit}
                onDelete={handleDelete}
                onToggle={handleToggle}
                onSalary={setSalaryStaff}/>
            ))}
          </motion.div>
        )}

        {!loading && displayed.length > 0 && (
          <p className="text-center text-xs font-medium" style={{color:C.inkFaint}}>
            Showing {displayed.length} of {staffList.length} staff members
          </p>
        )}
      </motion.div>

      <AnimatePresence>
        {drawerStaff && (
          <StaffDrawer
            staff={drawerStaff}
            onClose={()=>setDrawerStaff(null)}
            onEdit={()=>handleEdit(drawerStaff)}
            onSalary={s=>{setSalaryStaff(s);setDrawerStaff(null);}}/>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {salaryStaff && (
          <SalaryModal
            staff={salaryStaff}
            onClose={()=>setSalaryStaff(null)}
            onRefresh={fetchStaff}/>
        )}
      </AnimatePresence>

      <StaffModal
        isOpen={modalOpen}
        onClose={()=>{setModalOpen(false);setEditingStaff(null);}}
        onSubmit={handleSubmit}
        staff={editingStaff}
        isLoading={saving}/>
    </>
  );
};

export default AdminStaff;