import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '@/context/AuthContext';
import api from '@/services/api';
import {
  Calendar, Users, IndianRupee, TrendingUp,
  Clock, CheckCircle2, XCircle, ArrowUpRight,
  Plus, UserPlus, Scissors, Gift,
  ChevronRight, RefreshCw, AlertCircle,
  Loader2, Sparkles,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

// ─── helpers ─────────────────────────────────────────────────────────────────
const fmt      = (n)    => Number(n || 0).toLocaleString('en-IN');
const initials = (name = '') =>
  name.split(' ').slice(0, 2).map((w) => w[0]).join('').toUpperCase() || '?';
const fmtTime  = (slot) => {
  if (!slot) return '—';
  const [h, m] = slot.split(':').map(Number);
  const period = h >= 12 ? 'PM' : 'AM';
  const dh = h > 12 ? h - 12 : h === 0 ? 12 : h;
  return `${dh}:${String(m).padStart(2, '0')} ${period}`;
};

// ─── tokens ──────────────────────────────────────────────────────────────────
const C = {
  cream:      '#FDF8F0',
  creamDark:  '#F5EDD8',
  creamBorder:'#E8D9B8',
  gold:       '#B8860B',
  goldLight:  '#DAA520',
  goldPale:   '#FFF8E7',
  ink:        '#1C1410',
  inkMid:     '#5C4A2A',
  inkLight:   '#9C8660',
  white:      '#FFFFFF',
};

// ─── status ──────────────────────────────────────────────────────────────────
const STATUS = {
  confirmed:     { label: 'Confirmed',   dot: '#F59E0B', bg: '#FFFBEB', border: '#FDE68A', text: '#92400E' },
  'in-progress': { label: 'In Progress', dot: '#10B981', bg: '#ECFDF5', border: '#A7F3D0', text: '#065F46' },
  completed:     { label: 'Completed',   dot: '#3B82F6', bg: '#EFF6FF', border: '#BFDBFE', text: '#1E40AF' },
  cancelled:     { label: 'Cancelled',   dot: '#EF4444', bg: '#FEF2F2', border: '#FECACA', text: '#991B1B' },
  'no-show':     { label: 'No Show',     dot: '#9CA3AF', bg: '#F9FAFB', border: '#E5E7EB', text: '#374151' },
};

// ─── avatar palette ──────────────────────────────────────────────────────────
const AVATARS = ['#B8860B','#8B6914','#C9952A','#6B4F12','#DAA520'];

// ─── quick actions ───────────────────────────────────────────────────────────
const ACTIONS = [
  { label: 'New Booking',  sub: 'Schedule now',      icon: Plus,     path: '/admin/appointments', gold: true  },
  { label: 'Add Customer', sub: 'Register client',   icon: UserPlus, path: '/admin/customers',   gold: false },
  { label: 'Add Service',  sub: 'Create listing',    icon: Scissors, path: '/admin/services',    gold: true  },
  { label: 'Coupons',      sub: 'Deals & offers',    icon: Gift,     path: '/admin/coupons',     gold: false },
];

// ─── animation ───────────────────────────────────────────────────────────────
const fade = {
  hidden: { opacity: 0, y: 16 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.22, 0.61, 0.36, 1] } },
};
const stagger = {
  hidden: { opacity: 0 },
  show:   { opacity: 1, transition: { staggerChildren: 0.07 } },
};

// ═════════════════════════════════════════════════════════════════════════════
export default function AdminDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [stats,      setStats]      = useState(null);
  const [bookings,   setBookings]   = useState([]);
  const [customers,  setCustomers]  = useState(0);
  const [loading,    setLoading]    = useState(true);
  const [error,      setError]      = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  const hour     = new Date().getHours();
  const greeting = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';
  const today    = new Date().toISOString().split('T')[0];
  const dateStr  = new Date().toLocaleDateString('en-IN', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric',
  });

  const fetchData = useCallback(async (silent = false) => {
    if (!silent) setLoading(true); else setRefreshing(true);
    setError(null);
    try {
      const [sRes, bRes, cRes] = await Promise.all([
        api.get('/bookings/today/stats'),
        api.get(`/bookings?date=${today}&limit=10`),
        api.get('/users?role=customer&limit=1').catch(() => ({ data: { pagination: { total: 0 } } })),
      ]);
      setStats(sRes.data.stats);
      setBookings(bRes.data.bookings || []);
      setCustomers(cRes.data?.pagination?.total || 0);
    } catch (e) {
      setError(e?.response?.data?.message || 'Failed to load dashboard');
    } finally {
      setLoading(false); setRefreshing(false);
    }
  }, [today]);

  useEffect(() => { fetchData(); }, [fetchData]);

  // ── stat cards data ────────────────────────────────────────────────────
  const STATS = [
    {
      icon:  Calendar,
      label: "Today's Bookings",
      value: stats ? String(stats.total) : '—',
      sub:   stats ? `${stats.confirmed} confirmed · ${stats.inProgress} active` : '…',
      accent: C.gold,
    },
    {
      icon:  Users,
      label: 'Total Customers',
      value: customers ? fmt(customers) : '—',
      sub:   'Registered clients',
      accent: C.gold,
    },
    {
      icon:  IndianRupee,
      label: "Today's Revenue",
      value: stats ? `₹${fmt(stats.todayRevenue)}` : '—',
      sub:   stats ? `${stats.completed} completed` : '…',
      accent: C.gold,
    },
    {
      icon:  TrendingUp,
      label: 'Cancellations',
      value: stats ? String(stats.cancelled) : '—',
      sub:   stats ? `${stats.total - stats.cancelled} still active` : '…',
      accent: C.gold,
    },
  ];

  // ── loading ────────────────────────────────────────────────────────────
  if (loading) return (
    <div style={{ background: C.cream }} className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
      <div className="w-14 h-14 rounded-2xl flex items-center justify-center shadow-md"
        style={{ background: `linear-gradient(135deg,${C.gold},${C.goldLight})` }}>
        <Loader2 size={24} className="text-white animate-spin" />
      </div>
      <p className="text-sm font-medium" style={{ color: C.inkLight }}>Loading your dashboard…</p>
    </div>
  );

  // ── error ──────────────────────────────────────────────────────────────
  if (error) return (
    <div style={{ background: C.cream }} className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
      <div className="w-14 h-14 rounded-2xl flex items-center justify-center"
        style={{ background: '#FEF2F2', border: '1px solid #FECACA' }}>
        <AlertCircle size={24} className="text-red-400" />
      </div>
      <p className="text-sm font-semibold" style={{ color: C.ink }}>{error}</p>
      <button onClick={() => fetchData()}
        className="flex items-center gap-2 text-xs font-semibold px-5 py-2.5 rounded-full border transition-all hover:shadow-md"
        style={{ borderColor: C.gold, color: C.gold, background: C.goldPale }}>
        <RefreshCw size={12} /> Try again
      </button>
    </div>
  );

  // ── main ───────────────────────────────────────────────────────────────
  return (
    <motion.div
      variants={stagger} initial="hidden" animate="show"
      className="min-h-screen px-2 py-6 space-y-8"
      style={{ background: C.cream, fontFamily: "'DM Sans', sans-serif" }}
    >

      {/* ══ HEADER ═══════════════════════════════════════════════════════ */}
      <motion.div variants={fade} className="flex items-start justify-between flex-wrap gap-4 px-1">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Sparkles size={13} style={{ color: C.goldLight }} />
            <span className="text-[11px] font-bold tracking-[0.18em] uppercase"
              style={{ color: C.inkLight }}>
              Dashboard Overview
            </span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold leading-tight"
            style={{ fontFamily: "'Playfair Display', serif", color: C.ink }}>
            {greeting}, <span style={{ color: C.gold }}>{user?.name?.split(' ')[0]}</span> 👋
          </h1>
          <p className="text-sm mt-1.5" style={{ color: C.inkLight }}>{dateStr}</p>
        </div>

        <div className="flex items-center gap-2.5 mt-1">
          <div className="flex items-center gap-1.5 px-3.5 py-2 rounded-full text-xs font-semibold"
            style={{ background: '#ECFDF5', border: '1px solid #A7F3D0', color: '#065F46' }}>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            System Online
          </div>
          <button onClick={() => fetchData(true)} disabled={refreshing}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-full text-xs font-semibold transition-all hover:shadow-sm disabled:opacity-40"
            style={{ background: C.white, border: `1px solid ${C.creamBorder}`, color: C.inkLight }}>
            <RefreshCw size={11} className={refreshing ? 'animate-spin' : ''} />
            Refresh
          </button>
        </div>
      </motion.div>

      {/* ══ STAT CARDS — single row ═══════════════════════════════════════ */}
      <motion.div variants={fade}
        className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {STATS.map((s) => {
          const Icon = s.icon;
          return (
            <motion.div key={s.label}
              whileHover={{ y: -4, boxShadow: '0 20px 48px rgba(184,134,11,0.13)' }}
              className="rounded-2xl p-6 transition-all duration-300 cursor-pointer"
              style={{
                background: C.white,
                border: `1px solid ${C.creamBorder}`,
                boxShadow: '0 2px 16px rgba(184,134,11,0.06)',
              }}>

              {/* icon + live badge */}
              <div className="flex items-center justify-between mb-5">
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center"
                  style={{ background: C.goldPale, border: `1px solid ${C.creamBorder}` }}>
                  <Icon size={22} style={{ color: C.gold }} />
                </div>
                <span className="text-[10px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1"
                  style={{ background: C.goldPale, color: C.gold, border: `1px solid ${C.creamBorder}` }}>
                  <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: C.goldLight }} />
                  LIVE
                </span>
              </div>

              {/* value */}
              <p className="text-4xl font-bold leading-none mb-2"
                style={{ fontFamily: "'Playfair Display', serif", color: C.ink }}>
                {s.value}
              </p>

              {/* label */}
              <p className="text-sm font-semibold mb-1" style={{ color: C.inkMid }}>{s.label}</p>

              {/* sub */}
              <p className="text-xs font-medium" style={{ color: C.inkLight }}>{s.sub}</p>

              {/* bottom accent bar */}
              <div className="mt-5 h-0.5 rounded-full"
                style={{ background: `linear-gradient(to right,${C.gold},transparent)` }} />
            </motion.div>
          );
        })}
      </motion.div>

      {/* ══ QUICK ACTIONS ════════════════════════════════════════════════ */}
      <motion.div variants={fade}>
        <div className="flex items-center gap-3 mb-4 px-1">
          <p className="text-[11px] font-bold tracking-[0.15em] uppercase"
            style={{ color: C.inkLight }}>Quick Actions</p>
          <div className="flex-1 h-px" style={{ background: C.creamBorder }} />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {ACTIONS.map((a) => {
            const Icon = a.icon;
            return (
              <motion.button key={a.label}
                whileHover={{ y: -3, boxShadow: a.gold ? '0 16px 36px rgba(184,134,11,0.22)' : '0 16px 36px rgba(28,20,16,0.18)' }}
                whileTap={{ scale: 0.97 }}
                onClick={() => navigate(a.path)}
                className="relative overflow-hidden rounded-2xl p-5 text-left flex flex-col gap-3 transition-all duration-200"
                style={{
                  background: a.gold
                    ? `linear-gradient(140deg,${C.gold} 0%,${C.goldLight} 100%)`
                    : `linear-gradient(140deg,${C.ink} 0%,#2d2510 100%)`,
                  boxShadow: a.gold
                    ? '0 4px 20px rgba(184,134,11,0.18)'
                    : '0 4px 20px rgba(28,20,16,0.14)',
                }}>

                {/* shimmer circle */}
                <div className="absolute -bottom-4 -right-4 w-20 h-20 rounded-full opacity-10 bg-white" />

                <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ background: 'rgba(255,255,255,0.18)' }}>
                  <Icon size={18} className="text-white" />
                </div>

                <div>
                  <p className="text-sm font-bold text-white leading-tight">{a.label}</p>
                  <p className="text-[11px] mt-0.5" style={{ color: 'rgba(255,255,255,0.60)' }}>{a.sub}</p>
                </div>
              </motion.button>
            );
          })}
        </div>
      </motion.div>

      {/* ══ BOOKINGS TABLE ═══════════════════════════════════════════════ */}
      <motion.div variants={fade}
        className="rounded-2xl overflow-hidden"
        style={{
          background: C.white,
          border: `1px solid ${C.creamBorder}`,
          boxShadow: '0 2px 16px rgba(184,134,11,0.05)',
        }}>

        {/* table head */}
        <div className="flex items-center justify-between px-6 py-5"
          style={{ borderBottom: `1px solid ${C.creamDark}` }}>
          <div>
            <h2 className="text-xl font-bold" style={{ fontFamily: "'Playfair Display', serif", color: C.ink }}>
              Today's Appointments
            </h2>
            <p className="text-xs mt-0.5" style={{ color: C.inkLight }}>
              Live booking feed · updates on refresh
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold px-3 py-1.5 rounded-full"
              style={{ background: C.goldPale, color: C.gold, border: `1px solid ${C.creamBorder}` }}>
              {bookings.length} bookings
            </span>
            <button onClick={() => navigate('/admin/appointments')}
              className="flex items-center gap-1.5 text-xs font-bold px-4 py-2 rounded-full transition-all hover:opacity-90"
              style={{ background: C.ink, color: C.white }}>
              View all <ChevronRight size={13} />
            </button>
          </div>
        </div>

        {/* empty */}
        {bookings.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center"
              style={{ background: C.goldPale, border: `1px solid ${C.creamBorder}` }}>
              <Calendar size={28} style={{ color: C.gold }} />
            </div>
            <div className="text-center">
              <p className="font-bold" style={{ color: C.ink }}>No appointments today</p>
              <p className="text-xs mt-1" style={{ color: C.inkLight }}>Bookings will appear here automatically</p>
            </div>
            <button onClick={() => navigate('/admin/appointments')}
              className="flex items-center gap-2 text-sm font-bold px-6 py-2.5 rounded-full text-white transition-all hover:opacity-90"
              style={{ background: `linear-gradient(135deg,${C.gold},${C.goldLight})` }}>
              <Plus size={14} /> Schedule Appointment
            </button>
          </div>
        ) : (
          <>
            {/* ── desktop ── */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr style={{ background: C.cream }}>
                    {['Client', 'Service', 'Stylist', 'Time', 'Amount', 'Status'].map((h) => (
                      <th key={h}
                        className="text-left px-6 py-3 text-[10px] font-bold tracking-[0.14em] uppercase"
                        style={{ color: C.inkLight }}>
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {bookings.map((b, i) => {
                    const st  = STATUS[b.status] || STATUS.confirmed;
                    const cn  = b.customer?.name || 'Walk-in';
                    const svc = b.service?.name  || '—';
                    const stf = b.staff?.name    || 'Any';
                    const av  = AVATARS[i % AVATARS.length];

                    return (
                      <tr key={b._id}
                        className="transition-colors cursor-pointer"
                        style={{ borderTop: `1px solid ${C.creamDark}` }}
                        onMouseEnter={e => e.currentTarget.style.background = C.cream}
                        onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                        onClick={() => navigate('/admin/appointments')}>

                        {/* client */}
                        <td className="px-6 py-3.5">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                              style={{ background: av }}>
                              {initials(cn)}
                            </div>
                            <span className="text-sm font-semibold" style={{ color: C.ink }}>{cn}</span>
                          </div>
                        </td>

                        {/* service */}
                        <td className="px-6 py-3.5">
                          <span className="text-sm" style={{ color: C.inkMid }}>{svc}</span>
                        </td>

                        {/* stylist */}
                        <td className="px-6 py-3.5">
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold"
                              style={{ background: C.goldPale, color: C.gold }}>
                              {stf[0]}
                            </div>
                            <span className="text-sm" style={{ color: C.inkMid }}>{stf}</span>
                          </div>
                        </td>

                        {/* time */}
                        <td className="px-6 py-3.5">
                          <span className="text-sm font-bold" style={{ color: C.ink }}>
                            {fmtTime(b.timeSlot?.start)}
                          </span>
                        </td>

                        {/* amount */}
                        <td className="px-6 py-3.5">
                          <span className="text-sm font-bold" style={{ color: C.gold }}>
                            ₹{fmt(b.finalAmount)}
                          </span>
                        </td>

                        {/* status — pill badge */}
                        <td className="px-6 py-3.5">
                          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border"
                            style={{ background: st.bg, borderColor: st.border, color: st.text }}>
                            <span className="w-1.5 h-1.5 rounded-full" style={{ background: st.dot }} />
                            {st.label}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* ── mobile ── */}
            <div className="md:hidden divide-y" style={{ borderColor: C.creamDark }}>
              {bookings.map((b, i) => {
                const st  = STATUS[b.status] || STATUS.confirmed;
                const cn  = b.customer?.name || 'Walk-in';
                const svc = b.service?.name  || '—';
                const stf = b.staff?.name    || 'Any';
                const av  = AVATARS[i % AVATARS.length];

                return (
                  <div key={b._id}
                    className="flex items-center justify-between px-5 py-4 cursor-pointer transition-colors"
                    style={{ borderTop: `1px solid ${C.creamDark}` }}
                    onClick={() => navigate('/admin/appointments')}>

                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                        style={{ background: av }}>
                        {initials(cn)}
                      </div>
                      <div>
                        <p className="text-sm font-bold" style={{ color: C.ink }}>{cn}</p>
                        <p className="text-xs" style={{ color: C.inkLight }}>{svc} · {stf}</p>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-1.5">
                      <span className="text-sm font-bold" style={{ color: C.gold }}>₹{fmt(b.finalAmount)}</span>
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-semibold border"
                        style={{ background: st.bg, borderColor: st.border, color: st.text }}>
                        <span className="w-1.5 h-1.5 rounded-full" style={{ background: st.dot }} />
                        {st.label}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {/* footer */}
        {bookings.length > 0 && (
          <div className="flex items-center justify-between px-6 py-4"
            style={{ borderTop: `1px solid ${C.creamDark}` }}>
            <p className="text-xs" style={{ color: C.inkLight }}>
              Showing {bookings.length} of today's appointments
            </p>
            <button onClick={() => navigate('/admin/appointments')}
              className="flex items-center gap-1 text-xs font-bold transition-all hover:gap-2"
              style={{ color: C.gold }}>
              View all appointments <ChevronRight size={13} />
            </button>
          </div>
        )}
      </motion.div>

    </motion.div>
  );
}
