import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Hash, Search, Download, Printer, MessageCircle,
  IndianRupee, Calendar, Filter, X, TrendingUp,
  CheckCircle2, Scissors, User, ChevronDown, ChevronUp,
  Sparkles, RefreshCw, FileText, Eye, Trash2,
} from 'lucide-react';

// ─── tokens ───────────────────────────────────────────────────────────────────
const C = {
  cream:'#FDF8F0', creamDark:'#F5EDD8', creamBorder:'#E8D9B8',
  gold:'#B8860B', goldLight:'#DAA520', goldPale:'#FFF8E7',
  ink:'#1C1410', inkMid:'#5C4A2A', inkLight:'#9C8660', white:'#FFFFFF',
};

const fade   = { hidden:{opacity:0,y:14}, show:{opacity:1,y:0,transition:{duration:0.45,ease:[0.22,0.61,0.36,1]}} };
const stagger= { hidden:{opacity:0}, show:{opacity:1,transition:{staggerChildren:0.05}} };

const fmtDate = d => new Date(d).toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'});
const fmtTime = t => { if(!t) return ''; const [h,m]=t.split(':').map(Number); const p=h>=12?'PM':'AM'; const dh=h>12?h-12:h===0?12:h; return `${dh}:${String(m).padStart(2,'0')} ${p}`; };
const initials= n=>(n||'?').split(' ').slice(0,2).map(w=>w[0]).join('').toUpperCase();
const AVATARS = ['#B8860B','#8B6914','#C9952A','#6B4F12','#DAA520'];

// ─── print single invoice ─────────────────────────────────────────────────────
const printInvoice = (inv) => {
  const win = window.open('','_blank','width=420,height=680');
  win.document.write(`
    <html><head><title>Invoice ${inv.invoiceRef}</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
      *{box-sizing:border-box;margin:0;padding:0}
      body{font-family:'DM Sans',sans-serif;background:#FDF8F0;padding:24px;max-width:400px;margin:auto;color:#1C1410}
      .card{background:#fff;border-radius:20px;overflow:hidden;box-shadow:0 4px 24px rgba(184,134,11,0.12)}
      .hdr{background:linear-gradient(135deg,#1C1410,#2d2510);padding:22px 24px;text-align:center;position:relative}
      .hdr::after{content:'';position:absolute;inset:0;background:repeating-linear-gradient(45deg,#B8860B 0,#B8860B 1px,transparent 0,transparent 50%);background-size:16px 16px;opacity:0.08}
      .logo{font-family:'Playfair Display',serif;font-size:24px;color:#fff;position:relative}
      .logo span{color:#DAA520}
      .sub{font-size:10px;color:#9C8660;letter-spacing:0.15em;text-transform:uppercase;position:relative;margin-top:3px}
      .ref{display:inline-block;margin-top:12px;background:rgba(218,165,32,0.15);border:1px solid rgba(218,165,32,0.3);border-radius:20px;padding:5px 14px;font-size:11px;font-weight:700;color:#DAA520;position:relative}
      .body{padding:20px 22px}
      .sec{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.14em;color:#9C8660;margin:14px 0 8px}
      .grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
      .cell{background:#FDF8F0;border-radius:10px;padding:8px 12px}
      .cl{font-size:10px;color:#9C8660;font-weight:600;text-transform:uppercase}
      .cv{font-size:13px;font-weight:700;color:#1C1410;margin-top:2px}
      .sbox{background:#FFF8E7;border:1px solid #E8D9B8;border-radius:12px;padding:12px 14px;margin-bottom:10px}
      .sname{font-family:'Playfair Display',serif;font-size:15px;font-weight:700}
      .scat{font-size:11px;color:#9C8660;margin-top:2px}
      table{width:100%;border-collapse:collapse;font-size:13px}
      td{padding:7px 0;border-bottom:1px dashed #F5EDD8}
      .tr td{font-weight:800;font-size:15px;border:none;padding-top:10px}
      .av{color:#B8860B}
      .gr{color:#10B981}
      .ftr{background:#FDF8F0;border-top:1px solid #F5EDD8;padding:14px 22px;text-align:center}
      .ftr p{font-size:11px;color:#9C8660;line-height:1.8}
      .ftr strong{color:#B8860B}
      .pbtn{display:block;width:100%;padding:12px;background:linear-gradient(135deg,#B8860B,#DAA520);color:#fff;border:none;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;margin-top:18px}
      @media print{.pbtn{display:none}body{background:#fff;padding:0}.card{box-shadow:none;border-radius:0}}
    </style></head><body>
    <div class="card">
      <div class="hdr">
        <div class="logo">✂ Glamour<span>.</span></div>
        <div class="sub">Premium Salon & Spa</div>
        <div class="ref">🧾 ${inv.invoiceRef}</div>
      </div>
      <div class="body">
        <div class="sec">Customer & Booking</div>
        <div class="grid">
          <div class="cell"><div class="cl">Customer</div><div class="cv">${inv.customerName}</div></div>
          <div class="cell"><div class="cl">Phone</div><div class="cv">${inv.customerPhone?'+91 '+inv.customerPhone.replace(/\D/g,'').slice(-10):'—'}</div></div>
          <div class="cell"><div class="cl">Date</div><div class="cv">${fmtDate(inv.date)}</div></div>
          <div class="cell"><div class="cl">Time</div><div class="cv">${fmtTime(inv.timeSlot?.start)}</div></div>
          <div class="cell"><div class="cl">Stylist</div><div class="cv">${inv.stylist}</div></div>
          <div class="cell"><div class="cl">Payment</div><div class="cv">${(inv.paymentMethod||'cash').toUpperCase()}</div></div>
        </div>
        <div class="sec">Service</div>
        <div class="sbox">
          <div class="sname">${inv.service}</div>
          <div class="scat">${inv.category} · Type: ${inv.type}</div>
        </div>
        <div class="sec">Amount</div>
        <table>
          <tr><td>Original</td><td style="text-align:right">₹${(inv.totalAmount||0).toLocaleString('en-IN')}</td></tr>
          ${inv.discountAmount>0?`<tr><td class="gr">Discount</td><td style="text-align:right" class="gr">−₹${(inv.discountAmount||0).toLocaleString('en-IN')}</td></tr>`:''}
          <tr class="tr"><td>Total Paid</td><td style="text-align:right" class="av">₹${(inv.finalAmount||0).toLocaleString('en-IN')}</td></tr>
        </table>
        ${inv.notes?`<div style="margin-top:12px;padding:10px;background:#FDF8F0;border-radius:10px;font-size:12px;color:#5C4A2A;font-style:italic">📝 ${inv.notes}</div>`:''}
      </div>
      <div class="ftr">
        <p>Thank you for choosing <strong>Glamour Salon</strong> 💛</p>
        <p>Ref: <strong>${inv.invoiceRef}</strong> · ${fmtDate(inv.completedAt||inv.date)}</p>
      </div>
    </div>
    <button class="pbtn" onclick="window.print()">🖨 &nbsp;Print Invoice</button>
    </body></html>
  `);
  win.document.close();
};

// ─── whatsapp resend ──────────────────────────────────────────────────────────
const resendWhatsApp = (inv) => {
  const phone = (inv.customerPhone||'').replace(/\D/g,'').slice(-10);
  if (!phone||phone.length<10) { alert('No valid phone number for this invoice.'); return; }
  const msg = [
    `✂ *Glamour Salon — Invoice Copy*`,``,
    `Hi *${inv.customerName}*! Here is your invoice copy. 💛`,``,
    `🧾 *Invoice Ref:* \`${inv.invoiceRef}\``,
    `📅 *Date:* ${fmtDate(inv.date)}`,
    `💆 *Service:* ${inv.service}`,
    `👩‍🎨 *Stylist:* ${inv.stylist}`,
    inv.discountAmount>0?`🏷 *Discount:* −₹${(inv.discountAmount||0).toLocaleString('en-IN')}`:'',
    `💰 *Total Paid:* ₹${(inv.finalAmount||0).toLocaleString('en-IN')} _(${(inv.paymentMethod||'cash').toUpperCase()})_`,``,
    `_Thank you for visiting Glamour Salon!_ ✨`,
  ].filter(l=>l!==undefined).join('%0A');
  window.open(`https://wa.me/91${phone}?text=${msg}`,'_blank');
};

// ─── export all invoices as CSV ───────────────────────────────────────────────
const exportAllCSV = (invoices) => {
  const headers = ['S.No','Invoice Ref','Customer','Phone','Service','Category','Stylist','Date','Original (Rs)','Discount (Rs)','Final (Rs)','Payment','Type','Notes','Completed At'];
  const rows = invoices.map((inv,i) => [
    i+1, inv.invoiceRef,
    `"${inv.customerName}"`,
    inv.customerPhone?`+91${(inv.customerPhone||'').replace(/\D/g,'').slice(-10)}`:'—',
    `"${inv.service}"`, inv.category||'—', `"${inv.stylist}"`,
    fmtDate(inv.date),
    inv.totalAmount||0, inv.discountAmount||0, inv.finalAmount||0,
    (inv.paymentMethod||'cash').toUpperCase(), inv.type||'online',
    `"${inv.notes||''}"`,
    inv.completedAt ? new Date(inv.completedAt).toLocaleString('en-IN') : '—',
  ]);
  const totalRev  = invoices.reduce((s,i)=>s+(i.finalAmount||0),0);
  const totalDisc = invoices.reduce((s,i)=>s+(i.discountAmount||0),0);
  const totals = ['','','TOTAL','','','','','','',totalDisc,totalRev,'','','',''];
  const meta = [
    ['GLAMOUR SALON — INVOICE HISTORY'],
    [`Exported: ${new Date().toLocaleString('en-IN')}`],
    [`Total Invoices: ${invoices.length}`],
    [],
  ];
  const csv  = [...meta,headers,...rows,[],totals].map(r=>Array.isArray(r)?r.join(','):'').join('\n');
  const blob = new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8;'});
  const a    = document.createElement('a');
  a.href     = URL.createObjectURL(blob);
  a.download = `Glamour-Invoices-${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
};

// ═════════════════════════════════════════════════════════════════════════════
export default function AdminInvoices() {
  const [invoices,    setInvoices]    = useState([]);
  const [search,      setSearch]      = useState('');
  const [typeFilter,  setTypeFilter]  = useState('');
  const [methodFilter,setMethodFilter]= useState('');
  const [dateFrom,    setDateFrom]    = useState('');
  const [dateTo,      setDateTo]      = useState('');
  const [expanded,    setExpanded]    = useState(null);
  const [showFilters, setShowFilters] = useState(false);

  // load from localStorage
  const loadInvoices = () => {
    try {
      const data = JSON.parse(localStorage.getItem('glamour_invoices')||'[]');
      setInvoices(data);
    } catch(e) { setInvoices([]); }
  };

  useEffect(() => { loadInvoices(); }, []);

  const deleteInvoice = (ref) => {
    if (!confirm(`Delete invoice ${ref}? This cannot be undone.`)) return;
    const updated = invoices.filter(i => i.invoiceRef !== ref);
    localStorage.setItem('glamour_invoices', JSON.stringify(updated));
    setInvoices(updated);
  };

  const clearAll = () => {
    if (!confirm('Clear ALL invoice history? This cannot be undone.')) return;
    localStorage.removeItem('glamour_invoices');
    setInvoices([]);
  };

  // ── filters ────────────────────────────────────────────────────────────
  const filtered = useMemo(() => invoices.filter(inv => {
    const q = search.toLowerCase();
    const matchQ = !q || inv.customerName?.toLowerCase().includes(q) ||
      inv.invoiceRef?.toLowerCase().includes(q) || inv.service?.toLowerCase().includes(q);
    const matchType   = !typeFilter   || inv.type   === typeFilter;
    const matchMethod = !methodFilter || inv.paymentMethod === methodFilter;
    const d = new Date(inv.date);
    const matchFrom = !dateFrom || d >= new Date(dateFrom);
    const matchTo   = !dateTo   || d <= new Date(dateTo);
    return matchQ && matchType && matchMethod && matchFrom && matchTo;
  }), [invoices, search, typeFilter, methodFilter, dateFrom, dateTo]);

  // ── stats ──────────────────────────────────────────────────────────────
  const totalRevenue  = filtered.reduce((s,i)=>s+(i.finalAmount||0),0);
  const totalDiscount = filtered.reduce((s,i)=>s+(i.discountAmount||0),0);
  const avgTicket     = filtered.length ? Math.round(totalRevenue/filtered.length) : 0;
  const onlineCount   = filtered.filter(i=>i.type==='online').length;
  const walkInCount   = filtered.filter(i=>i.type==='walk-in').length;

  const inp = (extra={}) => ({
    padding:'9px 13px', borderRadius:12, border:`1px solid ${C.creamBorder}`,
    background:C.cream, fontSize:13, color:C.ink, outline:'none',
    fontFamily:"'DM Sans',sans-serif", ...extra,
  });

  return (
    <motion.div variants={stagger} initial="hidden" animate="show"
      className="min-h-screen pb-12 space-y-6"
      style={{ background:C.cream, fontFamily:"'DM Sans',sans-serif" }}>

      {/* ══ HEADER ══════════════════════════════════════════════════════ */}
      <motion.div variants={fade}
        className="relative overflow-hidden rounded-2xl px-7 py-6"
        style={{ background:`linear-gradient(135deg,${C.ink},#2d2510)`, border:`1px solid #3d3010` }}>
        <div className="absolute inset-0 opacity-10"
          style={{ backgroundImage:'repeating-linear-gradient(45deg,#B8860B 0,#B8860B 1px,transparent 0,transparent 50%)', backgroundSize:'18px 18px' }} />
        <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full opacity-10"
          style={{ background:`radial-gradient(circle,${C.goldLight},transparent)` }} />
        <div className="relative flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Sparkles size={13} style={{ color:C.goldLight }} />
              <span className="text-[11px] font-bold tracking-[0.18em] uppercase" style={{ color:C.goldLight }}>
                Invoice History
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-white"
              style={{ fontFamily:"'Playfair Display',serif" }}>All Invoices</h1>
            <p className="text-sm mt-1" style={{ color:'#9ca3af' }}>
              {filtered.length} invoice{filtered.length!==1?'s':''} · ₹{totalRevenue.toLocaleString('en-IN')} total revenue
            </p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button onClick={loadInvoices}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold hover:opacity-80"
              style={{ background:'rgba(255,255,255,0.1)', color:'#fff', border:'1px solid rgba(255,255,255,0.15)' }}>
              <RefreshCw size={13} /> Refresh
            </button>
            <button onClick={() => exportAllCSV(filtered)}
              disabled={filtered.length===0}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold hover:opacity-80 disabled:opacity-40"
              style={{ background:'rgba(255,255,255,0.1)', color:'#fff', border:'1px solid rgba(255,255,255,0.15)' }}>
              <Download size={13} /> Export CSV
            </button>
            <button onClick={clearAll} disabled={invoices.length===0}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold hover:opacity-80 disabled:opacity-40"
              style={{ background:'rgba(239,68,68,0.15)', color:'#FCA5A5', border:'1px solid rgba(239,68,68,0.3)' }}>
              <Trash2 size={13} /> Clear All
            </button>
          </div>
        </div>
      </motion.div>

      {/* ══ STAT CARDS ══════════════════════════════════════════════════ */}
      <motion.div variants={fade} className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {[
          { label:'Total Invoices', value:filtered.length,                                     icon:FileText,    accent:C.gold    },
          { label:'Revenue',        value:`₹${totalRevenue.toLocaleString('en-IN')}`,           icon:IndianRupee, accent:C.gold    },
          { label:'Avg Ticket',     value:`₹${avgTicket.toLocaleString('en-IN')}`,              icon:TrendingUp,  accent:'#10B981' },
          { label:'Online',         value:onlineCount,                                          icon:CheckCircle2,accent:'#3B82F6' },
          { label:'Walk-in',        value:walkInCount,                                          icon:User,        accent:'#F59E0B' },
        ].map(s => {
          const Icon = s.icon;
          return (
            <motion.div key={s.label} whileHover={{ y:-3 }}
              className="rounded-2xl p-4 text-center transition-all"
              style={{ background:C.white, border:`1px solid ${C.creamBorder}`, boxShadow:'0 2px 12px rgba(184,134,11,0.05)' }}>
              <div className="w-8 h-8 rounded-xl mx-auto mb-2 flex items-center justify-center"
                style={{ background:`${s.accent}18` }}>
                <Icon size={15} style={{ color:s.accent }} />
              </div>
              <p className="text-xl font-bold" style={{ fontFamily:"'Playfair Display',serif", color:C.ink }}>{s.value}</p>
              <p className="text-[10px] font-semibold uppercase tracking-wide" style={{ color:C.inkLight }}>{s.label}</p>
            </motion.div>
          );
        })}
      </motion.div>

      {/* ══ SEARCH + FILTERS ════════════════════════════════════════════ */}
      <motion.div variants={fade} className="rounded-2xl p-4 space-y-3"
        style={{ background:C.white, border:`1px solid ${C.creamBorder}` }}>
        <div className="flex flex-wrap items-center gap-3">
          {/* search */}
          <div className="relative flex-1 min-w-[220px]">
            <Search size={13} style={{ color:C.inkLight, position:'absolute', left:12, top:'50%', transform:'translateY(-50%)' }} />
            <input style={{ ...inp(), paddingLeft:34, width:'100%' }}
              placeholder="Search invoice ref, customer, service…"
              value={search} onChange={e=>setSearch(e.target.value)}
              onFocus={e=>e.target.style.borderColor=C.gold}
              onBlur={e=>e.target.style.borderColor=C.creamBorder} />
          </div>
          {/* type pills */}
          <div className="flex gap-2">
            {[['','All'],['online','Online'],['walk-in','Walk-in']].map(([v,l])=>(
              <button key={v} onClick={()=>setTypeFilter(v)}
                className="px-3.5 py-2 rounded-full text-xs font-semibold transition-all"
                style={{
                  background: typeFilter===v ? `linear-gradient(135deg,${C.gold},${C.goldLight})` : C.cream,
                  color: typeFilter===v ? '#fff' : C.inkMid,
                  border:`1px solid ${typeFilter===v ? C.gold : C.creamBorder}`,
                }}>{l}</button>
            ))}
          </div>
          {/* method pills */}
          <div className="flex gap-2">
            {[['','Any'],['cash','Cash'],['upi','UPI'],['card','Card']].map(([v,l])=>(
              <button key={v} onClick={()=>setMethodFilter(v)}
                className="px-3.5 py-2 rounded-full text-xs font-semibold transition-all"
                style={{
                  background: methodFilter===v ? C.ink : C.cream,
                  color: methodFilter===v ? '#fff' : C.inkMid,
                  border:`1px solid ${methodFilter===v ? C.ink : C.creamBorder}`,
                }}>{l}</button>
            ))}
          </div>
          {/* date range toggle */}
          <button onClick={()=>setShowFilters(!showFilters)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-full text-xs font-semibold transition-all"
            style={{ background:showFilters?C.ink:C.cream, color:showFilters?'#fff':C.inkMid, border:`1px solid ${showFilters?C.ink:C.creamBorder}` }}>
            <Filter size={12} /> Date Range
          </button>
        </div>

        {/* date range inputs */}
        <AnimatePresence>
          {showFilters && (
            <motion.div initial={{opacity:0,height:0}} animate={{opacity:1,height:'auto'}} exit={{opacity:0,height:0}}
              className="flex items-center gap-3 overflow-hidden flex-wrap">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold" style={{ color:C.inkLight }}>From</span>
                <input type="date" style={{ ...inp(), width:'auto', cursor:'pointer' }}
                  value={dateFrom} onChange={e=>setDateFrom(e.target.value)}
                  onFocus={e=>e.target.style.borderColor=C.gold}
                  onBlur={e=>e.target.style.borderColor=C.creamBorder} />
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold" style={{ color:C.inkLight }}>To</span>
                <input type="date" style={{ ...inp(), width:'auto', cursor:'pointer' }}
                  value={dateTo} onChange={e=>setDateTo(e.target.value)}
                  onFocus={e=>e.target.style.borderColor=C.gold}
                  onBlur={e=>e.target.style.borderColor=C.creamBorder} />
              </div>
              {(dateFrom||dateTo) && (
                <button onClick={()=>{ setDateFrom(''); setDateTo(''); }}
                  className="flex items-center gap-1 text-xs font-semibold px-3 py-2 rounded-full"
                  style={{ background:'#FEF2F2', color:'#991B1B', border:'1px solid #FECACA' }}>
                  <X size={11}/> Clear dates
                </button>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* active chips */}
        {(search||typeFilter||methodFilter||dateFrom||dateTo) && (
          <div className="flex items-center gap-2 pt-2 flex-wrap" style={{ borderTop:`1px solid ${C.creamDark}` }}>
            <span className="text-[11px] font-semibold" style={{ color:C.inkLight }}>Active:</span>
            {[
              search      && [search,      ()=>setSearch('')],
              typeFilter  && [typeFilter,  ()=>setTypeFilter('')],
              methodFilter&& [methodFilter,()=>setMethodFilter('')],
              dateFrom    && [`From ${dateFrom}`,()=>setDateFrom('')],
              dateTo      && [`To ${dateTo}`,  ()=>setDateTo('')],
            ].filter(Boolean).map(([v,clear],i) => (
              <span key={i} onClick={clear}
                className="flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold cursor-pointer"
                style={{ background:C.goldPale, color:C.gold, border:`1px solid ${C.creamBorder}` }}>
                {v} <X size={9}/>
              </span>
            ))}
          </div>
        )}
      </motion.div>

      {/* ══ INVOICE LIST ════════════════════════════════════════════════ */}
      {invoices.length === 0 ? (
        <motion.div variants={fade}
          className="flex flex-col items-center justify-center py-24 rounded-2xl gap-4"
          style={{ background:C.white, border:`2px dashed ${C.creamBorder}` }}>
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center"
            style={{ background:C.goldPale, border:`1px solid ${C.creamBorder}` }}>
            <FileText size={28} style={{ color:C.gold }} />
          </div>
          <div className="text-center">
            <p className="font-bold text-lg" style={{ fontFamily:"'Playfair Display',serif", color:C.ink }}>
              No invoices yet
            </p>
            <p className="text-sm mt-1" style={{ color:C.inkLight }}>
              Invoices are saved here automatically when you complete bookings
            </p>
          </div>
        </motion.div>
      ) : filtered.length === 0 ? (
        <motion.div variants={fade}
          className="flex flex-col items-center justify-center py-20 rounded-2xl gap-3"
          style={{ background:C.white, border:`1px solid ${C.creamBorder}` }}>
          <Search size={28} style={{ color:C.creamBorder }} />
          <p className="font-semibold" style={{ color:C.inkLight }}>No invoices match your filters</p>
          <button onClick={()=>{ setSearch(''); setTypeFilter(''); setMethodFilter(''); setDateFrom(''); setDateTo(''); }}
            className="px-5 py-2 rounded-full text-xs font-bold"
            style={{ background:C.ink, color:'#fff' }}>
            Clear all filters
          </button>
        </motion.div>
      ) : (
        <motion.div variants={stagger} className="space-y-3">
          {filtered.map((inv, i) => {
            const isOpen = expanded === inv.invoiceRef;
            const av = AVATARS[i % AVATARS.length];
            return (
              <motion.div key={inv.invoiceRef} variants={fade}
                className="rounded-2xl overflow-hidden transition-all"
                style={{ background:C.white, border:`1px solid ${C.creamBorder}`, boxShadow:'0 2px 10px rgba(184,134,11,0.04)' }}>

                {/* row */}
                <div className="flex items-center gap-4 px-5 py-4 cursor-pointer"
                  onClick={()=>setExpanded(isOpen ? null : inv.invoiceRef)}
                  onMouseEnter={e=>e.currentTarget.style.background=C.cream}
                  onMouseLeave={e=>e.currentTarget.style.background='transparent'}>

                  {/* avatar */}
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                    style={{ background:`linear-gradient(135deg,${av},${av}cc)` }}>
                    {initials(inv.customerName)}
                  </div>

                  {/* main */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm font-bold" style={{ color:C.ink }}>{inv.customerName}</p>
                      <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full"
                        style={{ background:C.goldPale, color:C.gold, border:`1px solid ${C.creamBorder}` }}>
                        <Hash size={8}/>{inv.invoiceRef}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full capitalize"
                        style={{
                          background: inv.type==='walk-in' ? '#F5F3FF' : '#EFF6FF',
                          color:      inv.type==='walk-in' ? '#4C1D95'  : '#1E40AF',
                          border:     `1px solid ${inv.type==='walk-in'?'#DDD6FE':'#BFDBFE'}`,
                        }}>
                        {inv.type}
                      </span>
                    </div>
                    <p className="text-xs mt-0.5 truncate" style={{ color:C.inkLight }}>
                      {inv.service} · {inv.stylist} · {fmtDate(inv.date)}
                    </p>
                  </div>

                  {/* amount */}
                  <div className="text-right flex-shrink-0 hidden sm:block">
                    <p className="text-base font-bold" style={{ fontFamily:"'Playfair Display',serif", color:C.gold }}>
                      ₹{(inv.finalAmount||0).toLocaleString('en-IN')}
                    </p>
                    <p className="text-[10px] font-semibold uppercase" style={{ color:C.inkLight }}>
                      {(inv.paymentMethod||'cash').toUpperCase()}
                    </p>
                  </div>

                  {/* actions */}
                  <div className="flex items-center gap-2 flex-shrink-0" onClick={e=>e.stopPropagation()}>
                    <button onClick={()=>printInvoice(inv)}
                      className="w-8 h-8 flex items-center justify-center rounded-xl transition-all hover:opacity-80"
                      style={{ background:C.goldPale, border:`1px solid ${C.creamBorder}` }}
                      title="Print Invoice">
                      <Printer size={13} style={{ color:C.gold }}/>
                    </button>
                    {inv.customerPhone && (
                      <button onClick={()=>resendWhatsApp(inv)}
                        className="w-8 h-8 flex items-center justify-center rounded-xl transition-all hover:opacity-80"
                        style={{ background:'#DCFCE7', border:'1px solid #A7F3D0' }}
                        title="Resend WhatsApp">
                        <MessageCircle size={13} style={{ color:'#16A34A' }}/>
                      </button>
                    )}
                    <button onClick={()=>deleteInvoice(inv.invoiceRef)}
                      className="w-8 h-8 flex items-center justify-center rounded-xl transition-all hover:opacity-80"
                      style={{ background:'#FEF2F2', border:'1px solid #FECACA' }}
                      title="Delete Invoice">
                      <Trash2 size={13} className="text-red-400"/>
                    </button>
                    <div className="w-6 h-6 flex items-center justify-center rounded-lg"
                      style={{ color:C.inkLight }}>
                      {isOpen ? <ChevronUp size={14}/> : <ChevronDown size={14}/>}
                    </div>
                  </div>
                </div>

                {/* expanded detail */}
                <AnimatePresence>
                  {isOpen && (
                    <motion.div initial={{opacity:0,height:0}} animate={{opacity:1,height:'auto'}} exit={{opacity:0,height:0}}
                      className="overflow-hidden">
                      <div className="px-5 pb-5 pt-1 grid grid-cols-2 sm:grid-cols-4 gap-3"
                        style={{ borderTop:`1px solid ${C.creamDark}` }}>
                        {[
                          { label:'Invoice Ref',  value:inv.invoiceRef },
                          { label:'Date',         value:fmtDate(inv.date) },
                          { label:'Time',         value:fmtTime(inv.timeSlot?.start)||'—' },
                          { label:'Phone',        value:inv.customerPhone?`+91 ${(inv.customerPhone||'').replace(/\D/g,'').slice(-10)}`:'—' },
                          { label:'Service',      value:inv.service },
                          { label:'Category',     value:inv.category||'—' },
                          { label:'Original',     value:`₹${(inv.totalAmount||0).toLocaleString('en-IN')}` },
                          { label:'Discount',     value:inv.discountAmount>0?`−₹${(inv.discountAmount||0).toLocaleString('en-IN')}`:'None', green:inv.discountAmount>0 },
                        ].map(item=>(
                          <div key={item.label} className="rounded-xl px-3 py-2.5"
                            style={{ background:C.cream, border:`1px solid ${C.creamBorder}` }}>
                            <p className="text-[10px] font-bold uppercase tracking-wide" style={{ color:C.inkLight }}>{item.label}</p>
                            <p className="text-xs font-bold mt-0.5 truncate"
                              style={{ color: item.green ? '#10B981' : C.ink }}>{item.value}</p>
                          </div>
                        ))}
                        {inv.notes && (
                          <div className="sm:col-span-4 rounded-xl px-3 py-2.5"
                            style={{ background:C.cream, border:`1px solid ${C.creamBorder}` }}>
                            <p className="text-[10px] font-bold uppercase tracking-wide mb-1" style={{ color:C.inkLight }}>Notes</p>
                            <p className="text-xs italic" style={{ color:C.inkMid }}>{inv.notes}</p>
                          </div>
                        )}
                        {/* completed at */}
                        {inv.completedAt && (
                          <div className="sm:col-span-4 text-right">
                            <p className="text-[11px]" style={{ color:C.inkLight }}>
                              Completed: {new Date(inv.completedAt).toLocaleString('en-IN')}
                            </p>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </motion.div>
      )}

      {/* footer count */}
      {filtered.length > 0 && (
        <motion.p variants={fade} className="text-center text-xs font-medium" style={{ color:C.inkLight }}>
          Showing {filtered.length} of {invoices.length} invoices
          {totalDiscount > 0 && ` · ₹${totalDiscount.toLocaleString('en-IN')} total discounts given`}
        </motion.p>
      )}
    </motion.div>
  );
}