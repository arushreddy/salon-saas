import axios from 'axios';

// Changed to explicit backend URL
const BASE_URL = 'http://localhost:5000/api';

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
  withCredentials: true // Required for cookies/auth
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('glamour_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('glamour_token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;