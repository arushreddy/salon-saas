import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Loader2, Calendar, Plus, UserPlus, Sparkles, Ticket,
  Check, Percent, RefreshCw, Search, X,
  TrendingUp, IndianRupee, CheckCircle2, XCircle, Clock,
  Download, ChevronRight, Trash2, User, Phone,
  Printer, MessageCircle, Star, Gift, Scissors,
  ChevronDown, FileText,
} from 'lucide-react';
import api from '@/services/api';
import BookingCard from '@/components/BookingCard';

// ─── tokens ───────────────────────────────────────────────────────────────────
const C = {
  cream: '#FDF8F0', creamDark: '#F5EDD8', creamBorder: '#E8D9B8',
  gold: '#B8860B', goldLight: '#DAA520', goldPale: '#FFF8E7',
  ink: '#1C1410', inkMid: '#5C4A2A', inkLight: '#9C8660', white: '#FFFFFF',
};

const inp = (extra = {}) => ({
  padding: '10px 14px', borderRadius: 12, border: `1px solid ${C.creamBorder}`,
  background: C.cream, fontSize: 13, color: C.ink, outline: 'none',
  width: '100%', fontFamily: "'DM Sans', sans-serif", ...extra,
});

const fade = {
  hidden: { opacity: 0, y: 14 },
  show: { opacity: 1, y: 0, transition: { duration: 0.45, ease: [0.22, 0.61, 0.36, 1] } },
};
const stagger = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.06 } } };

// ─── receipt printer ──────────────────────────────────────────────────────────
// ─── invoice ref generator ────────────────────────────────────────────────────
const generateInvoiceRef = () => {
  const now   = new Date();
  const yy    = String(now.getFullYear()).slice(2);
  const mm    = String(now.getMonth() + 1).padStart(2, '0');
  const dd    = String(now.getDate()).padStart(2, '0');
  const rand  = Math.floor(1000 + Math.random() * 9000);
  return `GLM-${yy}${mm}${dd}-${rand}`;
};

// ─── normalize phone → always +91XXXXXXXXXX ──────────────────────────────────
const normalizePhone = (raw = '') => {
  const digits = raw.replace(/\D/g, '');
  if (digits.startsWith('91') && digits.length === 12) return digits;
  if (digits.length === 10) return '91' + digits;
  return digits;
};

const printReceipt = (data) => {
  const win  = window.open('', '_blank', 'width=420,height=700');
  const lines = data.services.map(s =>
    `<tr><td>${s.name}</td><td style="text-align:right">₹${s.price.toLocaleString('en-IN')}</td></tr>`
  ).join('');
  const dateStr = new Date().toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' });
  const timeStr = new Date().toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit' });

  win.document.write(`
    <html><head><title>Invoice ${data.invoiceRef} — Glamour Salon</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
      *{box-sizing:border-box;margin:0;padding:0}
      body{font-family:'DM Sans',sans-serif;background:#FDF8F0;padding:28px;max-width:400px;margin:auto;color:#1C1410}
      .card{background:#fff;border-radius:20px;overflow:hidden;box-shadow:0 4px 24px rgba(184,134,11,0.10)}
      .header{background:linear-gradient(135deg,#1C1410,#2d2510);padding:24px;text-align:center;position:relative}
      .header::after{content:'';position:absolute;inset:0;background:repeating-linear-gradient(45deg,#B8860B 0,#B8860B 1px,transparent 0,transparent 50%);background-size:16px 16px;opacity:0.08}
      .logo{font-family:'Playfair Display',serif;font-size:26px;color:#fff;position:relative}
      .logo span{color:#DAA520}
      .tagline{font-size:11px;color:#9C8660;margin-top:4px;position:relative;letter-spacing:0.12em;text-transform:uppercase}
      .inv-ref{display:inline-block;margin-top:14px;background:rgba(218,165,32,0.15);border:1px solid rgba(218,165,32,0.3);border-radius:20px;padding:5px 16px;font-size:12px;font-weight:700;color:#DAA520;letter-spacing:0.08em;position:relative}
      .body{padding:20px}
      .section-title{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.14em;color:#9C8660;margin-bottom:10px;margin-top:18px}
      .meta-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
      .meta-item{background:#FDF8F0;border-radius:10px;padding:8px 12px}
      .meta-label{font-size:10px;color:#9C8660;font-weight:600;text-transform:uppercase;letter-spacing:0.1em}
      .meta-value{font-size:13px;font-weight:700;color:#1C1410;margin-top:2px}
      table{width:100%;border-collapse:collapse;font-size:13px;margin-top:8px}
      th{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;color:#9C8660;padding:0 0 8px;border-bottom:1px solid #E8D9B8}
      td{padding:8px 0;border-bottom:1px dashed #F5EDD8;color:#1C1410}
      .amount-col{text-align:right}
      .discount{color:#10B981}
      .total-row td{font-weight:800;font-size:16px;border-bottom:none;padding-top:12px;color:#1C1410}
      .total-row .amount-col{color:#B8860B}
      .loyalty{background:linear-gradient(135deg,#FFF8E7,#FDF0D0);border:1px solid #E8D9B8;border-radius:12px;padding:10px 14px;margin-top:16px;display:flex;align-items:center;gap:10px}
      .loyalty-icon{font-size:20px}
      .loyalty-text{font-size:11px;color:#5C4A2A;font-weight:600;line-height:1.5}
      .loyalty-pts{font-size:15px;font-weight:800;color:#B8860B}
      .footer{text-align:center;padding:16px 20px;background:#FDF8F0;border-top:1px solid #F5EDD8}
      .footer p{font-size:11px;color:#9C8660;line-height:1.8}
      .footer strong{color:#B8860B}
      .print-btn{display:block;width:100%;padding:12px;background:linear-gradient(135deg,#B8860B,#DAA520);color:#fff;border:none;border-radius:10px;font-size:13px;cursor:pointer;font-weight:700;margin-top:20px;letter-spacing:0.05em}
      @media print{.print-btn{display:none}body{background:#fff;padding:0}.card{box-shadow:none;border-radius:0}}
    </style></head>
    <body>
    <div class="card">
      <div class="header">
        <div class="logo">✂ Glamour<span>.</span></div>
        <div class="tagline">Premium Salon & Spa</div>
        <div class="inv-ref">INVOICE · ${data.invoiceRef}</div>
      </div>
      <div class="body">
        <div class="section-title">Bill Details</div>
        <div class="meta-grid">
          <div class="meta-item">
            <div class="meta-label">Customer</div>
            <div class="meta-value">${data.customerName || 'Walk-in'}</div>
          </div>
          <div class="meta-item">
            <div class="meta-label">Phone</div>
            <div class="meta-value">${data.customerPhone ? '+91 ' + normalizePhone(data.customerPhone).slice(2) : '—'}</div>
          </div>
          <div class="meta-item">
            <div class="meta-label">Stylist</div>
            <div class="meta-value">${data.staffName || 'Any'}</div>
          </div>
          <div class="meta-item">
            <div class="meta-label">Payment</div>
            <div class="meta-value">${(data.paymentMethod||'cash').toUpperCase()}</div>
          </div>
          <div class="meta-item">
            <div class="meta-label">Date</div>
            <div class="meta-value">${dateStr}</div>
          </div>
          <div class="meta-item">
            <div class="meta-label">Time</div>
            <div class="meta-value">${timeStr}</div>
          </div>
        </div>

        <div class="section-title">Services</div>
        <table>
          <tr><th>Description</th><th class="amount-col">Amount</th></tr>
          ${lines}
          ${data.couponDiscount ? `<tr><td class="discount">Coupon (${data.couponCode})</td><td class="amount-col discount">−₹${data.couponDiscount.toLocaleString('en-IN')}</td></tr>` : ''}
          ${data.manualDiscount ? `<tr><td class="discount">Special Discount</td><td class="amount-col discount">−₹${data.manualDiscount.toLocaleString('en-IN')}</td></tr>` : ''}
          <tr class="total-row"><td>Total Paid</td><td class="amount-col">₹${data.finalAmount.toLocaleString('en-IN')}</td></tr>
        </table>

        ${data.loyaltyPoints ? `
        <div class="loyalty">
          <div class="loyalty-icon">⭐</div>
          <div><div class="loyalty-pts">+${data.loyaltyPoints} Points Earned</div>
          <div class="loyalty-text">Added to your loyalty wallet on this visit</div></div>
        </div>` : ''}
      </div>

      <div class="footer">
        <p>Thank you for choosing <strong>Glamour Salon</strong> 💛</p>
        <p>Ref: <strong>${data.invoiceRef}</strong> · ${dateStr} ${timeStr}</p>
        <p style="margin-top:6px;font-size:10px">Keep this receipt for your records</p>
      </div>
    </div>
    <button class="print-btn" onclick="window.print()">🖨&nbsp; Print Invoice</button>
    </body></html>
  `);
  win.document.close();
};

const whatsappReceipt = (data) => {
  if (!data.customerPhone) { alert('Please add a phone number to send via WhatsApp.'); return; }
  const phone = normalizePhone(data.customerPhone);
  if (phone.length < 12) { alert('Invalid phone number. Please enter a valid 10-digit number.'); return; }
  const svcs  = data.services.map(s => `  • ${s.name}: ₹${s.price.toLocaleString('en-IN')}`).join('%0A');
  const disc  = [
    data.couponDiscount  ? `  🏷 Coupon (${data.couponCode}): −₹${data.couponDiscount.toLocaleString('en-IN')}` : '',
    data.manualDiscount  ? `  🎁 Special Discount: −₹${data.manualDiscount.toLocaleString('en-IN')}` : '',
  ].filter(Boolean).join('%0A');
  const msg = [
    `✂ *Glamour Salon — Invoice*`,
    ``,
    `Hi *${data.customerName || 'there'}*, thank you for your visit! 💛`,
    ``,
    `📋 *Invoice Ref:* \`${data.invoiceRef}\``,
    `📅 *Date:* ${new Date().toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'})}`,
    `💆 *Stylist:* ${data.staffName || 'Any'}`,
    ``,
    `*Services:*`,
    svcs,
    disc ? `%0A*Discounts:*%0A${disc}` : '',
    ``,
    `💰 *Total Paid:* ₹${data.finalAmount.toLocaleString('en-IN')} _(${(data.paymentMethod||'cash').toUpperCase()})_`,
    data.loyaltyPoints ? `⭐ *Loyalty Points Earned:* +${data.loyaltyPoints} pts` : '',
    ``,
    `_Visit us again soon at Glamour Salon!_ ✨`,
  ].filter(v => v !== undefined).join('%0A');

  window.open(`https://wa.me/${phone}?text=${msg}`, '_blank');
};

// ─── generate PDF blob ───────────────────────────────────────────────────────
const generateReceiptPdfBlob = (data) => {
  return new Promise((resolve) => {
    const loadScript = (src) => new Promise((res, rej) => {
      if (document.querySelector(`script[src="${src}"]`)) { res(); return; }
      const s = document.createElement('script');
      s.src = src; s.onload = res; s.onerror = rej;
      document.head.appendChild(s);
    });
    Promise.all([
      loadScript('https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js'),
      loadScript('https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js'),
    ]).then(() => {
      const dateStr = new Date().toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' });
      const timeStr = new Date().toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit' });
      const lines   = data.services.map(s =>
        `<tr><td style="padding:8px 0;border-bottom:1px dashed #F5EDD8;font-size:13px;color:#1C1410">${s.name}</td><td style="padding:8px 0;border-bottom:1px dashed #F5EDD8;font-size:13px;color:#1C1410;text-align:right">₹${s.price.toLocaleString('en-IN')}</td></tr>`
      ).join('');
      const metaItems = [
        ['Customer', data.customerName || 'Walk-in'],
        ['Phone',    data.customerPhone ? '+91 ' + normalizePhone(data.customerPhone).slice(2) : '—'],
        ['Stylist',  data.staffName || 'Any'],
        ['Payment',  (data.paymentMethod||'cash').toUpperCase()],
        ['Date',     dateStr],
        ['Time',     timeStr],
      ].map(([l,v]) => `<div style="background:#FDF8F0;border-radius:8px;padding:8px 10px"><div style="font-size:9px;color:#9C8660;font-weight:600;text-transform:uppercase">${l}</div><div style="font-size:13px;font-weight:700;color:#1C1410;margin-top:2px">${v}</div></div>`).join('');

      const html = `<div style="font-family:Arial,sans-serif;width:380px;background:#fff">
        <div style="background:linear-gradient(135deg,#1C1410,#2d2510);padding:24px;text-align:center">
          <div style="font-size:22px;color:#fff;font-weight:bold">✂ Glamour Salon</div>
          <div style="font-size:10px;color:#9C8660;margin-top:4px;letter-spacing:.1em;text-transform:uppercase">Premium Salon &amp; Spa</div>
          <div style="display:inline-block;margin-top:12px;background:rgba(218,165,32,.15);border:1px solid rgba(218,165,32,.3);border-radius:20px;padding:4px 14px;font-size:11px;font-weight:700;color:#DAA520">${data.invoiceRef}</div>
        </div>
        <div style="padding:20px;background:#fff">
          <div style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.12em;color:#9C8660;margin-bottom:10px">Bill Details</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:16px">${metaItems}</div>
          <div style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.12em;color:#9C8660;margin-bottom:8px">Services</div>
          <table style="width:100%;border-collapse:collapse">
            <tr><th style="font-size:9px;font-weight:700;text-transform:uppercase;color:#9C8660;padding:0 0 8px;border-bottom:1px solid #E8D9B8;text-align:left">Description</th><th style="font-size:9px;font-weight:700;text-transform:uppercase;color:#9C8660;padding:0 0 8px;border-bottom:1px solid #E8D9B8;text-align:right">Amount</th></tr>
            ${lines}
            ${data.couponDiscount ? `<tr><td style="padding:8px 0;font-size:13px;color:#10B981">Coupon (${data.couponCode})</td><td style="padding:8px 0;font-size:13px;color:#10B981;text-align:right">−₹${data.couponDiscount.toLocaleString('en-IN')}</td></tr>` : ''}
            ${data.manualDiscount ? `<tr><td style="padding:8px 0;font-size:13px;color:#10B981">Special Discount</td><td style="padding:8px 0;font-size:13px;color:#10B981;text-align:right">−₹${data.manualDiscount.toLocaleString('en-IN')}</td></tr>` : ''}
            <tr><td style="padding:12px 0 0;font-size:15px;font-weight:800;color:#1C1410">Total Paid</td><td style="padding:12px 0 0;font-size:15px;font-weight:800;color:#B8860B;text-align:right">₹${data.finalAmount.toLocaleString('en-IN')}</td></tr>
          </table>
          ${data.loyaltyPoints ? `<div style="margin-top:14px;background:#FFF8E7;border:1px solid #E8D9B8;border-radius:10px;padding:10px 14px"><span style="font-size:18px">⭐</span> <strong style="color:#B8860B;font-size:14px">+${data.loyaltyPoints} Points Earned</strong><div style="font-size:11px;color:#5C4A2A">Added to your loyalty wallet</div></div>` : ''}
        </div>
        <div style="text-align:center;padding:14px 20px;background:#FDF8F0;border-top:1px solid #F5EDD8">
          <p style="font-size:11px;color:#9C8660;margin:0">Thank you for choosing <strong style="color:#B8860B">Glamour Salon</strong> 💛</p>
          <p style="font-size:10px;color:#9C8660;margin:4px 0 0">Ref: <strong style="color:#B8860B">${data.invoiceRef}</strong> · ${dateStr} ${timeStr}</p>
        </div>
      </div>`;

      const container = document.createElement('div');
      container.style.cssText = 'position:fixed;left:-9999px;top:0;width:380px;background:#fff;z-index:-1;';
      container.innerHTML = html;
      document.body.appendChild(container);

      setTimeout(() => {
        window.html2canvas(container, { scale:2, useCORS:true, backgroundColor:'#ffffff', logging:false, width:380 })
          .then((canvas) => {
            try { document.body.removeChild(container); } catch(e) {}
            const { jsPDF } = window.jspdf;
            const pdfW = 380;
            const pdfH = (canvas.height / canvas.width) * pdfW;
            const pdf  = new jsPDF({ unit:'px', format:[pdfW, pdfH], orientation:'portrait' });
            pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, 0, pdfW, pdfH);
            resolve(pdf.output('blob'));
          })
          .catch(() => { try { document.body.removeChild(container); } catch(e) {} resolve(null); });
      }, 500);
    }).catch(() => resolve(null));
  });
};

// ─── download PDF + open WhatsApp ────────────────────────────────────────────
const whatsappPdfReceipt = async (data, setLoadingFn) => {
  if (!data.customerPhone) { alert('Please add a phone number to send via WhatsApp.'); return; }
  const phone = normalizePhone(data.customerPhone);
  if (phone.length < 12) { alert('Invalid phone number. Please enter a valid 10-digit number.'); return; }
  setLoadingFn(true);
  try {
    const blob = await generateReceiptPdfBlob(data);
    if (blob) {
      const url = URL.createObjectURL(blob);
      const a   = document.createElement('a');
      a.href = url; a.download = `Invoice-${data.invoiceRef}.pdf`; a.click();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    } else {
      alert('PDF generation failed. Sending text receipt via WhatsApp instead.');
    }
    const dateStr = new Date().toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' });
    const svcs    = data.services.map(s => `  • ${s.name}: ₹${s.price.toLocaleString('en-IN')}`).join('%0A');
    const msg = [
      `✂ *Glamour Salon — Invoice*`, ``,
      `Hi *${data.customerName || 'there'}* 👋 Your invoice is ready! 📄`, ``,
      `*Invoice Ref:* \`${data.invoiceRef}\``,
      `*Date:* ${dateStr}`,
      `*Stylist:* ${data.staffName || 'Any'}`, ``,
      `*Services:*`, svcs,
      data.couponDiscount ? `  🏷 Coupon: −₹${data.couponDiscount.toLocaleString('en-IN')}` : null,
      data.manualDiscount ? `  🎁 Discount: −₹${data.manualDiscount.toLocaleString('en-IN')}` : null, ``,
      `💰 *Total Paid:* ₹${data.finalAmount.toLocaleString('en-IN')} _(${(data.paymentMethod||'cash').toUpperCase()})_`,
      data.loyaltyPoints ? `⭐ *Loyalty Points Earned:* +${data.loyaltyPoints} pts` : null, ``,
      `📎 _PDF invoice downloaded to your device — share it here!_`, ``,
      `_Thank you for visiting Glamour Salon!_ 💛`,
    ].filter(v => v !== null).join('%0A');
    setTimeout(() => window.open(`https://wa.me/${phone}?text=${msg}`, '_blank'), 800);
  } finally { setLoadingFn(false); }
};

// ═════════════════════════════════════════════════════════════════════════════
export default function AdminBookings() {
  const [bookings,      setBookings]      = useState([]);
  const [loading,       setLoading]       = useState(true);
  const [statusFilter,  setStatusFilter]  = useState('');
  const [dateFilter,    setDateFilter]    = useState(new Date().toISOString().split('T')[0]);
  const [typeFilter,    setTypeFilter]    = useState('');
  const [searchQuery,   setSearchQuery]   = useState('');
  const [stats,         setStats]         = useState(null);
  const [showWalkIn,    setShowWalkIn]    = useState(false);
  const [viewMode,      setViewMode]      = useState('grid');
  const [services,      setServices]      = useState([]);
  const [staffList,     setStaffList]     = useState([]);
  const [busyStaffIds,  setBusyStaffIds]  = useState(new Set());
  const [walkInLoading, setWalkInLoading] = useState(false);
  const [couponLoading, setCouponLoading] = useState(false);
  const [appliedCoupon, setAppliedCoupon] = useState(null);
  const [couponMsg,     setCouponMsg]     = useState('');
  const [billDone,      setBillDone]      = useState(null); // receipt data after success
  const [pdfLoading,    setPdfLoading]    = useState(false);
  const [custSearch,    setCustSearch]    = useState('');
  const [custResults,   setCustResults]   = useState([]);
  const [custSearching, setCustSearching] = useState(false);
  const custTimer = useRef(null);

  const [walkInForm, setWalkInForm] = useState({
    customerName: '', customerPhone: '', customerId: '',
    loyaltyPoints: 0,
    staffId: '',
    selectedServices: [], // [{ serviceId, name, price }]
    paymentMethod: 'cash',
    notes: '',
    couponCode: '',
    manualDiscountPercent: 0,
  });

  // ── fetchers ───────────────────────────────────────────────────────────
  const fetchBookings = useCallback(async () => {
    setLoading(true);
    try {
      const params = {};
      if (statusFilter) params.status = statusFilter;
      if (dateFilter)   params.date   = dateFilter;
      if (typeFilter)   params.type   = typeFilter;
      const { data } = await api.get('/bookings', { params });
      setBookings(data.bookings || []);
    } catch(e) { console.error(e); }
    finally { setLoading(false); }
  }, [statusFilter, dateFilter, typeFilter]);

  const fetchStats    = async () => { try { const { data } = await api.get('/bookings/today/stats'); setStats(data.stats); } catch(e){} };
  const fetchServices = async () => { try { const { data } = await api.get('/services'); setServices(data.services || []); } catch(e){} };
  const fetchStaff    = async () => { try { const { data } = await api.get('/users?role=staff&limit=50'); setStaffList(data.users || []); } catch(e){} };

  useEffect(() => { fetchBookings(); }, [fetchBookings]);
  useEffect(() => {
    fetchStats(); fetchServices(); fetchStaff();
    // compute busy staff from active bookings
    const computeBusy = async () => {
      try {
        const today = new Date().toISOString().split('T')[0];
        const { data } = await api.get(`/bookings?date=${today}&limit=100`);
        const busy = new Set(
          (data.bookings || [])
            .filter(b => b.status === 'in-progress' && b.staff?._id)
            .map(b => b.staff._id)
        );
        setBusyStaffIds(busy);
      } catch(e) {}
    };
    computeBusy();
  }, []);

  // ── customer lookup (debounced) ────────────────────────────────────────
  const searchCustomers = (q) => {
    setCustSearch(q);
    setWalkInForm(f => ({ ...f, customerName: q, customerId: '', loyaltyPoints: 0 }));
    clearTimeout(custTimer.current);
    if (!q || q.length < 2) { setCustResults([]); return; }
    custTimer.current = setTimeout(async () => {
      setCustSearching(true);
      try {
        const { data } = await api.get(`/users?role=customer&search=${q}&limit=6`);
        setCustResults(data.users || []);
      } catch(e) { setCustResults([]); }
      finally { setCustSearching(false); }
    }, 350);
  };

  const selectCustomer = (c) => {
    const rawPhone = (c.phone || '').replace(/\D/g,'');
    const phone10  = rawPhone.startsWith('91') && rawPhone.length === 12 ? rawPhone.slice(2) : rawPhone.slice(-10);
    setWalkInForm(f => ({
      ...f,
      customerName:   c.name,
      customerPhone:  phone10,
      customerId:     c._id,
      loyaltyPoints:  c.loyaltyPoints || 0,
    }));
    setCustSearch(c.name);
    setCustResults([]);
  };

  // ── multi-service helpers ──────────────────────────────────────────────
  const addService = (svcId) => {
    if (!svcId) return;
    const svc = services.find(s => s._id === svcId);
    if (!svc) return;
    if (walkInForm.selectedServices.find(s => s.serviceId === svcId)) return; // no duplicates
    setWalkInForm(f => ({
      ...f,
      selectedServices: [...f.selectedServices, {
        serviceId: svc._id,
        name: svc.name,
        price: svc.discountPrice || svc.price,
        duration: svc.duration,
      }],
    }));
  };

  const removeService = (svcId) => {
    setWalkInForm(f => ({
      ...f,
      selectedServices: f.selectedServices.filter(s => s.serviceId !== svcId),
    }));
    setAppliedCoupon(null); setCouponMsg('');
  };

  const subtotal = walkInForm.selectedServices.reduce((sum, s) => sum + s.price, 0);
  const totalDuration = walkInForm.selectedServices.reduce((sum, s) => sum + (s.duration || 0), 0);

  // ── price calculation ──────────────────────────────────────────────────
  const getCouponDiscount = () => appliedCoupon ? Math.max(0, subtotal - appliedCoupon.finalAmount) : 0;
  const getManualDiscount = () => {
    const base = subtotal - getCouponDiscount();
    return Math.round(base * walkInForm.manualDiscountPercent / 100);
  };
  const getFinalPrice = () => Math.max(0, subtotal - getCouponDiscount() - getManualDiscount());
  const getLoyaltyEarned = () => Math.floor(getFinalPrice() / 100); // 1 point per ₹100

  // ── coupon verify ──────────────────────────────────────────────────────
  const handleVerifyCoupon = async () => {
    if (!walkInForm.couponCode || subtotal === 0) return;
    setCouponLoading(true); setCouponMsg('');
    try {
      const { data } = await api.post('/coupons/validate', { code: walkInForm.couponCode, amount: subtotal });
      setAppliedCoupon(data.coupon);
      setCouponMsg('✓ Coupon applied successfully!');
    } catch(e) {
      setAppliedCoupon(null);
      setCouponMsg(e.response?.data?.message || 'Invalid or expired coupon');
    } finally { setCouponLoading(false); }
  };

  // ── status change ──────────────────────────────────────────────────────
  const handleStatusChange = async (bookingId, status, paymentMethod, paymentStatus) => {
    try {
      const body = { status };
      if (paymentMethod) body.paymentMethod = paymentMethod;
      if (paymentStatus) body.paymentStatus = paymentStatus;
      await api.patch(`/bookings/${bookingId}/status`, body);
      if (status === 'completed' && paymentMethod) {
        try { await api.post('/payments/mark-paid', { bookingId, method: paymentMethod }); } catch(e) {}
      }
      fetchBookings(); fetchStats();
      // refresh busy staff
      try {
        const today = new Date().toISOString().split('T')[0];
        const { data: bd } = await api.get(`/bookings?date=${today}&limit=100`);
        setBusyStaffIds(new Set(
          (bd.bookings||[]).filter(b=>b.status==='in-progress'&&b.staff?._id).map(b=>b.staff._id)
        ));
      } catch(e) {}
    } catch(e) { console.error(e); }
  };

  // ── reset walk-in form ─────────────────────────────────────────────────
  const resetForm = () => {
    setWalkInForm({ customerName:'', customerPhone:'', customerId:'', loyaltyPoints:0, staffId:'', selectedServices:[], paymentMethod:'cash', notes:'', couponCode:'', manualDiscountPercent:0 });
    setAppliedCoupon(null); setCouponMsg(''); setCustSearch(''); setCustResults([]);
  };

  // ── walk-in submit ─────────────────────────────────────────────────────
  const handleWalkIn = async (e) => {
    e.preventDefault();
    if (walkInForm.selectedServices.length === 0) return;
    setWalkInLoading(true);
    try {
      // For multi-service: create one booking per service (or use first service as primary)
      const primaryService = walkInForm.selectedServices[0];
      await api.post('/bookings/walk-in', {
        customerName: walkInForm.customerName,
        customerPhone: walkInForm.customerPhone,
        serviceId: primaryService.serviceId,
        staffId: walkInForm.staffId || undefined,
        paymentMethod: walkInForm.paymentMethod,
        notes: walkInForm.selectedServices.length > 1
          ? `Multi-service: ${walkInForm.selectedServices.map(s=>s.name).join(', ')}. ${walkInForm.notes}`
          : walkInForm.notes,
        couponCode: appliedCoupon ? walkInForm.couponCode : '',
        manualDiscountPercent: walkInForm.manualDiscountPercent,
      });

      // build receipt data
      const receiptData = {
        invoiceRef: generateInvoiceRef(),
        customerName: walkInForm.customerName,
        customerPhone: walkInForm.customerPhone,
        staffName: staffList.find(s => s._id === walkInForm.staffId)?.name || 'Any',
        services: walkInForm.selectedServices,
        paymentMethod: walkInForm.paymentMethod,
        couponCode: appliedCoupon?.code,
        couponDiscount: getCouponDiscount(),
        manualDiscount: getManualDiscount(),
        finalAmount: getFinalPrice(),
        loyaltyPoints: getLoyaltyEarned(),
      };

      setBillDone(receiptData);
      resetForm();
      fetchBookings(); fetchStats();
    } catch(e) {
      alert(e.response?.data?.message || 'Booking failed');
    } finally { setWalkInLoading(false); }
  };

  // ── export CSV (premium formatted) ────────────────────────────────────
  const exportCSV = () => {
    const exportDate = new Date(dateFilter).toLocaleDateString('en-IN', { day:'numeric', month:'long', year:'numeric' });
    const now = new Date().toLocaleString('en-IN');
    const meta = [
      ['GLAMOUR SALON — BOOKINGS REPORT'],
      [`Date: ${exportDate}`],
      [`Exported: ${now}`],
      [`Total Records: ${filteredBookings.length}`],
      [`Filters: Status=${statusFilter||'All'} | Type=${typeFilter||'All'}`],
      [],
    ];
    const headers = [
      'S.No','Invoice Ref','Customer Name','Phone','Service',
      'Category','Duration (min)','Stylist','Date','Time Slot',
      'Original (Rs)','Discount (Rs)','Final Amount (Rs)',
      'Payment Method','Payment Status','Booking Status','Type','Notes','Completed At'
    ];
    const rows = filteredBookings.map((b, i) => {
      // ── phone: force Excel text format with ="..." trick to prevent 9.2E+11
      const digits      = (b.customer?.phone||'').replace(/\D/g,'').slice(-10);
      const phoneVal    = digits ? `+91${digits}` : '—';
      const phoneCsv    = digits ? `="${phoneVal}"` : phoneVal;

      // ── date: readable string, quoted so Excel won't mangle it
      const rawDate     = b.date ? new Date(b.date) : null;
      const dateStr     = rawDate && !isNaN(rawDate)
        ? `"${rawDate.toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' })}"`
        : '"—"';

      // ── time slot
      const slot        = b.timeSlot?.start && b.timeSlot?.end
        ? `"${b.timeSlot.start} - ${b.timeSlot.end}"`
        : '"—"';

      // ── completed at
      const completedAt = b.completedAt ? new Date(b.completedAt) : null;
      const completedStr = completedAt && !isNaN(completedAt)
        ? `"${completedAt.toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' })} ${completedAt.toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit' })}"`
        : '"—"';

      return [
        i + 1,
        `"GLM-${String(b._id).slice(-6).toUpperCase()}"`,
        `"${(b.customer?.name||'Walk-in').replace(/"/g,"'")}"`,
        phoneCsv,
        `"${(b.service?.name||'—').replace(/"/g,"'")}"`,
        `"${b.service?.category||'—'}"`,
        b.service?.duration||'—',
        `"${(b.staff?.name||'Any').replace(/"/g,"'")}"`,
        dateStr,
        slot,
        b.totalAmount||0,
        b.discountAmount||0,
        b.finalAmount||0,
        `"${(b.paymentMethod||'cash').toUpperCase()}"`,
        `"${(b.paymentStatus||'pending').toUpperCase()}"`,
        `"${b.status.toUpperCase()}"`,
        `"${b.type||'online'}"`,
        `"${(b.notes||'').replace(/"/g,"'")}"`,
        completedStr,
      ];
    });
    const totalRevenue  = filteredBookings.reduce((s,b) => s+(b.finalAmount||0), 0);
    const totalDiscount = filteredBookings.reduce((s,b) => s+(b.discountAmount||0), 0);
    const totals = ['','','TOTAL','','','','','','','','',totalDiscount,totalRevenue,'','','','','',''];
    const allRows = [...meta, headers, ...rows, [], totals, [], ['Generated by Glamour Salon Management System']];
    const csv  = allRows.map(r => Array.isArray(r) ? r.join(',') : '').join('\n');
    const BOM  = '\uFEFF';
    const blob = new Blob([BOM + csv], { type: 'text/csv;charset=utf-8;' });
    const a    = document.createElement('a');
    a.href     = URL.createObjectURL(blob);
    a.download = `Glamour-Bookings-${dateFilter}.csv`;
    a.click();
  };

  // ── filter ─────────────────────────────────────────────────────────────
  const filteredBookings = bookings.filter(b => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return b.customer?.name?.toLowerCase().includes(q) ||
           b.service?.name?.toLowerCase().includes(q)  ||
           b.staff?.name?.toLowerCase().includes(q);
  });

  // ── derived ────────────────────────────────────────────────────────────
  const availableStaffCount = staffList.length - busyStaffIds.size;

  const statCards = stats ? [
    { label:'Total',       value: stats.total,                                             icon: Calendar,     accent: C.gold    },
    { label:'Confirmed',   value: stats.confirmed,                                         icon: Clock,        accent: '#F59E0B' },
    { label:'In Progress', value: stats.inProgress,                                        icon: TrendingUp,   accent: '#10B981' },
    { label:'Completed',   value: stats.completed,                                         icon: CheckCircle2, accent: '#3B82F6' },
    { label:'Cancelled',   value: stats.cancelled,                                         icon: XCircle,      accent: '#EF4444' },
    { label:'Revenue',     value:`₹${(stats.todayRevenue||0).toLocaleString('en-IN')}`,    icon: IndianRupee,  accent: C.gold    },
  ] : [];

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <motion.div variants={stagger} initial="hidden" animate="show"
      className="min-h-screen pb-12 space-y-6"
      style={{ background: C.cream, fontFamily:"'DM Sans',sans-serif" }}>

      {/* ══ HEADER ══════════════════════════════════════════════════════ */}
      <motion.div variants={fade}
        className="relative overflow-hidden rounded-2xl px-7 py-6"
        style={{ background:`linear-gradient(135deg,${C.ink} 0%,#2d2510 100%)`, border:`1px solid #3d3010` }}>
        <div className="absolute inset-0 opacity-10"
          style={{ backgroundImage:'repeating-linear-gradient(45deg,#B8860B 0,#B8860B 1px,transparent 0,transparent 50%)', backgroundSize:'18px 18px' }} />
        <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full opacity-10"
          style={{ background:`radial-gradient(circle,${C.goldLight},transparent)` }} />
        <div className="relative flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Sparkles size={13} style={{ color:C.goldLight }} />
              <span className="text-[11px] font-bold tracking-[0.18em] uppercase" style={{ color:C.goldLight }}>Appointments</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-white" style={{ fontFamily:"'Playfair Display',serif" }}>
              Manage Bookings
            </h1>
            <p className="text-sm mt-1" style={{ color:'#9ca3af' }}>
              {filteredBookings.length} appointment{filteredBookings.length!==1?'s':''} · {new Date(dateFilter).toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long'})}
            </p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button onClick={exportCSV}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold transition-all hover:opacity-80"
              style={{ background:'rgba(255,255,255,0.1)', color:'#fff', border:'1px solid rgba(255,255,255,0.15)' }}>
              <Download size={13} /> Export CSV
            </button>
            <button onClick={() => { fetchBookings(); fetchStats(); }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold hover:opacity-80"
              style={{ background:'rgba(255,255,255,0.1)', color:'#fff', border:'1px solid rgba(255,255,255,0.15)' }}>
              <RefreshCw size={13} /> Refresh
            </button>
            <button onClick={() => { setShowWalkIn(!showWalkIn); setBillDone(null); }}
              className="flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold hover:opacity-90 shadow-lg"
              style={{ background:`linear-gradient(135deg,${C.gold},${C.goldLight})`, color:'#fff' }}>
              <UserPlus size={15} /> Walk-in Billing
            </button>
          </div>
        </div>
      </motion.div>

      {/* ══ STATS ═══════════════════════════════════════════════════════ */}
      {stats && (
        <motion.div variants={fade} className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {statCards.map(s => {
            const Icon = s.icon;
            return (
              <motion.div key={s.label} whileHover={{ y:-3 }}
                className="rounded-2xl p-4 text-center transition-all"
                style={{ background:C.white, border:`1px solid ${C.creamBorder}`, boxShadow:'0 2px 12px rgba(184,134,11,0.05)' }}>
                <div className="w-8 h-8 rounded-xl mx-auto mb-2 flex items-center justify-center"
                  style={{ background:`${s.accent}18` }}>
                  <Icon size={15} style={{ color:s.accent }} />
                </div>
                <p className="text-xl font-bold" style={{ fontFamily:"'Playfair Display',serif", color:C.ink }}>{s.value}</p>
                <p className="text-[10px] font-semibold uppercase tracking-wide" style={{ color:C.inkLight }}>{s.label}</p>
              </motion.div>
            );
          })}
        </motion.div>
      )}

      {/* ══ SUCCESS RECEIPT BANNER ═══════════════════════════════════════ */}
      <AnimatePresence>
        {billDone && (
          <motion.div initial={{ opacity:0, y:-10 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0, y:-10 }}
            className="rounded-2xl p-5"
            style={{ background:'#ECFDF5', border:'1px solid #A7F3D0' }}>

            {/* top row */}
            <div className="flex items-center justify-between flex-wrap gap-4 mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center">
                  <Check size={18} className="text-white" />
                </div>
                <div>
                  <p className="text-sm font-bold text-emerald-800">Walk-in booking created!</p>
                  <p className="text-xs text-emerald-600">
                    {billDone.customerName || 'Walk-in'} · ₹{billDone.finalAmount.toLocaleString('en-IN')} · +{billDone.loyaltyPoints} pts · <span className="font-bold">{billDone.invoiceRef}</span>
                  </p>
                </div>
              </div>
              <button onClick={() => setBillDone(null)}
                className="w-8 h-8 flex items-center justify-center rounded-full transition-all hover:opacity-70"
                style={{ background:'#A7F3D0' }}>
                <X size={13} className="text-emerald-800" />
              </button>
            </div>

            {/* action buttons */}
            <div className="flex items-center gap-2 flex-wrap">
              <button onClick={() => printReceipt(billDone)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold transition-all hover:opacity-80"
                style={{ background:'#065F46', color:'#fff' }}>
                <Printer size={13} /> Print Receipt
              </button>
              <button onClick={() => whatsappReceipt(billDone)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold transition-all hover:opacity-80"
                style={{ background:'#25D366', color:'#fff' }}>
                <MessageCircle size={13} /> WhatsApp Text
              </button>
              <button
                onClick={() => whatsappPdfReceipt(billDone, setPdfLoading)}
                disabled={pdfLoading}
                className="flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold transition-all hover:opacity-80 disabled:opacity-50"
                style={{ background:'linear-gradient(135deg,#075E54,#128C7E)', color:'#fff' }}>
                {pdfLoading
                  ? <><Loader2 size={13} className="animate-spin" /> Generating PDF…</>
                  : <><FileText size={13} /> WhatsApp PDF Invoice</>}
              </button>
            </div>

            <p className="text-[11px] mt-3 pl-1" style={{ color:'#065F46' }}>
              💡 <b>WhatsApp PDF</b> — auto-downloads the PDF invoice, then opens WhatsApp so you can forward it to the customer.
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ══ WALK-IN BILLING PANEL ════════════════════════════════════════ */}
      <AnimatePresence>
        {showWalkIn && (
          <motion.div
            initial={{ opacity:0, height:0 }} animate={{ opacity:1, height:'auto' }} exit={{ opacity:0, height:0 }}
            className="overflow-hidden">
            <div className="rounded-2xl overflow-hidden"
              style={{ background:C.white, border:`1px solid ${C.creamBorder}`, boxShadow:'0 4px 24px rgba(184,134,11,0.08)' }}>

              {/* panel header */}
              <div className="flex items-center justify-between px-6 py-4"
                style={{ borderBottom:`1px solid ${C.creamDark}`, background:C.goldPale }}>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center"
                    style={{ background:`linear-gradient(135deg,${C.gold},${C.goldLight})` }}>
                    <UserPlus size={16} className="text-white" />
                  </div>
                  <div>
                    <p className="text-sm font-bold" style={{ color:C.ink }}>Walk-in Premium Billing</p>
                    <p className="text-xs" style={{ color:C.inkLight }}>Multi-service · Customer lookup · Loyalty · Receipt</p>
                  </div>
                </div>
                <button onClick={() => setShowWalkIn(false)}
                  className="w-8 h-8 flex items-center justify-center rounded-xl"
                  style={{ background:C.creamDark }}>
                  <X size={14} style={{ color:C.inkMid }} />
                </button>
              </div>

              <form onSubmit={handleWalkIn} className="p-6 space-y-6">

                {/* ── SECTION 1: Customer ── */}
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-wider mb-3 flex items-center gap-2"
                    style={{ color:C.gold }}>
                    <User size={12} /> Customer Details
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">

                    {/* customer search / name */}
                    <div className="relative">
                      <label className="block text-[11px] font-bold uppercase tracking-wider mb-1.5" style={{ color:C.inkLight }}>
                        Customer Name / Search
                      </label>
                      <div className="relative">
                        <Search size={13} style={{ color:C.inkLight, position:'absolute', left:12, top:'50%', transform:'translateY(-50%)' }} />
                        <input style={{ ...inp(), paddingLeft:34 }}
                          placeholder="Type name to search existing…"
                          value={custSearch}
                          onChange={e => searchCustomers(e.target.value)}
                          onFocus={e => e.target.style.borderColor = C.gold}
                          onBlur={e => e.target.style.borderColor = C.creamBorder} />
                        {custSearching && <Loader2 size={12} style={{ color:C.gold, position:'absolute', right:12, top:'50%', transform:'translateY(-50%)' }} className="animate-spin" />}
                      </div>

                      {/* customer dropdown results */}
                      {custResults.length > 0 && (
                        <div className="absolute z-20 left-0 right-0 mt-1 rounded-xl overflow-hidden shadow-lg"
                          style={{ background:C.white, border:`1px solid ${C.creamBorder}` }}>
                          {custResults.map(c => (
                            <button key={c._id} type="button"
                              onClick={() => selectCustomer(c)}
                              className="w-full flex items-center gap-3 px-4 py-3 text-left transition-colors hover:opacity-80"
                              style={{ borderBottom:`1px solid ${C.creamDark}` }}
                              onMouseEnter={e => e.currentTarget.style.background = C.goldPale}
                              onMouseLeave={e => e.currentTarget.style.background = C.white}>
                              <div className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold text-white"
                                style={{ background:C.gold }}>
                                {(c.name||'?')[0].toUpperCase()}
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-bold truncate" style={{ color:C.ink }}>{c.name}</p>
                                <p className="text-xs truncate" style={{ color:C.inkLight }}>{c.phone || c.email}</p>
                              </div>
                              {c.loyaltyPoints > 0 && (
                                <span className="flex items-center gap-1 text-[11px] font-bold px-2 py-1 rounded-full"
                                  style={{ background:C.goldPale, color:C.gold }}>
                                  <Star size={9} /> {c.loyaltyPoints}pts
                                </span>
                              )}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* phone */}
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider mb-1.5" style={{ color:C.inkLight }}>
                        Phone Number
                      </label>
                      <div className="flex rounded-xl overflow-hidden"
                        style={{ border:`1px solid ${C.creamBorder}` }}>
                        <span className="flex items-center justify-center px-3 text-xs font-bold flex-shrink-0 select-none"
                          style={{ background:C.goldPale, borderRight:`1px solid ${C.creamBorder}`, color:C.gold, minWidth:48 }}>
                          +91
                        </span>
                        <input
                          style={{ ...inp(), border:'none', borderRadius:0, flex:1, paddingLeft:12, paddingRight:12 }}
                          type="tel" placeholder="98765 43210" maxLength={10}
                          value={walkInForm.customerPhone}
                          onChange={e => {
                            const digits = e.target.value.replace(/\D/g,'').slice(0,10);
                            setWalkInForm(f => ({ ...f, customerPhone: digits }));
                          }}
                          onFocus={e => e.target.parentElement.style.borderColor = C.gold}
                          onBlur={e => e.target.parentElement.style.borderColor = C.creamBorder} />
                      </div>
                    </div>

                    {/* loyalty points display */}
                    {walkInForm.customerId && (
                      <div className="sm:col-span-2 flex items-center gap-3 px-4 py-3 rounded-xl"
                        style={{ background:C.goldPale, border:`1px solid ${C.creamBorder}` }}>
                        <Star size={16} style={{ color:C.gold }} />
                        <div>
                          <p className="text-xs font-bold" style={{ color:C.ink }}>
                            Existing customer · {walkInForm.loyaltyPoints} loyalty points
                          </p>
                          <p className="text-[11px]" style={{ color:C.inkLight }}>
                            Will earn +{getLoyaltyEarned()} more points on this visit
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* ── SECTION 2: Services ── */}
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-wider mb-3 flex items-center gap-2"
                    style={{ color:C.gold }}>
                    <Scissors size={12} /> Services (add multiple)
                  </p>

                  {/* service picker */}
                  <div className="flex gap-2 mb-3">
                    <select style={{ ...inp(), flex:1 }}
                      value=""
                      onChange={e => { addService(e.target.value); e.target.value=''; }}
                      onFocus={e => e.target.style.borderColor = C.gold}
                      onBlur={e => e.target.style.borderColor = C.creamBorder}>
                      <option value="">+ Add a service…</option>
                      {services.filter(s => !walkInForm.selectedServices.find(sel => sel.serviceId === s._id)).map(s => (
                        <option key={s._id} value={s._id}>
                          {s.name} — ₹{(s.discountPrice||s.price).toLocaleString('en-IN')} · {s.duration}min
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* selected services list */}
                  {walkInForm.selectedServices.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-6 rounded-xl"
                      style={{ border:`2px dashed ${C.creamBorder}` }}>
                      <Scissors size={22} style={{ color:C.creamBorder }} />
                      <p className="text-xs mt-2" style={{ color:C.inkLight }}>No services added yet</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {walkInForm.selectedServices.map((s, i) => (
                        <div key={s.serviceId}
                          className="flex items-center justify-between px-4 py-3 rounded-xl"
                          style={{ background:C.cream, border:`1px solid ${C.creamBorder}` }}>
                          <div className="flex items-center gap-3">
                            <div className="w-7 h-7 rounded-lg flex items-center justify-center text-[10px] font-bold"
                              style={{ background:C.goldPale, color:C.gold }}>{i+1}</div>
                            <div>
                              <p className="text-sm font-bold" style={{ color:C.ink }}>{s.name}</p>
                              <p className="text-[11px]" style={{ color:C.inkLight }}>{s.duration} min</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <p className="text-sm font-bold" style={{ color:C.gold }}>₹{s.price.toLocaleString('en-IN')}</p>
                            <button type="button" onClick={() => removeService(s.serviceId)}
                              className="w-7 h-7 flex items-center justify-center rounded-lg transition-all hover:opacity-70"
                              style={{ background:'#FEF2F2' }}>
                              <Trash2 size={13} className="text-red-500" />
                            </button>
                          </div>
                        </div>
                      ))}
                      <div className="flex justify-between px-4 pt-1 text-xs font-semibold" style={{ color:C.inkLight }}>
                        <span>{walkInForm.selectedServices.length} service{walkInForm.selectedServices.length>1?'s':''} · {totalDuration} min total</span>
                        <span style={{ color:C.ink }}>Subtotal: ₹{subtotal.toLocaleString('en-IN')}</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* ── SECTION 3: Stylist + Payment ── */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* staff selector with busy indicator */}
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider mb-1.5" style={{ color:C.inkLight }}>
                      Assign Stylist
                    </label>
                    <div className="space-y-2">
                      {/* any available option */}
                      <button type="button"
                        onClick={() => setWalkInForm(f => ({ ...f, staffId:'' }))}
                        className="w-full flex items-center justify-between px-4 py-2.5 rounded-xl text-sm font-semibold transition-all"
                        style={{
                          background: walkInForm.staffId==='' ? `linear-gradient(135deg,${C.gold},${C.goldLight})` : C.cream,
                          color: walkInForm.staffId==='' ? '#fff' : C.inkMid,
                          border:`1px solid ${walkInForm.staffId==='' ? C.gold : C.creamBorder}`,
                        }}>
                        <span>Any available stylist</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                          style={{ background:'rgba(255,255,255,0.25)', color: walkInForm.staffId==='' ? '#fff' : C.inkLight }}>
                          AUTO
                        </span>
                      </button>
                      {/* staff list with busy badge */}
                      {staffList.map(s => {
                        const isBusy     = busyStaffIds.has(s._id);
                        const isSelected = walkInForm.staffId === s._id;
                        return (
                          <button key={s._id} type="button"
                            onClick={() => !isBusy && setWalkInForm(f => ({ ...f, staffId: s._id }))}
                            className="w-full flex items-center justify-between px-4 py-2.5 rounded-xl text-sm font-semibold transition-all"
                            style={{
                              background: isBusy ? '#FEF2F2' : isSelected ? `linear-gradient(135deg,${C.gold},${C.goldLight})` : C.cream,
                              color: isBusy ? '#991B1B' : isSelected ? '#fff' : C.ink,
                              border:`1px solid ${isBusy ? '#FECACA' : isSelected ? C.gold : C.creamBorder}`,
                              cursor: isBusy ? 'not-allowed' : 'pointer',
                              opacity: isBusy ? 0.75 : 1,
                            }}>
                            <div className="flex items-center gap-2">
                              <span className="w-2 h-2 rounded-full flex-shrink-0"
                                style={{ background: isBusy ? '#EF4444' : '#10B981' }} />
                              <span>{s.name}</span>
                            </div>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                              style={{
                                background: isBusy ? '#FECACA' : isSelected ? 'rgba(255,255,255,0.25)' : '#ECFDF5',
                                color: isBusy ? '#991B1B' : isSelected ? '#fff' : '#065F46',
                              }}>
                              {isBusy ? '🔴 BUSY' : '🟢 FREE'}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* payment method */}
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider mb-1.5" style={{ color:C.inkLight }}>
                      Payment Method
                    </label>
                    <div className="flex gap-2">
                      {['cash','upi','card'].map(m => (
                        <button key={m} type="button"
                          onClick={() => setWalkInForm(f => ({ ...f, paymentMethod:m }))}
                          className="flex-1 py-2.5 rounded-xl text-xs font-bold capitalize transition-all"
                          style={{
                            background: walkInForm.paymentMethod===m ? `linear-gradient(135deg,${C.gold},${C.goldLight})` : C.cream,
                            color: walkInForm.paymentMethod===m ? '#fff' : C.inkMid,
                            border: `1px solid ${walkInForm.paymentMethod===m ? C.gold : C.creamBorder}`,
                          }}>
                          {m.toUpperCase()}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* ── SECTION 4: Discounts ── */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* coupon */}
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider mb-1.5" style={{ color:C.inkLight }}>
                      Coupon Code
                    </label>
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <Ticket size={13} style={{ color:C.inkLight, position:'absolute', left:12, top:'50%', transform:'translateY(-50%)' }} />
                        <input style={{ ...inp(), paddingLeft:34 }} type="text" placeholder="SAVE20"
                          value={walkInForm.couponCode}
                          onChange={e => { setWalkInForm(f => ({ ...f, couponCode:e.target.value.toUpperCase() })); setAppliedCoupon(null); setCouponMsg(''); }}
                          onFocus={e => e.target.style.borderColor = C.gold}
                          onBlur={e => e.target.style.borderColor = C.creamBorder} />
                      </div>
                      <button type="button" onClick={handleVerifyCoupon}
                        disabled={!walkInForm.couponCode || subtotal===0 || couponLoading}
                        className="px-4 rounded-xl text-xs font-bold transition-all disabled:opacity-40"
                        style={{ background:C.ink, color:'#fff' }}>
                        {couponLoading ? <Loader2 size={13} className="animate-spin" /> : 'Apply'}
                      </button>
                    </div>
                    {couponMsg && (
                      <p className="text-[11px] mt-1 font-semibold"
                        style={{ color: appliedCoupon ? '#10B981' : '#EF4444' }}>{couponMsg}</p>
                    )}
                  </div>

                  {/* manual discount */}
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider mb-1.5" style={{ color:C.inkLight }}>
                      Special Discount (max 10%)
                    </label>
                    <div className="relative">
                      <Percent size={13} style={{ color:C.inkLight, position:'absolute', left:12, top:'50%', transform:'translateY(-50%)' }} />
                      <input style={{ ...inp(), paddingLeft:34 }} type="number" placeholder="0" min={0} max={10}
                        value={walkInForm.manualDiscountPercent || ''}
                        onChange={e => setWalkInForm(f => ({ ...f, manualDiscountPercent: Math.min(10, Math.max(0, Number(e.target.value))) }))}
                        onFocus={e => e.target.style.borderColor = C.gold}
                        onBlur={e => e.target.style.borderColor = C.creamBorder} />
                    </div>
                  </div>

                  {/* notes */}
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-bold uppercase tracking-wider mb-1.5" style={{ color:C.inkLight }}>
                      Notes (optional)
                    </label>
                    <input style={inp()} type="text" placeholder="Any special requests…"
                      value={walkInForm.notes}
                      onChange={e => setWalkInForm(f => ({ ...f, notes:e.target.value }))}
                      onFocus={e => e.target.style.borderColor = C.gold}
                      onBlur={e => e.target.style.borderColor = C.creamBorder} />
                  </div>
                </div>

                {/* ── BILLING SUMMARY ── */}
                {walkInForm.selectedServices.length > 0 && (
                  <div className="rounded-2xl p-5 space-y-2.5"
                    style={{ background:C.goldPale, border:`1px solid ${C.creamBorder}` }}>
                    <p className="text-xs font-bold uppercase tracking-wider mb-1" style={{ color:C.inkMid }}>
                      Billing Summary
                    </p>
                    {walkInForm.selectedServices.map(s => (
                      <div key={s.serviceId} className="flex justify-between text-sm" style={{ color:C.inkMid }}>
                        <span>{s.name}</span>
                        <span>₹{s.price.toLocaleString('en-IN')}</span>
                      </div>
                    ))}
                    {appliedCoupon && (
                      <div className="flex justify-between text-sm" style={{ color:'#10B981' }}>
                        <span>Coupon ({appliedCoupon.code})</span>
                        <span>-₹{getCouponDiscount().toLocaleString('en-IN')}</span>
                      </div>
                    )}
                    {walkInForm.manualDiscountPercent > 0 && (
                      <div className="flex justify-between text-sm" style={{ color:'#10B981' }}>
                        <span>Special Discount ({walkInForm.manualDiscountPercent}%)</span>
                        <span>-₹{getManualDiscount().toLocaleString('en-IN')}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-base font-bold pt-3"
                      style={{ borderTop:`1px solid ${C.creamBorder}`, color:C.ink }}>
                      <span>Total Payable</span>
                      <span style={{ color:C.gold }}>₹{getFinalPrice().toLocaleString('en-IN')}</span>
                    </div>
                    <div className="flex items-center gap-2 pt-1">
                      <Star size={13} style={{ color:C.gold }} />
                      <p className="text-xs font-semibold" style={{ color:C.inkMid }}>
                        Customer earns <b style={{ color:C.gold }}>+{getLoyaltyEarned()} loyalty points</b> on this visit
                      </p>
                    </div>
                  </div>
                )}

                {/* submit */}
                <button type="submit"
                  disabled={walkInLoading || walkInForm.selectedServices.length===0}
                  className="w-full flex items-center justify-center gap-2 py-4 rounded-xl text-sm font-bold transition-all hover:opacity-90 disabled:opacity-40"
                  style={{ background:`linear-gradient(135deg,${C.gold},${C.goldLight})`, color:'#fff' }}>
                  {walkInLoading
                    ? <Loader2 size={16} className="animate-spin" />
                    : <><Plus size={16} /> Create Booking — ₹{getFinalPrice().toLocaleString('en-IN')}</>}
                </button>

              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ══ STAFF AVAILABILITY BAR ════════════════════════════════════════ */}
      {staffList.length > 0 && (
        <motion.div variants={fade}
          className="rounded-2xl px-5 py-3.5 flex items-center justify-between flex-wrap gap-3"
          style={{ background:C.white, border:`1px solid ${C.creamBorder}` }}>
          <div className="flex items-center gap-3">
            <p className="text-xs font-bold uppercase tracking-wider" style={{ color:C.inkLight }}>Staff Status</p>
            <div className="flex items-center gap-2 flex-wrap">
              {staffList.map(s => {
                const busy = busyStaffIds.has(s._id);
                return (
                  <span key={s._id}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-semibold"
                    style={{
                      background: busy ? '#FEF2F2' : '#ECFDF5',
                      color:      busy ? '#991B1B' : '#065F46',
                      border:     `1px solid ${busy ? '#FECACA' : '#A7F3D0'}`,
                    }}>
                    <span className="w-1.5 h-1.5 rounded-full" style={{ background: busy ? '#EF4444' : '#10B981' }} />
                    {s.name}
                    <span className="font-bold">{busy ? '· Busy' : '· Free'}</span>
                  </span>
                );
              })}
            </div>
          </div>
          <p className="text-xs font-semibold" style={{ color:C.inkLight }}>
            <span style={{ color:'#10B981', fontWeight:700 }}>{availableStaffCount} available</span>
            {' '}· {busyStaffIds.size} in session
          </p>
        </motion.div>
      )}

      {/* ══ FILTERS + SEARCH ════════════════════════════════════════════ */}
      <motion.div variants={fade} className="rounded-2xl p-4"
        style={{ background:C.white, border:`1px solid ${C.creamBorder}` }}>
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search size={14} style={{ color:C.inkLight, position:'absolute', left:12, top:'50%', transform:'translateY(-50%)' }} />
            <input style={{ ...inp(), paddingLeft:36 }} placeholder="Search customer, service, stylist…"
              value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
              onFocus={e => e.target.style.borderColor = C.gold}
              onBlur={e => e.target.style.borderColor = C.creamBorder} />
          </div>
          <input type="date" value={dateFilter} onChange={e => setDateFilter(e.target.value)}
            style={{ ...inp(), width:'auto', cursor:'pointer' }}
            onFocus={e => e.target.style.borderColor = C.gold}
            onBlur={e => e.target.style.borderColor = C.creamBorder} />
          <div className="flex gap-2 flex-wrap">
            {['','confirmed','in-progress','completed','cancelled'].map(s => (
              <button key={s} onClick={() => setStatusFilter(s)}
                className="px-3.5 py-2 rounded-full text-xs font-semibold capitalize transition-all"
                style={{
                  background: statusFilter===s ? `linear-gradient(135deg,${C.gold},${C.goldLight})` : C.cream,
                  color: statusFilter===s ? '#fff' : C.inkMid,
                  border:`1px solid ${statusFilter===s ? C.gold : C.creamBorder}`,
                }}>
                {s==='' ? 'All' : s.replace('-',' ')}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            {[['','All'],['online','Online'],['walk-in','Walk-in']].map(([v,l]) => (
              <button key={v} onClick={() => setTypeFilter(v)}
                className="px-3.5 py-2 rounded-full text-xs font-semibold transition-all"
                style={{
                  background: typeFilter===v ? C.ink : C.cream,
                  color: typeFilter===v ? '#fff' : C.inkMid,
                  border:`1px solid ${typeFilter===v ? C.ink : C.creamBorder}`,
                }}>
                {l}
              </button>
            ))}
          </div>
          <div className="flex gap-1 rounded-xl p-1" style={{ background:C.cream, border:`1px solid ${C.creamBorder}` }}>
            {[['grid','▦'],['list','☰']].map(([mode,icon]) => (
              <button key={mode} onClick={() => setViewMode(mode)}
                className="w-8 h-8 flex items-center justify-center rounded-lg text-sm transition-all"
                style={{
                  background: viewMode===mode ? C.white : 'transparent',
                  color: viewMode===mode ? C.gold : C.inkLight,
                  boxShadow: viewMode===mode ? '0 1px 4px rgba(0,0,0,0.08)' : 'none',
                }}>
                {icon}
              </button>
            ))}
          </div>
        </div>
        {(searchQuery||statusFilter||typeFilter) && (
          <div className="flex items-center gap-2 mt-3 pt-3" style={{ borderTop:`1px solid ${C.creamDark}` }}>
            <span className="text-[11px] font-semibold" style={{ color:C.inkLight }}>Filters:</span>
            {[searchQuery && ['search', searchQuery, () => setSearchQuery('')],
              statusFilter && ['status', statusFilter, () => setStatusFilter('')],
              typeFilter   && ['type',   typeFilter,   () => setTypeFilter('')]
            ].filter(Boolean).map(([k,v,clear]) => (
              <span key={k} className="flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold cursor-pointer"
                style={{ background:C.goldPale, color:C.gold, border:`1px solid ${C.creamBorder}` }}
                onClick={clear}>
                {v} <X size={10} />
              </span>
            ))}
          </div>
        )}
      </motion.div>

      {/* ══ BOOKINGS ════════════════════════════════════════════════════ */}
      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 gap-3">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center"
            style={{ background:`linear-gradient(135deg,${C.gold},${C.goldLight})` }}>
            <Loader2 size={22} className="text-white animate-spin" />
          </div>
          <p className="text-sm font-medium" style={{ color:C.inkLight }}>Loading appointments…</p>
        </div>
      ) : filteredBookings.length === 0 ? (
        <motion.div variants={fade} className="flex flex-col items-center justify-center py-24 gap-4 rounded-2xl"
          style={{ background:C.white, border:`1px solid ${C.creamBorder}` }}>
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center"
            style={{ background:C.goldPale, border:`1px solid ${C.creamBorder}` }}>
            <Calendar size={28} style={{ color:C.gold }} />
          </div>
          <div className="text-center">
            <p className="font-bold" style={{ color:C.ink }}>No appointments found</p>
            <p className="text-xs mt-1" style={{ color:C.inkLight }}>
              {searchQuery ? 'Try a different search' : 'No bookings for selected filters'}
            </p>
          </div>
          <button onClick={() => { setSearchQuery(''); setStatusFilter(''); setTypeFilter(''); }}
            className="flex items-center gap-2 text-xs font-bold px-5 py-2.5 rounded-full"
            style={{ background:C.ink, color:'#fff' }}>
            <X size={13} /> Clear filters
          </button>
        </motion.div>
      ) : (
        <motion.div variants={stagger}
          className={viewMode==='grid' ? 'grid grid-cols-1 lg:grid-cols-2 gap-4' : 'flex flex-col gap-3'}>
          {filteredBookings.map((booking, i) => (
            <motion.div key={booking._id} variants={fade}>
              <BookingCard booking={booking} onStatusChange={handleStatusChange}
                showActions={true} role="admin" viewMode={viewMode} index={i} />
            </motion.div>
          ))}
        </motion.div>
      )}

      {!loading && filteredBookings.length > 0 && (
        <p className="text-center text-xs font-medium" style={{ color:C.inkLight }}>
          Showing {filteredBookings.length} of {bookings.length} appointments
        </p>
      )}
    </motion.div>
  );
}