import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Save, Loader2, Sparkles, Store, Clock, CreditCard,
  Palette, FileText, Percent, Check, RefreshCw,
  ToggleLeft, ToggleRight, Star, ShieldCheck,
} from 'lucide-react';
import api from '@/services/api';

// ─── design tokens (matches AdminBookings / AdminServices) ────────────────────
const C = {
  cream: '#FDF8F0', creamDark: '#F5EDD8', creamBorder: '#E8D9B8',
  gold: '#B8860B', goldLight: '#DAA520', goldPale: '#FFF8E7',
  ink: '#1C1410', inkMid: '#5C4A2A', inkLight: '#9C8660', white: '#FFFFFF',
  green: '#10B981', red: '#EF4444', redPale: '#FEF2F2',
};

const fade = {
  hidden: { opacity: 0, y: 10 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.35, ease: [0.22, 0.61, 0.36, 1] } },
};

const inp = (extra = {}) => ({
  padding: '10px 14px', borderRadius: 12,
  border: `1px solid ${C.creamBorder}`,
  background: C.cream, fontSize: 13, color: C.ink,
  outline: 'none', width: '100%',
  fontFamily: "'DM Sans',sans-serif", ...extra,
});

// ─── reusable sub-components ──────────────────────────────────────────────────
const Label = ({ children }) => (
  <label className="block text-[11px] font-bold uppercase tracking-wider mb-1.5"
    style={{ color: C.inkLight }}>{children}</label>
);

const SectionTitle = ({ children }) => (
  <p className="text-xs font-bold uppercase tracking-wider pb-2 mb-4"
    style={{ color: C.gold, borderBottom: `1px solid ${C.creamDark}` }}>{children}</p>
);

const Toggle = ({ checked, onChange, label, description }) => (
  <div className="flex items-center justify-between py-2.5">
    <div className="flex-1 mr-4">
      <p className="text-sm font-semibold" style={{ color: C.ink }}>{label}</p>
      {description && <p className="text-xs mt-0.5" style={{ color: C.inkLight }}>{description}</p>}
    </div>
    <button type="button" onClick={() => onChange(!checked)}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all flex-shrink-0"
      style={{
        background: checked ? '#ECFDF5' : C.redPale,
        color:      checked ? C.green   : C.red,
        border:     `1px solid ${checked ? '#A7F3D0' : '#FECACA'}`,
      }}>
      {checked ? <ToggleRight size={13} /> : <ToggleLeft size={13} />}
      {checked ? 'Enabled' : 'Disabled'}
    </button>
  </div>
);

const Field = ({ label, children }) => (
  <div>
    <Label>{label}</Label>
    {children}
  </div>
);

// ═════════════════════════════════════════════════════════════════════════════
const AdminSettings = () => {
  const [settings,  setSettings]  = useState(null);
  const [loading,   setLoading]   = useState(true);
  const [saving,    setSaving]    = useState(false);
  const [saved,     setSaved]     = useState(false);
  const [activeTab, setActiveTab] = useState('general');

  const fetchSettings = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/settings');
      setSettings({
        ...data.settings,
        billing: {
          maxDiscountPercent:    10,
          allowStaffDiscount:    true,
          loyaltyPointsPerRupee: 1,
          ...(data.settings?.billing || {}),
        },
      });
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchSettings(); }, []);

  const handleSave = async () => {
    try {
      setSaving(true);
      await api.put('/settings', settings);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) { console.error(err); }
    finally { setSaving(false); }
  };

  const updateField = (path, value) => {
    setSettings(prev => {
      const updated = { ...prev };
      const keys = path.split('.');
      let obj = updated;
      for (let i = 0; i < keys.length - 1; i++) {
        obj[keys[i]] = { ...obj[keys[i]] };
        obj = obj[keys[i]];
      }
      obj[keys[keys.length - 1]] = value;
      return updated;
    });
  };

  const tabs = [
    { id: 'general', label: 'General',   icon: Store      },
    { id: 'hours',   label: 'Hours',     icon: Clock      },
    { id: 'billing', label: 'Billing',   icon: Percent,  badge: true },
    { id: 'payment', label: 'Payment',   icon: CreditCard },
    { id: 'tax',     label: 'Tax & GST', icon: FileText   },
    { id: 'theme',   label: 'Theme',     icon: Palette    },
  ];

  if (loading || !settings) return (
    <div className="flex flex-col items-center justify-center py-24 gap-3 min-h-[50vh]"
      style={{ background: C.cream }}>
      <div className="w-12 h-12 rounded-2xl flex items-center justify-center"
        style={{ background: `linear-gradient(135deg,${C.gold},${C.goldLight})` }}>
        <Loader2 size={22} className="text-white animate-spin" />
      </div>
      <p className="text-sm font-medium" style={{ color: C.inkLight }}>Loading settings…</p>
    </div>
  );

  const maxDiscount = settings.billing?.maxDiscountPercent ?? 10;

  return (
    <motion.div initial="hidden" animate="show"
      className="min-h-screen pb-12 space-y-5"
      style={{ background: C.cream, fontFamily: "'DM Sans',sans-serif" }}>

      {/* ══ HEADER ══════════════════════════════════════════════════════ */}
      <motion.div variants={fade}
        className="relative overflow-hidden rounded-2xl px-7 py-6"
        style={{ background: `linear-gradient(135deg,${C.ink} 0%,#2d2510 100%)`, border: `1px solid #3d3010` }}>
        <div className="absolute inset-0 opacity-10"
          style={{ backgroundImage: 'repeating-linear-gradient(45deg,#B8860B 0,#B8860B 1px,transparent 0,transparent 50%)', backgroundSize: '18px 18px' }} />
        <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full opacity-10"
          style={{ background: `radial-gradient(circle,${C.goldLight},transparent)` }} />
        <div className="relative flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Sparkles size={13} style={{ color: C.goldLight }} />
              <span className="text-[11px] font-bold tracking-[0.18em] uppercase" style={{ color: C.goldLight }}>Configuration</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-white" style={{ fontFamily: "'Playfair Display',serif" }}>
              Salon Settings
            </h1>
            <p className="text-sm mt-1" style={{ color: '#9ca3af' }}>
              {settings.salonName} · All changes saved to database
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={fetchSettings}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold hover:opacity-80 transition-all"
              style={{ background: 'rgba(255,255,255,0.1)', color: '#fff', border: '1px solid rgba(255,255,255,0.15)' }}>
              <RefreshCw size={13} /> Refresh
            </button>
            <button onClick={handleSave} disabled={saving}
              className="flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold hover:opacity-90 shadow-lg disabled:opacity-50 transition-all"
              style={{ background: saved ? C.green : `linear-gradient(135deg,${C.gold},${C.goldLight})`, color: '#fff' }}>
              {saving
                ? <><Loader2 size={14} className="animate-spin" /> Saving…</>
                : saved
                  ? <><Check size={14} /> Saved!</>
                  : <><Save size={14} /> Save Changes</>}
            </button>
          </div>
        </div>
      </motion.div>

      {/* ══ TABS ════════════════════════════════════════════════════════ */}
      <motion.div variants={fade} className="flex gap-2 overflow-x-auto pb-1">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-full text-xs font-bold whitespace-nowrap transition-all flex-shrink-0"
              style={{
                background: active ? `linear-gradient(135deg,${C.gold},${C.goldLight})` : C.white,
                color:      active ? '#fff' : C.inkMid,
                border:     `1px solid ${active ? C.gold : C.creamBorder}`,
                boxShadow:  active ? `0 2px 12px rgba(184,134,11,0.25)` : 'none',
              }}>
              <Icon size={13} />
              {tab.label}
              {tab.badge && (
                <span className="w-4 h-4 rounded-full text-[9px] font-black flex items-center justify-center"
                  style={{ background: active ? 'rgba(255,255,255,0.3)' : C.goldPale, color: active ? '#fff' : C.gold }}>
                  ★
                </span>
              )}
            </button>
          );
        })}
      </motion.div>

      {/* ══ TAB PANELS ══════════════════════════════════════════════════ */}
      <AnimatePresence mode="wait">

        {/* ── GENERAL ─────────────────────────────────────────────── */}
        {activeTab === 'general' && (
          <motion.div key="general" variants={fade} initial="hidden" animate="show" exit="hidden"
            className="rounded-2xl p-6 space-y-6"
            style={{ background: C.white, border: `1px solid ${C.creamBorder}` }}>
            <SectionTitle>Salon Information</SectionTitle>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Salon Name">
                <input style={inp()} type="text" value={settings.salonName || ''}
                  onChange={e => updateField('salonName', e.target.value)}
                  onFocus={e => e.target.style.borderColor = C.gold}
                  onBlur={e => e.target.style.borderColor = C.creamBorder} />
              </Field>
              <Field label="Tagline">
                <input style={inp()} type="text" value={settings.tagline || ''}
                  onChange={e => updateField('tagline', e.target.value)}
                  onFocus={e => e.target.style.borderColor = C.gold}
                  onBlur={e => e.target.style.borderColor = C.creamBorder} />
              </Field>
              <Field label="Phone">
                <input style={inp()} type="tel" value={settings.phone || ''}
                  onChange={e => updateField('phone', e.target.value)}
                  onFocus={e => e.target.style.borderColor = C.gold}
                  onBlur={e => e.target.style.borderColor = C.creamBorder} />
              </Field>
              <Field label="Email">
                <input style={inp()} type="email" value={settings.email || ''}
                  onChange={e => updateField('email', e.target.value)}
                  onFocus={e => e.target.style.borderColor = C.gold}
                  onBlur={e => e.target.style.borderColor = C.creamBorder} />
              </Field>
            </div>

            <SectionTitle>Address</SectionTitle>
            <Field label="Street Address">
              <input style={inp()} type="text" value={settings.address?.street || ''}
                onChange={e => updateField('address.street', e.target.value)}
                onFocus={e => e.target.style.borderColor = C.gold}
                onBlur={e => e.target.style.borderColor = C.creamBorder} />
            </Field>
            <div className="grid grid-cols-3 gap-4">
              {[['City','address.city'],['State','address.state'],['Pincode','address.pincode']].map(([l, p]) => (
                <Field key={p} label={l}>
                  <input style={inp()} type="text"
                    value={settings.address?.[p.split('.')[1]] || ''}
                    onChange={e => updateField(p, e.target.value)}
                    onFocus={e => e.target.style.borderColor = C.gold}
                    onBlur={e => e.target.style.borderColor = C.creamBorder} />
                </Field>
              ))}
            </div>
          </motion.div>
        )}

        {/* ── HOURS ───────────────────────────────────────────────── */}
        {activeTab === 'hours' && (
          <motion.div key="hours" variants={fade} initial="hidden" animate="show" exit="hidden"
            className="rounded-2xl p-6 space-y-6"
            style={{ background: C.white, border: `1px solid ${C.creamBorder}` }}>
            <SectionTitle>Operating Hours</SectionTitle>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {[
                ['Opening Time',       'operatingHours.openTime',     'time'  ],
                ['Closing Time',       'operatingHours.closeTime',    'time'  ],
                ['Slot Interval (min)','operatingHours.slotInterval', 'number'],
              ].map(([l, p, t]) => (
                <Field key={p} label={l}>
                  <input style={inp()} type={t}
                    value={settings.operatingHours?.[p.split('.')[1]] || ''}
                    onChange={e => updateField(p, t === 'number' ? parseInt(e.target.value) : e.target.value)}
                    onFocus={e => e.target.style.borderColor = C.gold}
                    onBlur={e => e.target.style.borderColor = C.creamBorder} />
                </Field>
              ))}
            </div>

            <SectionTitle>Weekly Schedule</SectionTitle>
            <div className="space-y-2">
              {['monday','tuesday','wednesday','thursday','friday','saturday','sunday'].map(day => (
                <div key={day} className="flex items-center gap-3 px-4 py-3 rounded-xl"
                  style={{ background: C.cream, border: `1px solid ${C.creamBorder}` }}>
                  <label className="flex items-center gap-2 w-24 flex-shrink-0">
                    <input type="checkbox"
                      checked={settings.weeklySchedule?.[day]?.isOpen !== false}
                      onChange={e => updateField(`weeklySchedule.${day}.isOpen`, e.target.checked)}
                      style={{ accentColor: C.gold, width: 16, height: 16 }} />
                    <span className="text-xs font-bold capitalize" style={{ color: C.ink }}>
                      {day.slice(0,3).toUpperCase()}
                    </span>
                  </label>
                  <input type="time" style={{ ...inp(), width: 'auto', padding: '6px 10px', flex: 1 }}
                    value={settings.weeklySchedule?.[day]?.open || '09:00'}
                    onChange={e => updateField(`weeklySchedule.${day}.open`, e.target.value)} />
                  <span className="text-xs font-semibold flex-shrink-0" style={{ color: C.inkLight }}>to</span>
                  <input type="time" style={{ ...inp(), width: 'auto', padding: '6px 10px', flex: 1 }}
                    value={settings.weeklySchedule?.[day]?.close || '21:00'}
                    onChange={e => updateField(`weeklySchedule.${day}.close`, e.target.value)} />
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* ── BILLING ★ ───────────────────────────────────────────── */}
        {activeTab === 'billing' && (
          <motion.div key="billing" variants={fade} initial="hidden" animate="show" exit="hidden"
            className="rounded-2xl p-6 space-y-6"
            style={{ background: C.white, border: `1px solid ${C.creamBorder}` }}>

            {/* info banner */}
            <div className="flex items-start gap-3 px-4 py-3 rounded-xl"
              style={{ background: C.goldPale, border: `1px solid ${C.creamBorder}` }}>
              <ShieldCheck size={18} style={{ color: C.gold, flexShrink: 0, marginTop: 1 }} />
              <div>
                <p className="text-sm font-bold" style={{ color: C.ink }}>Owner-controlled billing rules</p>
                <p className="text-xs mt-0.5" style={{ color: C.inkLight }}>
                  These limits apply to all staff during billing — they cannot exceed what you set here. Changes are saved to the database and apply instantly on all devices.
                </p>
              </div>
            </div>

            {/* ── staff discount toggle ── */}
            <div>
              <SectionTitle>Staff Discount Permission</SectionTitle>
              <div className="px-4 rounded-xl divide-y"
                style={{ background: C.cream, border: `1px solid ${C.creamBorder}`, divideColor: C.creamDark }}>
                <Toggle
                  checked={settings.billing?.allowStaffDiscount !== false}
                  onChange={v => updateField('billing.allowStaffDiscount', v)}
                  label="Allow Staff to Give Manual Discounts"
                  description="Turn off to completely remove the discount field from staff billing" />
              </div>
            </div>

            {/* ── max discount % ── only shows if allowed ── */}
            <AnimatePresence>
              {settings.billing?.allowStaffDiscount !== false && (
                <motion.div key="discountBlock"
                  initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
                  className="overflow-hidden">
                  <SectionTitle>Maximum Discount Staff Can Apply</SectionTitle>
                  <div className="px-5 py-5 rounded-xl space-y-4"
                    style={{ background: C.cream, border: `1px solid ${C.creamBorder}` }}>

                    {/* big % display */}
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-semibold" style={{ color: C.ink }}>
                          Staff discount limit
                        </p>
                        <p className="text-xs mt-0.5" style={{ color: C.inkLight }}>
                          Staff cannot enter a % higher than this during walk-in billing
                        </p>
                      </div>
                      <div className="flex items-end gap-1">
                        <div className="w-20 h-20 rounded-2xl flex items-center justify-center"
                          style={{ background: `linear-gradient(135deg,${C.gold},${C.goldLight})` }}>
                          <span className="text-3xl font-black text-white">{maxDiscount}</span>
                        </div>
                        <span className="text-2xl font-black mb-2" style={{ color: C.gold }}>%</span>
                      </div>
                    </div>

                    {/* slider */}
                    <div>
                      <input type="range" min={0} max={100} step={1}
                        value={maxDiscount}
                        onChange={e => updateField('billing.maxDiscountPercent', Number(e.target.value))}
                        style={{ width: '100%', accentColor: C.gold, cursor: 'pointer' }} />
                      <div className="flex justify-between text-[10px] font-semibold mt-1" style={{ color: C.inkLight }}>
                        <span>0%</span><span>25%</span><span>50%</span><span>75%</span><span>100%</span>
                      </div>
                    </div>

                    {/* quick preset buttons */}
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[11px] font-bold" style={{ color: C.inkLight }}>Quick set:</span>
                      {[5, 10, 15, 20, 25, 30, 50].map(v => (
                        <button key={v} type="button"
                          onClick={() => updateField('billing.maxDiscountPercent', v)}
                          className="px-3 py-1.5 rounded-full text-xs font-bold transition-all"
                          style={{
                            background: maxDiscount === v
                              ? `linear-gradient(135deg,${C.gold},${C.goldLight})`
                              : C.creamDark,
                            color: maxDiscount === v ? '#fff' : C.inkMid,
                          }}>
                          {v}%
                        </button>
                      ))}
                    </div>

                    {/* high % warning */}
                    <AnimatePresence>
                      {maxDiscount > 30 && (
                        <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                          className="flex items-center gap-2 px-3 py-2 rounded-xl"
                          style={{ background: '#FEF3C7', border: '1px solid #FCD34D' }}>
                          <span>⚠️</span>
                          <p className="text-xs font-semibold" style={{ color: '#92400E' }}>
                            High limit — staff can give up to {maxDiscount}% off. Make sure this is intentional.
                          </p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* ── loyalty points ── */}
            <div>
              <SectionTitle>Loyalty Points</SectionTitle>
              <div className="px-5 py-5 rounded-xl space-y-3"
                style={{ background: C.cream, border: `1px solid ${C.creamBorder}` }}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-semibold" style={{ color: C.ink }}>Points earned per ₹100 spent</p>
                    <p className="text-xs mt-0.5" style={{ color: C.inkLight }}>
                      Customer earns this many loyalty points for every ₹100 they pay
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Star size={16} style={{ color: C.gold }} />
                    <span className="text-3xl font-black" style={{ color: C.gold }}>
                      {settings.billing?.loyaltyPointsPerRupee ?? 1}
                    </span>
                    <span className="text-sm font-semibold" style={{ color: C.inkLight }}>pt</span>
                  </div>
                </div>
                <input type="range" min={1} max={10} step={1}
                  value={settings.billing?.loyaltyPointsPerRupee ?? 1}
                  onChange={e => updateField('billing.loyaltyPointsPerRupee', Number(e.target.value))}
                  style={{ width: '100%', accentColor: C.gold, cursor: 'pointer' }} />
                <div className="flex justify-between text-[10px] font-semibold" style={{ color: C.inkLight }}>
                  {[1,2,3,4,5,6,7,8,9,10].map(v => <span key={v}>{v}</span>)}
                </div>
              </div>
            </div>

          </motion.div>
        )}

        {/* ── PAYMENT ─────────────────────────────────────────────── */}
        {activeTab === 'payment' && (
          <motion.div key="payment" variants={fade} initial="hidden" animate="show" exit="hidden"
            className="rounded-2xl p-6 space-y-6"
            style={{ background: C.white, border: `1px solid ${C.creamBorder}` }}>
            <SectionTitle>In-Store Payment Methods</SectionTitle>
            <div className="px-4 rounded-xl divide-y"
              style={{ background: C.cream, border: `1px solid ${C.creamBorder}` }}>
              {[
                ['payAtSalonEnabled', 'Pay at Salon',  'Allow customers to pay at the counter'],
                ['acceptCash',        'Cash',           'Accept cash payments'],
                ['acceptUPI',         'UPI',            'Accept UPI (GPay, PhonePe, Paytm etc.)'],
                ['acceptCard',        'Card',           'Accept debit/credit card payments'],
              ].map(([key, label, desc]) => (
                <Toggle key={key}
                  checked={settings.payment?.[key] !== false}
                  onChange={v => updateField(`payment.${key}`, v)}
                  label={label} description={desc} />
              ))}
            </div>

            <SectionTitle>Razorpay Online Payments</SectionTitle>
            <div className="px-4 rounded-xl" style={{ background: C.cream, border: `1px solid ${C.creamBorder}` }}>
              <Toggle
                checked={settings.payment?.razorpayEnabled || false}
                onChange={v => updateField('payment.razorpayEnabled', v)}
                label="Enable Razorpay"
                description="Accept online payments from customers during booking" />
            </div>
            <AnimatePresence>
              {settings.payment?.razorpayEnabled && (
                <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                  className="grid grid-cols-1 sm:grid-cols-2 gap-4 px-5 py-4 rounded-xl"
                  style={{ background: C.cream, border: `1px solid ${C.creamBorder}` }}>
                  <Field label="Razorpay Key ID">
                    <input style={inp()} type="text" placeholder="rzp_live_xxxxxxxxxxxxx"
                      value={settings.payment?.razorpayKeyId || ''}
                      onChange={e => updateField('payment.razorpayKeyId', e.target.value)}
                      onFocus={e => e.target.style.borderColor = C.gold}
                      onBlur={e => e.target.style.borderColor = C.creamBorder} />
                  </Field>
                  <Field label="Razorpay Key Secret">
                    <input style={inp()} type="password" placeholder="Enter secret key"
                      value={settings.payment?.razorpayKeySecret || ''}
                      onChange={e => updateField('payment.razorpayKeySecret', e.target.value)}
                      onFocus={e => e.target.style.borderColor = C.gold}
                      onBlur={e => e.target.style.borderColor = C.creamBorder} />
                  </Field>
                  <p className="sm:col-span-2 text-xs" style={{ color: C.inkLight }}>
                    Get your keys from{' '}
                    <a href="https://dashboard.razorpay.com/app/keys" target="_blank" rel="noreferrer"
                      style={{ color: C.gold, textDecoration: 'underline' }}>Razorpay Dashboard</a>.
                    Payments go directly to your linked bank account.
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}

        {/* ── TAX ─────────────────────────────────────────────────── */}
        {activeTab === 'tax' && (
          <motion.div key="tax" variants={fade} initial="hidden" animate="show" exit="hidden"
            className="rounded-2xl p-6 space-y-6"
            style={{ background: C.white, border: `1px solid ${C.creamBorder}` }}>
            <SectionTitle>GST & Tax</SectionTitle>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="GST Number">
                <input style={inp()} type="text" placeholder="22AAAAA0000A1Z5"
                  value={settings.gstNumber || ''}
                  onChange={e => updateField('gstNumber', e.target.value)}
                  onFocus={e => e.target.style.borderColor = C.gold}
                  onBlur={e => e.target.style.borderColor = C.creamBorder} />
              </Field>
              <Field label="Tax Rate (%)">
                <input style={inp()} type="number" min={0} max={28}
                  value={settings.taxRate ?? 18}
                  onChange={e => updateField('taxRate', parseFloat(e.target.value))}
                  onFocus={e => e.target.style.borderColor = C.gold}
                  onBlur={e => e.target.style.borderColor = C.creamBorder} />
              </Field>
            </div>
            <p className="text-xs" style={{ color: C.inkLight }}>
              GST will be automatically calculated on all invoices using this rate.
            </p>
          </motion.div>
        )}

        {/* ── THEME ───────────────────────────────────────────────── */}
        {activeTab === 'theme' && (
          <motion.div key="theme" variants={fade} initial="hidden" animate="show" exit="hidden"
            className="rounded-2xl p-6 space-y-6"
            style={{ background: C.white, border: `1px solid ${C.creamBorder}` }}>
            <SectionTitle>Brand Colors</SectionTitle>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                ['Primary Color',    'theme.primaryColor',    '#C9A96E'],
                ['Accent Color',     'theme.accentColor',     '#2C2C2C'],
                ['Background Color', 'theme.backgroundColor', '#FAF7F2'],
              ].map(([label, path, def]) => (
                <Field key={path} label={label}>
                  <div className="flex items-center gap-2">
                    <input type="color"
                      value={settings.theme?.[path.split('.')[1]] || def}
                      onChange={e => updateField(path, e.target.value)}
                      className="w-11 h-11 rounded-xl cursor-pointer flex-shrink-0"
                      style={{ border: `1px solid ${C.creamBorder}`, padding: 2, background: 'transparent' }} />
                    <input style={inp()} type="text"
                      value={settings.theme?.[path.split('.')[1]] || def}
                      onChange={e => updateField(path, e.target.value)}
                      onFocus={e => e.target.style.borderColor = C.gold}
                      onBlur={e => e.target.style.borderColor = C.creamBorder} />
                  </div>
                </Field>
              ))}
            </div>

            <SectionTitle>Live Preview</SectionTitle>
            <div className="rounded-2xl p-6 border transition-all"
              style={{ backgroundColor: settings.theme?.backgroundColor || '#FAF7F2', border: `1px solid ${C.creamBorder}` }}>
              <h3 className="text-xl font-bold" style={{ fontFamily: "'Playfair Display',serif", color: settings.theme?.accentColor || '#2C2C2C' }}>
                {settings.salonName || 'Salon Name'}
                <span style={{ color: settings.theme?.primaryColor || '#C9A96E' }}>.</span>
              </h3>
              <p className="text-sm mt-1" style={{ color: settings.theme?.accentColor || '#2C2C2C', opacity: 0.6 }}>
                {settings.tagline || 'Your tagline here'}
              </p>
              <button className="mt-4 px-6 py-2 rounded-xl text-white text-sm font-bold"
                style={{ background: `linear-gradient(135deg,${settings.theme?.primaryColor || '#C9A96E'},${settings.theme?.accentColor || '#2C2C2C'})` }}>
                Book Appointment
              </button>
            </div>
          </motion.div>
        )}

      </AnimatePresence>
    </motion.div>
  );
};

export default AdminSettings;