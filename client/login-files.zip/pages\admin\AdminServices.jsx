import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus, Search, Edit2, Trash2, Loader2, Clock,
  Sparkles, Filter, X, Copy, ToggleLeft, ToggleRight,
  Tag, IndianRupee, Grid, List, RefreshCw,
  CheckSquare, Square, Scissors,
} from 'lucide-react';
import api from '@/services/api';
import ServiceModal from '@/components/ServiceModal';

// ─── design tokens (exact match to AdminBookings) ─────────────────────────────
const C = {
  cream: '#FDF8F0', creamDark: '#F5EDD8', creamBorder: '#E8D9B8',
  gold: '#B8860B', goldLight: '#DAA520', goldPale: '#FFF8E7',
  ink: '#1C1410', inkMid: '#5C4A2A', inkLight: '#9C8660', white: '#FFFFFF',
  green: '#10B981', red: '#EF4444', redPale: '#FEF2F2',
};

const fade = {
  hidden: { opacity: 0, y: 14 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.4, ease: [0.22, 0.61, 0.36, 1] } },
};
const stagger = {
  hidden: { opacity: 0 },
  show:   { opacity: 1, transition: { staggerChildren: 0.05 } },
};

const categoryMeta = {
  hair:     { emoji: '💇', label: 'Hair',      color: '#8B5CF6' },
  skin:     { emoji: '✨', label: 'Skin Care',  color: '#EC4899' },
  nails:    { emoji: '💅', label: 'Nails',     color: '#F59E0B' },
  makeup:   { emoji: '💄', label: 'Makeup',    color: '#EF4444' },
  spa:      { emoji: '🧖', label: 'Spa',       color: '#06B6D4' },
  bridal:   { emoji: '👰', label: 'Bridal',    color: '#B8860B' },
  grooming: { emoji: '🧔', label: 'Grooming',  color: '#6B7280' },
  combo:    { emoji: '🎁', label: 'Combo',     color: '#10B981' },
};

const fmtDuration = (min) => {
  if (!min) return '—';
  if (min < 60) return `${min}m`;
  const h = Math.floor(min / 60), m = min % 60;
  return m ? `${h}h ${m}m` : `${h}h`;
};
const fmtPrice = (n) => n?.toLocaleString('en-IN') ?? '—';

const inp = (extra = {}) => ({
  padding: '10px 14px', borderRadius: 12, border: `1px solid ${C.creamBorder}`,
  background: C.cream, fontSize: 13, color: C.ink, outline: 'none',
  width: '100%', fontFamily: "'DM Sans',sans-serif", ...extra,
});

// ─── stat card ────────────────────────────────────────────────────────────────
const StatCard = ({ label, value, icon: Icon, accent }) => (
  <motion.div variants={fade} whileHover={{ y: -3 }}
    className="rounded-2xl p-4 flex items-center gap-3 transition-all"
    style={{ background: C.white, border: `1px solid ${C.creamBorder}`, boxShadow: '0 2px 12px rgba(184,134,11,0.05)' }}>
    <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
      style={{ background: `${accent}18` }}>
      <Icon size={18} style={{ color: accent }} />
    </div>
    <div>
      <p className="text-lg font-bold" style={{ fontFamily: "'Playfair Display',serif", color: C.ink }}>{value}</p>
      <p className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: C.inkLight }}>{label}</p>
    </div>
  </motion.div>
);

// ─── grid card ────────────────────────────────────────────────────────────────
const ServiceCard = ({ service, selected, onSelect, onEdit, onDelete, onToggle, onDuplicate }) => {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const cat = categoryMeta[service.category] || { emoji: '✨', label: service.category, color: C.gold };
  const discount = service.discountPrice && service.discountPrice < service.price;
  const discountPct = discount ? Math.round((1 - service.discountPrice / service.price) * 100) : 0;

  return (
    <motion.div variants={fade} layout whileHover={{ y: -2 }}
      className="group relative rounded-2xl overflow-hidden transition-all duration-300"
      style={{
        background: C.white,
        border: `1px solid ${selected ? C.gold : C.creamBorder}`,
        boxShadow: selected ? `0 0 0 2px ${C.gold}40, 0 4px 20px rgba(184,134,11,0.12)` : '0 2px 12px rgba(184,134,11,0.06)',
      }}>

      {/* banner */}
      <div className="relative h-40 overflow-hidden"
        style={{ background: `linear-gradient(135deg,${cat.color}20,${C.creamDark})` }}>
        {service.image
          ? <img src={service.image} alt={service.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
          : <div className="w-full h-full flex items-center justify-center"><span className="text-6xl select-none">{cat.emoji}</span></div>
        }
        <div className="absolute inset-0" style={{ background: 'linear-gradient(to top,rgba(28,20,16,0.55) 0%,transparent 55%)' }} />

        {/* top row */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
          <button onClick={() => onSelect(service._id)}
            className="w-6 h-6 flex items-center justify-center rounded-lg transition-all"
            style={{ background: selected ? C.gold : 'rgba(255,255,255,0.88)' }}>
            {selected ? <CheckSquare size={13} className="text-white" /> : <Square size={13} style={{ color: C.inkMid }} />}
          </button>
          <span className="text-[10px] font-bold px-2.5 py-1 rounded-full"
            style={{ background: service.isActive ? 'rgba(16,185,129,0.88)' : 'rgba(239,68,68,0.88)', color: '#fff', backdropFilter: 'blur(4px)' }}>
            {service.isActive ? 'Active' : 'Inactive'}
          </span>
        </div>

        {/* bottom row */}
        <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between">
          <span className="text-[10px] font-bold px-2.5 py-1 rounded-lg"
            style={{ background: 'rgba(0,0,0,0.32)', color: '#fff', backdropFilter: 'blur(4px)' }}>
            {cat.emoji} {cat.label}
          </span>
          {discount && (
            <span className="text-[10px] font-bold px-2 py-1 rounded-lg" style={{ background: C.gold, color: '#fff' }}>
              {discountPct}% OFF
            </span>
          )}
        </div>
      </div>

      {/* body */}
      <div className="p-4">
        <div className="flex items-start justify-between mb-1 gap-2">
          <h3 className="text-sm font-bold leading-snug" style={{ color: C.ink, fontFamily: "'Playfair Display',serif" }}>
            {service.name}
          </h3>
          <div className="text-right shrink-0">
            {discount ? (
              <>
                <p className="text-sm font-bold" style={{ color: C.gold }}>₹{fmtPrice(service.discountPrice)}</p>
                <p className="text-[10px] line-through" style={{ color: C.inkLight }}>₹{fmtPrice(service.price)}</p>
              </>
            ) : (
              <p className="text-sm font-bold" style={{ color: C.gold }}>₹{fmtPrice(service.price)}</p>
            )}
          </div>
        </div>

        <p className="text-[11px] mb-3 line-clamp-2" style={{ color: C.inkLight }}>
          {service.description || 'No description provided'}
        </p>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1 text-[11px] font-semibold px-2 py-1 rounded-full"
              style={{ background: C.goldPale, color: C.inkMid }}>
              <Clock size={10} /> {fmtDuration(service.duration)}
            </span>
            <span className="text-[11px] font-semibold px-2 py-1 rounded-full capitalize"
              style={{ background: C.creamDark, color: C.inkMid }}>
              {service.gender || 'all'}
            </span>
          </div>

          {/* action buttons — show on hover */}
          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <button onClick={() => onDuplicate(service)} title="Duplicate"
              className="w-7 h-7 flex items-center justify-center rounded-lg hover:opacity-80"
              style={{ background: C.goldPale }}>
              <Copy size={12} style={{ color: C.gold }} />
            </button>
            <button onClick={() => onToggle(service)} title={service.isActive ? 'Deactivate' : 'Activate'}
              className="w-7 h-7 flex items-center justify-center rounded-lg hover:opacity-80"
              style={{ background: service.isActive ? '#ECFDF5' : C.redPale }}>
              {service.isActive
                ? <ToggleRight size={12} style={{ color: C.green }} />
                : <ToggleLeft  size={12} style={{ color: C.red }} />}
            </button>
            <button onClick={() => onEdit(service)} title="Edit"
              className="w-7 h-7 flex items-center justify-center rounded-lg hover:opacity-80"
              style={{ background: C.goldPale }}>
              <Edit2 size={12} style={{ color: C.gold }} />
            </button>
            <button onClick={() => setConfirmDelete(true)} title="Delete"
              className="w-7 h-7 flex items-center justify-center rounded-lg hover:opacity-80"
              style={{ background: C.redPale }}>
              <Trash2 size={12} style={{ color: C.red }} />
            </button>
          </div>
        </div>
      </div>

      {/* delete overlay */}
      <AnimatePresence>
        {confirmDelete && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="absolute inset-0 flex flex-col items-center justify-center p-5 rounded-2xl"
            style={{ background: 'rgba(253,248,240,0.97)', backdropFilter: 'blur(4px)' }}>
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-3" style={{ background: C.redPale }}>
              <Trash2 size={20} style={{ color: C.red }} />
            </div>
            <p className="text-sm font-bold mb-1" style={{ color: C.ink }}>Delete this service?</p>
            <p className="text-xs mb-4 text-center" style={{ color: C.inkLight }}>This cannot be undone</p>
            <div className="flex gap-2">
              <button onClick={() => setConfirmDelete(false)}
                className="px-4 py-1.5 rounded-xl text-xs font-bold hover:opacity-80"
                style={{ background: C.creamDark, color: C.inkMid }}>Cancel</button>
              <button onClick={() => { onDelete(service._id); setConfirmDelete(false); }}
                className="px-4 py-1.5 rounded-xl text-xs font-bold text-white hover:opacity-80"
                style={{ background: C.red }}>Delete</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

// ─── list row ─────────────────────────────────────────────────────────────────
const ServiceRow = ({ service, selected, onSelect, onEdit, onDelete, onToggle, onDuplicate }) => {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const cat = categoryMeta[service.category] || { emoji: '✨', label: service.category, color: C.gold };
  const discount = service.discountPrice && service.discountPrice < service.price;

  return (
    <motion.div variants={fade} layout
      className="flex items-center gap-3 px-4 py-3 rounded-2xl transition-all"
      style={{
        background: selected ? C.goldPale : C.white,
        border: `1px solid ${selected ? C.gold : C.creamBorder}`,
      }}>
      <button onClick={() => onSelect(service._id)}
        className="w-6 h-6 flex items-center justify-center rounded-lg flex-shrink-0"
        style={{ background: selected ? C.gold : C.creamDark }}>
        {selected ? <CheckSquare size={13} className="text-white" /> : <Square size={13} style={{ color: C.inkLight }} />}
      </button>

      <div className="w-9 h-9 rounded-xl flex items-center justify-center text-lg flex-shrink-0"
        style={{ background: `${cat.color}18` }}>
        {cat.emoji}
      </div>

      <div className="flex-1 min-w-0">
        <p className="text-sm font-bold truncate" style={{ color: C.ink }}>{service.name}</p>
        <p className="text-[11px] truncate" style={{ color: C.inkLight }}>{service.description || '—'}</p>
      </div>

      <span className="hidden sm:block text-[11px] font-semibold px-2.5 py-1 rounded-full flex-shrink-0"
        style={{ background: `${cat.color}15`, color: cat.color }}>{cat.label}</span>

      <span className="hidden md:flex items-center gap-1 text-[11px] font-semibold flex-shrink-0"
        style={{ color: C.inkMid }}>
        <Clock size={10} /> {fmtDuration(service.duration)}
      </span>

      <div className="text-right flex-shrink-0">
        {discount ? (
          <>
            <p className="text-sm font-bold" style={{ color: C.gold }}>₹{fmtPrice(service.discountPrice)}</p>
            <p className="text-[10px] line-through" style={{ color: C.inkLight }}>₹{fmtPrice(service.price)}</p>
          </>
        ) : (
          <p className="text-sm font-bold" style={{ color: C.gold }}>₹{fmtPrice(service.price)}</p>
        )}
      </div>

      <span className="text-[10px] font-bold px-2.5 py-1 rounded-full flex-shrink-0"
        style={{ background: service.isActive ? '#ECFDF5' : C.redPale, color: service.isActive ? C.green : C.red }}>
        {service.isActive ? 'Active' : 'Inactive'}
      </span>

      {!confirmDelete ? (
        <div className="flex gap-1 flex-shrink-0">
          {[
            [() => onDuplicate(service), Copy,       C.goldPale, C.gold,  'Duplicate'],
            [() => onToggle(service),    service.isActive ? ToggleRight : ToggleLeft,
              service.isActive ? '#ECFDF5' : C.redPale,
              service.isActive ? C.green : C.red, 'Toggle'],
            [() => onEdit(service),      Edit2,      C.goldPale, C.gold,  'Edit'],
            [() => setConfirmDelete(true), Trash2,   C.redPale,  C.red,   'Delete'],
          ].map(([fn, Icon, bg, color, title], i) => (
            <button key={i} onClick={fn} title={title}
              className="w-7 h-7 flex items-center justify-center rounded-lg hover:opacity-80"
              style={{ background: bg }}>
              <Icon size={12} style={{ color }} />
            </button>
          ))}
        </div>
      ) : (
        <div className="flex gap-2 flex-shrink-0">
          <button onClick={() => setConfirmDelete(false)}
            className="px-3 py-1 rounded-lg text-xs font-bold hover:opacity-80"
            style={{ background: C.creamDark, color: C.inkMid }}>Cancel</button>
          <button onClick={() => { onDelete(service._id); setConfirmDelete(false); }}
            className="px-3 py-1 rounded-lg text-xs font-bold text-white hover:opacity-80"
            style={{ background: C.red }}>Delete</button>
        </div>
      )}
    </motion.div>
  );
};

// ═════════════════════════════════════════════════════════════════════════════
const AdminServices = () => {
  const [services,       setServices]       = useState([]);
  const [loading,        setLoading]        = useState(true);
  const [modalOpen,      setModalOpen]      = useState(false);
  const [editingService, setEditingService] = useState(null);
  const [saving,         setSaving]         = useState(false);
  const [searchQuery,    setSearchQuery]    = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterStatus,   setFilterStatus]   = useState('');
  const [filterGender,   setFilterGender]   = useState('');
  const [viewMode,       setViewMode]       = useState('grid');
  const [selected,       setSelected]       = useState(new Set());
  const [bulkLoading,    setBulkLoading]    = useState(false);
  const [showFilters,    setShowFilters]    = useState(false);

  const fetchServices = useCallback(async () => {
    try {
      setLoading(true);
      const params = { showAll: true, includeInactive: true }; // admin always sees all
      if (searchQuery)    params.search   = searchQuery;
      if (filterCategory) params.category = filterCategory;
      const { data } = await api.get('/services', { params });
      setServices(data.services || []);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [searchQuery, filterCategory]);

  useEffect(() => { fetchServices(); }, [fetchServices]);

  // client-side filters
  const displayed = services.filter(s => {
    if (filterStatus === 'active'   && !s.isActive) return false;
    if (filterStatus === 'inactive' &&  s.isActive) return false;
    if (filterGender && s.gender && s.gender !== filterGender) return false;
    return true;
  });

  // stats
  const totalActive   = services.filter(s => s.isActive).length;
  const totalInactive = services.filter(s => !s.isActive).length;
  const withDiscount  = services.filter(s => s.discountPrice && s.discountPrice < s.price).length;
  const avgPrice      = services.length
    ? Math.round(services.reduce((a, s) => a + (s.discountPrice || s.price || 0), 0) / services.length)
    : 0;

  // selection
  const toggleSelect = (id) => setSelected(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const selectAll    = () => setSelected(new Set(displayed.map(s => s._id)));
  const clearSelect  = () => setSelected(new Set());
  const allSelected  = displayed.length > 0 && displayed.every(s => selected.has(s._id));

  // handlers
  const handleAdd  = () => { setEditingService(null); setModalOpen(true); };
  const handleEdit = (s) => { setEditingService(s); setModalOpen(true); };

  const handleSubmit = async (formData) => {
    try {
      setSaving(true);
      editingService
        ? await api.put(`/services/${editingService._id}`, formData)
        : await api.post('/services', formData);
      setModalOpen(false); setEditingService(null); fetchServices();
    } catch (e) { console.error(e); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    try { await api.delete(`/services/${id}`); fetchServices(); } catch(e) { console.error(e); }
  };

  const handleToggle = async (svc) => {
    // optimistic update first so UI feels instant
    setServices(prev => prev.map(s => s._id === svc._id ? { ...s, isActive: !s.isActive } : s));
    try {
      // try PATCH first, fall back to PUT if 404/405
      try {
        await api.patch(`/services/${svc._id}`, { isActive: !svc.isActive });
      } catch (patchErr) {
        if (patchErr.response?.status === 404 || patchErr.response?.status === 405) {
          await api.put(`/services/${svc._id}`, { ...svc, isActive: !svc.isActive });
        } else throw patchErr;
      }
      fetchServices(); // sync with server
    } catch(e) {
      // revert optimistic update on failure
      setServices(prev => prev.map(s => s._id === svc._id ? { ...s, isActive: svc.isActive } : s));
      console.error('Toggle failed:', e);
    }
  };

  const handleDuplicate = async (svc) => {
    try {
      const { _id, createdAt, updatedAt, __v, ...rest } = svc;
      await api.post('/services', { ...rest, name: `${svc.name} (Copy)`, isActive: false });
      fetchServices();
    } catch(e) { console.error(e); }
  };

  const bulkAction = async (action) => {
    if (!selected.size) return;
    setBulkLoading(true);
    try {
      const ids = [...selected];
      if (action === 'delete') {
        await Promise.all(ids.map(id => api.delete(`/services/${id}`)));
      } else {
        const isActive = action === 'activate';
        // optimistic update
        setServices(prev => prev.map(s => ids.includes(s._id) ? { ...s, isActive } : s));
        try {
          await Promise.all(ids.map(id => api.patch(`/services/${id}`, { isActive })));
        } catch {
          await Promise.all(ids.map(id => {
            const svc = services.find(s => s._id === id);
            return svc ? api.put(`/services/${id}`, { ...svc, isActive }) : Promise.resolve();
          }));
        }
      }
      clearSelect(); fetchServices();
    } catch(e) { console.error(e); }
    finally { setBulkLoading(false); }
  };

  const activeFiltersCount = [filterCategory, filterStatus, filterGender].filter(Boolean).length;

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <motion.div variants={stagger} initial="hidden" animate="show"
      className="min-h-screen pb-12 space-y-5"
      style={{ background: C.cream, fontFamily: "'DM Sans',sans-serif" }}>

      {/* ══ HEADER ══════════════════════════════════════════════════════ */}
      <motion.div variants={fade}
        className="relative overflow-hidden rounded-2xl px-7 py-6"
        style={{ background: `linear-gradient(135deg,${C.ink} 0%,#2d2510 100%)`, border: `1px solid #3d3010` }}>
        <div className="absolute inset-0 opacity-10"
          style={{ backgroundImage: 'repeating-linear-gradient(45deg,#B8860B 0,#B8860B 1px,transparent 0,transparent 50%)', backgroundSize: '18px 18px' }} />
        <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full opacity-10"
          style={{ background: `radial-gradient(circle,${C.goldLight},transparent)` }} />
        <div className="relative flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Sparkles size={13} style={{ color: C.goldLight }} />
              <span className="text-[11px] font-bold tracking-[0.18em] uppercase" style={{ color: C.goldLight }}>Services</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-white" style={{ fontFamily: "'Playfair Display',serif" }}>
              Manage Services
            </h1>
            <p className="text-sm mt-1" style={{ color: '#9ca3af' }}>
              {displayed.length} service{displayed.length !== 1 ? 's' : ''} · {totalActive} active · {totalInactive} inactive
            </p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button onClick={fetchServices}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold hover:opacity-80"
              style={{ background: 'rgba(255,255,255,0.1)', color: '#fff', border: '1px solid rgba(255,255,255,0.15)' }}>
              <RefreshCw size={13} /> Refresh
            </button>
            <button onClick={handleAdd}
              className="flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold hover:opacity-90 shadow-lg"
              style={{ background: `linear-gradient(135deg,${C.gold},${C.goldLight})`, color: '#fff' }}>
              <Plus size={15} /> Add Service
            </button>
          </div>
        </div>
      </motion.div>

      {/* ══ STATS ═══════════════════════════════════════════════════════ */}
      <motion.div variants={fade} className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <StatCard label="Total"       value={services.length}         icon={Scissors}      accent={C.gold}    />
        <StatCard label="Active"      value={totalActive}             icon={ToggleRight}   accent={C.green}   />
        <StatCard label="On Discount" value={withDiscount}            icon={Tag}           accent="#F59E0B"   />
        <StatCard label="Avg Price"   value={`₹${fmtPrice(avgPrice)}`} icon={IndianRupee}  accent="#8B5CF6"   />
      </motion.div>

      {/* ══ BULK ACTION BAR ═════════════════════════════════════════════ */}
      <AnimatePresence>
        {selected.size > 0 && (
          <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
            className="rounded-2xl px-5 py-3 flex items-center justify-between flex-wrap gap-3"
            style={{ background: C.goldPale, border: `1px solid ${C.gold}` }}>
            <div className="flex items-center gap-3">
              <span className="text-sm font-bold" style={{ color: C.ink }}>{selected.size} selected</span>
              <button onClick={clearSelect} className="text-xs font-semibold hover:opacity-70" style={{ color: C.inkLight }}>Clear</button>
            </div>
            <div className="flex items-center gap-2">
              {bulkLoading ? <Loader2 size={16} className="animate-spin" style={{ color: C.gold }} /> : (
                <>
                  <button onClick={() => bulkAction('activate')}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold hover:opacity-80"
                    style={{ background: '#ECFDF5', color: C.green }}>
                    <ToggleRight size={13} /> Activate
                  </button>
                  <button onClick={() => bulkAction('deactivate')}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold hover:opacity-80"
                    style={{ background: C.redPale, color: C.red }}>
                    <ToggleLeft size={13} /> Deactivate
                  </button>
                  <button onClick={() => bulkAction('delete')}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold text-white hover:opacity-80"
                    style={{ background: C.red }}>
                    <Trash2 size={13} /> Delete
                  </button>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ══ SEARCH + FILTERS ════════════════════════════════════════════ */}
      <motion.div variants={fade} className="rounded-2xl p-4 space-y-3"
        style={{ background: C.white, border: `1px solid ${C.creamBorder}` }}>

        <div className="flex flex-wrap items-center gap-3">
          {/* search */}
          <div className="relative flex-1 min-w-[180px]">
            <Search size={14} style={{ color: C.inkLight, position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }} />
            <input style={{ ...inp(), paddingLeft: 36 }} placeholder="Search services…"
              value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
              onFocus={e => e.target.style.borderColor = C.gold}
              onBlur={e => e.target.style.borderColor = C.creamBorder} />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)' }}>
                <X size={13} style={{ color: C.inkLight }} />
              </button>
            )}
          </div>

          {/* extra filters */}
          <button onClick={() => setShowFilters(f => !f)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-full text-xs font-semibold transition-all relative"
            style={{ background: showFilters ? C.ink : C.cream, color: showFilters ? '#fff' : C.inkMid, border: `1px solid ${showFilters ? C.ink : C.creamBorder}` }}>
            <Filter size={12} /> Filters
            {activeFiltersCount > 0 && (
              <span className="w-4 h-4 rounded-full text-[10px] font-bold flex items-center justify-center"
                style={{ background: C.gold, color: '#fff' }}>{activeFiltersCount}</span>
            )}
          </button>

          {/* view toggle */}
          <div className="flex gap-1 rounded-xl p-1" style={{ background: C.cream, border: `1px solid ${C.creamBorder}` }}>
            {[['grid', Grid], ['list', List]].map(([mode, Icon]) => (
              <button key={mode} onClick={() => setViewMode(mode)}
                className="w-8 h-8 flex items-center justify-center rounded-lg transition-all"
                style={{ background: viewMode === mode ? C.white : 'transparent', color: viewMode === mode ? C.gold : C.inkLight, boxShadow: viewMode === mode ? '0 1px 4px rgba(0,0,0,0.08)' : 'none' }}>
                <Icon size={14} />
              </button>
            ))}
          </div>

          {/* select all */}
          <button onClick={allSelected ? clearSelect : selectAll}
            className="flex items-center gap-1.5 px-3 py-2 rounded-full text-xs font-semibold"
            style={{ background: C.cream, color: C.inkMid, border: `1px solid ${C.creamBorder}` }}>
            {allSelected ? <CheckSquare size={12} style={{ color: C.gold }} /> : <Square size={12} />}
            {allSelected ? 'Deselect All' : 'Select All'}
          </button>
        </div>

        {/* category pills */}
        <div className="flex gap-2 flex-wrap">
          {[['', 'All ✦'], ...Object.entries(categoryMeta).map(([k, v]) => [k, `${v.emoji} ${v.label}`])].map(([val, lbl]) => (
            <button key={val} onClick={() => setFilterCategory(val)}
              className="px-3 py-1.5 rounded-full text-xs font-semibold transition-all"
              style={{
                background: filterCategory === val ? `linear-gradient(135deg,${C.gold},${C.goldLight})` : C.cream,
                color: filterCategory === val ? '#fff' : C.inkMid,
                border: `1px solid ${filterCategory === val ? C.gold : C.creamBorder}`,
              }}>{lbl}</button>
          ))}
        </div>

        {/* extra filters panel */}
        <AnimatePresence>
          {showFilters && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden">
              <div className="pt-3 flex flex-wrap gap-4" style={{ borderTop: `1px solid ${C.creamDark}` }}>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[11px] font-bold uppercase tracking-wider" style={{ color: C.inkLight }}>Status:</span>
                  {[['', 'All'], ['active', 'Active'], ['inactive', 'Inactive']].map(([v, l]) => (
                    <button key={v} onClick={() => setFilterStatus(v)}
                      className="px-3 py-1.5 rounded-full text-xs font-semibold"
                      style={{ background: filterStatus === v ? C.ink : C.cream, color: filterStatus === v ? '#fff' : C.inkMid, border: `1px solid ${filterStatus === v ? C.ink : C.creamBorder}` }}>{l}</button>
                  ))}
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[11px] font-bold uppercase tracking-wider" style={{ color: C.inkLight }}>Gender:</span>
                  {[['', 'All'], ['male', 'Male'], ['female', 'Female'], ['unisex', 'Unisex']].map(([v, l]) => (
                    <button key={v} onClick={() => setFilterGender(v)}
                      className="px-3 py-1.5 rounded-full text-xs font-semibold"
                      style={{ background: filterGender === v ? C.ink : C.cream, color: filterGender === v ? '#fff' : C.inkMid, border: `1px solid ${filterGender === v ? C.ink : C.creamBorder}` }}>{l}</button>
                  ))}
                </div>
                {activeFiltersCount > 0 && (
                  <button onClick={() => { setFilterStatus(''); setFilterGender(''); setFilterCategory(''); }}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold"
                    style={{ background: C.redPale, color: C.red }}>
                    <X size={11} /> Clear all
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* ══ SERVICES LIST / GRID ════════════════════════════════════════ */}
      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 gap-3">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center"
            style={{ background: `linear-gradient(135deg,${C.gold},${C.goldLight})` }}>
            <Loader2 size={22} className="text-white animate-spin" />
          </div>
          <p className="text-sm font-medium" style={{ color: C.inkLight }}>Loading services…</p>
        </div>
      ) : displayed.length === 0 ? (
        <motion.div variants={fade} className="flex flex-col items-center justify-center py-24 gap-4 rounded-2xl"
          style={{ background: C.white, border: `1px solid ${C.creamBorder}` }}>
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center"
            style={{ background: C.goldPale, border: `1px solid ${C.creamBorder}` }}>
            <Scissors size={28} style={{ color: C.gold }} />
          </div>
          <div className="text-center">
            <p className="font-bold" style={{ color: C.ink }}>No services found</p>
            <p className="text-xs mt-1" style={{ color: C.inkLight }}>
              {searchQuery ? 'Try a different search' : 'Add your first service to get started'}
            </p>
          </div>
          <button onClick={handleAdd}
            className="flex items-center gap-2 text-xs font-bold px-5 py-2.5 rounded-full"
            style={{ background: `linear-gradient(135deg,${C.gold},${C.goldLight})`, color: '#fff' }}>
            <Plus size={13} /> Add Service
          </button>
        </motion.div>
      ) : viewMode === 'grid' ? (
        <motion.div variants={stagger} className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {displayed.map(s => (
            <ServiceCard key={s._id} service={s}
              selected={selected.has(s._id)}
              onSelect={toggleSelect} onEdit={handleEdit}
              onDelete={handleDelete} onToggle={handleToggle} onDuplicate={handleDuplicate} />
          ))}
        </motion.div>
      ) : (
        <motion.div variants={stagger} className="space-y-2">
          {displayed.map(s => (
            <ServiceRow key={s._id} service={s}
              selected={selected.has(s._id)}
              onSelect={toggleSelect} onEdit={handleEdit}
              onDelete={handleDelete} onToggle={handleToggle} onDuplicate={handleDuplicate} />
          ))}
        </motion.div>
      )}

      {!loading && displayed.length > 0 && (
        <p className="text-center text-xs font-medium" style={{ color: C.inkLight }}>
          Showing {displayed.length} of {services.length} services
        </p>
      )}

      {/* ══ MODAL ═══════════════════════════════════════════════════════ */}
      <ServiceModal
        isOpen={modalOpen}
        onClose={() => { setModalOpen(false); setEditingService(null); }}
        onSubmit={handleSubmit}
        service={editingService}
        isLoading={saving} />
    </motion.div>
  );
};

export default AdminServices;