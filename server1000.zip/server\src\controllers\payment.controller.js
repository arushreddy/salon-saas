const Payment      = require('../models/Payment');
const Booking      = require('../models/Booking');
const SalonSettings= require('../models/SalonSettings');
const { AppError } = require('../middlewares/errorHandler');

const getOrCreateSettings = async (tenantId) => {
  let s = await SalonSettings.findOne({ tenantId });
  if (!s) s = await SalonSettings.create({ tenantId });
  return s;
};

// POST /api/payments/record — Record a cash/UPI/card payment (walk-in)
const recordPayment = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { bookingId, method, amount, notes } = req.body;

    const booking = await Booking.findOne({ _id: bookingId, tenantId });
    if (!booking) throw new AppError('Booking not found', 404);

    const payment = await Payment.create({
      tenantId,
      booking:  bookingId,
      customer: booking.customer,
      amount:   amount || booking.finalAmount,
      method,
      status:   'completed',
      notes:    notes || '',
    });

    booking.paymentStatus = 'paid';
    booking.paymentMethod = method;
    await booking.save();

    res.status(201).json({ success: true, payment });
  } catch (error) { next(error); }
};

// POST /api/payments/create-order — Razorpay order
const createOrder = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { bookingId } = req.body;
    const settings = await getOrCreateSettings(tenantId);

    if (!settings.payment.razorpayEnabled) throw new AppError('Online payments not enabled for this salon', 400);

    const Razorpay = require('razorpay');
    const razorpay = new Razorpay({ key_id: settings.payment.razorpayKeyId, key_secret: settings.payment.razorpayKeySecret });

    const booking = await Booking.findOne({ _id: bookingId, tenantId }).populate('service');
    if (!booking) throw new AppError('Booking not found', 404);

    const order = await razorpay.orders.create({
      amount:   booking.finalAmount * 100,
      currency: 'INR',
      receipt:  `rcpt_${bookingId}`,
    });

    const payment = await Payment.create({
      tenantId, booking: bookingId, customer: booking.customer,
      amount: booking.finalAmount, method: 'razorpay',
      status: 'pending', razorpayOrderId: order.id,
    });

    res.status(200).json({ success: true, order, payment, keyId: settings.payment.razorpayKeyId });
  } catch (error) { next(error); }
};

// POST /api/payments/verify — Razorpay verify
const verifyPayment = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, bookingId } = req.body;

    const crypto   = require('crypto');
    const settings = await getOrCreateSettings(tenantId);
    const expected = crypto.createHmac('sha256', settings.payment.razorpayKeySecret)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');

    if (expected !== razorpay_signature) throw new AppError('Payment verification failed', 400);

    const payment = await Payment.findOneAndUpdate(
      { tenantId, razorpayOrderId: razorpay_order_id },
      { status: 'completed', razorpayPaymentId: razorpay_payment_id, razorpaySignature: razorpay_signature },
      { new: true }
    );

    await Booking.findOneAndUpdate({ _id: bookingId, tenantId }, { paymentStatus: 'paid', paymentMethod: 'online' });

    res.status(200).json({ success: true, message: 'Payment verified', payment });
  } catch (error) { next(error); }
};

// GET /api/payments
const getPayments = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { method, from, to, page = 1, limit = 20 } = req.query;
    const filter = { tenantId, status: 'completed' };
    if (method) filter.method = method;
    if (from || to) {
      filter.createdAt = {};
      if (from) filter.createdAt.$gte = new Date(from);
      if (to)   filter.createdAt.$lte = new Date(to);
    }

    const [payments, total] = await Promise.all([
      Payment.find(filter).populate('booking').populate('customer','name phone').sort({ createdAt: -1 }).skip((Number(page)-1)*Number(limit)).limit(Number(limit)),
      Payment.countDocuments(filter),
    ]);

    res.status(200).json({ success: true, payments, total, page: Number(page), pages: Math.ceil(total/limit) });
  } catch (error) { next(error); }
};


// POST /api/payments/mark-paid — manual mark as paid (cash/UPI/card at counter)
const markAsPaid = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { bookingId, method = 'cash', amount, notes } = req.body;

    const booking = await Booking.findOne({ _id: bookingId, tenantId });
    if (!booking) throw new AppError('Booking not found', 404);

    const payment = await Payment.create({
      tenantId,
      booking:  bookingId,
      customer: booking.customer,
      amount:   amount || booking.finalAmount,
      method,
      status:   'completed',
      notes:    notes || '',
    });

    booking.paymentStatus = 'paid';
    booking.paymentMethod = method;
    await booking.save();

    res.status(201).json({ success: true, payment });
  } catch (error) { next(error); }
};

// POST /api/payments/refund
const refundPayment = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { paymentId, reason } = req.body;

    const payment = await Payment.findOne({ _id: paymentId, tenantId });
    if (!payment) throw new AppError('Payment not found', 404);

    payment.status = 'refunded';
    payment.notes  = reason || 'Refunded';
    await payment.save();

    res.status(200).json({ success: true, message: 'Payment refunded', payment });
  } catch (error) { next(error); }
};

// GET /api/payments/dashboard — summary stats for admin
const getPaymentDashboard = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const today    = new Date(); today.setHours(0,0,0,0);

    const [todayPayments, totalRevenue, methodBreakdown] = await Promise.all([
      Payment.find({ tenantId, status: 'completed', createdAt: { $gte: today } }),
      Payment.aggregate([
        { $match: { tenantId: require('mongoose').Types.ObjectId.createFromHexString ? require('mongoose').Types.ObjectId.createFromHexString(tenantId.toString()) : tenantId, status: 'completed' } },
        { $group: { _id: null, total: { $sum: '$amount' } } },
      ]),
      Payment.aggregate([
        { $match: { tenantId, status: 'completed' } },
        { $group: { _id: '$method', total: { $sum: '$amount' }, count: { $sum: 1 } } },
      ]),
    ]);

    res.status(200).json({
      success: true,
      data: {
        todayRevenue:    todayPayments.reduce((s, p) => s + p.amount, 0),
        todayCount:      todayPayments.length,
        totalRevenue:    totalRevenue[0]?.total || 0,
        methodBreakdown,
      },
    });
  } catch (error) { next(error); }
};

// GET /api/payments/config — returns whether Razorpay is enabled + public key
const getPaymentConfig = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const settings = await SalonSettings.findOne({ tenantId });
    res.status(200).json({
      success: true,
      config: {
        razorpayEnabled: settings?.payment?.razorpayEnabled || false,
        razorpayKeyId:   settings?.payment?.razorpayEnabled ? settings.payment.razorpayKeyId : null,
      },
    });
  } catch (error) { next(error); }
};

module.exports = {
  recordPayment, createOrder, verifyPayment, getPayments,
  markAsPaid, refundPayment, getPaymentDashboard, getPaymentConfig,
};
