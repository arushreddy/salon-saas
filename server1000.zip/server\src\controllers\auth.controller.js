const User    = require('../models/User');
const Tenant  = require('../models/Tenant');
const { AppError } = require('../middlewares/errorHandler');
const {
  generateAccessToken,
  generateRefreshToken,
  verifyRefreshToken,
  setRefreshTokenCookie,
  clearRefreshTokenCookie,
} = require('../utils/token');

// POST /api/auth/login
// NOTE: Registration is removed. Admins are created by superadmin only.
//       Staff/receptionists are created by their salon admin.
const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      throw new AppError('Email and password are required', 400);
    }

    const user = await User.findOne({ email }).select('+password +refreshTokens');
    if (!user) {
      throw new AppError('Invalid email or password', 401);
    }

    if (!user.isActive) {
      throw new AppError('Your account has been deactivated. Please contact support.', 403);
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      throw new AppError('Invalid email or password', 401);
    }

    // ── Subscription check for salon roles ────────────────────────────────
    if (['admin', 'staff', 'receptionist'].includes(user.role)) {
      if (!user.tenantId) {
        throw new AppError('Account not linked to a salon. Contact your administrator.', 403);
      }

      const tenant = await Tenant.findById(user.tenantId);
      if (!tenant) {
        throw new AppError('Salon account not found. Contact support.', 404);
      }
      if (!tenant.isActive) {
        throw new AppError('Your salon account has been suspended. Please contact your service provider.', 403);
      }
      if (!tenant.isSubscriptionActive()) {
        throw new AppError(
          'Your subscription has expired. Please contact your service provider to renew.',
          402
        );
      }
    }
    // ─────────────────────────────────────────────────────────────────────

    const tenantId = user.tenantId ? user.tenantId.toString() : null;

    const accessToken  = generateAccessToken(user._id, user.role, tenantId);
    const refreshToken = generateRefreshToken(user._id, user.role, tenantId);

    await User.findByIdAndUpdate(user._id, {
      $push: { refreshTokens: refreshToken },
    });

    setRefreshTokenCookie(res, refreshToken);

    res.status(200).json({
      success: true,
      message: 'Login successful',
      accessToken,
      user: user.toSafeObject(),
    });
  } catch (error) {
    next(error);
  }
};

// POST /api/auth/logout
const logout = async (req, res, next) => {
  try {
    const refreshToken = req.cookies?.refreshToken;

    if (refreshToken) {
      await User.findByIdAndUpdate(req.user.userId, {
        $pull: { refreshTokens: refreshToken },
      });
    }

    clearRefreshTokenCookie(res);

    res.status(200).json({
      success: true,
      message: 'Logged out successfully',
    });
  } catch (error) {
    next(error);
  }
};

// POST /api/auth/refresh
const refreshAccessToken = async (req, res, next) => {
  try {
    const refreshToken = req.cookies?.refreshToken;

    if (!refreshToken) {
      throw new AppError('No refresh token provided', 401);
    }

    let decoded;
    try {
      decoded = verifyRefreshToken(refreshToken);
    } catch {
      throw new AppError('Invalid or expired refresh token', 401);
    }

    const user = await User.findById(decoded.userId).select('+refreshTokens');
    if (!user || !user.refreshTokens.includes(refreshToken)) {
      throw new AppError('Refresh token not recognised', 401);
    }

    if (!user.isActive) {
      throw new AppError('Account is deactivated', 403);
    }

    // Re-check subscription on token refresh too
    if (['admin', 'staff', 'receptionist'].includes(user.role) && user.tenantId) {
      const tenant = await Tenant.findById(user.tenantId);
      if (!tenant || !tenant.isActive || !tenant.isSubscriptionActive()) {
        clearRefreshTokenCookie(res);
        throw new AppError('Subscription expired or account suspended.', 402);
      }
    }

    const tenantId = user.tenantId ? user.tenantId.toString() : null;

    const newAccessToken  = generateAccessToken(user._id, user.role, tenantId);
    const newRefreshToken = generateRefreshToken(user._id, user.role, tenantId);

    await User.findByIdAndUpdate(user._id, {
      $pull: { refreshTokens: refreshToken },
      $push: { refreshTokens: newRefreshToken },
    });

    setRefreshTokenCookie(res, newRefreshToken);

    res.status(200).json({
      success: true,
      accessToken: newAccessToken,
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/auth/me
const getMe = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.userId);
    if (!user) {
      throw new AppError('User not found', 404);
    }

    res.status(200).json({
      success: true,
      user: user.toSafeObject(),
    });
  } catch (error) {
    next(error);
  }
};

module.exports = { login, logout, refreshAccessToken, getMe };
