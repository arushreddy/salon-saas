const express  = require('express');
const router   = express.Router();
const {
  addStaff,
  getAllStaff,
  getAvailableStaff,
  getLiveStatus,
  getMyProfile,
  getMyEarnings,
  getStaffById,
  getStaffPerformance,
  getStaffRevenue,
  addSalaryPayment,
  updateStaff,
  patchStaff,
  patchFloorStatus,
  deleteStaff,
  getStaffLimits,
} = require('../controllers/staff.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');

// ── IMPORTANT: all named/static routes MUST come before /:id ─────────────────

router.get('/limits',       protect, authorize('admin'), getStaffLimits);
router.get('/available',    protect, getAvailableStaff);
router.get('/live-status',  protect, getLiveStatus);             // admin + receptionist
router.get('/me',           protect, getMyProfile);              // staff's own profile
router.get('/my/earnings',  protect, getMyEarnings);             // staff own earnings

router.get('/',             protect, getAllStaff);
router.post('/',            protect, authorize('admin'), addStaff);

// ── Routes with :id  (AFTER all named routes) ─────────────────────────────────
router.get('/:id',                   protect, getStaffById);
router.get('/:id/performance',       protect, authorize('admin'), getStaffPerformance);
router.get('/:id/revenue',           protect, authorize('admin'), getStaffRevenue);
router.post('/:id/salary-payment',   protect, authorize('admin'), addSalaryPayment);
router.patch('/:id/floor-status',    protect, authorize('admin', 'receptionist'), patchFloorStatus);
router.put('/:id',                   protect, authorize('admin'), updateStaff);
router.patch('/:id',                 protect, authorize('admin'), patchStaff);
router.delete('/:id',                protect, authorize('admin'), deleteStaff);

module.exports = router;