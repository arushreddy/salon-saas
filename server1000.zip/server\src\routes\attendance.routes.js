const express = require('express');
const router  = express.Router();
const {
  clockIn,
  clockOut,
  getTodayAttendance,
  getMyAttendance,
  markAttendance,
  getStaffList,
  getReport,
  applyDeduction,
} = require('../controllers/attendance.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');

// ── Named routes FIRST (never after /:id or they'll be swallowed) ─────────────
router.post('/clock-in',   protect, authorize('staff', 'receptionist'), clockIn);
router.post('/clock-out',  protect, authorize('staff', 'receptionist'), clockOut);
router.get('/today',       protect, authorize('admin', 'receptionist'), getTodayAttendance);
router.get('/my',          protect, getMyAttendance);
router.get('/staff-list',  protect, authorize('admin', 'receptionist'), getStaffList);
router.get('/report',      protect, authorize('admin', 'receptionist'), getReport);
router.post('/mark',       protect, authorize('admin', 'receptionist'), markAttendance);
router.post('/deduction',  protect, authorize('admin'), applyDeduction);

module.exports = router;