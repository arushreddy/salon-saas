const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/superadmin.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');

// ── Public ──────────────────────────────────────────────────────────────────
router.post('/login', ctrl.superAdminLogin);

// ── All routes below require superadmin JWT ──────────────────────────────────
router.use(protect, authorize('superadmin'));

// Dashboard
router.get('/dashboard', ctrl.getDashboardStats);
router.get('/report',    ctrl.getSubscriptionReport);

// Tenant CRUD
router.get('/',             ctrl.listTenants);
router.post('/',            ctrl.createTenant);
router.get('/:id',          ctrl.getTenant);
router.put('/:id',          ctrl.updateTenant);
router.delete('/:id',       ctrl.deleteTenant);

// Subscription management
router.post('/:id/activate',         ctrl.activateSubscription);
router.patch('/:id/toggle-access',   ctrl.toggleTenantAccess);
router.patch('/:id/reset-password',  ctrl.resetAdminPassword);

// WhatsApp
router.post('/:id/whatsapp',   ctrl.sendWhatsApp);
router.post('/whatsapp/bulk',  ctrl.bulkWhatsApp);

module.exports = router;
