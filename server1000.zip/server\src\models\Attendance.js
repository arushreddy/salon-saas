const mongoose = require('mongoose');

const sessionSchema = new mongoose.Schema({
  clockIn:         { type: Date, required: true },
  clockOut:        { type: Date, default: null },
  durationMinutes: { type: Number, default: 0 },
}, { _id: false });

const attendanceSchema = new mongoose.Schema(
  {
    tenantId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Tenant',
      required: true,
      index: true,
    },
    staff: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',        // ← ALWAYS User._id, never Staff._id
      required: true,
    },
    date:   { type: Date, required: true },

    // Legacy single-session fields (kept for backward compat)
    clockIn:  { type: Date, default: null },
    clockOut: { type: Date, default: null },

    // Multi-session support
    sessions: { type: [sessionSchema], default: [] },

    status: {
      type: String,
      enum: ['present','absent','late','half-day','holiday','leave'],
      default: 'absent',
    },

    // Computed time fields
    totalHours:      { type: Number, default: 0 },   // kept for compat
    totalMinutes:    { type: Number, default: 0 },   // primary field used by frontend
    lateByMinutes:   { type: Number, default: 0 },
    overtimeMinutes: { type: Number, default: 0 },

    // Deduction (applied via /attendance/deduction endpoint)
    deduction:       { type: Number, default: 0 },
    deductionReason: { type: String, default: '' },

    notes:    { type: String, default: '' },
    markedBy: { type: String, enum: ['self','admin','receptionist'], default: 'self' },
  },
  { timestamps: true }
);

attendanceSchema.index({ staff: 1, date: 1 }, { unique: true });
attendanceSchema.index({ tenantId: 1, date: 1 });

module.exports = mongoose.model('Attendance', attendanceSchema);