const Booking      = require('../models/Booking');
const Payment      = require('../models/Payment');
const SalonSettings= require('../models/SalonSettings');
const { AppError } = require('../middlewares/errorHandler');

// GET /api/invoices/:bookingId
const getInvoice = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { bookingId } = req.params;

    const booking = await Booking.findOne({ _id: bookingId, tenantId })
      .populate('customer', 'name phone email')
      .populate('service',  'name category price duration')
      .populate('staff',    'name');
    if (!booking) throw new AppError('Booking not found', 404);

    const payment  = await Payment.findOne({ booking: bookingId, tenantId, status: 'completed' });
    let settings   = await SalonSettings.findOne({ tenantId });
    if (!settings) settings = await SalonSettings.create({ tenantId });

    const safeSettings = settings.toObject();
    if (safeSettings.payment) delete safeSettings.payment.razorpayKeySecret;

    res.status(200).json({
      success: true,
      invoice: {
        booking,
        payment,
        salon:    safeSettings,
        invoiceNo:`INV-${booking._id.toString().slice(-8).toUpperCase()}`,
        issuedAt: payment?.createdAt || booking.updatedAt,
        paidAt:   payment?.createdAt || null,
      },
    });
  } catch (error) { next(error); }
};

// GET /api/invoices
const listInvoices = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { search, from, to, page = 1, limit = 20 } = req.query;

    const filter = { tenantId, status: 'completed' };
    if (from || to) {
      filter.date = {};
      if (from) filter.date.$gte = new Date(from);
      if (to)   filter.date.$lte = new Date(to);
    }

    const [bookings, total] = await Promise.all([
      Booking.find(filter)
        .populate('customer', 'name phone email')
        .populate('service',  'name price')
        .sort({ date: -1 })
        .skip((Number(page)-1)*Number(limit))
        .limit(Number(limit)),
      Booking.countDocuments(filter),
    ]);

    res.status(200).json({ success: true, invoices: bookings, total, page: Number(page), pages: Math.ceil(total/limit) });
  } catch (error) { next(error); }
};

const generateInvoice = getInvoice;
const getAllInvoices = listInvoices;
module.exports = { getInvoice, generateInvoice, listInvoices, getAllInvoices };
