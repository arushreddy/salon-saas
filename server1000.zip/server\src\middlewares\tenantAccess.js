/**
 * tenantAccess middleware
 *
 * Attach this to any route that requires an active salon subscription.
 * Reads req.user.tenantId (set by auth middleware after JWT decode).
 * 
 * Also attaches req.tenant and req.tenantFeatures for downstream use.
 */

const Tenant     = require('../models/Tenant');
const { AppError } = require('./errorHandler');

const tenantAccess = async (req, res, next) => {
  try {
    // superadmin bypasses tenant checks
    if (req.user?.role === 'superadmin') return next();

    const tenantId = req.user?.tenantId;
    if (!tenantId) {
      return next(new AppError('Tenant not identified. Please log in again.', 401));
    }

    const tenant = await Tenant.findById(tenantId);
    if (!tenant) {
      return next(new AppError('Salon account not found.', 404));
    }

    if (!tenant.isActive) {
      return next(new AppError('Your salon account has been suspended. Please contact support.', 403));
    }

    if (!tenant.isSubscriptionActive()) {
      return next(new AppError(
        'Your subscription has expired. Please renew to continue using the system.',
        402   // Payment Required – shows a specific error on frontend
      ));
    }

    req.tenant         = tenant;
    req.tenantFeatures = tenant.subscription.features;
    next();
  } catch (err) {
    next(err);
  }
};

/**
 * requireFeature('userPanel')
 * Use AFTER tenantAccess to guard plan-specific routes.
 */
const requireFeature = (featureKey) => (req, res, next) => {
  if (req.user?.role === 'superadmin') return next();

  const features = req.tenantFeatures;
  if (!features || !features[featureKey]) {
    return next(new AppError(
      `This feature (${featureKey}) is not available in your current plan. Please upgrade.`,
      403
    ));
  }
  next();
};


/**
 * getSubscriptionStatus
 * Route handler: GET /api/subscription/status
 * Returns the current tenant's subscription info for the frontend banner.
 */
const getSubscriptionStatus = async (req, res, next) => {
  try {
    if (req.user?.role === 'superadmin') {
      return res.json({ success: true, data: { status: 'active', role: 'superadmin' } });
    }

    const tenantId = req.user?.tenantId;
    if (!tenantId) {
      return next(new AppError('Tenant not identified.', 401));
    }

    const tenant = await Tenant.findById(tenantId).select('name subscription isActive');
    if (!tenant) {
      return next(new AppError('Salon account not found.', 404));
    }

    const isActive = tenant.isActive && tenant.isSubscriptionActive();

    return res.json({
      success: true,
      data: {
        salonName: tenant.name,
        plan:      tenant.subscription?.plan || 'trial',
        status:    isActive ? 'active' : (tenant.isActive ? 'expired' : 'suspended'),
        expiresAt: tenant.subscription?.expiresAt || null,
        isActive,
      },
    });
  } catch (err) {
    next(err);
  }
};

module.exports = { tenantAccess, requireFeature, getSubscriptionStatus };
