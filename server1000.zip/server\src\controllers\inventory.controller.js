const Inventory    = require('../models/Inventory');
const InventoryLog = require('../models/InventoryLog');
const { AppError } = require('../middlewares/errorHandler');

// GET /api/inventory
const getProducts = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { category, lowStock, search, page = 1, limit = 20 } = req.query;
    const filter = { tenantId, isActive: true };
    if (category) filter.category = category;
    if (search)   filter.name = { $regex: search, $options: 'i' };
    // lowStockThreshold replaces reorderLevel
    if (lowStock === 'true') filter.$expr = { $lte: ['$quantity', '$lowStockThreshold'] };

    const [products, total, lowStockCount] = await Promise.all([
      Inventory.find(filter).sort({ createdAt: -1 }).skip((Number(page)-1)*Number(limit)).limit(Number(limit)),
      Inventory.countDocuments(filter),
      Inventory.countDocuments({ tenantId, isActive: true, $expr: { $lte: ['$quantity', '$lowStockThreshold'] } }),
    ]);

    res.status(200).json({ success: true, products, total, lowStockCount, page: Number(page), pages: Math.ceil(total/limit) });
  } catch (error) { next(error); }
};

// POST /api/inventory
const createProduct = async (req, res, next) => {
  try {
    const product = await Inventory.create({ ...req.body, tenantId: req.user.tenantId });
    res.status(201).json({ success: true, product });
  } catch (error) { next(error); }
};

// PUT /api/inventory/:id
const updateProduct = async (req, res, next) => {
  try {
    const product = await Inventory.findOneAndUpdate(
      { _id: req.params.id, tenantId: req.user.tenantId },
      req.body,
      { new: true, runValidators: true }
    );
    if (!product) throw new AppError('Product not found', 404);
    res.status(200).json({ success: true, product });
  } catch (error) { next(error); }
};

// PATCH /api/inventory/:id/stock
// Frontend sends: { quantity, type, notes }
// type = 'add' | 'use'
const adjustStock = async (req, res, next) => {
  try {
    const { quantity, type, notes } = req.body;

    if (quantity === undefined && req.body.adjustment !== undefined) {
      // Legacy support: if old { adjustment } shape is sent
      return adjustStockLegacy(req, res, next);
    }

    const amount = Number(quantity);
    if (!amount || amount <= 0) throw new AppError('Enter a valid quantity', 400);

    const product = await Inventory.findOne({ _id: req.params.id, tenantId: req.user.tenantId });
    if (!product) throw new AppError('Product not found', 404);

    const stockBefore = product.quantity;
    let stockAfter;

    if (type === 'use') {
      stockAfter = stockBefore - amount;
      if (stockAfter < 0) throw new AppError('Stock cannot go below zero', 400);
    } else {
      // 'add' or anything else
      stockAfter = stockBefore + amount;
    }

    product.quantity = stockAfter;
    await product.save();

    // Log the change
    try {
      await InventoryLog.create({
        product: product._id,
        type: type === 'use' ? 'use' : 'refill',
        quantity: amount,
        stockBefore,
        stockAfter,
        performedBy: req.user._id,
        notes: notes || `Manual ${type === 'use' ? 'deduction' : 'addition'}`,
      });
    } catch (logErr) {
      console.error('Failed to write inventory log:', logErr.message);
    }

    res.status(200).json({ success: true, product });
  } catch (error) { next(error); }
};

// Legacy handler for old { adjustment } shape (kept for backward compat)
const adjustStockLegacy = async (req, res, next) => {
  try {
    const { adjustment, reason } = req.body;
    const product = await Inventory.findOne({ _id: req.params.id, tenantId: req.user.tenantId });
    if (!product) throw new AppError('Product not found', 404);
    const newQty = product.quantity + Number(adjustment);
    if (newQty < 0) throw new AppError('Stock cannot go below zero', 400);
    product.quantity = newQty;
    await product.save();
    res.status(200).json({ success: true, product });
  } catch (error) { next(error); }
};

// DELETE /api/inventory/:id
const deleteProduct = async (req, res, next) => {
  try {
    await Inventory.findOneAndUpdate(
      { _id: req.params.id, tenantId: req.user.tenantId },
      { isActive: false }
    );
    res.status(200).json({ success: true, message: 'Product removed' });
  } catch (error) { next(error); }
};

// GET /api/inventory/history?productId=xxx&limit=80
const getHistory = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { productId, limit = 80 } = req.query;

    if (!productId) throw new AppError('productId is required', 400);

    // Verify product belongs to this tenant
    const product = await Inventory.findOne({ _id: productId, tenantId });
    if (!product) throw new AppError('Product not found', 404);

    const logs = await InventoryLog.find({ product: productId })
      .populate('performedBy', 'name')
      .sort({ createdAt: -1 })
      .limit(Number(limit));

    res.status(200).json({ success: true, logs });
  } catch (error) { next(error); }
};

const getAllProducts = getProducts;
const updateStock   = adjustStock;

module.exports = {
  getProducts, getAllProducts, createProduct, updateProduct,
  adjustStock, updateStock, deleteProduct, getHistory,
};