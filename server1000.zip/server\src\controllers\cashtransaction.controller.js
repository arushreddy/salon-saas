// src/controllers/cashTransaction.controller.js
//
// KEY FIX (v2): computeSummary() now only counts cash bookings SINCE the last
// shift close. Previously it summed ALL-TIME cash bookings (causing ₹1.1L when
// reality was ₹2K). Now admin and receptionist show identical numbers.
//
// Sync strategy:
//  - Both panels poll GET /cash-transactions/since/:ts every 6 s
//  - Writes (POST/DELETE) return a fresh summary immediately
//  - BroadcastChannel('glamour_cash_sync') used on the frontend for <100ms
//    same-browser updates; the 6-second poll handles cross-device/cross-browser

const CashTransaction = require('../models/CashTransaction');
const ShiftReport     = require('../models/ShiftReport');
const Booking         = require('../models/Booking');

/* ── IST helpers ─────────────────────────────────────────────────────────── */
const IST_MS        = 5.5 * 60 * 60 * 1000;
const todayIST      = () => new Date(Date.now() + IST_MS).toISOString().split('T')[0];
const startOfDayIST = d  => new Date(d + 'T00:00:00+05:30');
const endOfDayIST   = d  => new Date(d + 'T23:59:59+05:30');

/* ═══════════════════════════════════════════════════════════════════════════
   CORE FIX: computeSummary(sinceDate?)
   ─────────────────────────────────────────────────────────────────────────
   sinceDate = Date object. When provided, only cash bookings AFTER sinceDate
   are counted. When null we fall back to the last shift close timestamp, and
   if there are no shift reports yet, we use the start of today (IST).

   This prevents all-time totals leaking into the "current drawer" balance.
   ═══════════════════════════════════════════════════════════════════════════ */
async function computeSummary(sinceDate = null) {

  // ── 1. Determine the shift boundary ──────────────────────────────────────
  let shiftStart = sinceDate;

  if (!shiftStart) {
    // Find the most recent shift close
    const lastShift = await ShiftReport.findOne().sort({ closedAt: -1 }).lean();
    if (lastShift?.closedAt) {
      shiftStart = new Date(lastShift.closedAt);
    } else {
      // No shift ever closed → count from start of current IST day only
      shiftStart = startOfDayIST(todayIST());
    }
  }

  // ── 2. Cash bookings SINCE shiftStart ────────────────────────────────────
  //    We match on the booking's `date` field (which is an ISODate stored as
  //    midnight UTC of the appointment date). For bookings made today we also
  //    check `createdAt` to catch walk-ins entered mid-shift.
  const cashAgg = await Booking.aggregate([
    {
      $match: {
        paymentMethod:  'cash',
        paymentStatus:  'paid',
        $or: [
          { date:      { $gte: shiftStart } },
          { createdAt: { $gte: shiftStart } },
          { paidAt:    { $gte: shiftStart } },
        ],
      },
    },
    { $group: { _id: null, total: { $sum: '$finalAmount' } } },
  ]);
  const cashIn = cashAgg[0]?.total || 0;

  // ── 3. Manual transactions SINCE shiftStart ───────────────────────────────
  const manualAgg = await CashTransaction.aggregate([
    { $match: { createdAt: { $gte: shiftStart } } },
    {
      $group: {
        _id: '$type',
        total: { $sum: '$amount' },
        signedTotal: {
          $sum: {
            $cond: [
              { $eq: ['$type', 'adjustment'] },
              { $cond: [{ $eq: ['$sign', '+'] }, '$amount', { $multiply: ['$amount', -1] }] },
              '$amount',
            ],
          },
        },
      },
    },
  ]);

  let manualCashIn = 0, withdrawn = 0, expenses = 0,
      salaries = 0,  advances = 0,  adjNet = 0;

  for (const row of manualAgg) {
    if (row._id === 'cash_in')    manualCashIn = row.total;
    if (row._id === 'withdrawal') withdrawn    = row.total;
    if (row._id === 'expense')    expenses     = row.total;
    if (row._id === 'salary')     salaries     = row.total;
    if (row._id === 'advance')    advances     = row.total;
    if (row._id === 'adjustment') adjNet       = row.signedTotal;
  }

  const balance = cashIn + manualCashIn + adjNet - withdrawn - expenses - salaries - advances;

  return {
    balance,
    cashIn,       // cash bookings since last shift close
    manualCashIn,
    withdrawn,
    expenses,
    salaries,
    advances,
    adjNet,
    shiftStartedAt: shiftStart.toISOString(), // expose so UI can display "since X"
  };
}

/* ═══════════════════════════════════════════════════════════════════════════
   GET /cash-transactions
   List all manual transactions (newest first)
   ═══════════════════════════════════════════════════════════════════════════ */
exports.list = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 500;
    const txns  = await CashTransaction.find()
      .sort({ createdAt: -1 })
      .limit(limit)
      .populate('createdBy', 'name role');

    res.json({ success: true, transactions: txns });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

/* ═══════════════════════════════════════════════════════════════════════════
   POST /cash-transactions
   Create a manual transaction — returns updated summary immediately
   ═══════════════════════════════════════════════════════════════════════════ */
exports.create = async (req, res) => {
  try {
    const { type, amount, note, date, time, recipient, sign } = req.body;

    if (!type || !amount || !note)
      return res.status(400).json({ success:false, message:'type, amount and note are required' });
    if (amount <= 0)
      return res.status(400).json({ success:false, message:'Amount must be positive' });

    const txn = await CashTransaction.create({
      type,
      amount:    Number(amount),
      note:      note.trim(),
      date:      date || todayIST(),
      time:      time || null,
      recipient: recipient || null,
      sign:      type === 'adjustment' ? (sign || '+') : '+',
      createdBy: req.user?.userId || null,
    });

    await txn.populate('createdBy', 'name role');

    const summary = await computeSummary();
    res.status(201).json({ success:true, transaction:txn, summary });
  } catch (err) {
    res.status(500).json({ success:false, message:err.message });
  }
};

/* ═══════════════════════════════════════════════════════════════════════════
   DELETE /cash-transactions/:id
   ═══════════════════════════════════════════════════════════════════════════ */
exports.remove = async (req, res) => {
  try {
    const txn = await CashTransaction.findByIdAndDelete(req.params.id);
    if (!txn)
      return res.status(404).json({ success:false, message:'Transaction not found' });

    const summary = await computeSummary();
    res.json({ success:true, deletedId:req.params.id, summary });
  } catch (err) {
    res.status(500).json({ success:false, message:err.message });
  }
};

/* ═══════════════════════════════════════════════════════════════════════════
   GET /cash-transactions/summary
   Running balance — shift-bounded (KEY FIX: no more all-time totals)
   ═══════════════════════════════════════════════════════════════════════════ */
exports.summary = async (req, res) => {
  try {
    const summary = await computeSummary();
    res.json({ success:true, summary });
  } catch (err) {
    res.status(500).json({ success:false, message:err.message });
  }
};

/* ═══════════════════════════════════════════════════════════════════════════
   GET /cash-transactions/today-bookings
   Today's cash + online split (IST date). Used for the "Today Cash / Online"
   pills — these always show TODAY regardless of shift boundary.
   ═══════════════════════════════════════════════════════════════════════════ */
exports.todayBookings = async (req, res) => {
  try {
    const today    = todayIST();
    const dayStart = startOfDayIST(today);
    const dayEnd   = endOfDayIST(today);

    const allToday = await Booking.find({
      $or: [
        { date:      { $gte: dayStart, $lte: dayEnd } },
        { createdAt: { $gte: dayStart, $lte: dayEnd } },
      ],
      paymentStatus: 'paid',
    })
      .populate('customer', 'name phone')
      .populate('service',  'name price')
      .populate('staff',    'name')
      .sort({ createdAt: -1 })
      .lean();

    const cashBookings   = allToday.filter(b => b.paymentMethod === 'cash');
    const onlineBookings = allToday.filter(b => ['upi','card','online','razorpay'].includes(b.paymentMethod));

    res.json({ success:true, cashBookings, onlineBookings, date:today });
  } catch (err) {
    res.status(500).json({ success:false, message:err.message });
  }
};

/* ═══════════════════════════════════════════════════════════════════════════
   GET /cash-transactions/since/:timestamp
   Delta poll — new/changed since lastTs (ms epoch). Used by both panels
   every 6 seconds to stay in sync without full refresh overhead.
   ═══════════════════════════════════════════════════════════════════════════ */
exports.since = async (req, res) => {
  try {
    const since = new Date(parseInt(req.params.timestamp));
    if (isNaN(since.getTime()))
      return res.status(400).json({ success:false, message:'Invalid timestamp' });

    const added = await CashTransaction.find({ updatedAt: { $gt: since } })
      .sort({ createdAt: -1 })
      .populate('createdBy', 'name role');

    // Soft-delete log: we don't track deletes server-side yet.
    // Frontend does a full refresh after its own DELETEs, so this is fine.
    const deletedIds = [];

    const summary = await computeSummary();

    res.json({
      success: true,
      added,
      deletedIds,
      summary,
      serverTime: Date.now(),
    });
  } catch (err) {
    res.status(500).json({ success:false, message:err.message });
  }
};

/* ═══════════════════════════════════════════════════════════════════════════
   POST /cash-transactions/shift-close
   Saves a shift report; next computeSummary() call will use this as the
   new shiftStart, effectively resetting the counter.
   ═══════════════════════════════════════════════════════════════════════════ */
exports.shiftClose = async (req, res) => {
  try {
    const {
      cashIn, manualCashIn, withdrawn, expenses, salaries, advances, adjNet,
      closingBalance, todayCash, todayOnline,
      physicalCount, variance, note,
    } = req.body;

    const report = await ShiftReport.create({
      date:           todayIST(),
      closingBalance: closingBalance || 0,
      cashIn:         cashIn         || 0,
      manualCashIn:   manualCashIn   || 0,
      withdrawn:      withdrawn      || 0,
      expenses:       expenses       || 0,
      salaries:       salaries       || 0,
      advances:       advances       || 0,
      adjNet:         adjNet         || 0,
      todayCash:      todayCash      || 0,
      todayOnline:    todayOnline    || 0,
      physicalCount:  physicalCount  || null,
      variance:       variance       || null,
      note:           note           || '',
      closedBy:       req.user?.userId || null,
      closedAt:       new Date(),
    });

    await report.populate('closedBy', 'name role');

    // Return fresh summary so UI resets immediately
    const summary = await computeSummary();
    res.status(201).json({ success:true, report, summary });
  } catch (err) {
    res.status(500).json({ success:false, message:err.message });
  }
};

/* ═══════════════════════════════════════════════════════════════════════════
   GET /cash-transactions/shift-reports
   List past shift reports (newest first)
   ═══════════════════════════════════════════════════════════════════════════ */
exports.shiftReports = async (req, res) => {
  try {
    const limit   = parseInt(req.query.limit) || 60;
    const reports = await ShiftReport.find()
      .sort({ closedAt: -1 })
      .limit(limit)
      .populate('closedBy', 'name role');

    res.json({ success:true, reports });
  } catch (err) {
    res.status(500).json({ success:false, message:err.message });
  }
};