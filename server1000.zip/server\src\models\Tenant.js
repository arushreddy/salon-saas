const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const subscriptionSchema = new mongoose.Schema({
  plan: {
    type: String,
    enum: ['basic', 'standard', 'premium'],
    default: 'basic',
  },
  // basic    = Admin + Staff + Receptionist (no user panel)
  // standard = basic + User booking panel
  // premium  = standard + advanced analytics + multi-branch
  status: {
    type: String,
    enum: ['trial', 'active', 'suspended', 'expired', 'cancelled'],
    default: 'trial',
  },
  startDate: { type: Date },
  endDate:   { type: Date },
  trialEndsAt: { type: Date },
  durationDays: { type: Number },   // store for display
  autoRenew: { type: Boolean, default: false },

  // features toggled by plan
  features: {
    userPanel:        { type: Boolean, default: false },
    onlineBooking:    { type: Boolean, default: false },
    advancedAnalytics:{ type: Boolean, default: false },
    multiBranch:      { type: Boolean, default: false },
    maxStaff:         { type: Number, default: 10 },
    maxReceptionists: { type: Number, default: 2 },
  },

  // payment records
  payments: [{
    amount:    Number,
    method:    String,
    reference: String,
    paidAt:    { type: Date, default: Date.now },
    notes:     String,
  }],
}, { _id: false });

const tenantSchema = new mongoose.Schema({
  // ── Salon / Owner Info ────────────────────────────────────────────────────
  salonName:    { type: String, required: true, trim: true },
  ownerName:    { type: String, required: true, trim: true },
  email:        { type: String, required: true, unique: true, lowercase: true, trim: true },
  phone:        { type: String, required: true, trim: true },   // primary contact
  whatsapp:     { type: String, trim: true },                   // can differ from phone
  address: {
    city:    { type: String, default: '' },
    state:   { type: String, default: '' },
    pincode: { type: String, default: '' },
  },

  // ── Login credentials for the salon admin ────────────────────────────────
  // The salon admin logs in at /login with this email + password
  // password is hashed
  adminPassword: {
    type: String,
    required: true,
    select: false,
  },

  // ── Subscription ─────────────────────────────────────────────────────────
  subscription: { type: subscriptionSchema, default: () => ({}) },

  // ── Access control ────────────────────────────────────────────────────────
  isActive: { type: Boolean, default: true },   // hard kill-switch by super admin
  accessNotes: { type: String, default: '' },   // internal notes

  // ── Notification tracking ─────────────────────────────────────────────────
  notifications: {
    activationSent:    { type: Boolean, default: false },
    expiryWarningSent: { type: Boolean, default: false },  // 7-day warning
    expiredSent:       { type: Boolean, default: false },
    lastNotifiedAt:    { type: Date },
  },

  // ── Stats cache (updated periodically) ───────────────────────────────────
  stats: {
    totalStaff:       { type: Number, default: 0 },
    totalBookings:    { type: Number, default: 0 },
    totalRevenue:     { type: Number, default: 0 },
    lastActivityAt:   { type: Date },
  },
}, {
  timestamps: true,
  toJSON: {
    transform: (doc, ret) => {
      delete ret.adminPassword;
      delete ret.__v;
      return ret;
    }
  }
});

// ── Password helpers ──────────────────────────────────────────────────────
tenantSchema.pre('save', async function () {
  if (!this.isModified('adminPassword')) return;
  const salt = await bcrypt.genSalt(12);
  this.adminPassword = await bcrypt.hash(this.adminPassword, salt);
});

tenantSchema.methods.comparePassword = async function (candidate) {
  return bcrypt.compare(candidate, this.adminPassword);
};

// ── Subscription helpers ──────────────────────────────────────────────────
tenantSchema.methods.isSubscriptionActive = function () {
  if (!this.isActive) return false;
  const s = this.subscription;
  if (s.status === 'active' && s.endDate && new Date() <= new Date(s.endDate)) return true;
  if (s.status === 'trial' && s.trialEndsAt && new Date() <= new Date(s.trialEndsAt)) return true;
  return false;
};

tenantSchema.methods.daysUntilExpiry = function () {
  const s = this.subscription;
  const end = s.status === 'trial' ? s.trialEndsAt : s.endDate;
  if (!end) return null;
  return Math.ceil((new Date(end) - new Date()) / (1000 * 60 * 60 * 24));
};

// ── Plan feature presets ──────────────────────────────────────────────────
tenantSchema.statics.planFeatures = {
  basic: {
    userPanel: false,
    onlineBooking: false,
    advancedAnalytics: false,
    multiBranch: false,
    maxStaff: 10,
    maxReceptionists: 2,
  },
  standard: {
    userPanel: true,
    onlineBooking: true,
    advancedAnalytics: false,
    multiBranch: false,
    maxStaff: 25,
    maxReceptionists: 5,
  },
  premium: {
    userPanel: true,
    onlineBooking: true,
    advancedAnalytics: true,
    multiBranch: true,
    maxStaff: 100,
    maxReceptionists: 20,
  },
};

module.exports = mongoose.model('Tenant', tenantSchema);
