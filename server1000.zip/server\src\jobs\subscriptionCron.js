/**
 * Subscription Cron Job
 *
 * Runs every day at 9 AM IST:
 *  1. Marks subscriptions as 'expired' if endDate has passed
 *  2. Sends 7-day expiry warning WhatsApp if not already sent
 *  3. Sends 'expired' WhatsApp on the day subscription expires
 *
 * Usage: require this file in server.js after DB connects.
 * Uses node-cron (add to package.json: "node-cron": "^3.0.3")
 */

const cron   = require('node-cron');
const Tenant = require('../models/Tenant');
const wa     = require('../services/whatsapp.service');
const logger = require('../utils/logger');

async function runSubscriptionCheck() {
  logger.info('[CRON] Running subscription check...');
  const now = new Date();

  try {
    // ── 1. Find all active/trial subscriptions ──────────────────────────────
    const tenants = await Tenant.find({
      isActive: true,
      'subscription.status': { $in: ['active', 'trial'] },
    }).select('+adminPassword');  // needed for methods

    let expired = 0, warned = 0;

    for (const tenant of tenants) {
      const sub     = tenant.subscription;
      const endDate = sub.status === 'trial' ? sub.trialEndsAt : sub.endDate;
      if (!endDate) continue;

      const daysLeft = Math.ceil((new Date(endDate) - now) / (1000 * 60 * 60 * 24));

      // ── Expired ────────────────────────────────────────────────────────────
      if (daysLeft <= 0) {
        sub.status = 'expired';
        if (!tenant.notifications.expiredSent) {
          await wa.notifyExpired(tenant);
          tenant.notifications.expiredSent  = true;
          tenant.notifications.lastNotifiedAt = now;
        }
        expired++;
      }
      // ── 7-day warning ──────────────────────────────────────────────────────
      else if (daysLeft <= 7 && !tenant.notifications.expiryWarningSent) {
        await wa.notifyExpiryWarning(tenant);
        tenant.notifications.expiryWarningSent = true;
        tenant.notifications.lastNotifiedAt    = now;
        warned++;
      }

      await tenant.save();
    }

    logger.info(`[CRON] Subscription check done. Expired: ${expired}, Warned: ${warned}`);
  } catch (err) {
    logger.error('[CRON] Subscription check failed', { error: err.message });
  }
}

function startSubscriptionCron() {
  // Run at 09:00 every day (Asia/Kolkata)
  cron.schedule('0 9 * * *', runSubscriptionCheck, {
    scheduled: true,
    timezone:  'Asia/Kolkata',
  });
  logger.info('[CRON] Subscription cron scheduled (daily 9 AM IST)');

  // Run once on startup too (catches overnight expiries)
  runSubscriptionCheck();
}

module.exports = { startSubscriptionCron, runSubscriptionCheck };
