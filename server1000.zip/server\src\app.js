require("dotenv").config();
const express      = require("express");
const cors         = require("cors");
const helmet       = require("helmet");
const morgan       = require("morgan");
const cookieParser = require("cookie-parser");
const rateLimit    = require("express-rate-limit");
const { errorHandler } = require("./middlewares/errorHandler");
const healthRoutes     = require("./routes/health.routes");

require("./models/Tenant");
require("./models/User");
require("./models/Service");
require("./models/Booking");
require("./models/Coupon");
require("./models/Payment");
require("./models/Inventory");
require("./models/SalonSettings");
require("./models/Staff");
require("./models/Attendance");
require("./models/CashTransaction");
require("./models/Notification");
require("./models/InventoryLog");
require("./models/SalaryPayment");
require("./models/ShiftReport");

const app = express();

const superAdminRoutes   = require("./routes/superadmin.routes");
const authRoutes         = require("./routes/auth.routes");
const subscriptionRoutes = require("./routes/subscription.routes");
const userRoutes         = require("./routes/user.routes");
const serviceRoutes      = require("./routes/service.routes");
const bookingRoutes      = require("./routes/booking.routes");
const staffRoutes        = require("./routes/staff.routes");
const attendanceRoutes   = require("./routes/attendance.routes");
const paymentRoutes      = require("./routes/payment.routes");
const settingsRoutes     = require("./routes/settings.routes");
const analyticsRoutes    = require("./routes/analytics.routes");
const inventoryRoutes    = require("./routes/inventory.routes");
const invoiceRoutes      = require("./routes/invoice.routes");
const couponRoutes       = require("./routes/coupon.routes");
const cashRoutes         = require("./routes/cashtransaction.routes");
const notificationRoutes = require("./routes/notification.routes");

app.use(helmet());
app.use(cors({
  origin: ["http://localhost:5173","http://localhost:5174", process.env.CLIENT_URL].filter(Boolean),
  credentials: true,
}));
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use("/api", rateLimit({ windowMs: 15*60*1000, max: 200, message: { success: false, message: "Too many requests." } }));
if (process.env.NODE_ENV === "development") app.use(morgan("dev"));

app.get("/", (req, res) => res.json({ success: true, message: "Salon SaaS API is live" }));
app.use("/api/health",        healthRoutes);
app.use("/api/superadmin",    superAdminRoutes);
app.use("/api/auth",          authRoutes);
app.use("/api/subscription",  subscriptionRoutes);
app.use("/api/users",         userRoutes);
app.use("/api/services",      serviceRoutes);
app.use("/api/bookings",      bookingRoutes);
app.use("/api/staff",         staffRoutes);
app.use("/api/attendance",    attendanceRoutes);
app.use("/api/payments",      paymentRoutes);
app.use("/api/settings",      settingsRoutes);
app.use("/api/analytics",     analyticsRoutes);
app.use("/api/inventory",     inventoryRoutes);
app.use("/api/invoices",      invoiceRoutes);
app.use("/api/coupons",       couponRoutes);
app.use("/api/cash-transactions",          cashRoutes);
app.use("/api/notifications", notificationRoutes);

app.use((req, res) => res.status(404).json({ success: false, message: `Route ${req.originalUrl} not found` }));
app.use(errorHandler);

module.exports = app;