const Service = require('../models/Service');
const { AppError } = require('../middlewares/errorHandler');

// GET /api/services  (also exported as getAllServices for named-import routes)
const getServices = async (req, res, next) => {
  try {
    const tenantId = req.user?.tenantId;
    const { category, search, sort, isActive, page = 1, limit = 50 } = req.query;

    const filter = { tenantId };
    // default to active only; pass isActive=all to get everything
    if (isActive !== 'all') filter.isActive = isActive === 'false' ? false : true;
    if (category) filter.category = category;
    if (search)   filter.name = { $regex: search, $options: 'i' };

    let sortOption = { createdAt: -1 };
    if (sort === 'price_asc')  sortOption = { price: 1 };
    if (sort === 'price_desc') sortOption = { price: -1 };
    if (sort === 'name')       sortOption = { name: 1 };

    const [services, total] = await Promise.all([
      Service.find(filter).sort(sortOption).skip((Number(page)-1)*Number(limit)).limit(Number(limit)),
      Service.countDocuments(filter),
    ]);

    res.status(200).json({ success: true, services, total });
  } catch (error) { next(error); }
};

// alias used by service.routes.js
const getAllServices = getServices;

const getServiceById = async (req, res, next) => {
  try {
    const service = await Service.findOne({ _id: req.params.id, tenantId: req.user?.tenantId });
    if (!service) throw new AppError('Service not found', 404);
    res.status(200).json({ success: true, service });
  } catch (error) { next(error); }
};

const createService = async (req, res, next) => {
  try {
    const service = await Service.create({ ...req.body, tenantId: req.user.tenantId });
    res.status(201).json({ success: true, message: 'Service created', service });
  } catch (error) { next(error); }
};

const updateService = async (req, res, next) => {
  try {
    const service = await Service.findOneAndUpdate(
      { _id: req.params.id, tenantId: req.user.tenantId },
      req.body, { new: true, runValidators: true }
    );
    if (!service) throw new AppError('Service not found', 404);
    res.status(200).json({ success: true, message: 'Service updated', service });
  } catch (error) { next(error); }
};

// PATCH: partial update — used to toggle isActive, change price, etc.
const patchService = async (req, res, next) => {
  try {
    const service = await Service.findOneAndUpdate(
      { _id: req.params.id, tenantId: req.user.tenantId },
      { $set: req.body }, { new: true, runValidators: true }
    );
    if (!service) throw new AppError('Service not found', 404);
    res.status(200).json({ success: true, message: 'Service updated', service });
  } catch (error) { next(error); }
};

const deleteService = async (req, res, next) => {
  try {
    const service = await Service.findOneAndUpdate(
      { _id: req.params.id, tenantId: req.user.tenantId },
      { isActive: false }, { new: true }
    );
    if (!service) throw new AppError('Service not found', 404);
    res.status(200).json({ success: true, message: 'Service deactivated' });
  } catch (error) { next(error); }
};

// GET /api/services/categories/list — distinct category list for the tenant
const getCategories = async (req, res, next) => {
  try {
    const tenantId = req.user?.tenantId;
    const categories = await Service.distinct('category', { tenantId, isActive: true });
    res.status(200).json({ success: true, categories: categories.filter(Boolean) });
  } catch (error) { next(error); }
};

module.exports = {
  getServices,
  getAllServices,
  getServiceById,
  createService,
  updateService,
  patchService,
  deleteService,
  getCategories,
};
