const mongoose = require('mongoose');

const couponSchema = new mongoose.Schema(
  {
    tenantId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Tenant',
      required: true,
      index: true,
    },
    code: {
      type: String,
      required: [true, 'Coupon code is required'],
      uppercase: true,
      trim: true,
      // Unique per tenant — handled by compound index below
    },
    description:  { type: String, default: '' },
    discountType: { type: String, enum: ['percentage', 'fixed'], required: true },
    discountValue:{ type: Number, required: true, min: 0 },
    minOrderValue:{ type: Number, default: 0 },
    maxUses:      { type: Number, default: 0 },  // 0 = unlimited
    usedCount:    { type: Number, default: 0 },
    validFrom:    { type: Date, default: Date.now },
    validUntil:   { type: Date },
    isActive:     { type: Boolean, default: true },
  },
  { timestamps: true }
);

// Code is unique within each salon (different salons can have same code)
couponSchema.index({ tenantId: 1, code: 1 }, { unique: true });

module.exports = mongoose.model('Coupon', couponSchema);
