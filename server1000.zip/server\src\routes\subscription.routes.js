const express = require('express');
const router  = express.Router();
const { protect } = require('../middlewares/auth.middleware');
const { getSubscriptionStatus } = require('../middlewares/tenantAccess');

// GET /api/subscription/status
// Called by AdminLayout banner every 5 minutes to keep expiry display fresh.
router.get('/status', protect, getSubscriptionStatus);

module.exports = router;
