/**
 * UPDATED User.js — replace your existing src/models/User.js with this
 *
 * Changes:
 *  - Added `tenantId` field (links user to their salon/tenant)
 *  - Added 'superadmin' to the role enum
 */

const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');
const validator= require('validator');

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String, required: [true, 'Name is required'],
      trim: true, minlength: [2,'Name must be at least 2 chars'], maxlength: [50,'Name cannot exceed 50 chars'],
    },
    email: {
      type: String, required: [true, 'Email is required'],
      unique: true, lowercase: true, trim: true,
      validate: { validator: validator.isEmail, message: 'Please provide a valid email' },
    },
    phone: {
      type: String, trim: true,
      validate: {
        validator: (v) => !v || /^[6-9]\d{9}$/.test(v),
        message: 'Please provide a valid 10-digit Indian phone number',
      },
    },
    password: {
      type: String, required: [true, 'Password is required'],
      minlength: [6, 'Password must be at least 6 characters'], select: false,
    },
    role: {
      type: String,
      enum: ['customer', 'staff', 'receptionist', 'admin', 'superadmin'],
      default: 'customer',
    },
    // ── Multi-tenancy ──────────────────────────────────────────────────────
    tenantId: {
      type: mongoose.Schema.Types.ObjectId,
      ref:  'Tenant',
      default: null,
      // null for customers (no tenant) and superadmin
    },
    avatar:   { type: String, default: '' },
    isActive: { type: Boolean, default: true },
    refreshTokens: { type: [String], select: false },
  },
  {
    timestamps: true,
    toJSON: {
      transform: (doc, ret) => {
        delete ret.password;
        delete ret.refreshTokens;
        delete ret.__v;
        return ret;
      },
    },
  }
);

userSchema.pre('save', async function () {
  if (!this.isModified('password')) return;
  const salt = await bcrypt.genSalt(12);
  this.password = await bcrypt.hash(this.password, salt);
});

userSchema.methods.comparePassword = async function (candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

userSchema.methods.toSafeObject = function () {
  const obj = this.toObject();
  delete obj.password;
  delete obj.refreshTokens;
  delete obj.__v;
  return obj;
};

module.exports = mongoose.model('User', userSchema);
