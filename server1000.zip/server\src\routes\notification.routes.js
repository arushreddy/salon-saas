const express = require('express');
const router  = express.Router();
const { protect, authorize } = require('../middlewares/auth.middleware');
const {
  getNotifications, createNotification,
  markRead, markAllRead, deleteNotification,
  getStaffForSending,
} = require('../controllers/notification.controller');

router.get('/staff-list',  protect, authorize('admin','receptionist'), getStaffForSending);
router.get('/',            protect, getNotifications);
router.post('/',           protect, authorize('admin','receptionist'), createNotification);
router.patch('/read-all',  protect, markAllRead);
router.patch('/:id/read',  protect, markRead);
router.delete('/:id',      protect, deleteNotification);

module.exports = router;