const mongoose = require('mongoose');

const inventorySchema = new mongoose.Schema(
  {
    tenantId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Tenant',
      required: true,
      index: true,
    },
    name:     { type: String, required: [true, 'Product name is required'], trim: true },
    category: {
      type: String,
      enum: ['shampoo','conditioner','oil','color','cream','serum','tools','accessories','consumables','other'],
      default: 'other',
    },
    brand:    { type: String, trim: true, default: '' },
    sku:      { type: String, sparse: true },
    quantity: { type: Number, required: true, min: 0, default: 0 },
    unit:     { type: String, default: 'pieces' },
    costPrice:        { type: Number, default: 0, min: 0 },
    sellingPrice:     { type: Number, default: 0, min: 0 },   // was: sellPrice
    lowStockThreshold:{ type: Number, default: 5 },            // was: reorderLevel
    supplier: {                                                 // was: String, now Object
      name:  { type: String, default: '' },
      phone: { type: String, default: '' },
    },
    notes:    { type: String, default: '' },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

// SKU unique within each salon
inventorySchema.index({ tenantId: 1, sku: 1 }, { unique: true, sparse: true });

module.exports = mongoose.model('Inventory', inventorySchema);