const express = require('express');
const router  = express.Router();
const { login, logout, refreshAccessToken, getMe } = require('../controllers/auth.controller');
const { protect } = require('../middlewares/auth.middleware');

// NOTE: /register is intentionally removed.
// Admins are created by the super admin panel.
// Staff and receptionists are created by their salon admin.

router.post('/login',   login);
router.post('/logout',  protect, logout);
router.post('/refresh', refreshAccessToken);
router.get('/me',       protect, getMe);

module.exports = router;
