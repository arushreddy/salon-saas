/**
 * WhatsApp Notification Service
 *
 * Provider options (set WHATSAPP_PROVIDER in .env):
 *   "twilio"  – Twilio WhatsApp sandbox / business
 *   "meta"    – Meta Cloud API (WhatsApp Business Platform)
 *   "log"     – Development mode – just logs to console (default)
 *
 * Twilio env vars: TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_WA_FROM
 * Meta env vars  : META_WA_TOKEN, META_WA_PHONE_ID
 */

const logger = require('../utils/logger');

// ─── Message Templates ────────────────────────────────────────────────────────

const templates = {
  activated: (data) =>
    `✅ *${data.salonName}* – Subscription Activated!\n\nHello ${data.ownerName},\n\nYour *${data.plan.toUpperCase()}* plan is now active.\n📅 Valid till: *${data.endDate}*\n\nLogin: ${data.loginUrl}\n\nFor support, reply to this message. 🙏`,

  expiryWarning: (data) =>
    `⚠️ *${data.salonName}* – Subscription Expiring Soon!\n\nHello ${data.ownerName},\n\nYour subscription expires in *${data.daysLeft} day(s)* on *${data.endDate}*.\n\nRenew now to avoid disruption:\n${data.renewUrl}\n\nNeed help? Reply here. 🙏`,

  expired: (data) =>
    `🚫 *${data.salonName}* – Subscription Expired\n\nHello ${data.ownerName},\n\nYour subscription expired on *${data.endDate}*. Access has been suspended.\n\nTo reactivate, contact us:\n📞 ${data.supportPhone || 'your support number'}\n\nWe'd love to have you back! 🙏`,

  suspended: (data) =>
    `⛔ *${data.salonName}* – Account Suspended\n\nHello ${data.ownerName},\n\nYour account has been suspended by the administrator.\n\nFor details, contact support:\n📞 ${data.supportPhone || 'your support number'}`,

  custom: (data) =>
    `📢 *${data.salonName}*\n\n${data.message}`,
};

// ─── Provider: Console / Log (dev) ───────────────────────────────────────────

async function sendViaLog(to, message) {
  logger.info(`[WhatsApp LOG] To: ${to}\n${message}`);
  return { success: true, provider: 'log', messageId: `log_${Date.now()}` };
}

// ─── Provider: Twilio ─────────────────────────────────────────────────────────

async function sendViaTwilio(to, message) {
  const twilio = require('twilio');
  const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
  const from   = process.env.TWILIO_WA_FROM || 'whatsapp:+14155238886';
  const toWA   = `whatsapp:+91${to.replace(/\D/g, '').slice(-10)}`;

  const msg = await client.messages.create({ from, to: toWA, body: message });
  return { success: true, provider: 'twilio', messageId: msg.sid };
}

// ─── Provider: Meta Cloud API ─────────────────────────────────────────────────

async function sendViaMeta(to, message) {
  const axios   = require('axios');
  const token   = process.env.META_WA_TOKEN;
  const phoneId = process.env.META_WA_PHONE_ID;
  const number  = `91${to.replace(/\D/g, '').slice(-10)}`;

  const res = await axios.post(
    `https://graph.facebook.com/v18.0/${phoneId}/messages`,
    {
      messaging_product: 'whatsapp',
      to: number,
      type: 'text',
      text: { body: message },
    },
    { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' } }
  );
  return { success: true, provider: 'meta', messageId: res.data.messages?.[0]?.id };
}

// ─── Dispatcher ───────────────────────────────────────────────────────────────

async function send(phoneNumber, message) {
  const provider = (process.env.WHATSAPP_PROVIDER || 'log').toLowerCase();
  try {
    if (provider === 'twilio') return await sendViaTwilio(phoneNumber, message);
    if (provider === 'meta')   return await sendViaMeta(phoneNumber, message);
    return await sendViaLog(phoneNumber, message);
  } catch (err) {
    logger.error(`WhatsApp send failed [${provider}]`, { error: err.message, to: phoneNumber });
    return { success: false, error: err.message };
  }
}

// ─── Named notification functions ─────────────────────────────────────────────

const BASE_URL   = process.env.CLIENT_URL || 'http://localhost:5174';
const SUPPORT_PH = process.env.SUPPORT_PHONE || '';

async function notifyActivation(tenant) {
  const sub = tenant.subscription;
  const end = sub.endDate
    ? new Date(sub.endDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
    : 'N/A';
  const msg = templates.activated({
    salonName: tenant.salonName,
    ownerName: tenant.ownerName,
    plan:      sub.plan,
    endDate:   end,
    loginUrl:  `${BASE_URL}/login`,
  });
  return send(tenant.whatsapp || tenant.phone, msg);
}

async function notifyExpiryWarning(tenant) {
  const days = tenant.daysUntilExpiry();
  const sub  = tenant.subscription;
  const end  = sub.endDate
    ? new Date(sub.endDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
    : 'N/A';
  const msg = templates.expiryWarning({
    salonName: tenant.salonName,
    ownerName: tenant.ownerName,
    daysLeft:  days,
    endDate:   end,
    renewUrl:  `${BASE_URL}/renew`,
  });
  return send(tenant.whatsapp || tenant.phone, msg);
}

async function notifyExpired(tenant) {
  const sub = tenant.subscription;
  const end = sub.endDate
    ? new Date(sub.endDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
    : 'N/A';
  const msg = templates.expired({
    salonName:    tenant.salonName,
    ownerName:    tenant.ownerName,
    endDate:      end,
    supportPhone: SUPPORT_PH,
  });
  return send(tenant.whatsapp || tenant.phone, msg);
}

async function notifySuspended(tenant) {
  const msg = templates.suspended({
    salonName:    tenant.salonName,
    ownerName:    tenant.ownerName,
    supportPhone: SUPPORT_PH,
  });
  return send(tenant.whatsapp || tenant.phone, msg);
}

async function notifyCustom(tenant, message) {
  const msg = templates.custom({ salonName: tenant.salonName, message });
  return send(tenant.whatsapp || tenant.phone, msg);
}

module.exports = {
  send,
  notifyActivation,
  notifyExpiryWarning,
  notifyExpired,
  notifySuspended,
  notifyCustom,
};
