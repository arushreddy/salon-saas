const Booking  = require('../models/Booking');
const Payment  = require('../models/Payment');
const User     = require('../models/User');
const Service  = require('../models/Service');
const Staff    = require('../models/Staff');
const { AppError } = require('../middlewares/errorHandler');

const getDateRange = (period) => {
  const now   = new Date();
  const today = new Date(now);
  today.setHours(0, 0, 0, 0);

  switch (period) {
    case 'today':     { const t = new Date(today); t.setDate(t.getDate()+1);     return { start: today, end: t }; }
    case 'yesterday': { const y = new Date(today); y.setDate(y.getDate()-1);     return { start: y, end: today }; }
    case 'thisWeek':  { const w = new Date(today); w.setDate(w.getDate()-w.getDay()); return { start: w, end: new Date() }; }
    case 'lastWeek':  {
      const le = new Date(today); le.setDate(le.getDate()-le.getDay());
      const ls = new Date(le);    ls.setDate(ls.getDate()-7);
      return { start: ls, end: le };
    }
    case 'thisMonth': { const m = new Date(today.getFullYear(),today.getMonth(),1); return { start: m, end: new Date() }; }
    case 'lastMonth': {
      const lms = new Date(today.getFullYear(),today.getMonth()-1,1);
      const lme = new Date(today.getFullYear(),today.getMonth(),1);
      return { start: lms, end: lme };
    }
    case 'thisYear':  { const y = new Date(today.getFullYear(),0,1); return { start: y, end: new Date() }; }
    case 'last30':    { const d = new Date(today); d.setDate(d.getDate()-30); return { start: d, end: new Date() }; }
    case 'last7':     { const d = new Date(today); d.setDate(d.getDate()-7);  return { start: d, end: new Date() }; }
    default:          { const m = new Date(today.getFullYear(),today.getMonth(),1); return { start: m, end: new Date() }; }
  }
};

// GET /api/analytics/overview
const getOverview = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { period = 'thisMonth' } = req.query;
    const { start, end } = getDateRange(period);
    const duration  = end - start;
    const prevStart = new Date(start - duration);
    const prevEnd   = new Date(start);

    const dateFilter     = { $gte: start,     $lt: end     };
    const prevDateFilter = { $gte: prevStart,  $lt: prevEnd };

    // Always cast tenantId to ObjectId safely for aggregates
    const mongoose = require('mongoose');
    let tenantOid;
    try { tenantOid = new mongoose.Types.ObjectId(tenantId); }
    catch { return next(new AppError('Invalid tenant', 400)); }

    const [revenue, prevRevenue, bookings, prevBookings, customers, prevCustomers] = await Promise.all([
      // Use Booking.finalAmount — same source as the payments page
      Booking.aggregate([{ $match: { tenantId: tenantOid, date: dateFilter, status: 'completed', paymentStatus: 'paid' } }, { $group: { _id: null, total: { $sum: '$finalAmount' }, count: { $sum: 1 } } }]),
      Booking.aggregate([{ $match: { tenantId: tenantOid, date: prevDateFilter, status: 'completed', paymentStatus: 'paid' } }, { $group: { _id: null, total: { $sum: '$finalAmount' }, count: { $sum: 1 } } }]),
      Booking.countDocuments({ tenantId: tenantOid, date: dateFilter,     status: { $ne: 'cancelled' } }),
      Booking.countDocuments({ tenantId: tenantOid, date: prevDateFilter, status: { $ne: 'cancelled' } }),
      User.countDocuments({ tenantId: tenantOid, role: 'customer', createdAt: dateFilter }),
      User.countDocuments({ tenantId: tenantOid, role: 'customer', createdAt: prevDateFilter }),
    ]);

    const currentRevenue  = revenue[0]?.total     || 0;
    const previousRevenue = prevRevenue[0]?.total  || 0;
    const revenueGrowth   = previousRevenue > 0 ? ((currentRevenue - previousRevenue) / previousRevenue * 100).toFixed(1) : 0;
    const bookingGrowth   = prevBookings > 0    ? ((bookings - prevBookings) / prevBookings * 100).toFixed(1) : 0;
    const customerGrowth  = prevCustomers > 0   ? ((customers - prevCustomers) / prevCustomers * 100).toFixed(1) : 0;

    const totalCustomers     = await User.countDocuments({ tenantId: tenantOid, role: 'customer' });
    const completedBookings  = await Booking.countDocuments({ tenantId: tenantOid, date: dateFilter, status: 'completed' });
    const cancelledBookings  = await Booking.countDocuments({ tenantId: tenantOid, date: dateFilter, status: 'cancelled' });

    res.status(200).json({
      success: true,
      overview: {
        revenue:   { current: currentRevenue, previous: previousRevenue, growth: parseFloat(revenueGrowth) },
        bookings:  { current: bookings, total: bookings, previous: prevBookings, growth: parseFloat(bookingGrowth), completed: completedBookings, cancelled: cancelledBookings },
        customers: { new: customers, previous: prevCustomers, growth: parseFloat(customerGrowth), total: totalCustomers },
        payments:  { count: revenue[0]?.count || 0 },
      },
    });
  } catch (error) { next(error); }
};

// GET /api/analytics/revenue
const getRevenueChart = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { period = 'thisMonth' } = req.query;
    const { start, end } = getDateRange(period);
    const mongoose = require('mongoose');
    const tid = new mongoose.Types.ObjectId(tenantId);

    // Use Bookings finalAmount as source of truth (same as payments page)
    const raw = await Booking.aggregate([
      { $match: { tenantId: tid, date: { $gte: start, $lt: end }, status: 'completed', paymentStatus: 'paid' } },
      { $group: {
          _id: { year: { $year: '$date' }, month: { $month: '$date' }, day: { $dayOfMonth: '$date' } },
          revenue:  { $sum: '$finalAmount' },
          bookings: { $sum: 1 },
      }},
      { $sort: { '_id.year': 1, '_id.month': 1, '_id.day': 1 } },
    ]);

    const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const chart = raw.map(r => ({
      label:    r._id.day + ' ' + MONTHS[r._id.month - 1],
      date:     new Date(r._id.year, r._id.month - 1, r._id.day).toISOString().split('T')[0],
      revenue:  r.revenue,
      bookings: r.bookings,
    }));

    res.status(200).json({ success: true, chart, revenueData: raw });
  } catch (error) { next(error); }
};

// GET /api/analytics/services
const getServiceStats = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { period = 'thisMonth' } = req.query;
    const { start, end } = getDateRange(period);
    const mongoose = require('mongoose');
    const tid = new mongoose.Types.ObjectId(tenantId);

    const serviceStats = await Booking.aggregate([
      { $match: { tenantId: tid, date: { $gte: start, $lt: end }, status: 'completed' } },
      { $group: { _id: '$service', bookingCount: { $sum: 1 }, revenue: { $sum: '$finalAmount' } } },
      { $lookup: { from: 'services', localField: '_id', foreignField: '_id', as: 'service' } },
      { $unwind: '$service' },
      { $project: { name: '$service.name', category: '$service.category', bookingCount: 1, revenue: 1 } },
      { $sort: { bookingCount: -1 } },
      { $limit: 10 },
    ]);

    res.status(200).json({ success: true, services: serviceStats, serviceStats });
  } catch (error) { next(error); }
};

// GET /api/analytics/staff
const getStaffStats = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { period = 'thisMonth' } = req.query;
    const { start, end } = getDateRange(period);
    const mongoose = require('mongoose');
    const tid = new mongoose.Types.ObjectId(tenantId);

    const staffStats = await Booking.aggregate([
      { $match: { tenantId: tid, date: { $gte: start, $lt: end }, status: 'completed', staff: { $ne: null } } },
      { $group: { _id: '$staff', bookingCount: { $sum: 1 }, revenue: { $sum: '$finalAmount' } } },
      { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'user' } },
      { $unwind: '$user' },
      { $project: { name: '$user.name', bookingCount: 1, revenue: 1 } },
      { $sort: { revenue: -1 } },
    ]);

    res.status(200).json({ success: true, staffStats });
  } catch (error) { next(error); }
};


// aliases + missing functions for route compatibility
const getTopServices      = getServiceStats;
const getStaffPerformance = getStaffStats;

const getPaymentMethods = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const data = await Payment.aggregate([
      { $match: { tenantId, status: 'completed' } },
      { $group: { _id: '$method', total: { $sum: '$amount' }, count: { $sum: 1 } } },
      { $sort: { total: -1 } }
    ]);
    res.status(200).json({ success: true, data });
  } catch (error) { next(error); }
};

const getBookingStats = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { period = 'month' } = req.query;
    const { start, end } = getDateRange(period);
    const data = await Booking.aggregate([
      { $match: { tenantId, createdAt: { $gte: start, $lte: end } } },
      { $group: { _id: '$status', count: { $sum: 1 } } }
    ]);
    res.status(200).json({ success: true, data });
  } catch (error) { next(error); }
};

module.exports = {
  getOverview, getRevenueChart, getServiceStats, getStaffStats,
  getTopServices, getStaffPerformance, getPaymentMethods, getBookingStats,
};