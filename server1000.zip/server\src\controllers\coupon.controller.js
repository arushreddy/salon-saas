// FILE 16: coupon.controller.js
const Coupon = require('../models/Coupon');
const { AppError } = require('../middlewares/errorHandler');

const getAllCoupons = async (req, res, next) => {
  try {
    const coupons = await Coupon.find({ tenantId: req.user.tenantId }).sort({ createdAt: -1 });
    res.status(200).json({ success: true, coupons });
  } catch (error) { next(error); }
};

const createCoupon = async (req, res, next) => {
  try {
    const coupon = await Coupon.create({ ...req.body, tenantId: req.user.tenantId });
    res.status(201).json({ success: true, message: 'Coupon created', coupon });
  } catch (error) { next(error); }
};

const validateCoupon = async (req, res, next) => {
  try {
    const { code, orderAmount } = req.body;
    const coupon = await Coupon.findOne({ tenantId: req.user.tenantId, code: code.toUpperCase() });
    if (!coupon || !coupon.isActive) throw new AppError('Invalid or expired coupon', 400);
    const now = new Date();
    if (coupon.validUntil && now > coupon.validUntil) throw new AppError('Coupon has expired', 400);
    if (coupon.maxUses > 0 && coupon.usedCount >= coupon.maxUses) throw new AppError('Coupon usage limit reached', 400);
    if (orderAmount < coupon.minOrderValue) throw new AppError(`Minimum order ₹${coupon.minOrderValue} required`, 400);
    const discount = coupon.discountType === 'percentage' ? (orderAmount * coupon.discountValue / 100) : coupon.discountValue;
    res.status(200).json({ success: true, coupon, discount: Math.min(discount, orderAmount) });
  } catch (error) { next(error); }
};

const updateCoupon = async (req, res, next) => {
  try {
    const coupon = await Coupon.findOneAndUpdate({ _id: req.params.id, tenantId: req.user.tenantId }, req.body, { new: true, runValidators: true });
    if (!coupon) throw new AppError('Coupon not found', 404);
    res.status(200).json({ success: true, coupon });
  } catch (error) { next(error); }
};

const deleteCoupon = async (req, res, next) => {
  try {
    const coupon = await Coupon.findOneAndDelete({ _id: req.params.id, tenantId: req.user.tenantId });
    if (!coupon) throw new AppError('Coupon not found', 404);
    res.status(200).json({ success: true, message: 'Coupon deleted' });
  } catch (error) { next(error); }
};

module.exports = { getAllCoupons, createCoupon, validateCoupon, updateCoupon, deleteCoupon };
