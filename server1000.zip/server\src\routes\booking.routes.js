const express = require('express');
const router  = express.Router();
const {
  getAvailableSlots, createBooking, createWalkInBooking,
  getBookings, updateBookingStatus, getTodayStats,
} = require('../controllers/booking.controller');
const { protect, authorize }            = require('../middlewares/auth.middleware');
const { tenantAccess, requireFeature }  = require('../middlewares/tenantAccess');

// ── Slot availability — also feature-gated for online booking ────────────────
router.get('/available-slots',
  protect, tenantAccess, requireFeature('onlineBooking'),
  getAvailableSlots
);

// ── Online booking (customer-created) — standard+ plan only ──────────────────
// Basic plan: this endpoint returns 403 "feature not available on your plan"
router.post('/',
  protect, tenantAccess, requireFeature('onlineBooking'),
  createBooking
);

// ── Walk-in booking — available on ALL plans (core admin/receptionist feature) ─
router.post('/walk-in',
  protect, tenantAccess, authorize('admin', 'receptionist'),
  createWalkInBooking
);

// ── Read / update bookings — all plans ───────────────────────────────────────
router.get('/today/stats', protect, tenantAccess, authorize('admin', 'staff', 'receptionist'), getTodayStats);
router.get('/',            protect, tenantAccess, getBookings);
router.patch('/:id/status',protect, tenantAccess, updateBookingStatus);

module.exports = router;
