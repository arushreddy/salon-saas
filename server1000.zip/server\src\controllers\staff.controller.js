const Staff         = require('../models/Staff');
const User          = require('../models/User');
const Booking       = require('../models/Booking');
const Tenant        = require('../models/Tenant');
const Attendance    = require('../models/Attendance');
const SalaryPayment = require('../models/SalaryPayment');
const { AppError }  = require('../middlewares/errorHandler');
const mongoose      = require('mongoose');

// ─── Internal helper ──────────────────────────────────────────────────────────
const addCommissionRate = (staff) => {
  if (!staff) return staff;
  const obj = staff.toObject ? staff.toObject() : { ...staff };
  obj.commissionRate = obj.salary?.commissionPercent ?? 0;
  return obj;
};
const addCommissionRateMany = (list) => list.map(addCommissionRate);

// ─── POST /api/staff ──────────────────────────────────────────────────────────
const addStaff = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { name, email, phone, password, role, specializations, designation, salary, schedule, bio, joiningDate } = req.body;

    if (!name || !email || !password) throw new AppError('Name, email and password are required', 400);

    const tenant   = await Tenant.findById(tenantId);
    const features = tenant?.subscription?.features || {};
    const planName = tenant?.subscription?.plan || 'basic';
    const assignedRole = role || 'staff';

    if (assignedRole === 'receptionist') {
      const receptionistCount = await User.countDocuments({ tenantId, role: 'receptionist', isActive: true });
      const maxReceptionists  = features.maxReceptionists ?? 2;
      if (receptionistCount >= maxReceptionists)
        throw new AppError(`Your ${planName} plan allows max ${maxReceptionists} receptionists. Upgrade to add more.`, 403);
    } else {
      const staffCount = await Staff.countDocuments({ tenantId });
      const maxStaff   = features.maxStaff ?? 10;
      if (staffCount >= maxStaff)
        throw new AppError(`Your ${planName} plan allows max ${maxStaff} staff. Upgrade to add more.`, 403);
    }

    const existing = await User.findOne({ email });
    if (existing) throw new AppError('A user with this email already exists', 409);

    const user = await User.create({ name, email, phone: phone || '', password, role: assignedRole, tenantId });

    const staffProfile = await Staff.create({
      tenantId,
      user:            user._id,
      specializations: specializations || [],
      designation:     designation || 'junior_stylist',
      salary:          salary   || { base: 0, commissionEnabled: false, commissionPercent: 0 },
      schedule:        schedule || { weeklyOff: ['sunday'], shiftStart: '09:00', shiftEnd: '21:00' },
      bio:             bio || '',
      joiningDate:     joiningDate || new Date(),
    });

    const populated = await Staff.findById(staffProfile._id).populate('user', 'name email phone role isActive');
    res.status(201).json({ success: true, message: 'Staff member added', staff: addCommissionRate(populated) });
  } catch (err) { next(err); }
};

// ─── GET /api/staff/limits ────────────────────────────────────────────────────
const getStaffLimits = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const tenant   = await Tenant.findById(tenantId);
    const features = tenant?.subscription?.features || {};

    const [staffCount, receptionistCount] = await Promise.all([
      Staff.countDocuments({ tenantId }),
      User.countDocuments({ tenantId, role: 'receptionist', isActive: true }),
    ]);

    res.status(200).json({
      success: true,
      limits: {
        staff:        { used: staffCount,        max: features.maxStaff         ?? 10 },
        receptionist: { used: receptionistCount, max: features.maxReceptionists ?? 2  },
        plan:         tenant?.subscription?.plan || 'basic',
      },
    });
  } catch (err) { next(err); }
};

// ─── GET /api/staff ───────────────────────────────────────────────────────────
const getAllStaff = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { designation, specialization, available } = req.query;
    const filter = { tenantId };
    if (designation)    filter.designation     = designation;
    if (specialization) filter.specializations = specialization;
    if (available !== undefined) filter.isAvailable = available === 'true';

    const staff = await Staff.find(filter)
      .populate('user', 'name email phone role isActive avatar')
      .sort({ createdAt: -1 });

    res.status(200).json({ success: true, staff: addCommissionRateMany(staff), total: staff.length });
  } catch (err) { next(err); }
};

// ─── GET /api/staff/available ─────────────────────────────────────────────────
const getAvailableStaff = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { date, serviceCategory } = req.query;
    const filter = { tenantId, isAvailable: true };
    if (serviceCategory) filter.specializations = serviceCategory;
    if (date) {
      const dayOfWeek = new Date(date).toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
      filter['schedule.weeklyOff'] = { $ne: dayOfWeek };
    }
    const staff      = await Staff.find(filter).populate('user', 'name email phone isActive').sort({ averageRating: -1 });
    const activeStaff = staff.filter(s => s.user && s.user.isActive);
    res.status(200).json({ success: true, staff: activeStaff });
  } catch (err) { next(err); }
};

// ─── GET /api/staff/live-status ───────────────────────────────────────────────
// Returns every active staff member with their real-time status
const getLiveStatus = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const today    = new Date(); today.setHours(0,0,0,0);
    const tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate() + 1);

    const [staffProfiles, todayAttendance, activeBookings] = await Promise.all([
      Staff.find({ tenantId }).populate('user', 'name email phone role isActive avatar'),
      Attendance.find({ tenantId, date: today }),
      Booking.find({
        tenantId,
        date:   { $gte: today, $lt: tomorrow },
        status: { $in: ['confirmed', 'in-progress'] },
      }),
    ]);

    const attMap     = {};
    todayAttendance.forEach(a => { attMap[String(a.staff)] = a; });

    const busyUserIds = new Set(activeBookings.map(b => String(b.staff)));

    const staffList = staffProfiles
      .filter(s => s.user && s.user.isActive)
      .map(s => {
        const uid = String(s.user._id);
        const att = attMap[uid];
        const isClockedIn = att && att.sessions.some(sess => sess.clockIn && !sess.clockOut);
        const hasClocked  = att && (att.clockIn || att.sessions.length > 0);

        let liveStatus;
        if (!att || att.status === 'absent')        liveStatus = 'absent';
        else if (['leave','holiday'].includes(att.status)) liveStatus = 'off-duty';
        else if (s.isAvailable === false)            liveStatus = 'off-duty';
        else if (busyUserIds.has(uid))               liveStatus = 'busy';
        else if (isClockedIn || hasClocked)          liveStatus = 'available';
        else                                          liveStatus = 'off-duty';

        return {
          _id:              uid,                       // User._id as string
          staffProfileId:   s._id,                    // Staff profile _id
          name:             s.user.name,
          email:            s.user.email,
          phone:            s.user.phone || '',
          role:             s.user.role,
          designation:      s.designation,
          specializations:  s.specializations,
          isAvailable:      s.isAvailable,
          liveStatus,
          isClockedIn,
          attendanceStatus: att?.status || 'absent',
          totalMinutes:     att?.totalMinutes || 0,
          shiftStart:       s.schedule?.shiftStart,
          shiftEnd:         s.schedule?.shiftEnd,
          currentBooking:   activeBookings.find(b => String(b.staff) === uid) || null,
          salary:           s.salary,
        };
      });

    const summary = {
      total:     staffList.length,
      available: staffList.filter(s => s.liveStatus === 'available').length,
      busy:      staffList.filter(s => s.liveStatus === 'busy').length,
      offDuty:   staffList.filter(s => s.liveStatus === 'off-duty').length,
      absent:    staffList.filter(s => s.liveStatus === 'absent').length,
    };

    res.status(200).json({ success: true, staff: staffList, summary });
  } catch (err) { next(err); }
};

// ─── GET /api/staff/me ────────────────────────────────────────────────────────
const getMyProfile = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const userId   = req.user.userId;

    const staffProfile = await Staff.findOne({ user: userId, tenantId })
      .populate('user', 'name email phone role isActive avatar');

    if (!staffProfile) throw new AppError('Staff profile not found', 404);

    res.status(200).json({ success: true, staff: addCommissionRate(staffProfile) });
  } catch (err) { next(err); }
};

// ─── GET /api/staff/my/earnings ───────────────────────────────────────────────
// Used by StaffEarnings.jsx and StaffSalary.jsx
const getMyEarnings = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const userId   = req.user.userId;
    const { period } = req.query;

    const staffProfile = await Staff.findOne({ user: userId, tenantId });
    if (!staffProfile) throw new AppError('Staff profile not found', 404);

    const now   = new Date(Date.now() + 5.5 * 60 * 60 * 1000);
    let startDate, endDate;

    if (period === 'today') {
      startDate = new Date(now); startDate.setHours(0,0,0,0);
      endDate   = new Date(now); endDate.setHours(23,59,59,999);
    } else if (period === 'week') {
      const day = now.getDay();
      startDate = new Date(now); startDate.setDate(now.getDate() - (day === 0 ? 6 : day - 1)); startDate.setHours(0,0,0,0);
      endDate   = new Date();
    } else if (period === 'year') {
      startDate = new Date(now.getFullYear(), 0, 1);
      endDate   = new Date();
    } else {
      // default: this month
      startDate = new Date(now.getFullYear(), now.getMonth(), 1);
      endDate   = new Date();
    }

    const tid = new mongoose.Types.ObjectId(tenantId);

    // Revenue from completed bookings in period
    const revenueAgg = await Booking.aggregate([
      { $match: {
        tenantId: tid,
        staff: new mongoose.Types.ObjectId(userId),
        date: { $gte: startDate, $lte: endDate },
        status: 'completed',
        paymentStatus: 'paid',
      }},
      { $group: { _id: null, total: { $sum: '$finalAmount' }, count: { $sum: 1 } } },
    ]);
    const periodRevenue   = revenueAgg[0]?.total  || 0;
    const periodBookings  = revenueAgg[0]?.count  || 0;

    // All salary payment records (all time)
    const salaryRecords = await SalaryPayment
      .find({ staff: userId })
      .sort({ paidAt: -1 });

    // Commission calculation
    const commission = staffProfile.salary?.commissionEnabled
      ? Math.round(periodRevenue * (staffProfile.salary.commissionPercent / 100))
      : 0;

    // This month totals
    const thisMonth     = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    const monthRecords  = salaryRecords.filter(r => r.month === thisMonth);
    const monthPaid     = monthRecords.filter(r => r.type === 'payment').reduce((s, r) => s + r.amount, 0);
    const monthDeducted = monthRecords.filter(r => r.type === 'deduction').reduce((s, r) => s + r.amount, 0);
    const monthBonus    = monthRecords.filter(r => r.type === 'bonus').reduce((s, r) => s + r.amount, 0);

    const baseSalary = staffProfile.salary?.base || 0;
    const netPay     = baseSalary + commission + monthBonus - monthDeducted;

    res.status(200).json({
      success: true,
      earnings: {
        period: period || 'month',
        periodRevenue,
        periodBookings,
        commission,
        baseSalary,
        commissionEnabled: staffProfile.salary?.commissionEnabled || false,
        commissionPercent: staffProfile.salary?.commissionPercent || 0,
        monthPaid,
        monthDeducted,
        monthBonus,
        netPay: Math.max(0, netPay),
        thisMonth,
        totalRevenueGenerated: staffProfile.totalRevenueGenerated || 0,
        totalServicesCompleted: staffProfile.totalServicesCompleted || 0,
        averageRating: staffProfile.averageRating || 0,
      },
      records: salaryRecords,
    });
  } catch (err) { next(err); }
};

// ─── GET /api/staff/:id ───────────────────────────────────────────────────────
const getStaffById = async (req, res, next) => {
  try {
    const staff = await Staff.findOne({ _id: req.params.id, tenantId: req.user.tenantId })
      .populate('user', 'name email phone role isActive avatar');
    if (!staff) throw new AppError('Staff not found', 404);

    const recentBookings = await Booking
      .find({ tenantId: req.user.tenantId, staff: staff.user._id })
      .populate('service', 'name category price')
      .populate('customer', 'name')
      .sort({ date: -1 }).limit(10);

    res.status(200).json({ success: true, staff: addCommissionRate(staff), recentBookings });
  } catch (err) { next(err); }
};

// ─── GET /api/staff/:id/performance ──────────────────────────────────────────
const getStaffPerformance = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const staff = await Staff.findOne({ _id: req.params.id, tenantId }).populate('user', 'name');
    if (!staff) throw new AppError('Staff not found', 404);

    const today          = new Date(); today.setHours(0,0,0,0);
    const tomorrow       = new Date(today); tomorrow.setDate(tomorrow.getDate() + 1);
    const thisMonthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    const tid            = new mongoose.Types.ObjectId(tenantId);

    const [todayBookings, monthBookings, monthRevenue] = await Promise.all([
      Booking.countDocuments({ tenantId, staff: staff.user._id, date: { $gte: today, $lt: tomorrow }, status: { $in: ['confirmed','in-progress','completed'] } }),
      Booking.countDocuments({ tenantId, staff: staff.user._id, date: { $gte: thisMonthStart }, status: 'completed' }),
      Booking.aggregate([
        { $match: { tenantId: tid, staff: staff.user._id, date: { $gte: thisMonthStart }, status: 'completed', paymentStatus: 'paid' } },
        { $group: { _id: null, total: { $sum: '$finalAmount' } } },
      ]),
    ]);

    res.status(200).json({
      success: true,
      performance: {
        name: staff.user.name,
        todayBookings,
        monthBookings,
        monthRevenue:           monthRevenue[0]?.total || 0,
        totalServicesCompleted: staff.totalServicesCompleted,
        totalRevenueGenerated:  staff.totalRevenueGenerated,
        averageRating:          staff.averageRating,
      },
    });
  } catch (err) { next(err); }
};

// ─── GET /api/staff/:id/revenue ───────────────────────────────────────────────
// Used by AdminStaff revenue tab. id = Staff._id
const getStaffRevenue = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const staff    = await Staff.findOne({ _id: req.params.id, tenantId }).populate('user', 'name');
    if (!staff) throw new AppError('Staff not found', 404);

    const userId = staff.user._id;
    const now    = new Date();
    const tid    = new mongoose.Types.ObjectId(tenantId);

    const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const lastMonthEnd   = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59);

    const [thisMonth, lastMonth, allTime, recentBookings] = await Promise.all([
      Booking.aggregate([
        { $match: { tenantId: tid, staff: userId, date: { $gte: thisMonthStart }, status: 'completed', paymentStatus: 'paid' } },
        { $group: { _id: null, total: { $sum: '$finalAmount' }, count: { $sum: 1 } } },
      ]),
      Booking.aggregate([
        { $match: { tenantId: tid, staff: userId, date: { $gte: lastMonthStart, $lte: lastMonthEnd }, status: 'completed', paymentStatus: 'paid' } },
        { $group: { _id: null, total: { $sum: '$finalAmount' }, count: { $sum: 1 } } },
      ]),
      Booking.aggregate([
        { $match: { tenantId: tid, staff: userId, status: 'completed', paymentStatus: 'paid' } },
        { $group: { _id: null, total: { $sum: '$finalAmount' }, count: { $sum: 1 } } },
      ]),
      Booking.find({ tenantId, staff: userId, status: 'completed' })
        .populate('service', 'name price')
        .populate('customer', 'name')
        .sort({ date: -1 }).limit(10),
    ]);

    // Salary payment records for this staff
    const salaryHistory = await SalaryPayment
      .find({ staff: userId })
      .sort({ paidAt: -1 }).limit(20);

    res.status(200).json({
      success: true,
      revenue: {
        thisMonth:   { total: thisMonth[0]?.total  || 0, count: thisMonth[0]?.count  || 0 },
        lastMonth:   { total: lastMonth[0]?.total  || 0, count: lastMonth[0]?.count  || 0 },
        allTime:     { total: allTime[0]?.total    || 0, count: allTime[0]?.count    || 0 },
        salary:      staff.salary,
        recentBookings,
        salaryHistory,
      },
    });
  } catch (err) { next(err); }
};

// ─── POST /api/staff/:id/salary-payment ──────────────────────────────────────
// id = Staff._id
const addSalaryPayment = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const adminId  = req.user.userId;
    const staff    = await Staff.findOne({ _id: req.params.id, tenantId }).populate('user', 'name');
    if (!staff) throw new AppError('Staff not found', 404);

    const {
      type, amount, month, note, paymentMethod,
      referenceNo, baseSalary, commissionAmount,
      revenueGenerated, totalNetPay,
    } = req.body;

    if (!type || !amount || !month) throw new AppError('type, amount, month are required', 400);

    const record = await SalaryPayment.create({
      staff:             staff.user._id,
      staffProfile:      staff._id,
      type,
      month,
      amount:            Number(amount),
      baseSalary:        baseSalary        || staff.salary?.base || 0,
      commissionEnabled: staff.salary?.commissionEnabled || false,
      commissionPercent: staff.salary?.commissionPercent || 0,
      commissionAmount:  commissionAmount  || 0,
      revenueGenerated:  revenueGenerated  || 0,
      totalNetPay:       totalNetPay       || Number(amount),
      note:              note || '',
      paymentMethod:     paymentMethod || 'cash',
      referenceNo:       referenceNo || '',
      paidBy:            adminId,
      status:            'paid',
    });

    res.status(201).json({ success: true, message: 'Payment recorded', record });
  } catch (err) { next(err); }
};

// ─── PUT /api/staff/:id ───────────────────────────────────────────────────────
const updateStaff = async (req, res, next) => {
  try {
    const staff = await Staff.findOne({ _id: req.params.id, tenantId: req.user.tenantId });
    if (!staff) throw new AppError('Staff not found', 404);

    const { name, phone, role, specializations, designation, salary, schedule, bio, isAvailable } = req.body;
    if (name || phone || role) await User.findByIdAndUpdate(staff.user, { ...(name && { name }), ...(phone && { phone }), ...(role && { role }) });
    if (specializations !== undefined) staff.specializations = specializations;
    if (designation !== undefined)     staff.designation     = designation;
    if (salary)    staff.salary   = { ...staff.salary.toObject(),   ...salary };
    if (schedule)  staff.schedule = { ...staff.schedule.toObject(), ...schedule };
    if (bio !== undefined)         staff.bio         = bio;
    if (isAvailable !== undefined) staff.isAvailable = isAvailable;
    await staff.save();

    const populated = await Staff.findById(staff._id).populate('user', 'name email phone role isActive');
    res.status(200).json({ success: true, message: 'Staff updated', staff: addCommissionRate(populated) });
  } catch (err) { next(err); }
};

// ─── PATCH /api/staff/:id ─────────────────────────────────────────────────────
const patchStaff = async (req, res, next) => {
  try {
    const staff = await Staff.findOne({ _id: req.params.id, tenantId: req.user.tenantId });
    if (!staff) throw new AppError('Staff not found', 404);

    if (req.body.commissionRate !== undefined) {
      const r = Number(req.body.commissionRate);
      staff.salary.commissionPercent = r;
      staff.salary.commissionEnabled = r > 0;
    }
    if (req.body.isAvailable !== undefined)     staff.isAvailable     = req.body.isAvailable;
    if (req.body.bio !== undefined)             staff.bio             = req.body.bio;
    if (req.body.designation !== undefined)     staff.designation     = req.body.designation;
    if (req.body.specializations !== undefined) staff.specializations = req.body.specializations;
    if (req.body.salary !== undefined)   staff.salary   = { ...staff.salary.toObject(),   ...req.body.salary };
    if (req.body.schedule !== undefined) staff.schedule = { ...staff.schedule.toObject(), ...req.body.schedule };
    await staff.save();

    const populated = await Staff.findById(staff._id).populate('user', 'name email phone role isActive');
    res.status(200).json({ success: true, message: 'Staff updated', staff: addCommissionRate(populated) });
  } catch (err) { next(err); }
};

// ─── PATCH /api/staff/:id/floor-status ───────────────────────────────────────
// id = Staff profile _id (receptionist sends this from StaffCard)
const patchFloorStatus = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { status } = req.body;
    if (!status) throw new AppError('status is required', 400);

    const staff = await Staff.findOne({ _id: req.params.id, tenantId });
    if (!staff) throw new AppError('Staff not found', 404);

    // floor status is reflected in isAvailable + we store it implicitly via attendance
    // 'available' → isAvailable true, 'off-duty'/'busy' → no change (attendance controls)
    if (status === 'available')  staff.isAvailable = true;
    if (status === 'off-duty')   staff.isAvailable = false;
    // 'busy' doesn't change isAvailable (booking drives that)
    await staff.save();

    res.status(200).json({ success: true, message: `Status set to ${status}`, status });
  } catch (err) { next(err); }
};

// ─── DELETE /api/staff/:id ────────────────────────────────────────────────────
const deleteStaff = async (req, res, next) => {
  try {
    const staff = await Staff.findOne({ _id: req.params.id, tenantId: req.user.tenantId });
    if (!staff) throw new AppError('Staff not found', 404);
    await User.findByIdAndUpdate(staff.user, { isActive: false });
    staff.isAvailable = false;
    await staff.save();
    res.status(200).json({ success: true, message: 'Staff member deactivated' });
  } catch (err) { next(err); }
};

module.exports = {
  addStaff,
  getAllStaff,
  getAvailableStaff,
  getLiveStatus,
  getMyProfile,
  getMyEarnings,
  getStaffById,
  getStaffPerformance,
  getStaffRevenue,
  addSalaryPayment,
  updateStaff,
  patchStaff,
  patchFloorStatus,
  deleteStaff,
  getStaffLimits,
};