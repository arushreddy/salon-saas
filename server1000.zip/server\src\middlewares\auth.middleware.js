/**
 * UPDATED auth.middleware.js
 *
 * Changes from original:
 *  - `req.user` now includes `tenantId` from the decoded token
 *  - superadmin role bypasses tenantId requirement
 *
 * Replace your existing src/middlewares/auth.middleware.js with this.
 */

const { verifyAccessToken } = require('../utils/token');
const { AppError }          = require('./errorHandler');

const protect = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new AppError('Access denied. No token provided.', 401);
    }

    const token   = authHeader.split(' ')[1];
    const decoded = verifyAccessToken(token);

    req.user = {
      userId:   decoded.userId,
      role:     decoded.role,
      tenantId: decoded.tenantId || null,   // ← NEW
    };

    next();
  } catch (error) {
    console.error('Token error:', error.message);
    if (error.name === 'JsonWebTokenError' || error.name === 'TokenExpiredError') {
      return next(new AppError('Invalid or expired token', 401));
    }
    next(error);
  }
};

const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      throw new AppError('You do not have permission to perform this action', 403);
    }
    next();
  };
};

module.exports = { protect, authorize };
