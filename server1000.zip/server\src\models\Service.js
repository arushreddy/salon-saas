const mongoose = require('mongoose');

const serviceSchema = new mongoose.Schema(
  {
    tenantId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Tenant',
      required: true,
      index: true,
    },
    name: { type: String, required: [true, 'Service name is required'], trim: true },
    description: { type: String, trim: true },
    category: {
      type: String, required: [true, 'Category is required'],
      enum: ['hair', 'skin', 'nails', 'makeup', 'spa', 'bridal', 'grooming', 'combo'],
      lowercase: true,
    },
    price:    { type: Number, required: [true, 'Price is required'], min: 0 },
    duration: { type: Number, required: [true, 'Duration is required'], min: 5 }, // minutes
    isActive: { type: Boolean, default: true },
    image:    { type: String, default: '' },
  },
  { timestamps: true }
);

serviceSchema.index({ tenantId: 1, category: 1 });
serviceSchema.index({ tenantId: 1, isActive: 1 });

module.exports = mongoose.model('Service', serviceSchema);
