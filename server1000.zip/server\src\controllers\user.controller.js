const User = require('../models/User');
const { AppError } = require('../middlewares/errorHandler');

// GET /api/users — Admin sees only their salon's users
const getAllUsers = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { role, search, page = 1, limit = 20 } = req.query;

    const filter = { tenantId };
    if (role)   filter.role = role;
    if (search) filter.$or = [
      { name:  { $regex: search, $options: 'i' } },
      { email: { $regex: search, $options: 'i' } },
    ];

    const [users, total] = await Promise.all([
      User.find(filter).sort({ createdAt: -1 }).skip((Number(page)-1)*Number(limit)).limit(Number(limit)),
      User.countDocuments(filter),
    ]);

    res.status(200).json({ success: true, users, pagination: { total, page: Number(page), pages: Math.ceil(total/Number(limit)) } });
  } catch (error) { next(error); }
};

// GET /api/users/customers — customers for this salon (used by receptionist/admin)
const getCustomers = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { search, page = 1, limit = 30 } = req.query;
    const filter = { tenantId, role: 'customer' };
    if (search) filter.$or = [
      { name:  { $regex: search, $options: 'i' } },
      { phone: { $regex: search, $options: 'i' } },
      { email: { $regex: search, $options: 'i' } },
    ];

    const [users, total] = await Promise.all([
      User.find(filter).sort({ createdAt: -1 }).skip((Number(page)-1)*Number(limit)).limit(Number(limit)),
      User.countDocuments(filter),
    ]);

    res.status(200).json({ success: true, customers: users, total, page: Number(page), pages: Math.ceil(total/Number(limit)) });
  } catch (error) { next(error); }
};

// POST /api/users/customers — Receptionist/admin creates a walk-in customer
const createCustomer = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { name, phone, email } = req.body;
    if (!name) throw new AppError('Name is required', 400);

    // Check if customer with same phone already exists in this salon
    if (phone) {
      const existing = await User.findOne({ tenantId, phone, role: 'customer' });
      if (existing) return res.status(200).json({ success: true, customer: existing, existed: true });
    }

    const password = phone || Math.random().toString(36).slice(-8); // auto-password for walk-ins
    const customer = await User.create({
      name, phone: phone||'', email: email||`walkin_${Date.now()}@salon.local`,
      password, role: 'customer', tenantId, isActive: true,
    });

    res.status(201).json({ success: true, customer, existed: false });
  } catch (error) { next(error); }
};

// PATCH /api/users/:id/role
const updateUserRole = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { role } = req.body;
    if (!['customer','staff','receptionist','admin'].includes(role)) throw new AppError('Invalid role', 400);

    const user = await User.findOneAndUpdate({ _id: req.params.id, tenantId }, { role }, { new: true, runValidators: true });
    if (!user) throw new AppError('User not found', 404);

    res.status(200).json({ success: true, message: `User role updated to ${role}`, user });
  } catch (error) { next(error); }
};

// PATCH /api/users/:id/status
const toggleUserStatus = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const user = await User.findOne({ _id: req.params.id, tenantId });
    if (!user) throw new AppError('User not found', 404);

    user.isActive = !user.isActive;
    await user.save({ validateBeforeSave: false });

    res.status(200).json({ success: true, message: `User ${user.isActive ? 'activated' : 'deactivated'}`, user });
  } catch (error) { next(error); }
};

module.exports = { getAllUsers, getCustomers, createCustomer, updateUserRole, toggleUserStatus };
