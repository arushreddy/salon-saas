const Tenant = require('../models/Tenant');
const User   = require('../models/User');
const Staff  = require('../models/Staff');
const wa     = require('../services/whatsapp.service');
const { AppError } = require('../middlewares/errorHandler');
const bcrypt = require('bcryptjs');
const jwt    = require('jsonwebtoken');

// ─── Super Admin Login ────────────────────────────────────────────────────────
// Super admin credentials are stored in .env (SUPERADMIN_EMAIL, SUPERADMIN_PASSWORD)

exports.superAdminLogin = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const SA_EMAIL = process.env.SUPERADMIN_EMAIL;
    const SA_PASS  = process.env.SUPERADMIN_PASSWORD;

    if (!SA_EMAIL || !SA_PASS) {
      return next(new AppError('Super admin not configured.', 500));
    }

    if (email !== SA_EMAIL || password !== SA_PASS) {
      return next(new AppError('Invalid super admin credentials.', 401));
    }

    const token = jwt.sign(
      { role: 'superadmin', email: SA_EMAIL },
      process.env.JWT_ACCESS_SECRET,
      { expiresIn: '8h' }
    );

    res.json({ success: true, token, role: 'superadmin' });
  } catch (err) { next(err); }
};

// ─── Dashboard Stats ──────────────────────────────────────────────────────────

exports.getDashboardStats = async (req, res, next) => {
  try {
    const [
      totalTenants,
      activeTenants,
      trialTenants,
      expiredTenants,
      suspendedTenants,
    ] = await Promise.all([
      Tenant.countDocuments(),
      Tenant.countDocuments({ isActive: true, 'subscription.status': 'active' }),
      Tenant.countDocuments({ isActive: true, 'subscription.status': 'trial' }),
      Tenant.countDocuments({ 'subscription.status': 'expired' }),
      Tenant.countDocuments({ isActive: false }),
    ]);

    // Expiring in 7 days
    const sevenDaysFromNow = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    const expiringSoon = await Tenant.countDocuments({
      isActive: true,
      'subscription.status': 'active',
      'subscription.endDate': { $lte: sevenDaysFromNow, $gte: new Date() },
    });

    // Revenue (sum all subscription payments)
    const revenueAgg = await Tenant.aggregate([
      { $unwind: { path: '$subscription.payments', preserveNullAndEmpty: true } },
      { $group: { _id: null, total: { $sum: '$subscription.payments.amount' } } },
    ]);
    const totalRevenue = revenueAgg[0]?.total || 0;

    // Plan breakdown
    const planBreakdown = await Tenant.aggregate([
      { $group: { _id: '$subscription.plan', count: { $sum: 1 } } },
    ]);

    // Recent tenants (last 7)
    const recentTenants = await Tenant.find()
      .sort({ createdAt: -1 })
      .limit(7)
      .select('salonName ownerName phone subscription.status subscription.plan createdAt');

    res.json({
      success: true,
      data: {
        counts: { totalTenants, activeTenants, trialTenants, expiredTenants, suspendedTenants, expiringSoon },
        totalRevenue,
        planBreakdown: planBreakdown.reduce((acc, p) => { acc[p._id || 'none'] = p.count; return acc; }, {}),
        recentTenants,
      }
    });
  } catch (err) { next(err); }
};

// ─── List All Tenants ─────────────────────────────────────────────────────────

exports.listTenants = async (req, res, next) => {
  try {
    const { status, plan, search, page = 1, limit = 20 } = req.query;
    const filter = {};
    if (status === 'active')    filter.isActive = true, filter['subscription.status'] = 'active';
    else if (status === 'suspended') filter.isActive = false;
    else if (status === 'expired')   filter['subscription.status'] = 'expired';
    else if (status === 'trial')     filter['subscription.status'] = 'trial';
    if (plan) filter['subscription.plan'] = plan;
    if (search) {
      filter.$or = [
        { salonName: { $regex: search, $options: 'i' } },
        { ownerName: { $regex: search, $options: 'i' } },
        { phone:     { $regex: search, $options: 'i' } },
        { email:     { $regex: search, $options: 'i' } },
      ];
    }

    const skip  = (Number(page) - 1) * Number(limit);
    const [tenants, total] = await Promise.all([
      Tenant.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      Tenant.countDocuments(filter),
    ]);

    // Enrich with live staff count
    const enriched = await Promise.all(tenants.map(async (t) => {
      const staffCount = await Staff.countDocuments({ tenantId: t._id });
      return { ...t.toObject(), liveStaffCount: staffCount };
    }));

    res.json({ success: true, data: enriched, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (err) { next(err); }
};

// ─── Get Single Tenant ────────────────────────────────────────────────────────

exports.getTenant = async (req, res, next) => {
  try {
    const tenant = await Tenant.findById(req.params.id);
    if (!tenant) return next(new AppError('Tenant not found', 404));

    const [staffCount, userCount] = await Promise.all([
      Staff.countDocuments({ tenantId: tenant._id }),
      User.countDocuments({ tenantId: tenant._id }),
    ]);

    res.json({ success: true, data: { ...tenant.toObject(), liveStaffCount: staffCount, liveUserCount: userCount } });
  } catch (err) { next(err); }
};

// ─── Create Tenant ────────────────────────────────────────────────────────────

exports.createTenant = async (req, res, next) => {
  try {
    const {
      salonName, ownerName, email, phone, whatsapp,
      address, adminPassword,
      plan = 'basic', trialDays = 14,
    } = req.body;

    if (!salonName || !ownerName || !email || !phone || !adminPassword) {
      return next(new AppError('salonName, ownerName, email, phone, adminPassword are required.', 400));
    }

    const exists = await Tenant.findOne({ email });
    if (exists) return next(new AppError('A tenant with this email already exists.', 409));

    const planFeatures = Tenant.planFeatures[plan] || Tenant.planFeatures.basic;
    const trialEndsAt  = new Date(Date.now() + trialDays * 24 * 60 * 60 * 1000);

    const tenant = await Tenant.create({
      salonName, ownerName, email, phone,
      whatsapp: whatsapp || phone,
      address: address || {},
      adminPassword,
      subscription: {
        plan,
        status:      'trial',
        trialEndsAt,
        durationDays: trialDays,
        features:     planFeatures,
      },
    });

    // Also create the admin User record in the main users collection
    const adminUser = await User.create({
      name:     ownerName,
      email,
      phone,
      password: adminPassword,
      role:     'admin',
      tenantId: tenant._id,
    });

    // Send WhatsApp activation message
    try {
      await wa.notifyActivation({
        ...tenant.toObject(),
        subscription: {
          ...tenant.subscription,
          endDate: trialEndsAt,
          plan,
        },
        daysUntilExpiry: () => trialDays,
      });
      tenant.notifications.activationSent  = true;
      tenant.notifications.lastNotifiedAt  = new Date();
      await tenant.save();
    } catch (waErr) {
      // WA failure should not block tenant creation
    }

    res.status(201).json({ success: true, data: tenant, adminUserId: adminUser._id });
  } catch (err) { next(err); }
};

// ─── Update Tenant Info ───────────────────────────────────────────────────────

exports.updateTenant = async (req, res, next) => {
  try {
    const allowed = ['salonName', 'ownerName', 'phone', 'whatsapp', 'address', 'accessNotes'];
    const updates = {};
    allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });

    const tenant = await Tenant.findByIdAndUpdate(req.params.id, updates, { new: true, runValidators: true });
    if (!tenant) return next(new AppError('Tenant not found', 404));

    res.json({ success: true, data: tenant });
  } catch (err) { next(err); }
};

// ─── Activate / Renew Subscription ───────────────────────────────────────────

exports.activateSubscription = async (req, res, next) => {
  try {
    const { plan = 'basic', durationDays, paymentAmount, paymentMethod, paymentReference, notes } = req.body;
    if (!durationDays || durationDays < 1) {
      return next(new AppError('durationDays is required and must be > 0', 400));
    }

    const tenant = await Tenant.findById(req.params.id);
    if (!tenant) return next(new AppError('Tenant not found', 404));

    const planFeatures = Tenant.planFeatures[plan] || Tenant.planFeatures.basic;
    const startDate    = new Date();
    const endDate      = new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000);

    tenant.subscription.plan         = plan;
    tenant.subscription.status       = 'active';
    tenant.subscription.startDate    = startDate;
    tenant.subscription.endDate      = endDate;
    tenant.subscription.durationDays = durationDays;
    tenant.subscription.features     = planFeatures;
    tenant.isActive                  = true;

    // Reset notification flags for new term
    tenant.notifications.expiryWarningSent = false;
    tenant.notifications.expiredSent       = false;

    // Record payment
    if (paymentAmount) {
      tenant.subscription.payments.push({
        amount:    paymentAmount,
        method:    paymentMethod || 'manual',
        reference: paymentReference || '',
        notes:     notes || '',
        paidAt:    new Date(),
      });
    }

    await tenant.save();

    // Sync admin user's tenantId if they exist
    await User.updateOne({ email: tenant.email, role: 'admin' }, { isActive: true });

    // WhatsApp
    try {
      await wa.notifyActivation(tenant);
      tenant.notifications.activationSent = true;
      tenant.notifications.lastNotifiedAt = new Date();
      await tenant.save();
    } catch (_) {}

    res.json({ success: true, data: tenant, message: 'Subscription activated successfully.' });
  } catch (err) { next(err); }
};

// ─── Suspend / Reactivate Tenant ─────────────────────────────────────────────

exports.toggleTenantAccess = async (req, res, next) => {
  try {
    const tenant = await Tenant.findById(req.params.id);
    if (!tenant) return next(new AppError('Tenant not found', 404));

    tenant.isActive = !tenant.isActive;
    await tenant.save();

    // Also suspend all users of this tenant
    await User.updateMany({ tenantId: tenant._id }, { isActive: tenant.isActive });

    if (!tenant.isActive) {
      try { await wa.notifySuspended(tenant); } catch (_) {}
    }

    res.json({ success: true, isActive: tenant.isActive, message: `Tenant ${tenant.isActive ? 'reactivated' : 'suspended'}.` });
  } catch (err) { next(err); }
};

// ─── Reset Admin Password ─────────────────────────────────────────────────────

exports.resetAdminPassword = async (req, res, next) => {
  try {
    const { newPassword } = req.body;
    if (!newPassword || newPassword.length < 6) {
      return next(new AppError('Password must be at least 6 characters.', 400));
    }

    const tenant = await Tenant.findById(req.params.id).select('+adminPassword');
    if (!tenant) return next(new AppError('Tenant not found', 404));

    tenant.adminPassword = newPassword;  // pre-save hook will hash it
    await tenant.save();

    // Sync main user password
    const salt = await bcrypt.genSalt(12);
    const hash = await bcrypt.hash(newPassword, salt);
    await User.findOneAndUpdate({ email: tenant.email, role: 'admin' }, { password: hash });

    res.json({ success: true, message: 'Admin password reset successfully.' });
  } catch (err) { next(err); }
};

// ─── Send WhatsApp Message ────────────────────────────────────────────────────

exports.sendWhatsApp = async (req, res, next) => {
  try {
    const { type, customMessage } = req.body;
    const tenant = await Tenant.findById(req.params.id);
    if (!tenant) return next(new AppError('Tenant not found', 404));

    let result;
    if (type === 'activation')     result = await wa.notifyActivation(tenant);
    else if (type === 'warning')   result = await wa.notifyExpiryWarning(tenant);
    else if (type === 'expired')   result = await wa.notifyExpired(tenant);
    else if (type === 'suspended') result = await wa.notifySuspended(tenant);
    else if (type === 'custom' && customMessage) result = await wa.notifyCustom(tenant, customMessage);
    else return next(new AppError('Invalid message type.', 400));

    res.json({ success: true, result });
  } catch (err) { next(err); }
};

// ─── Bulk WhatsApp (e.g., broadcast renewal reminders) ───────────────────────

exports.bulkWhatsApp = async (req, res, next) => {
  try {
    const { type, tenantIds } = req.body;
    const filter = tenantIds?.length ? { _id: { $in: tenantIds } } : {};
    const tenants = await Tenant.find(filter);

    const results = await Promise.allSettled(
      tenants.map(t => {
        if (type === 'warning') return wa.notifyExpiryWarning(t);
        if (type === 'custom' && req.body.customMessage) return wa.notifyCustom(t, req.body.customMessage);
        return Promise.resolve({ skipped: true });
      })
    );

    const sent   = results.filter(r => r.status === 'fulfilled' && r.value?.success).length;
    const failed = results.length - sent;
    res.json({ success: true, sent, failed, total: results.length });
  } catch (err) { next(err); }
};

// ─── Subscription Report ──────────────────────────────────────────────────────

exports.getSubscriptionReport = async (req, res, next) => {
  try {
    const now = new Date();
    const in7  = new Date(now.getTime() + 7  * 86400000);
    const in30 = new Date(now.getTime() + 30 * 86400000);

    const [
      active, trial, expired, suspended,
      expiringIn7, expiringIn30,
      planStats, monthlyRevenue,
    ] = await Promise.all([
      Tenant.countDocuments({ isActive: true, 'subscription.status': 'active' }),
      Tenant.countDocuments({ isActive: true, 'subscription.status': 'trial' }),
      Tenant.countDocuments({ 'subscription.status': 'expired' }),
      Tenant.countDocuments({ isActive: false }),
      Tenant.find({ isActive: true, 'subscription.status': 'active', 'subscription.endDate': { $gte: now, $lte: in7 } })
        .select('salonName ownerName phone whatsapp subscription.endDate subscription.plan'),
      Tenant.countDocuments({ isActive: true, 'subscription.status': 'active', 'subscription.endDate': { $gte: now, $lte: in30 } }),
      Tenant.aggregate([
        { $group: { _id: '$subscription.plan', count: { $sum: 1 }, revenue: { $sum: { $sum: '$subscription.payments.amount' } } } },
      ]),
      // Monthly revenue for last 6 months
      Tenant.aggregate([
        { $unwind: '$subscription.payments' },
        { $group: {
          _id: {
            year:  { $year:  '$subscription.payments.paidAt' },
            month: { $month: '$subscription.payments.paidAt' },
          },
          revenue: { $sum: '$subscription.payments.amount' },
          count:   { $sum: 1 },
        }},
        { $sort: { '_id.year': -1, '_id.month': -1 } },
        { $limit: 6 },
      ]),
    ]);

    res.json({
      success: true,
      data: {
        summary: { active, trial, expired, suspended, expiringIn7: expiringIn7.length, expiringIn30 },
        expiringIn7,
        planStats,
        monthlyRevenue,
      }
    });
  } catch (err) { next(err); }
};

// ─── Delete Tenant (soft - just marks cancelled) ──────────────────────────────

exports.deleteTenant = async (req, res, next) => {
  try {
    const tenant = await Tenant.findByIdAndUpdate(
      req.params.id,
      { isActive: false, 'subscription.status': 'cancelled' },
      { new: true }
    );
    if (!tenant) return next(new AppError('Tenant not found', 404));
    await User.updateMany({ tenantId: tenant._id }, { isActive: false });
    res.json({ success: true, message: 'Tenant cancelled.' });
  } catch (err) { next(err); }
};
