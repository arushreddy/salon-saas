const Attendance    = require('../models/Attendance');
const Staff         = require('../models/Staff');
const SalaryPayment = require('../models/SalaryPayment');
const { AppError }  = require('../middlewares/errorHandler');

// ─── Helpers ──────────────────────────────────────────────────────────────────
const todayDate = () => {
  const d = new Date(); d.setHours(0,0,0,0); return d;
};

const recomputeTotals = (att) => {
  let totalMins = 0;
  (att.sessions || []).forEach(s => {
    if (s.clockIn && s.clockOut) {
      const mins = Math.round((new Date(s.clockOut) - new Date(s.clockIn)) / 60000);
      s.durationMinutes = mins > 0 ? mins : 0;
      totalMins += s.durationMinutes;
    }
  });
  att.totalMinutes = totalMins;
  att.totalHours   = parseFloat((totalMins / 60).toFixed(2));
  return att;
};

// ─── POST /api/attendance/clock-in ────────────────────────────────────────────
const clockIn = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const userId   = req.user.userId;
    const now      = new Date();
    const today    = todayDate();

    // Check for open session (already clocked in without clock-out)
    let att = await Attendance.findOne({ staff: userId, date: today });
    if (att) {
      const hasOpenSession = att.sessions.some(s => s.clockIn && !s.clockOut);
      if (hasOpenSession) throw new AppError('You are already clocked in', 400);
    }

    const staffProfile = await Staff.findOne({ user: userId, tenantId });
    const shiftStart   = staffProfile?.schedule?.shiftStart || '09:00';
    const [sh, sm]     = shiftStart.split(':').map(Number);
    const nowMins      = now.getHours() * 60 + now.getMinutes();
    const shiftMins    = sh * 60 + sm;
    const lateBy       = Math.max(0, nowMins - shiftMins - 15);

    const session = { clockIn: now, clockOut: null, durationMinutes: 0 };

    if (att) {
      att.sessions.push(session);
      if (att.status === 'absent') {
        att.status       = lateBy > 0 ? 'late' : 'present';
        att.lateByMinutes = lateBy;
      }
      att.clockIn  = att.sessions[0]?.clockIn || now;
      att.markedBy = 'self';
      await att.save();
    } else {
      att = await Attendance.create({
        tenantId, staff: userId, date: today,
        sessions: [session],
        clockIn:  now,
        status:   lateBy > 0 ? 'late' : 'present',
        lateByMinutes: lateBy,
        markedBy: 'self',
      });
    }

    res.status(200).json({
      success: true,
      message: `Clocked in at ${now.toLocaleTimeString('en-IN')}${lateBy > 0 ? ` (Late by ${lateBy} min)` : ''}`,
      attendance: att,
    });
  } catch (err) { next(err); }
};

// ─── POST /api/attendance/clock-out ───────────────────────────────────────────
const clockOut = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const userId   = req.user.userId;
    const now      = new Date();
    const today    = todayDate();

    const att = await Attendance.findOne({ staff: userId, date: today });
    if (!att) throw new AppError("You haven't clocked in today", 400);

    const openIdx = att.sessions.findIndex(s => s.clockIn && !s.clockOut);
    if (openIdx === -1) throw new AppError('No active clock-in session found', 400);

    att.sessions[openIdx].clockOut = now;
    att.sessions[openIdx].durationMinutes = Math.max(
      0, Math.round((now - new Date(att.sessions[openIdx].clockIn)) / 60000)
    );

    recomputeTotals(att);
    att.clockOut = now; // sync legacy field

    // Overtime check
    const staffProfile = await Staff.findOne({ user: userId, tenantId });
    const shiftEnd     = staffProfile?.schedule?.shiftEnd || '21:00';
    const [eh, em]     = shiftEnd.split(':').map(Number);
    const shiftEndMins = eh * 60 + em;
    const nowMins      = now.getHours() * 60 + now.getMinutes();
    att.overtimeMinutes = Math.max(0, nowMins - shiftEndMins);

    await att.save();

    res.status(200).json({
      success: true,
      message: `Clocked out. Total: ${att.totalMinutes} min`,
      attendance: att,
    });
  } catch (err) { next(err); }
};

// ─── GET /api/attendance/today  (admin) ───────────────────────────────────────
const getTodayAttendance = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const today    = todayDate();
    const records  = await Attendance
      .find({ tenantId, date: today })
      .populate('staff', 'name email phone');
    res.status(200).json({ success: true, attendance: records });
  } catch (err) { next(err); }
};

// ─── GET /api/attendance/my  (own staff) ──────────────────────────────────────
const getMyAttendance = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const userId   = req.user.userId;
    const { month, year } = req.query;

    let startDate, endDate;
    if (month && year) {
      startDate = new Date(year, month - 1, 1);
      endDate   = new Date(year, month, 0, 23, 59, 59);
    } else {
      startDate = new Date(); startDate.setDate(1); startDate.setHours(0,0,0,0);
      endDate   = new Date();
    }

    const records = await Attendance.find({
      tenantId, staff: userId,
      date: { $gte: startDate, $lte: endDate },
    }).sort({ date: 1 });

    const summary = {
      present:       records.filter(r => r.status === 'present').length,
      late:          records.filter(r => r.status === 'late').length,
      absent:        records.filter(r => r.status === 'absent').length,
      halfDay:       records.filter(r => r.status === 'half-day').length,
      holiday:       records.filter(r => r.status === 'holiday').length,
      leave:         records.filter(r => r.status === 'leave').length,
      totalMinutes:  records.reduce((s, r) => s + (r.totalMinutes || 0), 0),
      totalHours:    parseFloat((records.reduce((s, r) => s + (r.totalHours || 0), 0)).toFixed(2)),
      overtimeMinutes: records.reduce((s, r) => s + (r.overtimeMinutes || 0), 0),
    };

    res.status(200).json({ success: true, records, summary });
  } catch (err) { next(err); }
};

// ─── POST /api/attendance/mark  (admin / receptionist) ───────────────────────
// staffId must be User._id (same as Attendance.staff field)
const markAttendance = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { staffId, date, status, notes } = req.body;
    if (!staffId || !status) throw new AppError('staffId and status are required', 400);

    const attDate = date ? new Date(date) : new Date();
    attDate.setHours(0,0,0,0);

    let att = await Attendance.findOne({ staff: staffId, date: attDate });

    if (att) {
      att.status   = status;
      att.notes    = notes || att.notes;
      att.markedBy = req.user.role === 'receptionist' ? 'receptionist' : 'admin';
      await att.save();
    } else {
      att = await Attendance.create({
        tenantId,
        staff:    staffId,
        date:     attDate,
        status,
        notes:    notes || '',
        markedBy: req.user.role === 'receptionist' ? 'receptionist' : 'admin',
      });
    }

    const populated = await Attendance.findById(att._id).populate('staff', 'name email phone');
    res.status(200).json({ success: true, message: `Attendance marked as ${status}`, attendance: populated });
  } catch (err) { next(err); }
};

// ─── GET /api/attendance/staff-list  (admin) ──────────────────────────────────
// Returns list keyed by User._id so it matches Attendance.staff and record.staff._id
const getStaffList = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const staffProfiles = await Staff
      .find({ tenantId })
      .populate('user', 'name email phone role isActive')
      .sort({ createdAt: 1 });

    const list = staffProfiles
      .filter(s => s.user && s.user.isActive)
      .map(s => ({
        _id:         s.user._id,       // ← User._id (matches Attendance.staff)
        staffId:     s._id,            // ← Staff profile _id (for floor-status patch)
        name:        s.user.name,
        email:       s.user.email,
        phone:       s.user.phone || '',
        role:        s.user.role,
        designation: s.designation,
        salary:      s.salary,         // { base, commissionEnabled, commissionPercent }
        schedule:    s.schedule,
        isAvailable: s.isAvailable,
      }));

    res.status(200).json({ success: true, staff: list });
  } catch (err) { next(err); }
};

// ─── GET /api/attendance/report  (admin / receptionist) ──────────────────────
// Query params: year, month, staffId (optional — User._id)
const getReport = async (req, res, next) => {
  try {
    const tenantId          = req.user.tenantId;
    const { year, month, staffId } = req.query;

    const y = parseInt(year)  || new Date().getFullYear();
    const m = parseInt(month) || (new Date().getMonth() + 1);

    const startDate = new Date(y, m - 1, 1);
    const endDate   = new Date(y, m, 0, 23, 59, 59);

    const filter = { tenantId, date: { $gte: startDate, $lte: endDate } };
    if (staffId) filter.staff = staffId;   // staffId is User._id

    const records = await Attendance
      .find(filter)
      .populate('staff', 'name email phone')
      .sort({ date: -1 });

    // Build per-staff summary
    const summaryMap = {};
    records.forEach(r => {
      const uid  = String(r.staff?._id || r.staff);
      if (!summaryMap[uid]) {
        summaryMap[uid] = {
          staff:           r.staff,         // populated User object
          present:         0,
          late:            0,
          absent:          0,
          halfDay:         0,
          leave:           0,
          holiday:         0,
          totalMinutes:    0,
          totalDeductions: 0,
        };
      }
      const e = summaryMap[uid];
      if (r.status === 'present')   e.present++;
      else if (r.status === 'late') e.late++;
      else if (r.status === 'absent') e.absent++;
      else if (r.status === 'half-day') e.halfDay++;
      else if (r.status === 'leave')    e.leave++;
      else if (r.status === 'holiday')  e.holiday++;
      e.totalMinutes    += r.totalMinutes    || 0;
      e.totalDeductions += r.deduction       || 0;
    });

    res.status(200).json({
      success: true,
      records,
      summary: Object.values(summaryMap),
    });
  } catch (err) { next(err); }
};

// ─── POST /api/attendance/deduction  (admin) ──────────────────────────────────
// staffId here is User._id (to match Attendance.staff)
const applyDeduction = async (req, res, next) => {
  try {
    const tenantId  = req.user.tenantId;
    const adminId   = req.user.userId;
    const { staffId, date, attendanceId, amount, reason, mode, autoType } = req.body;

    if (!staffId || !amount || amount <= 0) throw new AppError('staffId and amount are required', 400);

    const monthStr = date
      ? date.substring(0, 7)
      : new Date().toISOString().substring(0, 7);

    // 1. Update the Attendance record
    let att;
    if (attendanceId) {
      att = await Attendance.findById(attendanceId);
    } else if (date) {
      const d = new Date(date); d.setHours(0,0,0,0);
      att = await Attendance.findOne({ staff: staffId, date: d });
    }

    if (att) {
      att.deduction       = (att.deduction || 0) + Number(amount);
      att.deductionReason = reason || att.deductionReason || 'Admin deduction';
      await att.save();
    }

    // 2. Find the Staff profile to link staffProfile ref in SalaryPayment
    const staffProfile = await Staff.findOne({ user: staffId, tenantId });

    // 3. Create a SalaryPayment deduction record
    const salPay = await SalaryPayment.create({
      staff:        staffId,                      // User._id
      staffProfile: staffProfile?._id || null,
      type:         'deduction',
      month:        monthStr,
      amount:       Number(amount),
      baseSalary:   staffProfile?.salary?.base || 0,
      note:         reason || `${autoType === 'full' ? 'Full day' : autoType === 'half' ? 'Half day' : 'Manual'} deduction — ${mode || 'manual'}`,
      paidBy:       adminId,
      status:       'paid',
    });

    res.status(200).json({
      success: true,
      message: `Deduction of ₹${amount} applied`,
      salaryPayment: salPay,
      attendance: att,
    });
  } catch (err) { next(err); }
};

module.exports = {
  clockIn,
  clockOut,
  getTodayAttendance,
  getMyAttendance,
  markAttendance,
  getStaffList,
  getReport,
  applyDeduction,
};