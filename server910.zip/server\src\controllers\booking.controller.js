const Booking  = require('../models/Booking');
const Service  = require('../models/Service');
const User     = require('../models/User');
const Coupon   = require('../models/Coupon');
const mongoose = require('mongoose');
const { AppError } = require('../middlewares/errorHandler');

// Helper: safely cast a value to ObjectId (returns null if invalid)
const toOid = (v) => {
  try { return new mongoose.Types.ObjectId(v); } catch { return null; }
};

const generateTimeSlots = (startHour = 9, endHour = 21, intervalMinutes = 30) => {
  const slots = [];
  for (let h = startHour; h < endHour; h++) {
    for (let m = 0; m < 60; m += intervalMinutes) {
      slots.push(`${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}`);
    }
  }
  return slots;
};

const addMinutesToTime = (timeStr, minutes) => {
  const [h, m]  = timeStr.split(':').map(Number);
  const total   = h * 60 + m + minutes;
  return `${Math.floor(total/60).toString().padStart(2,'0')}:${(total%60).toString().padStart(2,'0')}`;
};

const timesOverlap = (s1, e1, s2, e2) => s1 < e2 && s2 < e1;

const getMaxPerSlot = async (tenantId) => {
  const count = await User.countDocuments({ tenantId, role: 'staff', isActive: true });
  return count > 0 ? count : 3;
};

// GET /api/bookings/available-slots
const getAvailableSlots = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { date, serviceId, staffId } = req.query;
    if (!date || !serviceId) throw new AppError('Date and service are required', 400);

    const service = await Service.findOne({ _id: serviceId, tenantId });
    if (!service) throw new AppError('Service not found', 404);

    const dayStart = new Date(date); dayStart.setHours(0,0,0,0);
    const dayEnd   = new Date(date); dayEnd.setHours(23,59,59,999);

    const filter = { tenantId, date: { $gte: dayStart, $lte: dayEnd }, status: { $nin: ['cancelled','no-show'] } };
    if (staffId) filter.staff = staffId;

    const existingBookings = await Booking.find(filter);
    const maxPerSlot       = staffId ? 1 : await getMaxPerSlot(tenantId);
    const allSlots         = generateTimeSlots(9, 21, 30);
    const duration         = service.duration;

    const availableSlots = allSlots.filter(slotStart => {
      const slotEnd = addMinutesToTime(slotStart, duration);
      if (slotEnd > '21:00') return false;

      const now = new Date();
      const bookingDate = new Date(date);
      if (bookingDate.toDateString() === now.toDateString() &&
          slotStart <= `${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}`) return false;

      const overlapCount = existingBookings.filter(b => timesOverlap(slotStart, slotEnd, b.timeSlot.start, b.timeSlot.end)).length;
      return overlapCount < maxPerSlot;
    });

    const formattedSlots = availableSlots.map(slot => {
      const endTime = addMinutesToTime(slot, duration);
      const [h] = slot.split(':').map(Number);
      const period = h >= 12 ? 'PM' : 'AM';
      const display = `${h > 12 ? h-12 : h === 0 ? 12 : h}:${slot.split(':')[1]} ${period}`;
      return { start: slot, end: endTime, display };
    });

    res.status(200).json({ success: true, slots: formattedSlots });
  } catch (error) { next(error); }
};

// POST /api/bookings/walk-in — Receptionist/Admin creates walk-in booking
// Accepts both legacy single-service and the new multi-service UI payload:
//   { customerName, customerPhone, customerId?,
//     serviceIds: [id, ...],  staffIds: [id, ...],
//     paymentMethod, notes, couponCode, manualDiscountPercent,
//     date?, timeSlot? }
const createWalkInBooking = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;

    // ── Normalise payload (support both old and new shapes) ──────────────────
    const {
      // new multi-service shape
      customerName, customerPhone,
      serviceIds, staffIds,
      manualDiscountPercent,
      // legacy single-service shape (keep working)
      serviceId,  staffId,
      // shared
      customerId: bodyCustomerId,
      date: bodyDate, timeSlot: bodyTimeSlot,
      paymentMethod, notes, couponCode,
    } = req.body;

    const serviceIdList = serviceIds?.length ? serviceIds
                        : serviceId           ? [serviceId]
                        : [];

    if (!serviceIdList.length) {
      throw new AppError('At least one service is required', 400);
    }

    // ── Resolve date / timeSlot (default to now in IST) ──────────────────────
    const ist       = new Date(Date.now() + 5.5 * 60 * 60 * 1000);
    const todayStr  = ist.toISOString().split('T')[0];
    const nowHH     = String(ist.getUTCHours()).padStart(2, '0');
    const nowMM     = String(ist.getUTCMinutes()).padStart(2, '0');
    const nowTime   = `${nowHH}:${nowMM}`;

    const bookingDate     = bodyDate     || todayStr;
    const bookingStart    = bodyTimeSlot?.start || nowTime;

    // ── Resolve / create customer ─────────────────────────────────────────────
    // Use req.tenant._id (real ObjectId set by tenantAccess) to avoid string→ObjectId cast issues
    const tenantOid = req.tenant?._id || toOid(tenantId);
    let customerId = bodyCustomerId;

    if (!customerId && customerPhone) {
      const existing = await User.findOne({ tenantId: tenantOid, phone: customerPhone, role: 'customer' });
      if (existing) customerId = existing._id;
    }

    if (!customerId) {
      const name  = (customerName || 'Walk-in Guest').trim();
      const phone = (customerPhone || '').trim();
      const guestEmail = phone
        ? `guest_${phone}_${tenantId}@walkin.local`
        : `guest_${Date.now()}_${tenantId}@walkin.local`;

      let guest = phone
        ? await User.findOne({ tenantId: tenantOid, phone, role: 'customer' })
        : null;

      if (!guest) {
        guest = await User.create({
          tenantId: tenantOid,
          name,
          phone:    phone || undefined,
          email:    guestEmail,
          role:     'customer',
          isActive: true,
          password: Math.random().toString(36).slice(2) + Date.now(),
        });
      } else if (name && name !== 'Walk-in Guest') {
        await User.findByIdAndUpdate(guest._id, { name });
      }

      customerId = guest._id;
    }

    const customer = await User.findById(customerId);
    if (!customer) throw new AppError('Customer not found', 404);

    // ── Fetch services — try with tenantId match first, fall back to ID-only ──
    const serviceOids = serviceIdList.map(toOid).filter(Boolean);
    if (!serviceOids.length) throw new AppError('Invalid service IDs provided', 400);

    let resolvedServices = await Service.find({ _id: { $in: serviceOids }, tenantId: tenantOid });
    // Fallback: if tenantId type mismatch in DB, fetch by ID only (still safe — IDs came from the client's own session)
    if (!resolvedServices.length) {
      resolvedServices = await Service.find({ _id: { $in: serviceOids } });
    }
    if (!resolvedServices.length) throw new AppError('No valid services found', 404);

    // ── Resolve coupon (once, applied per booking proportionally) ────────────
    let couponDoc = null;
    if (couponCode) {
      const c = await Coupon.findOne({ tenantId: tenantOid, code: couponCode.toUpperCase(), isActive: true });
      if (c) {
        const now = new Date();
        const valid = (!c.validUntil || now <= c.validUntil)
                   && (c.maxUses === 0 || c.usedCount < c.maxUses);
        if (valid) couponDoc = c;
      }
    }

    // ── Build one booking per service ─────────────────────────────────────────
    const bookings = [];
    let runningStart = bookingStart;

    for (let i = 0; i < resolvedServices.length; i++) {
      const svc       = resolvedServices[i];
      const duration  = svc.duration || 30;
      const slotStart = runningStart;
      const slotEnd   = addMinutesToTime(slotStart, duration);

      // Assign staff: staffIds[i] → staffIds[0] → null
      const assignedStaffId = staffIds?.[i] || staffIds?.[0] || staffId || null;

      // Coupon discount for this service
      let couponDiscount = 0;
      if (couponDoc && svc.price >= (couponDoc.minOrderValue || 0)) {
        couponDiscount = couponDoc.discountType === 'percentage'
          ? Math.round(svc.price * couponDoc.discountValue / 100)
          : couponDoc.discountValue;
        couponDiscount = Math.min(couponDiscount, svc.price);
      }

      // Manual discount
      const manualPct  = Math.min(50, Math.max(0, manualDiscountPercent || 0));
      const manualDisc = Math.round(svc.price * manualPct / 100);

      const discountAmount = couponDiscount + manualDisc;
      const finalAmount    = Math.max(0, svc.price - discountAmount);

      const booking = await Booking.create({
        tenantId:      tenantOid,
        customer:      customerId,
        service:       svc._id,
        staff:         assignedStaffId,
        date:          new Date(bookingDate + 'T00:00:00.000Z'),
        timeSlot:      { start: slotStart, end: slotEnd },
        type:          'walk-in',
        totalAmount:   svc.price,
        discountAmount,
        finalAmount,
        paymentMethod: paymentMethod || 'cash',
        paymentStatus: 'pending', // payment must be explicitly confirmed — never auto-paid on creation
        notes:         notes || '',
        status:        'confirmed',
        coupon:        couponDoc?._id || null,
      });

      bookings.push(booking._id);
      runningStart = slotEnd; // chain service slots back-to-back
    }

    // Increment coupon usage once (not per service)
    if (couponDoc) {
      await Coupon.findByIdAndUpdate(couponDoc._id, { $inc: { usedCount: 1 } });
    }

    // Return all populated bookings
    const populated = await Booking.find({ _id: { $in: bookings } })
      .populate('customer', 'name phone email')
      .populate('service',  'name category price duration')
      .populate('staff',    'name');

    res.status(201).json({
      success:  true,
      message:  `${bookings.length} walk-in booking${bookings.length > 1 ? 's' : ''} created`,
      bookings: populated,
      booking:  populated[0], // backward-compat for clients reading .booking
    });
  } catch (error) { next(error); }
};

// POST /api/bookings — Customer/online booking (only for standard+ plan)
const createBooking = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { serviceId, staffId, date, timeSlot, couponCode, notes } = req.body;
    const customerId = req.user.userId;

    if (!serviceId || !date || !timeSlot) throw new AppError('Service, date and time slot are required', 400);

    const service = await Service.findOne({ _id: serviceId, tenantId });
    if (!service) throw new AppError('Service not found', 404);

    let discountAmount = 0;
    if (couponCode) {
      const coupon = await Coupon.findOne({ tenantId, code: couponCode.toUpperCase(), isActive: true });
      if (coupon && service.price >= coupon.minOrderValue) {
        discountAmount = coupon.discountType === 'percentage'
          ? (service.price * coupon.discountValue / 100) : coupon.discountValue;
        discountAmount = Math.min(discountAmount, service.price);
        await Coupon.findByIdAndUpdate(coupon._id, { $inc: { usedCount: 1 } });
      }
    }

    const booking = await Booking.create({
      tenantId,
      customer:      customerId,
      service:       serviceId,
      staff:         staffId || null,
      date:          new Date(date),
      timeSlot,
      type:          'online',
      totalAmount:   service.price,
      discountAmount,
      finalAmount:   service.price - discountAmount,
      notes:         notes || '',
      status:        'confirmed',
    });

    const populated = await Booking.findById(booking._id)
      .populate('service', 'name category price duration')
      .populate('staff', 'name');

    res.status(201).json({ success: true, message: 'Booking confirmed', booking: populated });
  } catch (error) { next(error); }
};

// GET /api/bookings
const getBookings = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { status, date, staffId, page = 1, limit = 20, search } = req.query;

    const filter = { tenantId };
    if (status)  filter.status  = status;
    if (staffId) filter.staff   = staffId;
    if (date) {
      const d = new Date(date); d.setHours(0,0,0,0);
      const e = new Date(date); e.setHours(23,59,59,999);
      filter.date = { $gte: d, $lte: e };
    }

    // staff only see their bookings
    if (req.user.role === 'staff') filter.staff = req.user.userId;

    const [bookings, total] = await Promise.all([
      Booking.find(filter)
        .populate('customer', 'name phone email')
        .populate('service',  'name category price duration')
        .populate('staff',    'name')
        .sort({ date: -1, 'timeSlot.start': 1 })
        .skip((Number(page)-1) * Number(limit))
        .limit(Number(limit)),
      Booking.countDocuments(filter),
    ]);

    res.status(200).json({ success: true, bookings, total, page: Number(page), pages: Math.ceil(total/limit) });
  } catch (error) { next(error); }
};

// PATCH /api/bookings/:id/status
const updateBookingStatus = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { status, cancelReason, paymentMethod, paymentStatus } = req.body;

    const booking = await Booking.findOne({ _id: req.params.id, tenantId });
    if (!booking) throw new AppError('Booking not found', 404);

    booking.status = status;
    if (status === 'cancelled')  { booking.cancelledAt = new Date(); booking.cancelReason = cancelReason || ''; }
    if (status === 'completed')  { booking.completedAt = new Date(); }
    if (paymentMethod) booking.paymentMethod = paymentMethod;
    if (paymentStatus) booking.paymentStatus = paymentStatus;

    await booking.save();

    res.status(200).json({ success: true, message: `Booking ${status}`, booking });
  } catch (error) { next(error); }
};

// GET /api/bookings/today/stats
const getTodayStats = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const today    = new Date(); today.setHours(0,0,0,0);
    const tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate()+1);
    const dateRange = { $gte: today, $lt: tomorrow };

    const [total, confirmed, completed, cancelled, revenue] = await Promise.all([
      Booking.countDocuments({ tenantId, date: dateRange }),
      Booking.countDocuments({ tenantId, date: dateRange, status: 'confirmed' }),
      Booking.countDocuments({ tenantId, date: dateRange, status: 'completed' }),
      Booking.countDocuments({ tenantId, date: dateRange, status: 'cancelled' }),
      Booking.aggregate([
        { $match: { tenantId: new (require('mongoose').Types.ObjectId)(tenantId), date: dateRange, status: 'completed', paymentStatus: 'paid' } },
        { $group: { _id: null, total: { $sum: '$finalAmount' } } }
      ]),
    ]);

    res.status(200).json({ success: true, stats: { total, confirmed, completed, cancelled, revenue: revenue[0]?.total || 0 } });
  } catch (error) { next(error); }
};

module.exports = { getAvailableSlots, createBooking, createWalkInBooking, getBookings, updateBookingStatus, getTodayStats };