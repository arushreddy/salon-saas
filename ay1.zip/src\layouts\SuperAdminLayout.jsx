import { useState, useEffect } from 'react';
import { Outlet, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import Sidebar from '@/components/Sidebar';
import MobileBottomNav from '@/components/MobileBottomNav';
import { useAuth } from '@/context/AuthContext';
import {
  Menu, LayoutDashboard, Building2, Users,
  Settings, LogOut, ChevronDown, Shield, RefreshCw,
} from 'lucide-react';

const SUPERADMIN_MENU = [
  { label: 'Dashboard', path: '/superadmin',        icon: LayoutDashboard },
  { label: 'Salons',    path: '/superadmin/salons',  icon: Building2       },
  { label: 'Users',     path: '/superadmin/users',   icon: Users           },
  { label: 'Settings',  path: '/superadmin/settings',icon: Settings        },
];

const SuperAdminLayout = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const [mobileOpen,   setMobileOpen]   = useState(false);
  const [collapsed,    setCollapsed]    = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  useEffect(() => {
    if (!userMenuOpen) return;
    const close = () => setUserMenuOpen(false);
    window.addEventListener('click', close);
    return () => window.removeEventListener('click', close);
  }, [userMenuOpen]);

  const initials = (name = '') =>
    name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase() || 'S';

  return (
    <div style={{ minHeight: '100vh', background: '#F4EDE0' }}>
      <Sidebar
        menuItems={SUPERADMIN_MENU}
        title="Super Admin"
        mobileOpen={mobileOpen}
        onMobileClose={() => setMobileOpen(false)}
        collapsed={collapsed}
        onToggleCollapse={() => setCollapsed(c => !c)}
      />

      <div
        className={`transition-all duration-300 ${collapsed ? '' : 'lg:ml-[264px]'}`}
        style={{ minHeight: '100vh' }}
        onClick={() => { if (!collapsed) setCollapsed(true); }}
      >
        {/* Top Header */}
        <header
          onClick={e => e.stopPropagation()}
          style={{
            position: 'sticky', top: 0, zIndex: 30,
            height: 56,
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '0 20px',
            background: 'rgba(250,250,248,0.92)',
            backdropFilter: 'blur(20px)',
            borderBottom: '1px solid rgba(184,137,42,0.12)',
            boxShadow: '0 1px 0 rgba(180,148,90,0.08)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <button
              onClick={e => {
                e.stopPropagation();
                if (window.innerWidth >= 1024) setCollapsed(c => !c);
                else setMobileOpen(true);
              }}
              style={{ padding: 8, marginLeft: -8, background: 'none', border: 'none', cursor: 'pointer', color: '#1c1712', borderRadius: 8, display: 'flex', alignItems: 'center' }}
            >
              <Menu size={20} />
            </button>

            {/* Super Admin badge */}
            <div style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '4px 10px', borderRadius: 20,
              background: 'rgba(109,40,217,0.08)',
              border: '1px solid rgba(109,40,217,0.18)',
            }}>
              <Shield size={11} color='#6D28D9' />
              <span style={{ fontSize: 11, fontWeight: 600, color: '#5B21B6', letterSpacing: '0.05em', textTransform: 'uppercase' }}>
                Super Admin
              </span>
            </div>
          </div>

          {/* Right: user menu */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }} onClick={e => e.stopPropagation()}>
            <div style={{ position: 'relative' }}>
              <button
                onClick={e => { e.stopPropagation(); setUserMenuOpen(o => !o); }}
                style={{
                  display: 'flex', alignItems: 'center', gap: 8,
                  padding: '5px 10px 5px 5px', borderRadius: 24,
                  border: '1px solid rgba(109,40,217,0.20)',
                  background: userMenuOpen ? 'rgba(109,40,217,0.08)' : 'rgba(250,250,248,0.6)',
                  cursor: 'pointer', transition: 'all 0.18s',
                }}
              >
                <div style={{
                  width: 28, height: 28, borderRadius: '50%',
                  background: 'linear-gradient(135deg, #7C3AED, #5B21B6)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  boxShadow: '0 2px 8px rgba(109,40,217,0.3)', flexShrink: 0,
                }}>
                  <span style={{ fontFamily: 'Cormorant Garamond, Georgia, serif', fontSize: 12, fontWeight: 600, color: '#fff', fontStyle: 'italic' }}>
                    {initials(user?.name)}
                  </span>
                </div>
                <span className="hidden sm:block" style={{ fontSize: 13, fontWeight: 500, color: '#1c1712' }}>
                  {user?.name?.split(' ')[0]}
                </span>
                <ChevronDown size={13} color='#9C8660' style={{ transition: 'transform 0.18s', transform: userMenuOpen ? 'rotate(180deg)' : 'none' }} />
              </button>

              <AnimatePresence>
                {userMenuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 6, scale: 0.96 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 4, scale: 0.97 }}
                    transition={{ duration: 0.14 }}
                    style={{
                      position: 'absolute', right: 0, top: 'calc(100% + 8px)',
                      width: 200, background: '#FDF8F0',
                      border: '1px solid rgba(184,137,42,0.18)', borderRadius: 14,
                      boxShadow: '0 8px 32px rgba(28,23,18,0.12)', overflow: 'hidden', zIndex: 50,
                    }}
                  >
                    <div style={{ padding: '12px 14px', borderBottom: '1px solid rgba(184,137,42,0.10)' }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: '#1c1712' }}>{user?.name}</div>
                      <div style={{ fontSize: 11, color: '#9C8660', marginTop: 2 }}>{user?.email}</div>
                      <div style={{ marginTop: 5, display: 'inline-flex', alignItems: 'center', gap: 4, padding: '2px 8px', borderRadius: 10, background: 'rgba(109,40,217,0.10)', fontSize: 10, fontWeight: 600, color: '#5B21B6' }}>
                        <Shield size={9} /> Super Admin
                      </div>
                    </div>
                    <button
                      onClick={() => { logout(); setUserMenuOpen(false); }}
                      style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '10px 14px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 13, color: '#991B1B', textAlign: 'left', transition: 'background 0.14s' }}
                      onMouseEnter={e => e.currentTarget.style.background = 'rgba(185,28,28,0.05)'}
                      onMouseLeave={e => e.currentTarget.style.background = 'none'}
                    >
                      <LogOut size={13} /> Sign Out
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </header>

        <main style={{ padding: '24px 20px' }}>
          <Outlet />
        </main>
      </div>

      <MobileBottomNav menuItems={SUPERADMIN_MENU} />
    </div>
  );
};

export default SuperAdminLayout;
