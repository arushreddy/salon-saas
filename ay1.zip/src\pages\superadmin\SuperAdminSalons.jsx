import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import api from '@/services/api';
import {
  Building2, Search, Plus, ShieldAlert, ShieldCheck,
  MoreVertical, X, Check, AlertTriangle, RefreshCw,
  ChevronLeft, ChevronRight, Edit2,
} from 'lucide-react';

const C = {
  pageBg: '#F4EDE0', cardBg: '#FDFAF4',
  gold: '#B8860B', goldLight: '#DAA520', goldPale: '#FFF8E7',
  ink: '#1A1208', inkMid: '#5C4A2A', inkLight: '#9C8660',
  border: '#DFD0A8',
  green: '#15803D', greenPale: '#DCFCE7', greenBorder: '#86EFAC',
  red: '#991B1B',   redPale: '#FEF2F2',   redBorder: '#FECACA',
  amber: '#92400E', amberPale: '#FFFBEB', amberBorder: '#FDE68A',
  blue: '#1D4ED8',  bluePale: '#EFF6FF',  blueBorder: '#BFDBFE',
  purple: '#5B21B6',purplePale: '#F5F3FF',purpleBorder: '#DDD6FE',
};

const PLAN_BADGE = {
  plan1: { label: 'Plan 1', color: C.blue,   bg: C.bluePale,   border: C.blueBorder   },
  plan2: { label: 'Plan 2', color: C.gold,   bg: C.goldPale,   border: C.border       },
  plan3: { label: 'Plan 3', color: C.purple, bg: C.purplePale, border: C.purpleBorder },
};

const Input = ({ label, ...props }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
    {label && <label style={{ fontSize: 12, fontWeight: 500, color: C.inkMid }}>{label}</label>}
    <input
      {...props}
      style={{
        padding: '9px 12px', borderRadius: 9, fontSize: 13,
        border: `1px solid ${C.border}`, background: '#fff',
        color: C.ink, outline: 'none',
        ...(props.style || {}),
      }}
    />
  </div>
);

const Select = ({ label, children, ...props }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
    {label && <label style={{ fontSize: 12, fontWeight: 500, color: C.inkMid }}>{label}</label>}
    <select
      {...props}
      style={{ padding: '9px 12px', borderRadius: 9, fontSize: 13, border: `1px solid ${C.border}`, background: '#fff', color: C.ink, outline: 'none' }}
    >
      {children}
    </select>
  </div>
);

// ── Create Salon Modal ────────────────────────────────────────────────────────
const CreateModal = ({ onClose, onCreated }) => {
  const [form, setForm]   = useState({ name: '', slug: '', adminEmail: '', adminName: '', adminPhone: '', adminPassword: '', plan: 'plan1' });
  const [saving, setSaving] = useState(false);
  const [err, setErr]     = useState('');

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  // Auto-generate slug from name
  const handleName = v => {
    set('name', v);
    set('slug', v.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''));
  };

  const submit = async () => {
    setErr('');
    setSaving(true);
    try {
      await api.post('/superadmin/salons', form);
      onCreated();
      onClose();
    } catch (e) {
      setErr(e.response?.data?.message || 'Failed to create salon');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(28,23,18,0.45)', backdropFilter: 'blur(6px)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        style={{ background: C.cardBg, borderRadius: 20, width: '100%', maxWidth: 480, boxShadow: '0 20px 60px rgba(28,23,18,0.2)', border: `1px solid ${C.border}` }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '20px 24px', borderBottom: `1px solid ${C.border}` }}>
          <h2 style={{ fontFamily: 'Playfair Display, Georgia, serif', fontSize: 18, fontWeight: 600, color: C.ink, margin: 0 }}>Create New Salon</h2>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.inkLight }}><X size={18} /></button>
        </div>

        <div style={{ padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Input label="Salon Name *"    value={form.name}          onChange={e => handleName(e.target.value)} placeholder="Royal Cuts" />
          <Input label="Slug *"          value={form.slug}          onChange={e => set('slug', e.target.value)} placeholder="royal-cuts" />
          <Select label="Plan" value={form.plan} onChange={e => set('plan', e.target.value)}>
            <option value="plan1">Plan 1 — Basic</option>
            <option value="plan2">Plan 2 — Online Booking</option>
            <option value="plan3">Plan 3 — Franchise</option>
          </Select>
          <hr style={{ border: 'none', borderTop: `1px solid ${C.border}`, margin: '4px 0' }} />
          <div style={{ fontSize: 11, fontWeight: 600, color: C.inkLight, letterSpacing: '0.1em', textTransform: 'uppercase' }}>Admin Account</div>
          <Input label="Admin Email *"   value={form.adminEmail}    onChange={e => set('adminEmail', e.target.value)}    placeholder="admin@royalcuts.com" type="email" />
          <Input label="Admin Name"      value={form.adminName}     onChange={e => set('adminName', e.target.value)}     placeholder="John Doe" />
          <Input label="Admin Phone"     value={form.adminPhone}    onChange={e => set('adminPhone', e.target.value)}    placeholder="9876543210" />
          <Input label="Password *"      value={form.adminPassword} onChange={e => set('adminPassword', e.target.value)} placeholder="Min 8 characters" type="password" />

          {err && (
            <div style={{ padding: '10px 14px', borderRadius: 9, background: C.redPale, border: `1px solid ${C.redBorder}`, fontSize: 13, color: C.red, display: 'flex', gap: 8, alignItems: 'center' }}>
              <AlertTriangle size={14} /> {err}
            </div>
          )}
        </div>

        <div style={{ display: 'flex', gap: 10, padding: '16px 24px', borderTop: `1px solid ${C.border}`, justifyContent: 'flex-end' }}>
          <button onClick={onClose} style={{ padding: '9px 18px', borderRadius: 10, border: `1px solid ${C.border}`, background: 'none', cursor: 'pointer', fontSize: 13, color: C.inkMid }}>Cancel</button>
          <button
            onClick={submit}
            disabled={saving}
            style={{ padding: '9px 20px', borderRadius: 10, background: `linear-gradient(135deg, ${C.goldLight}, ${C.gold})`, border: 'none', cursor: saving ? 'not-allowed' : 'pointer', fontSize: 13, fontWeight: 600, color: '#fff', display: 'flex', alignItems: 'center', gap: 6, opacity: saving ? 0.7 : 1 }}
          >
            {saving ? <RefreshCw size={13} style={{ animation: 'spin 1s linear infinite' }} /> : <Check size={13} />}
            {saving ? 'Creating…' : 'Create Salon'}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

// ── Suspend Modal ─────────────────────────────────────────────────────────────
const SuspendModal = ({ salon, onClose, onDone }) => {
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);

  const submit = async () => {
    setSaving(true);
    try {
      await api.post(`/superadmin/salons/${salon._id}/suspend`, { reason });
      onDone();
      onClose();
    } catch (e) { console.error(e); }
    finally { setSaving(false); }
  };

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(28,23,18,0.45)', backdropFilter: 'blur(6px)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
        style={{ background: C.cardBg, borderRadius: 20, width: '100%', maxWidth: 400, boxShadow: '0 20px 60px rgba(28,23,18,0.2)', border: `1px solid ${C.redBorder}` }}
      >
        <div style={{ padding: '20px 24px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 style={{ fontFamily: 'Playfair Display, Georgia, serif', fontSize: 18, fontWeight: 600, color: C.red, margin: 0 }}>Suspend Salon</h2>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.inkLight }}><X size={18} /></button>
        </div>
        <div style={{ padding: '20px 24px' }}>
          <p style={{ fontSize: 13, color: C.inkMid, marginBottom: 14 }}>
            Suspending <strong>{salon.name}</strong> will prevent all users from logging in.
          </p>
          <textarea
            value={reason}
            onChange={e => setReason(e.target.value)}
            placeholder="Reason for suspension (optional)…"
            rows={3}
            style={{ width: '100%', padding: '10px 12px', borderRadius: 9, border: `1px solid ${C.border}`, fontSize: 13, color: C.ink, resize: 'vertical', outline: 'none', boxSizing: 'border-box' }}
          />
        </div>
        <div style={{ display: 'flex', gap: 10, padding: '16px 24px', borderTop: `1px solid ${C.border}`, justifyContent: 'flex-end' }}>
          <button onClick={onClose} style={{ padding: '9px 18px', borderRadius: 10, border: `1px solid ${C.border}`, background: 'none', cursor: 'pointer', fontSize: 13, color: C.inkMid }}>Cancel</button>
          <button onClick={submit} disabled={saving} style={{ padding: '9px 20px', borderRadius: 10, background: C.red, border: 'none', cursor: saving ? 'not-allowed' : 'pointer', fontSize: 13, fontWeight: 600, color: '#fff', opacity: saving ? 0.7 : 1 }}>
            {saving ? 'Suspending…' : 'Suspend'}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

// ── Main Page ─────────────────────────────────────────────────────────────────
const SuperAdminSalons = () => {
  const [salons,    setSalons]    = useState([]);
  const [total,     setTotal]     = useState(0);
  const [page,      setPage]      = useState(1);
  const [loading,   setLoading]   = useState(true);
  const [search,    setSearch]    = useState('');
  const [planFilter,setPlanFilter]= useState('');
  const [statusFilter,setStatusFilter] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [suspendTarget, setSuspendTarget] = useState(null);
  const [actionMenu,  setActionMenu]  = useState(null); // salonId with open menu

  const LIMIT = 20;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page, limit: LIMIT });
      if (search)       params.set('search', search);
      if (planFilter)   params.set('plan',   planFilter);
      if (statusFilter) params.set('status', statusFilter);
      const { data } = await api.get(`/superadmin/salons?${params}`);
      setSalons(data.salons);
      setTotal(data.pagination.total);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [page, search, planFilter, statusFilter]);

  useEffect(() => { load(); }, [load]);

  const unsuspend = async (id) => {
    try { await api.post(`/superadmin/salons/${id}/unsuspend`); load(); } catch (e) { console.error(e); }
  };

  const pages = Math.ceil(total / LIMIT);

  return (
    <div style={{ maxWidth: 1100, margin: '0 auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24, flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h1 style={{ fontFamily: 'Playfair Display, Georgia, serif', fontSize: 24, fontWeight: 600, color: C.ink, margin: 0 }}>Salons</h1>
          <p style={{ fontSize: 13, color: C.inkLight, marginTop: 3 }}>{total} total salons</p>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '9px 18px', borderRadius: 11, background: `linear-gradient(135deg, ${C.goldLight}, ${C.gold})`, border: 'none', cursor: 'pointer', fontSize: 13, fontWeight: 600, color: '#fff', boxShadow: '0 4px 14px rgba(184,137,42,0.3)' }}
        >
          <Plus size={15} /> New Salon
        </button>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 18, flexWrap: 'wrap', alignItems: 'center' }}>
        <div style={{ flex: 1, minWidth: 200, position: 'relative' }}>
          <Search size={14} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: C.inkLight, pointerEvents: 'none' }} />
          <input
            value={search} onChange={e => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search by name, slug or email…"
            style={{ width: '100%', padding: '9px 12px 9px 32px', borderRadius: 10, border: `1px solid ${C.border}`, background: C.cardBg, fontSize: 13, color: C.ink, outline: 'none', boxSizing: 'border-box' }}
          />
        </div>
        <select value={planFilter} onChange={e => { setPlanFilter(e.target.value); setPage(1); }}
          style={{ padding: '9px 12px', borderRadius: 10, border: `1px solid ${C.border}`, background: C.cardBg, fontSize: 13, color: C.ink, outline: 'none' }}>
          <option value="">All Plans</option>
          <option value="plan1">Plan 1</option>
          <option value="plan2">Plan 2</option>
          <option value="plan3">Plan 3</option>
        </select>
        <select value={statusFilter} onChange={e => { setStatusFilter(e.target.value); setPage(1); }}
          style={{ padding: '9px 12px', borderRadius: 10, border: `1px solid ${C.border}`, background: C.cardBg, fontSize: 13, color: C.ink, outline: 'none' }}>
          <option value="">All Status</option>
          <option value="active">Active</option>
          <option value="suspended">Suspended</option>
          <option value="inactive">Inactive</option>
        </select>
        <button onClick={load} style={{ padding: '9px 14px', borderRadius: 10, border: `1px solid ${C.border}`, background: C.cardBg, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5, fontSize: 13, color: C.inkMid }}>
          <RefreshCw size={13} style={{ animation: loading ? 'spin 1s linear infinite' : 'none' }} />
        </button>
      </div>

      {/* Table */}
      <div style={{ background: C.cardBg, borderRadius: 16, border: `1px solid ${C.border}`, overflow: 'hidden', boxShadow: '0 2px 12px rgba(28,23,18,0.05)' }}>
        {loading ? (
          <div style={{ textAlign: 'center', padding: 48, color: C.inkLight }}>Loading…</div>
        ) : salons.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 48, color: C.inkLight }}>
            <Building2 size={32} style={{ opacity: 0.3, marginBottom: 10 }} />
            <p>No salons found</p>
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                  {['Salon', 'Slug', 'Plan', 'Admin', 'Status', ''].map(h => (
                    <th key={h} style={{ padding: '12px 16px', textAlign: 'left', fontSize: 11, fontWeight: 600, color: C.inkLight, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {salons.map((s, i) => {
                  const plan  = PLAN_BADGE[s.plan] || PLAN_BADGE.plan1;
                  const suspended = s.isSuspended;
                  const inactive  = !s.isActive;
                  return (
                    <tr key={s._id} style={{ borderBottom: i < salons.length - 1 ? `1px solid ${C.border}` : 'none', background: suspended ? `${C.redPale}60` : 'transparent' }}>
                      <td style={{ padding: '13px 16px' }}>
                        <div style={{ fontWeight: 500, fontSize: 13, color: C.ink }}>{s.name}</div>
                        {s.email && <div style={{ fontSize: 11, color: C.inkLight, marginTop: 2 }}>{s.email}</div>}
                      </td>
                      <td style={{ padding: '13px 16px' }}>
                        <span style={{ fontSize: 12, fontFamily: 'monospace', color: C.inkMid, background: `${C.border}50`, padding: '2px 7px', borderRadius: 5 }}>{s.slug}</span>
                      </td>
                      <td style={{ padding: '13px 16px' }}>
                        <span style={{ fontSize: 11, fontWeight: 600, padding: '3px 9px', borderRadius: 20, background: plan.bg, color: plan.color, border: `1px solid ${plan.border}` }}>
                          {plan.label}
                        </span>
                      </td>
                      <td style={{ padding: '13px 16px' }}>
                        <div style={{ fontSize: 13, color: C.inkMid }}>{s.admin?.name || '—'}</div>
                        <div style={{ fontSize: 11, color: C.inkLight }}>{s.admin?.email || ''}</div>
                      </td>
                      <td style={{ padding: '13px 16px' }}>
                        {suspended ? (
                          <span style={{ fontSize: 11, fontWeight: 600, padding: '3px 9px', borderRadius: 20, background: C.redPale, color: C.red, border: `1px solid ${C.redBorder}`, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                            <ShieldAlert size={10} /> Suspended
                          </span>
                        ) : inactive ? (
                          <span style={{ fontSize: 11, fontWeight: 600, padding: '3px 9px', borderRadius: 20, background: '#F9FAFB', color: '#6B7280', border: '1px solid #E5E7EB' }}>Inactive</span>
                        ) : (
                          <span style={{ fontSize: 11, fontWeight: 600, padding: '3px 9px', borderRadius: 20, background: C.greenPale, color: C.green, border: `1px solid ${C.greenBorder}`, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                            <ShieldCheck size={10} /> Active
                          </span>
                        )}
                      </td>
                      <td style={{ padding: '13px 16px', position: 'relative' }}>
                        <button
                          onClick={() => setActionMenu(actionMenu === s._id ? null : s._id)}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4, color: C.inkLight, borderRadius: 6 }}
                        >
                          <MoreVertical size={16} />
                        </button>
                        <AnimatePresence>
                          {actionMenu === s._id && (
                            <motion.div
                              initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
                              style={{ position: 'absolute', right: 12, top: '100%', zIndex: 10, background: C.cardBg, border: `1px solid ${C.border}`, borderRadius: 12, boxShadow: '0 8px 28px rgba(28,23,18,0.12)', width: 160, overflow: 'hidden' }}
                            >
                              {suspended ? (
                                <button onClick={() => { unsuspend(s._id); setActionMenu(null); }}
                                  style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '10px 14px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 13, color: C.green, textAlign: 'left' }}>
                                  <ShieldCheck size={13} /> Reinstate
                                </button>
                              ) : (
                                <button onClick={() => { setSuspendTarget(s); setActionMenu(null); }}
                                  style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '10px 14px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 13, color: C.red, textAlign: 'left' }}>
                                  <ShieldAlert size={13} /> Suspend
                                </button>
                              )}
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Pagination */}
      {pages > 1 && (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginTop: 20 }}>
          <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} style={{ padding: '7px 12px', borderRadius: 8, border: `1px solid ${C.border}`, background: C.cardBg, cursor: page === 1 ? 'not-allowed' : 'pointer', color: C.inkMid, opacity: page === 1 ? 0.4 : 1 }}>
            <ChevronLeft size={14} />
          </button>
          <span style={{ fontSize: 13, color: C.inkMid }}>Page {page} of {pages}</span>
          <button onClick={() => setPage(p => Math.min(pages, p + 1))} disabled={page === pages} style={{ padding: '7px 12px', borderRadius: 8, border: `1px solid ${C.border}`, background: C.cardBg, cursor: page === pages ? 'not-allowed' : 'pointer', color: C.inkMid, opacity: page === pages ? 0.4 : 1 }}>
            <ChevronRight size={14} />
          </button>
        </div>
      )}

      {/* Modals */}
      <AnimatePresence>
        {showCreate    && <CreateModal  onClose={() => setShowCreate(false)}    onCreated={load} />}
        {suspendTarget && <SuspendModal salon={suspendTarget} onClose={() => setSuspendTarget(null)} onDone={load} />}
      </AnimatePresence>

      <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
    </div>
  );
};

export default SuperAdminSalons;
