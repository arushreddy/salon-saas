import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import api from '@/services/api';
import { Building2, Users, ShieldAlert, ShieldCheck, TrendingUp, RefreshCw } from 'lucide-react';

const C = {
  pageBg: '#F4EDE0', cardBg: '#FDFAF4',
  gold: '#B8860B', goldLight: '#DAA520', goldPale: '#FFF8E7',
  ink: '#1A1208', inkMid: '#5C4A2A', inkLight: '#9C8660',
  border: '#DFD0A8',
  green: '#15803D', greenPale: '#DCFCE7', greenBorder: '#86EFAC',
  red: '#991B1B',   redPale: '#FEF2F2',   redBorder: '#FECACA',
  purple: '#5B21B6', purplePale: '#F5F3FF', purpleBorder: '#DDD6FE',
  blue: '#1D4ED8', bluePale: '#EFF6FF', blueBorder: '#BFDBFE',
};

const PLAN_LABELS = { plan1: 'Plan 1 — Basic', plan2: 'Plan 2 — Online', plan3: 'Plan 3 — Franchise' };
const PLAN_COLORS = { plan1: C.blue, plan2: C.gold, plan3: C.purple };

const StatCard = ({ label, value, icon: Icon, color, pale, border, onClick }) => (
  <motion.div
    initial={{ opacity: 0, y: 12 }}
    animate={{ opacity: 1, y: 0 }}
    whileHover={{ y: -2 }}
    onClick={onClick}
    style={{
      background: C.cardBg, borderRadius: 16, padding: '20px 22px',
      border: `1px solid ${border || C.border}`,
      boxShadow: '0 2px 12px rgba(28,23,18,0.05)',
      cursor: onClick ? 'pointer' : 'default',
      display: 'flex', alignItems: 'center', gap: 16,
    }}
  >
    <div style={{ width: 48, height: 48, borderRadius: 12, background: pale || C.goldPale, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
      <Icon size={22} color={color || C.gold} />
    </div>
    <div>
      <div style={{ fontSize: 26, fontWeight: 700, color: C.ink, lineHeight: 1.1 }}>{value ?? '—'}</div>
      <div style={{ fontSize: 12, color: C.inkLight, marginTop: 3 }}>{label}</div>
    </div>
  </motion.div>
);

const SuperAdminDashboard = () => {
  const navigate = useNavigate();
  const [stats, setStats]     = useState(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/superadmin/stats');
      setStats(data.stats);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  return (
    <div style={{ maxWidth: 1100, margin: '0 auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 28 }}>
        <div>
          <h1 style={{ fontFamily: 'Playfair Display, Georgia, serif', fontSize: 26, fontWeight: 600, color: C.ink, margin: 0 }}>
            Platform Overview
          </h1>
          <p style={{ fontSize: 13, color: C.inkLight, marginTop: 4 }}>All salons across your platform</p>
        </div>
        <button
          onClick={load}
          style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 16px', borderRadius: 10, border: `1px solid ${C.border}`, background: C.cardBg, cursor: 'pointer', fontSize: 13, color: C.inkMid }}
        >
          <RefreshCw size={14} style={{ animation: loading ? 'spin 1s linear infinite' : 'none' }} /> Refresh
        </button>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: 60, color: C.inkLight }}>Loading stats…</div>
      ) : (
        <>
          {/* Stat Cards */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 16, marginBottom: 28 }}>
            <StatCard label="Total Salons"     value={stats?.totalSalons}     icon={Building2}    color={C.blue}   pale={C.bluePale}   border={C.blueBorder}   onClick={() => navigate('/superadmin/salons')} />
            <StatCard label="Active Salons"    value={stats?.activeSalons}    icon={ShieldCheck}  color={C.green}  pale={C.greenPale}  border={C.greenBorder}  onClick={() => navigate('/superadmin/salons?status=active')} />
            <StatCard label="Suspended"        value={stats?.suspendedSalons} icon={ShieldAlert}  color={C.red}    pale={C.redPale}    border={C.redBorder}    onClick={() => navigate('/superadmin/salons?status=suspended')} />
            <StatCard label="Total Users"      value={stats?.totalUsers}      icon={Users}        color={C.gold}   pale={C.goldPale}   border={C.border}       onClick={() => navigate('/superadmin/users')} />
          </div>

          {/* Plan Breakdown */}
          {stats?.planBreakdown && (
            <div style={{ background: C.cardBg, borderRadius: 16, padding: 24, border: `1px solid ${C.border}`, boxShadow: '0 2px 12px rgba(28,23,18,0.05)' }}>
              <h2 style={{ fontFamily: 'Playfair Display, Georgia, serif', fontSize: 16, fontWeight: 600, color: C.ink, marginBottom: 18 }}>
                Plan Distribution
              </h2>
              <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
                {['plan1', 'plan2', 'plan3'].map(p => (
                  <div key={p} style={{ flex: 1, minWidth: 140, padding: '14px 18px', borderRadius: 12, background: `${PLAN_COLORS[p]}10`, border: `1px solid ${PLAN_COLORS[p]}30` }}>
                    <div style={{ fontSize: 28, fontWeight: 700, color: PLAN_COLORS[p] }}>{stats.planBreakdown[p] || 0}</div>
                    <div style={{ fontSize: 12, color: C.inkLight, marginTop: 4 }}>{PLAN_LABELS[p]}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}

      <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
    </div>
  );
};

export default SuperAdminDashboard;
