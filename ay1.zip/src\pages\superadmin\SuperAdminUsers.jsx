import { useState, useEffect, useCallback } from 'react';
import api from '@/services/api';
import { Users, Search, RefreshCw, ChevronLeft, ChevronRight } from 'lucide-react';

const C = {
  cardBg: '#FDFAF4', ink: '#1A1208', inkMid: '#5C4A2A', inkLight: '#9C8660',
  border: '#DFD0A8', gold: '#B8860B', goldPale: '#FFF8E7',
  green: '#15803D', greenPale: '#DCFCE7', greenBorder: '#86EFAC',
  purple: '#5B21B6', purplePale: '#F5F3FF', purpleBorder: '#DDD6FE',
  blue: '#1D4ED8', bluePale: '#EFF6FF', blueBorder: '#BFDBFE',
  amber: '#92400E', amberPale: '#FFFBEB', amberBorder: '#FDE68A',
};

const ROLE_BADGE = {
  super_admin:       { label: 'Super Admin',        color: C.purple, bg: C.purplePale, border: C.purpleBorder },
  franchise_owner:   { label: 'Franchise Owner',    color: C.blue,   bg: C.bluePale,   border: C.blueBorder   },
  franchise_manager: { label: 'Franchise Manager',  color: C.blue,   bg: C.bluePale,   border: C.blueBorder   },
  admin:             { label: 'Admin',               color: C.gold,   bg: C.goldPale,   border: C.border       },
  receptionist:      { label: 'Receptionist',        color: C.amber,  bg: C.amberPale,  border: C.amberBorder  },
  staff:             { label: 'Staff',               color: C.green,  bg: C.greenPale,  border: C.greenBorder  },
  customer:          { label: 'Customer',            color: '#374151',bg: '#F9FAFB',    border: '#E5E7EB'       },
};

const SuperAdminUsers = () => {
  const [users,   setUsers]   = useState([]);
  const [total,   setTotal]   = useState(0);
  const [page,    setPage]    = useState(1);
  const [loading, setLoading] = useState(true);
  const [search,  setSearch]  = useState('');
  const [roleFilter, setRoleFilter] = useState('');
  const LIMIT = 30;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page, limit: LIMIT });
      if (search)     params.set('search', search);
      if (roleFilter) params.set('role',   roleFilter);
      const { data } = await api.get(`/superadmin/users?${params}`);
      setUsers(data.users);
      setTotal(data.pagination.total);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [page, search, roleFilter]);

  useEffect(() => { load(); }, [load]);

  const pages = Math.ceil(total / LIMIT);

  return (
    <div style={{ maxWidth: 1100, margin: '0 auto' }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontFamily: 'Playfair Display, Georgia, serif', fontSize: 24, fontWeight: 600, color: C.ink, margin: 0 }}>Users</h1>
        <p style={{ fontSize: 13, color: C.inkLight, marginTop: 3 }}>{total} total users</p>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 18, flexWrap: 'wrap', alignItems: 'center' }}>
        <div style={{ flex: 1, minWidth: 220, position: 'relative' }}>
          <Search size={14} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: C.inkLight, pointerEvents: 'none' }} />
          <input
            value={search} onChange={e => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search by name or email…"
            style={{ width: '100%', padding: '9px 12px 9px 32px', borderRadius: 10, border: `1px solid ${C.border}`, background: C.cardBg, fontSize: 13, color: C.ink, outline: 'none', boxSizing: 'border-box' }}
          />
        </div>
        <select value={roleFilter} onChange={e => { setRoleFilter(e.target.value); setPage(1); }}
          style={{ padding: '9px 12px', borderRadius: 10, border: `1px solid ${C.border}`, background: C.cardBg, fontSize: 13, color: C.ink, outline: 'none' }}>
          <option value="">All Roles</option>
          {Object.keys(ROLE_BADGE).map(r => <option key={r} value={r}>{ROLE_BADGE[r].label}</option>)}
        </select>
        <button onClick={load} style={{ padding: '9px 14px', borderRadius: 10, border: `1px solid ${C.border}`, background: C.cardBg, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5, fontSize: 13, color: C.inkMid }}>
          <RefreshCw size={13} style={{ animation: loading ? 'spin 1s linear infinite' : 'none' }} />
        </button>
      </div>

      {/* Table */}
      <div style={{ background: C.cardBg, borderRadius: 16, border: `1px solid ${C.border}`, overflow: 'hidden', boxShadow: '0 2px 12px rgba(28,23,18,0.05)' }}>
        {loading ? (
          <div style={{ textAlign: 'center', padding: 48, color: C.inkLight }}>Loading…</div>
        ) : users.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 48, color: C.inkLight }}>
            <Users size={32} style={{ opacity: 0.3, marginBottom: 10 }} />
            <p>No users found</p>
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                  {['Name', 'Email', 'Role', 'Salon', 'Joined'].map(h => (
                    <th key={h} style={{ padding: '12px 16px', textAlign: 'left', fontSize: 11, fontWeight: 600, color: C.inkLight, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {users.map((u, i) => {
                  const badge = ROLE_BADGE[u.role] || ROLE_BADGE.customer;
                  return (
                    <tr key={u._id} style={{ borderBottom: i < users.length - 1 ? `1px solid ${C.border}` : 'none' }}>
                      <td style={{ padding: '12px 16px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                          <div style={{ width: 32, height: 32, borderRadius: 8, background: `linear-gradient(135deg, ${C.gold}40, ${C.gold}20)`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 600, color: C.gold, flexShrink: 0 }}>
                            {u.name?.charAt(0)?.toUpperCase() || '?'}
                          </div>
                          <span style={{ fontSize: 13, fontWeight: 500, color: C.ink }}>{u.name}</span>
                        </div>
                      </td>
                      <td style={{ padding: '12px 16px', fontSize: 13, color: C.inkMid }}>{u.email}</td>
                      <td style={{ padding: '12px 16px' }}>
                        <span style={{ fontSize: 11, fontWeight: 600, padding: '3px 9px', borderRadius: 20, background: badge.bg, color: badge.color, border: `1px solid ${badge.border}` }}>
                          {badge.label}
                        </span>
                      </td>
                      <td style={{ padding: '12px 16px', fontSize: 12, color: C.inkLight }}>{u.salonId?.name || '—'}</td>
                      <td style={{ padding: '12px 16px', fontSize: 12, color: C.inkLight }}>
                        {u.createdAt ? new Date(u.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Pagination */}
      {pages > 1 && (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginTop: 20 }}>
          <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
            style={{ padding: '7px 12px', borderRadius: 8, border: `1px solid ${C.border}`, background: C.cardBg, cursor: page === 1 ? 'not-allowed' : 'pointer', color: C.inkMid, opacity: page === 1 ? 0.4 : 1 }}>
            <ChevronLeft size={14} />
          </button>
          <span style={{ fontSize: 13, color: C.inkMid }}>Page {page} of {pages}</span>
          <button onClick={() => setPage(p => Math.min(pages, p + 1))} disabled={page === pages}
            style={{ padding: '7px 12px', borderRadius: 8, border: `1px solid ${C.border}`, background: C.cardBg, cursor: page === pages ? 'not-allowed' : 'pointer', color: C.inkMid, opacity: page === pages ? 0.4 : 1 }}>
            <ChevronRight size={14} />
          </button>
        </div>
      )}

      <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
    </div>
  );
};

export default SuperAdminUsers;
