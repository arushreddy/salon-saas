// src/pages/public/SalonLanding.jsx
// Public-facing salon page — no login required
// Route: /book/:slug
import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import axios from 'axios';
import {
  MapPin, Phone, Mail, Clock, Star, ChevronRight,
  Scissors, Sparkles, Calendar, ArrowRight,
} from 'lucide-react';

const API = 'http://localhost:5000/api/public';

const C = {
  bg: '#FDFAF5', card: '#FFFFFF',
  gold: '#B8860B', goldLight: '#DAA520', goldPale: '#FFF8E7',
  ink: '#1A1208', inkMid: '#5C4A2A', inkLight: '#9C8660',
  border: '#EDE3D0',
  green: '#15803D', greenPale: '#DCFCE7',
};

const publicApi = (slug) => axios.create({
  baseURL: API,
  headers: { 'X-Salon-Slug': slug },
});

// Category icons
const CAT_ICON = {
  'Hair':     <Scissors size={16}/>,
  'Skin':     <Sparkles size={16}/>,
  'Nails':    <Star size={16}/>,
  'default':  <Scissors size={16}/>,
};

export default function SalonLanding() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const api = publicApi(slug);

  const [salon, setSalon]       = useState(null);
  const [services, setServices] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState('');
  const [activeCategory, setActiveCategory] = useState('All');

  useEffect(() => {
    const load = async () => {
      try {
        const [salonRes, servicesRes] = await Promise.all([
          api.get('/salon-info'),
          api.get('/services').catch(() => ({ data: { services: [] } })),
        ]);
        setSalon(salonRes.data.salon);
        setServices(servicesRes.data.services || []);
      } catch (e) {
        setError(e.response?.data?.message || 'Salon not found');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [slug]);

  if (loading) return (
    <div style={{ minHeight: '100vh', background: C.bg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ width: 48, height: 48, border: `3px solid ${C.gold}`, borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 0.8s linear infinite', margin: '0 auto 16px' }}/>
        <div style={{ color: C.inkLight, fontSize: 14 }}>Loading…</div>
      </div>
      <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
    </div>
  );

  if (error) return (
    <div style={{ minHeight: '100vh', background: C.bg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ textAlign: 'center', padding: 32 }}>
        <div style={{ fontSize: 48, marginBottom: 12 }}>✂️</div>
        <div style={{ fontSize: 20, fontWeight: 700, color: C.ink, marginBottom: 8 }}>Salon not found</div>
        <div style={{ color: C.inkLight, fontSize: 14 }}>{error}</div>
      </div>
    </div>
  );

  const categories = ['All', ...new Set(services.map(s => s.category).filter(Boolean))];
  const filtered = activeCategory === 'All' ? services : services.filter(s => s.category === activeCategory);

  return (
    <div style={{ background: C.bg, minHeight: '100vh', fontFamily: 'Georgia, serif' }}>

      {/* Hero */}
      <div style={{
        background: `linear-gradient(135deg, #1A1208 0%, #2e1f0e 50%, #1A1208 100%)`,
        padding: '48px 24px 56px',
        position: 'relative', overflow: 'hidden',
      }}>
        {/* Decorative pattern */}
        <div style={{
          position: 'absolute', inset: 0, opacity: 0.05,
          backgroundImage: `repeating-linear-gradient(45deg, ${C.gold} 0, ${C.gold} 1px, transparent 0, transparent 50%)`,
          backgroundSize: '20px 20px',
        }}/>

        <div style={{ maxWidth: 900, margin: '0 auto', position: 'relative', textAlign: 'center' }}>
          {salon.logo && (
            <motion.img
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              src={salon.logo} alt={salon.name}
              style={{ width: 80, height: 80, borderRadius: 20, objectFit: 'cover', border: `2px solid ${C.gold}40`, marginBottom: 20 }}
            />
          )}
          {!salon.logo && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              style={{
                width: 72, height: 72, borderRadius: 20, background: C.goldPale,
                border: `2px solid ${C.gold}40`, margin: '0 auto 20px',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 28, fontStyle: 'italic', color: C.gold, fontFamily: 'Georgia, serif',
              }}
            >
              {salon.name?.charAt(0)}
            </motion.div>
          )}

          <motion.h1
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            style={{
              fontFamily: 'Georgia, serif', fontSize: 'clamp(28px,5vw,44px)',
              fontWeight: 400, fontStyle: 'italic', color: '#FAF6EF',
              margin: '0 0 8px', letterSpacing: '-0.5px',
            }}
          >
            {salon.name}
          </motion.h1>

          {salon.tagline && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              style={{ fontSize: 15, color: C.gold, margin: '0 0 28px', fontStyle: 'italic' }}
            >
              {salon.tagline}
            </motion.p>
          )}

          <motion.button
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => navigate(`/book/${slug}/appointment`)}
            style={{
              background: C.gold, color: '#1A1208',
              border: 'none', borderRadius: 50,
              padding: '14px 36px', fontSize: 15, fontWeight: 700,
              cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 8,
              boxShadow: `0 4px 24px ${C.gold}50`,
            }}
          >
            <Calendar size={16}/> Book Appointment
          </motion.button>
        </div>
      </div>

      {/* Info strip */}
      {(salon.phone || salon.email || salon.address?.city) && (
        <div style={{
          background: C.card, borderBottom: `1px solid ${C.border}`,
          padding: '14px 24px',
        }}>
          <div style={{
            maxWidth: 900, margin: '0 auto',
            display: 'flex', gap: 24, flexWrap: 'wrap', justifyContent: 'center',
          }}>
            {salon.phone && (
              <a href={`tel:${salon.phone}`} style={{ display: 'flex', alignItems: 'center', gap: 7, color: C.inkMid, fontSize: 13, textDecoration: 'none' }}>
                <Phone size={14} color={C.gold}/> {salon.phone}
              </a>
            )}
            {salon.email && (
              <a href={`mailto:${salon.email}`} style={{ display: 'flex', alignItems: 'center', gap: 7, color: C.inkMid, fontSize: 13, textDecoration: 'none' }}>
                <Mail size={14} color={C.gold}/> {salon.email}
              </a>
            )}
            {salon.address?.city && (
              <span style={{ display: 'flex', alignItems: 'center', gap: 7, color: C.inkMid, fontSize: 13 }}>
                <MapPin size={14} color={C.gold}/>
                {[salon.address.street, salon.address.city, salon.address.state].filter(Boolean).join(', ')}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Services */}
      <div style={{ maxWidth: 900, margin: '0 auto', padding: '40px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24, flexWrap: 'wrap', gap: 12 }}>
          <div>
            <h2 style={{ fontFamily: 'Georgia, serif', fontSize: 26, fontWeight: 400, fontStyle: 'italic', color: C.ink, margin: 0 }}>
              Our Services
            </h2>
            <p style={{ color: C.inkLight, fontSize: 13, margin: '4px 0 0' }}>
              {services.length} services available
            </p>
          </div>
          <button
            onClick={() => navigate(`/book/${slug}/appointment`)}
            style={{
              display: 'flex', alignItems: 'center', gap: 7,
              background: C.goldPale, border: `1px solid ${C.gold}40`,
              borderRadius: 20, padding: '8px 18px', cursor: 'pointer',
              fontSize: 13, fontWeight: 600, color: C.gold,
            }}
          >
            Book Now <ArrowRight size={14}/>
          </button>
        </div>

        {/* Category tabs */}
        {categories.length > 2 && (
          <div style={{ display: 'flex', gap: 8, marginBottom: 24, flexWrap: 'wrap' }}>
            {categories.map(cat => (
              <button key={cat} onClick={() => setActiveCategory(cat)} style={{
                padding: '6px 16px', borderRadius: 20, cursor: 'pointer',
                fontSize: 12, fontWeight: 600,
                background: activeCategory === cat ? C.gold : C.card,
                color: activeCategory === cat ? '#1A1208' : C.inkMid,
                border: `1px solid ${activeCategory === cat ? C.gold : C.border}`,
              }}>{cat}</button>
            ))}
          </div>
        )}

        {services.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '48px 0', color: C.inkLight }}>
            <Scissors size={32} style={{ margin: '0 auto 12px', display: 'block', opacity: 0.3 }}/>
            No services listed yet
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 16 }}>
            {filtered.map((service, i) => (
              <motion.div
                key={service._id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
                whileHover={{ y: -3, boxShadow: `0 8px 32px rgba(184,134,11,0.12)` }}
                onClick={() => navigate(`/book/${slug}/appointment`, { state: { selectedService: service } })}
                style={{
                  background: C.card, borderRadius: 16, padding: '20px',
                  border: `1px solid ${C.border}`, cursor: 'pointer',
                  boxShadow: '0 2px 12px rgba(0,0,0,0.04)',
                  transition: 'box-shadow 0.2s',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 10 }}>
                  <div style={{
                    width: 36, height: 36, borderRadius: 10, background: C.goldPale,
                    display: 'flex', alignItems: 'center', justifyContent: 'center', color: C.gold,
                  }}>
                    {CAT_ICON[service.category] || CAT_ICON.default}
                  </div>
                  {service.category && (
                    <span style={{
                      fontSize: 10, fontWeight: 700, color: C.inkLight,
                      background: C.border, borderRadius: 20, padding: '2px 8px',
                      textTransform: 'uppercase', letterSpacing: '0.05em',
                    }}>{service.category}</span>
                  )}
                </div>

                <div style={{ fontSize: 15, fontWeight: 700, color: C.ink, marginBottom: 4 }}>{service.name}</div>

                {service.description && (
                  <div style={{ fontSize: 12, color: C.inkLight, marginBottom: 12, lineHeight: 1.5, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                    {service.description}
                  </div>
                )}

                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, color: C.inkLight, fontSize: 12 }}>
                    <Clock size={12}/> {service.duration} min
                  </div>
                  <div style={{ fontSize: 17, fontWeight: 800, color: C.gold }}>
                    ₹{service.price}
                  </div>
                </div>

                <div style={{
                  marginTop: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                  background: C.goldPale, borderRadius: 8, padding: '8px',
                  fontSize: 12, fontWeight: 600, color: C.gold,
                }}>
                  Book this service <ChevronRight size={13}/>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      <div style={{
        background: '#1A1208', padding: '28px 24px',
        textAlign: 'center', marginTop: 40,
      }}>
        <div style={{ fontFamily: 'Georgia, serif', fontSize: 20, fontStyle: 'italic', color: '#FAF6EF', marginBottom: 6 }}>
          {salon.name}
        </div>
        <div style={{ fontSize: 12, color: C.gold, marginBottom: 12 }}>
          Online booking powered by Glamour Platform
        </div>
        <button
          onClick={() => navigate(`/book/${slug}/appointment`)}
          style={{
            background: C.gold, color: '#1A1208', border: 'none',
            borderRadius: 50, padding: '10px 28px', fontSize: 13,
            fontWeight: 700, cursor: 'pointer',
          }}
        >
          Book Appointment
        </button>
      </div>
    </div>
  );
}