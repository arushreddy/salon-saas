// src/pages/Login.jsx
import { useState, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Eye, EyeOff, LogIn, Loader2, Phone, Mail, KeyRound, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import api from '@/services/api';

// ── Design tokens ──────────────────────────────────────────────────────────
const C = {
  bg:       '#FAF6EF',
  card:     '#FFFFFF',
  gold:     '#B8860B',
  goldPale: '#FFF8E7',
  ink:      '#1A1208',
  inkMid:   '#5C4A2A',
  inkLight: '#9C8660',
  border:   '#DFD0A8',
  green:    '#15803D',
  greenPale:'#DCFCE7',
  red:      '#991B1B',
  redPale:  '#FEF2F2',
};

const ROLE_REDIRECT = {
  super_admin:       '/superadmin',
  franchise_owner:   '/franchise',
  franchise_manager: '/franchise',
  admin:             '/admin',
  receptionist:      '/staff',
  staff:             '/staff',
  customer:          '/dashboard',
};

// ── Shared input ───────────────────────────────────────────────────────────
const Inp = ({ label, icon: Icon, rightEl, error, ...p }) => (
  <div>
    {label && (
      <label style={{ display: 'block', fontSize: 12, fontWeight: 600, color: C.inkMid, marginBottom: 6 }}>
        {label}
      </label>
    )}
    <div style={{ position: 'relative' }}>
      {Icon && (
        <Icon size={16} color={C.inkLight} style={{
          position: 'absolute', left: 13, top: '50%',
          transform: 'translateY(-50%)', pointerEvents: 'none',
        }}/>
      )}
      <input {...p} style={{
        width: '100%', boxSizing: 'border-box',
        padding: `11px ${rightEl ? '48px' : '14px'} 11px ${Icon ? '40px' : '14px'}`,
        borderRadius: 10,
        border: `1.5px solid ${error ? C.red : C.border}`,
        background: '#FDFAF9', fontSize: 14, color: C.ink,
        outline: 'none', transition: 'border-color 0.15s',
        ...(p.style||{}),
      }}
        onFocus={e => e.target.style.borderColor = C.gold}
        onBlur={e => e.target.style.borderColor = error ? C.red : C.border}
      />
      {rightEl && (
        <div style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)' }}>
          {rightEl}
        </div>
      )}
    </div>
    {error && <p style={{ fontSize: 11, color: C.red, margin: '4px 0 0' }}>{error}</p>}
  </div>
);

// ── OTP input — 6 boxes ────────────────────────────────────────────────────
const OTPInput = ({ value, onChange }) => {
  const ref0 = useRef(null); const ref1 = useRef(null);
  const ref2 = useRef(null); const ref3 = useRef(null);
  const ref4 = useRef(null); const ref5 = useRef(null);
  const refs = [ref0, ref1, ref2, ref3, ref4, ref5];
  const digits = (value || '').padEnd(6, '').split('').slice(0, 6);

  const handle = (i, e) => {
    const v = e.target.value.replace(/\D/g, '').slice(-1);
    const next = [...digits];
    next[i] = v;
    onChange(next.join('').trim());
    if (v && i < 5) refs[i + 1].current?.focus();
  };

  const handleKey = (i, e) => {
    if (e.key === 'Backspace' && !digits[i] && i > 0) refs[i - 1].current?.focus();
    if (e.key === 'ArrowLeft' && i > 0) refs[i - 1].current?.focus();
    if (e.key === 'ArrowRight' && i < 5) refs[i + 1].current?.focus();
  };

  const handlePaste = (e) => {
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    onChange(pasted);
    refs[Math.min(pasted.length, 5)].current?.focus();
    e.preventDefault();
  };

  return (
    <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
      {digits.map((d, i) => (
        <input
          key={i}
          ref={refs[i]}
          type="text"
          inputMode="numeric"
          maxLength={1}
          value={d}
          onChange={e => handle(i, e)}
          onKeyDown={e => handleKey(i, e)}
          onPaste={handlePaste}
          style={{
            width: 44, height: 52, textAlign: 'center',
            fontSize: 22, fontWeight: 700, color: C.ink,
            border: `2px solid ${d ? C.gold : C.border}`,
            borderRadius: 10, background: d ? C.goldPale : '#FDFAF9',
            outline: 'none', transition: 'all 0.15s',
          }}
          onFocus={e => e.target.style.borderColor = C.gold}
          onBlur={e => e.target.style.borderColor = d ? C.gold : C.border}
        />
      ))}
    </div>
  );
};

// ══════════════════════════════════════════════════════════════════════════════
export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();

  // 'email-pw' | 'phone-otp' | 'forgot'
  const [mode, setMode] = useState('email-pw');

  // Email + password
  const [epForm, setEpForm]     = useState({ email: '', password: '' });
  const [showPw, setShowPw]     = useState(false);

  // Phone + OTP login
  const [poPhone, setPoPhone]   = useState('');
  const [poOTP,   setPoOTP]     = useState('');
  const [poSent,  setPoSent]    = useState(false);
  const [poCooldown, setPoCooldown] = useState(0);

  // Forgot password
  const [fpStep,     setFpStep]     = useState(1); // 1=enter identifier, 2=enter otp+new pw, 3=done
  const [fpId,       setFpId]       = useState('');
  const [fpChannel,  setFpChannel]  = useState('email'); // 'email' | 'phone'
  const [fpOTP,      setFpOTP]      = useState('');
  const [fpNewPw,    setFpNewPw]    = useState('');
  const [fpShowPw,   setFpShowPw]   = useState(false);

  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState('');

  const clearError = () => setError('');

  const startCooldown = (setter) => {
    let s = 30;
    setter(s);
    const t = setInterval(() => {
      s--;
      setter(s);
      if (s <= 0) clearInterval(t);
    }, 1000);
  };

  const redirectByRole = (role) => {
    navigate(ROLE_REDIRECT[role] || '/admin');
  };

  // ── Email + Password login ───────────────────────────────────────────────
  const handleEmailLogin = async (e) => {
    e.preventDefault();
    setLoading(true); clearError();
    try {
      const data = await login(epForm.email, epForm.password);
      redirectByRole(data.user.role);
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed.');
    } finally { setLoading(false); }
  };

  // ── Send OTP for phone login ─────────────────────────────────────────────
  const handleSendPhoneOTP = async () => {
    if (!poPhone || poPhone.replace(/\D/g,'').length < 10) {
      setError('Enter a valid 10-digit phone number'); return;
    }
    setLoading(true); clearError();
    try {
      await api.post('/auth/send-otp', {
        identifier: poPhone.replace(/\D/g,''),
        channel: 'phone',
        purpose: 'login',
      });
      setPoSent(true);
      startCooldown(setPoCooldown);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to send OTP.');
    } finally { setLoading(false); }
  };

  // ── Verify OTP for phone login ───────────────────────────────────────────
  const handlePhoneOTPLogin = async (e) => {
    e.preventDefault();
    if (poOTP.length < 6) { setError('Enter the 6-digit OTP'); return; }
    setLoading(true); clearError();
    try {
      const { data } = await api.post('/auth/verify-otp-login', {
        identifier: poPhone.replace(/\D/g,''),
        channel: 'phone',
        otp: poOTP,
      });
      // Manually set token + user like AuthContext login does
      localStorage.setItem('accessToken', data.accessToken);
      localStorage.setItem('user', JSON.stringify(data.user));
      redirectByRole(data.user.role);
    } catch (err) {
      setError(err.response?.data?.message || 'Invalid OTP.');
    } finally { setLoading(false); }
  };

  // ── Send OTP for forgot password ─────────────────────────────────────────
  const handleForgotSendOTP = async () => {
    if (!fpId.trim()) { setError('Enter your phone or email'); return; }
    setLoading(true); clearError();
    try {
      await api.post('/auth/send-otp', {
        identifier: fpChannel === 'phone' ? fpId.replace(/\D/g,'') : fpId.toLowerCase(),
        channel: fpChannel,
        purpose: 'reset',
      });
      setFpStep(2);
      startCooldown(setPoCooldown);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to send OTP.');
    } finally { setLoading(false); }
  };

  // ── Reset password via OTP ───────────────────────────────────────────────
  const handleResetPassword = async (e) => {
    e.preventDefault();
    if (fpOTP.length < 6) { setError('Enter the 6-digit OTP'); return; }
    if (fpNewPw.length < 6) { setError('Password must be at least 6 characters'); return; }
    setLoading(true); clearError();
    try {
      await api.post('/auth/reset-password-otp', {
        identifier: fpChannel === 'phone' ? fpId.replace(/\D/g,'') : fpId.toLowerCase(),
        channel: fpChannel,
        otp: fpOTP,
        newPassword: fpNewPw,
      });
      setFpStep(3);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to reset password.');
    } finally { setLoading(false); }
  };

  return (
    <div style={{
      minHeight: '100vh', background: C.bg,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: '24px 16px', position: 'relative', overflow: 'hidden',
    }}>
      {/* Background blobs */}
      <div style={{ position: 'absolute', top: '10%', right: '15%', width: 320, height: 320, borderRadius: '50%', background: `${C.gold}08`, filter: 'blur(60px)', pointerEvents: 'none' }}/>
      <div style={{ position: 'absolute', bottom: '15%', left: '10%', width: 400, height: 400, borderRadius: '50%', background: `${C.gold}05`, filter: 'blur(80px)', pointerEvents: 'none' }}/>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        style={{ width: '100%', maxWidth: 420, position: 'relative', zIndex: 1 }}
      >
        {/* Brand */}
        <div style={{ textAlign: 'center', marginBottom: 28 }}>
          <Link to="/" style={{ textDecoration: 'none' }}>
            <span style={{ fontFamily: 'Georgia, serif', fontSize: 28, fontWeight: 400, fontStyle: 'italic', color: C.ink }}>
              Glamour<span style={{ color: C.gold }}>.</span>
            </span>
          </Link>
          <p style={{ fontSize: 13, color: C.inkLight, marginTop: 6 }}>
            {mode === 'forgot' ? 'Reset your password' : 'Sign in to your account'}
          </p>
        </div>

        {/* Card */}
        <div style={{
          background: C.card, borderRadius: 20, padding: '28px 28px',
          boxShadow: '0 4px 32px rgba(184,134,11,0.08)',
          border: `1px solid ${C.border}`,
        }}>
          <AnimatePresence mode="wait">

            {/* ══ Email + Password Mode ══════════════════════════════════════ */}
            {mode === 'email-pw' && (
              <motion.div key="email-pw" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }}>
                {/* Mode tabs */}
                <div style={{ display: 'flex', gap: 0, marginBottom: 24, background: '#F5F0E8', borderRadius: 10, padding: 3 }}>
                  <button onClick={() => { setMode('email-pw'); clearError(); }} style={{
                    flex: 1, padding: '8px', borderRadius: 8, border: 'none', cursor: 'pointer', fontSize: 13, fontWeight: 600,
                    background: C.card, color: C.ink, boxShadow: '0 1px 4px rgba(0,0,0,0.08)',
                  }}>
                    📧 Email
                  </button>
                  <button onClick={() => { setMode('phone-otp'); clearError(); }} style={{
                    flex: 1, padding: '8px', borderRadius: 8, border: 'none', cursor: 'pointer', fontSize: 13, fontWeight: 600,
                    background: 'transparent', color: C.inkLight,
                  }}>
                    📱 Phone OTP
                  </button>
                </div>

                {error && (
                  <div style={{ background: C.redPale, border: `1px solid ${C.red}30`, borderRadius: 9, padding: '10px 14px', fontSize: 13, color: C.red, marginBottom: 16 }}>
                    {error}
                  </div>
                )}

                <form onSubmit={handleEmailLogin} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                  <Inp label="Email Address" icon={Mail} type="email" placeholder="admin@salon.com"
                    value={epForm.email} onChange={e => setEpForm(f => ({ ...f, email: e.target.value }))} required/>
                  <Inp label="Password" icon={KeyRound} type={showPw ? 'text' : 'password'} placeholder="Your password"
                    value={epForm.password} onChange={e => setEpForm(f => ({ ...f, password: e.target.value }))} required
                    rightEl={
                      <button type="button" onClick={() => setShowPw(!showPw)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.inkLight, padding: 2, display: 'flex' }}>
                        {showPw ? <EyeOff size={16}/> : <Eye size={16}/>}
                      </button>
                    }
                  />

                  <div style={{ textAlign: 'right', marginTop: -8 }}>
                    <button type="button" onClick={() => { setMode('forgot'); clearError(); }} style={{
                      background: 'none', border: 'none', cursor: 'pointer',
                      color: C.gold, fontSize: 13, fontWeight: 600, padding: 0,
                    }}>
                      Forgot password?
                    </button>
                  </div>

                  <button type="submit" disabled={loading} style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                    padding: '12px', borderRadius: 10, border: 'none',
                    background: C.gold, color: '#1A1208', fontSize: 15, fontWeight: 700,
                    cursor: loading ? 'not-allowed' : 'pointer', opacity: loading ? 0.7 : 1,
                    marginTop: 4,
                  }}>
                    {loading ? <Loader2 size={18} style={{ animation: 'spin 1s linear infinite' }}/> : <LogIn size={18}/>}
                    {loading ? 'Signing in…' : 'Sign In'}
                  </button>
                </form>
              </motion.div>
            )}

            {/* ══ Phone + OTP Mode ══════════════════════════════════════════ */}
            {mode === 'phone-otp' && (
              <motion.div key="phone-otp" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}>
                {/* Mode tabs */}
                <div style={{ display: 'flex', gap: 0, marginBottom: 24, background: '#F5F0E8', borderRadius: 10, padding: 3 }}>
                  <button onClick={() => { setMode('email-pw'); clearError(); setPoSent(false); setPoOTP(''); }} style={{
                    flex: 1, padding: '8px', borderRadius: 8, border: 'none', cursor: 'pointer', fontSize: 13, fontWeight: 600,
                    background: 'transparent', color: C.inkLight,
                  }}>
                    📧 Email
                  </button>
                  <button onClick={() => { setMode('phone-otp'); clearError(); }} style={{
                    flex: 1, padding: '8px', borderRadius: 8, border: 'none', cursor: 'pointer', fontSize: 13, fontWeight: 600,
                    background: C.card, color: C.ink, boxShadow: '0 1px 4px rgba(0,0,0,0.08)',
                  }}>
                    📱 Phone OTP
                  </button>
                </div>

                {error && (
                  <div style={{ background: C.redPale, border: `1px solid ${C.red}30`, borderRadius: 9, padding: '10px 14px', fontSize: 13, color: C.red, marginBottom: 16 }}>
                    {error}
                  </div>
                )}

                {!poSent ? (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                    <Inp label="Mobile Number" icon={Phone} type="tel" placeholder="98765 43210"
                      value={poPhone} onChange={e => setPoPhone(e.target.value)} maxLength={10}/>
                    <button onClick={handleSendPhoneOTP} disabled={loading} style={{
                      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                      padding: '12px', borderRadius: 10, border: 'none',
                      background: C.gold, color: '#1A1208', fontSize: 15, fontWeight: 700,
                      cursor: loading ? 'not-allowed' : 'pointer', opacity: loading ? 0.7 : 1,
                    }}>
                      {loading ? <Loader2 size={18} style={{ animation: 'spin 1s linear infinite' }}/> : <Phone size={18}/>}
                      {loading ? 'Sending…' : 'Send OTP'}
                    </button>
                    <div style={{ textAlign: 'center', marginTop: -4 }}>
                      <button type="button" onClick={() => { setMode('forgot'); clearError(); }} style={{
                        background: 'none', border: 'none', cursor: 'pointer',
                        color: C.gold, fontSize: 13, fontWeight: 600, padding: 0,
                      }}>
                        Forgot password?
                      </button>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handlePhoneOTPLogin} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: 13, color: C.inkMid, marginBottom: 16 }}>
                        OTP sent to <b>+91 {poPhone}</b>
                      </div>
                      <OTPInput value={poOTP} onChange={setPoOTP}/>
                    </div>

                    <button type="submit" disabled={loading || poOTP.length < 6} style={{
                      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                      padding: '12px', borderRadius: 10, border: 'none',
                      background: poOTP.length === 6 ? C.gold : C.border,
                      color: poOTP.length === 6 ? '#1A1208' : C.inkLight,
                      fontSize: 15, fontWeight: 700,
                      cursor: (loading || poOTP.length < 6) ? 'not-allowed' : 'pointer',
                    }}>
                      {loading ? <Loader2 size={18} style={{ animation: 'spin 1s linear infinite' }}/> : <LogIn size={18}/>}
                      {loading ? 'Verifying…' : 'Verify & Sign In'}
                    </button>

                    <div style={{ textAlign: 'center', fontSize: 13, color: C.inkLight }}>
                      {poCooldown > 0
                        ? `Resend OTP in ${poCooldown}s`
                        : <button type="button" onClick={() => { setPoOTP(''); handleSendPhoneOTP(); }} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.gold, fontWeight: 600, fontSize: 13 }}>Resend OTP</button>
                      }
                    </div>
                    <button type="button" onClick={() => { setPoSent(false); setPoOTP(''); clearError(); }} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.inkLight, fontSize: 13, display: 'flex', alignItems: 'center', gap: 5, justifyContent: 'center' }}>
                      <ArrowLeft size={13}/> Change number
                    </button>
                  </form>
                )}
              </motion.div>
            )}

            {/* ══ Forgot Password Mode ══════════════════════════════════════ */}
            {mode === 'forgot' && (
              <motion.div key="forgot" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}>
                <button onClick={() => { setMode('email-pw'); clearError(); setFpStep(1); setFpOTP(''); setFpNewPw(''); }} style={{
                  display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none',
                  cursor: 'pointer', color: C.inkLight, fontSize: 13, marginBottom: 20, padding: 0,
                }}>
                  <ArrowLeft size={14}/> Back to login
                </button>

                {/* Step 3 — Success */}
                {fpStep === 3 ? (
                  <div style={{ textAlign: 'center', padding: '12px 0' }}>
                    <div style={{ width: 56, height: 56, borderRadius: 16, background: C.greenPale, margin: '0 auto 14px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <CheckCircle2 size={28} color={C.green}/>
                    </div>
                    <div style={{ fontSize: 17, fontWeight: 700, color: C.ink, marginBottom: 6 }}>Password Reset!</div>
                    <div style={{ fontSize: 13, color: C.inkLight, marginBottom: 20 }}>Your password has been updated successfully.</div>
                    <button onClick={() => { setMode('email-pw'); setFpStep(1); setFpOTP(''); setFpNewPw(''); clearError(); }} style={{
                      padding: '11px 28px', borderRadius: 10, border: 'none',
                      background: C.gold, color: '#1A1208', fontSize: 14, fontWeight: 700, cursor: 'pointer',
                    }}>
                      Sign In Now
                    </button>
                  </div>
                ) : (
                  <>
                    <h3 style={{ fontSize: 16, fontWeight: 700, color: C.ink, margin: '0 0 4px' }}>
                      {fpStep === 1 ? 'Reset Password' : 'Enter OTP & New Password'}
                    </h3>
                    <p style={{ fontSize: 13, color: C.inkLight, margin: '0 0 20px' }}>
                      {fpStep === 1
                        ? 'Enter your registered phone or email. We\'ll send an OTP.'
                        : `OTP sent to ${fpId}. Enter it below along with your new password.`}
                    </p>

                    {error && (
                      <div style={{ background: C.redPale, border: `1px solid ${C.red}30`, borderRadius: 9, padding: '10px 14px', fontSize: 13, color: C.red, marginBottom: 16 }}>
                        {error}
                      </div>
                    )}

                    {/* Step 1 — Enter identifier */}
                    {fpStep === 1 && (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                        {/* Channel toggle */}
                        <div style={{ display: 'flex', gap: 8 }}>
                          {[['email','📧 Email'],['phone','📱 Phone']].map(([v,l]) => (
                            <button key={v} onClick={() => { setFpChannel(v); setFpId(''); clearError(); }} style={{
                              flex: 1, padding: '8px', borderRadius: 9, cursor: 'pointer', fontSize: 12, fontWeight: 600,
                              background: fpChannel === v ? C.goldPale : '#F5F0E8',
                              border: `1.5px solid ${fpChannel === v ? C.gold : C.border}`,
                              color: fpChannel === v ? C.gold : C.inkMid,
                            }}>{l}</button>
                          ))}
                        </div>
                        <Inp
                          icon={fpChannel === 'email' ? Mail : Phone}
                          type={fpChannel === 'email' ? 'email' : 'tel'}
                          placeholder={fpChannel === 'email' ? 'admin@salon.com' : '98765 43210'}
                          value={fpId}
                          onChange={e => setFpId(e.target.value)}
                        />
                        <button onClick={handleForgotSendOTP} disabled={loading} style={{
                          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                          padding: '12px', borderRadius: 10, border: 'none',
                          background: C.gold, color: '#1A1208', fontSize: 14, fontWeight: 700,
                          cursor: loading ? 'not-allowed' : 'pointer', opacity: loading ? 0.7 : 1,
                        }}>
                          {loading ? <Loader2 size={16} style={{ animation: 'spin 1s linear infinite' }}/> : null}
                          {loading ? 'Sending…' : 'Send OTP'}
                        </button>
                      </div>
                    )}

                    {/* Step 2 — OTP + new password */}
                    {fpStep === 2 && (
                      <form onSubmit={handleResetPassword} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                        <div>
                          <label style={{ display: 'block', fontSize: 12, fontWeight: 600, color: C.inkMid, marginBottom: 10 }}>Enter OTP</label>
                          <OTPInput value={fpOTP} onChange={setFpOTP}/>
                        </div>
                        <Inp label="New Password" icon={KeyRound} type={fpShowPw ? 'text' : 'password'}
                          placeholder="Min 6 characters" value={fpNewPw}
                          onChange={e => setFpNewPw(e.target.value)}
                          rightEl={
                            <button type="button" onClick={() => setFpShowPw(!fpShowPw)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.inkLight, padding: 2, display: 'flex' }}>
                              {fpShowPw ? <EyeOff size={16}/> : <Eye size={16}/>}
                            </button>
                          }
                        />
                        <button type="submit" disabled={loading || fpOTP.length < 6 || fpNewPw.length < 6} style={{
                          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                          padding: '12px', borderRadius: 10, border: 'none',
                          background: (fpOTP.length === 6 && fpNewPw.length >= 6) ? C.gold : C.border,
                          color: (fpOTP.length === 6 && fpNewPw.length >= 6) ? '#1A1208' : C.inkLight,
                          fontSize: 14, fontWeight: 700,
                          cursor: loading ? 'not-allowed' : 'pointer',
                        }}>
                          {loading ? <Loader2 size={16} style={{ animation: 'spin 1s linear infinite' }}/> : <CheckCircle2 size={16}/>}
                          {loading ? 'Resetting…' : 'Reset Password'}
                        </button>
                        <div style={{ textAlign: 'center', fontSize: 13, color: C.inkLight }}>
                          {poCooldown > 0
                            ? `Resend OTP in ${poCooldown}s`
                            : <button type="button" onClick={handleForgotSendOTP} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.gold, fontWeight: 600, fontSize: 13 }}>Resend OTP</button>
                          }
                        </div>
                      </form>
                    )}
                  </>
                )}
              </motion.div>
            )}

          </AnimatePresence>
        </div>

        {/* Footer */}
        {mode !== 'forgot' && (
          <p style={{ textAlign: 'center', fontSize: 12, color: C.inkLight, marginTop: 20 }}>
            Platform managed by Glamour Salon SaaS
          </p>
        )}
      </motion.div>

      <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}