import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import RootLayout from '@/layouts/RootLayout';
import AdminLayout from '@/layouts/AdminLayout';
import StaffLayout from '@/layouts/StaffLayout';
import CustomerLayout from '@/layouts/CustomerLayout';
import ProtectedRoute from '@/components/ProtectedRoute';

import Home from '@/pages/Home';
import Login from '@/pages/Login';
import Register from '@/pages/Register';

// Admin pages
import AdminDashboard from '@/pages/admin/AdminDashboard';
import AdminServices from '@/pages/admin/AdminServices';
import AdminStaff from '@/pages/admin/AdminStaff';
import AdminCustomers from '@/pages/admin/AdminCustomers';
import AdminBookings from '@/pages/admin/AdminBookings';
import AdminAttendance from '@/pages/admin/AdminAttendance';
import AdminInventory from '@/pages/admin/AdminInventory';
import AdminInvoices from '@/pages/admin/AdminInvoices';
import AdminCoupons from '@/pages/admin/AdminCoupons';
import AdminPayments from '@/pages/admin/AdminPayments';
import AdminSettings from '@/pages/admin/AdminSettings';
import AdminAnalytics from '@/pages/admin/AdminAnalytics';
import SetupWizard from '@/pages/admin/SetupWizard';

// Staff pages
import StaffHome from '@/pages/staff/StaffHome';
import StaffHistory from '@/pages/staff/StaffHistory';
import StaffSalary from '@/pages/staff/StaffSalary';
import StaffAttendance from '@/pages/staff/StaffAttendance';
import StaffNotifications from '@/pages/staff/StaffNotifications';
import ReceptionistPanel from '@/pages/staff/ReceptionistPanel';

// Receptionist pages
import ReceptionistDashboard from '@/pages/receptionist/ReceptionistDashboard';
import ReceptionistAppointments from '@/pages/receptionist/ReceptionistAppointments';
import ReceptionistCustomers from '@/pages/receptionist/ReceptionistCustomers';
import ReceptionistInventory from '@/pages/receptionist/ReceptionistInventory';
import ReceptionistStaff from '@/pages/receptionist/ReceptionistStaff';
import ReceptionistCash from '@/pages/receptionist/ReceptionistCash';

// Customer pages
import CustomerDashboard from '@/pages/customer/CustomerDashboard';
import BookingFlow from '@/pages/customer/BookingFlow';

// Smart home — renders correct dashboard based on role
const StaffOrReceptionistHome = () => {
  const { user } = useAuth();
  if (user?.role === 'receptionist') return <ReceptionistDashboard />;
  return <StaffHome />;
};

const AppRouter = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/setup" element={<ProtectedRoute allowedRoles={['admin']}><SetupWizard /></ProtectedRoute>} />

        {/* Public */}
        <Route element={<RootLayout />}>
          <Route path="/" element={<Home />} />
        </Route>
        <Route path="/login"    element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* Admin */}
        <Route path="/admin" element={<ProtectedRoute allowedRoles={['admin']}><AdminLayout /></ProtectedRoute>}>
          <Route index               element={<AdminDashboard />} />
          <Route path="appointments" element={<AdminBookings />} />
          <Route path="attendance"   element={<AdminAttendance />} />
          <Route path="services"     element={<AdminServices />} />
          <Route path="staff"        element={<AdminStaff />} />
          <Route path="customers"    element={<AdminCustomers />} />
          <Route path="payments"     element={<AdminPayments />} />
          <Route path="inventory"    element={<AdminInventory />} />
          <Route path="invoices"     element={<AdminInvoices />} />
          <Route path="coupons"      element={<AdminCoupons />} />
          <Route path="analytics"    element={<AdminAnalytics />} />
          <Route path="settings"     element={<AdminSettings />} />
        </Route>

        {/* Staff — 5 focused pages */}
        <Route path="/staff" element={<ProtectedRoute allowedRoles={['staff', 'receptionist']}><StaffLayout /></ProtectedRoute>}>
          <Route index                element={<StaffOrReceptionistHome />} />
          <Route path="history"       element={<StaffHistory />} />
          <Route path="salary"        element={<StaffSalary />} />
          <Route path="attendance"    element={<StaffAttendance />} />
          <Route path="notifications" element={<StaffNotifications />} />
          <Route path="reception"     element={<ProtectedRoute allowedRoles={['receptionist']}><ReceptionistPanel /></ProtectedRoute>} />
          {/* Receptionist dedicated pages */}
          <Route path="appointments"  element={<ProtectedRoute allowedRoles={['receptionist']}><ReceptionistAppointments /></ProtectedRoute>} />
          <Route path="customers"     element={<ProtectedRoute allowedRoles={['receptionist']}><ReceptionistCustomers /></ProtectedRoute>} />
          <Route path="inventory"     element={<ProtectedRoute allowedRoles={['receptionist']}><ReceptionistInventory /></ProtectedRoute>} />
          <Route path="staff-status"  element={<ProtectedRoute allowedRoles={['receptionist']}><ReceptionistStaff /></ProtectedRoute>} />
          <Route path="cash"          element={<ProtectedRoute allowedRoles={['receptionist']}><ReceptionistCash /></ProtectedRoute>} />
        </Route>

        {/* Customer */}
        <Route path="/dashboard" element={<ProtectedRoute allowedRoles={['customer']}><CustomerLayout /></ProtectedRoute>}>
          <Route index       element={<CustomerDashboard />} />
          <Route path="book" element={<BookingFlow />} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
};

export default AppRouter;