import { useState, useEffect } from 'react';
import { Outlet, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import Sidebar from '@/components/Sidebar';
import MobileBottomNav from '@/components/MobileBottomNav';
import { useAuth } from '@/context/AuthContext';
import { useDataStore } from '@/context/DataStore';
import {
  Menu,
  LayoutDashboard,
  Calendar,
  Users,
  Scissors,
  IndianRupee,
  Package,
  Receipt,
  Tag,
  BarChart3,
  Settings,
  Clock,
  RefreshCw,
  Bell,
  Search,
  ChevronDown,
  LogOut,
  Shield,
} from 'lucide-react';

// ─── Admin nav items ──────────────────────────────────────────────────────────
// All paths under /admin — grouped into logical sections for Sidebar display
const ADMIN_MENU = [
  { label: 'Dashboard',    path: '/admin',              icon: LayoutDashboard },
  { label: 'Appointments', path: '/admin/appointments', icon: Calendar        },
  { label: 'Attendance',   path: '/admin/attendance',   icon: Clock           },
  { label: 'Services',     path: '/admin/services',     icon: Scissors        },
  { label: 'Staff',        path: '/admin/staff',        icon: Users           },
  { label: 'Customers',    path: '/admin/customers',    icon: Users           },
  { label: 'Payments',     path: '/admin/payments',     icon: IndianRupee     },
  { label: 'Inventory',    path: '/admin/inventory',    icon: Package         },
  { label: 'Invoices',     path: '/admin/invoices',     icon: Receipt         },
  { label: 'Coupons',      path: '/admin/coupons',      icon: Tag             },
  { label: 'Analytics',    path: '/admin/analytics',    icon: BarChart3       },
  { label: 'Settings',     path: '/admin/settings',     icon: Settings        },
];

// ─── Sync indicator ───────────────────────────────────────────────────────────
function SyncDot({ syncing }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
      {syncing ? (
        <>
          <RefreshCw size={12} color='#B8860B' style={{ animation: 'spin 1s linear infinite' }} />
          <span style={{ fontSize: 11, color: '#B8860B', fontWeight: 500 }}>Syncing…</span>
        </>
      ) : (
        <>
          <span style={{
            width: 7, height: 7, borderRadius: '50%',
            background: '#22C55E',
            boxShadow: '0 0 6px rgba(34,197,94,0.5)',
            animation: 'pulse 2.5s ease-in-out infinite',
          }} />
          <span style={{ fontSize: 11, color: '#6B7280', fontWeight: 500 }}>Live</span>
        </>
      )}
    </div>
  );
}

// ─── Admin Layout ─────────────────────────────────────────────────────────────
const AdminLayout = () => {
  const { user, logout } = useAuth();
  const { syncing } = useDataStore();
  const navigate = useNavigate();

  const [mobileOpen,  setMobileOpen]  = useState(false);
  const [collapsed,   setCollapsed]   = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  // Close user menu when clicking outside
  useEffect(() => {
    if (!userMenuOpen) return;
    const close = () => setUserMenuOpen(false);
    window.addEventListener('click', close);
    return () => window.removeEventListener('click', close);
  }, [userMenuOpen]);

  const initials = (name = '') =>
    name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase() || 'A';

  return (
    <div style={{ minHeight: '100vh', background: '#FAFAF8' }}>
      {/* ── Sidebar ── */}
      <Sidebar
        menuItems={ADMIN_MENU}
        title="Admin Panel"
        mobileOpen={mobileOpen}
        onMobileClose={() => setMobileOpen(false)}
        collapsed={collapsed}
        onToggleCollapse={() => setCollapsed(c => !c)}
      />

      {/* ── Main area ── */}
      <div
        className={`transition-all duration-300 ${collapsed ? '' : 'lg:ml-[264px]'}`}
        style={{ minHeight: '100vh' }}
        onClick={() => { if (!collapsed) setCollapsed(true); }}
      >
        {/* ── Top Header ── */}
        <header
          onClick={e => e.stopPropagation()}
          style={{
            position: 'sticky', top: 0, zIndex: 30,
            height: 56,
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '0 20px',
            background: 'rgba(250,250,248,0.92)',
            backdropFilter: 'blur(20px)',
            borderBottom: '1px solid rgba(184,137,42,0.12)',
            boxShadow: '0 1px 0 rgba(180,148,90,0.08)',
          }}
        >
          {/* Left: hamburger + breadcrumb */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <button
              onClick={e => {
                e.stopPropagation();
                if (window.innerWidth >= 1024) setCollapsed(c => !c);
                else setMobileOpen(true);
              }}
              style={{
                padding: 8, marginLeft: -8,
                background: 'none', border: 'none', cursor: 'pointer',
                color: '#1c1712', borderRadius: 8,
                display: 'flex', alignItems: 'center',
              }}
            >
              <Menu size={20} />
            </button>

            {/* Admin badge */}
            <div style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '4px 10px', borderRadius: 20,
              background: 'rgba(184,137,42,0.08)',
              border: '1px solid rgba(184,137,42,0.18)',
            }}>
              <Shield size={11} color='#B8860B' />
              <span style={{ fontSize: 11, fontWeight: 600, color: '#8B6914', letterSpacing: '0.05em', textTransform: 'uppercase' }}>
                Admin
              </span>
            </div>
          </div>

          {/* Right: sync + user */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }} onClick={e => e.stopPropagation()}>

            {/* Sync status */}
            <SyncDot syncing={syncing} />

            {/* User menu */}
            <div style={{ position: 'relative' }}>
              <button
                onClick={e => { e.stopPropagation(); setUserMenuOpen(o => !o); }}
                style={{
                  display: 'flex', alignItems: 'center', gap: 8,
                  padding: '5px 10px 5px 5px',
                  borderRadius: 24,
                  border: '1px solid rgba(184,137,42,0.20)',
                  background: userMenuOpen ? 'rgba(184,137,42,0.08)' : 'rgba(250,250,248,0.6)',
                  cursor: 'pointer',
                  transition: 'all 0.18s',
                }}
              >
                {/* Avatar */}
                <div style={{
                  width: 28, height: 28, borderRadius: '50%',
                  background: 'linear-gradient(135deg, #DAA520, #B8860B)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  boxShadow: '0 2px 8px rgba(184,137,42,0.3)',
                  flexShrink: 0,
                }}>
                  <span style={{
                    fontFamily: 'Cormorant Garamond, Georgia, serif',
                    fontSize: 12, fontWeight: 600, color: '#fff', fontStyle: 'italic',
                  }}>
                    {initials(user?.name)}
                  </span>
                </div>
                <span className="hidden sm:block" style={{ fontSize: 13, fontWeight: 500, color: '#1c1712' }}>
                  {user?.name?.split(' ')[0]}
                </span>
                <ChevronDown size={13} color='#9C8660' style={{ transition: 'transform 0.18s', transform: userMenuOpen ? 'rotate(180deg)' : 'none' }} />
              </button>

              {/* Dropdown */}
              <AnimatePresence>
                {userMenuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 6, scale: 0.96 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 4, scale: 0.97 }}
                    transition={{ duration: 0.14 }}
                    style={{
                      position: 'absolute', right: 0, top: 'calc(100% + 8px)',
                      width: 200,
                      background: '#FDF8F0',
                      border: '1px solid rgba(184,137,42,0.18)',
                      borderRadius: 14,
                      boxShadow: '0 8px 32px rgba(28,23,18,0.12)',
                      overflow: 'hidden',
                      zIndex: 50,
                    }}
                  >
                    {/* User info */}
                    <div style={{ padding: '12px 14px', borderBottom: '1px solid rgba(184,137,42,0.10)' }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: '#1c1712' }}>{user?.name}</div>
                      <div style={{ fontSize: 11, color: '#9C8660', marginTop: 2 }}>{user?.email}</div>
                      <div style={{
                        marginTop: 5, display: 'inline-flex', alignItems: 'center', gap: 4,
                        padding: '2px 8px', borderRadius: 10,
                        background: 'rgba(184,137,42,0.10)', fontSize: 10, fontWeight: 600, color: '#8B6914',
                      }}>
                        <Shield size={9}/> Administrator
                      </div>
                    </div>
                    {/* Settings link */}
                    <button
                      onClick={() => { navigate('/admin/settings'); setUserMenuOpen(false); }}
                      style={{
                        display: 'flex', alignItems: 'center', gap: 8,
                        width: '100%', padding: '10px 14px',
                        background: 'none', border: 'none', cursor: 'pointer',
                        fontSize: 13, color: '#2e2619', textAlign: 'left',
                        transition: 'background 0.14s',
                      }}
                      onMouseEnter={e => e.currentTarget.style.background = 'rgba(184,137,42,0.06)'}
                      onMouseLeave={e => e.currentTarget.style.background = 'none'}
                    >
                      <Settings size={13} color='#9C8660'/> Settings
                    </button>
                    {/* Logout */}
                    <button
                      onClick={() => { logout(); setUserMenuOpen(false); }}
                      style={{
                        display: 'flex', alignItems: 'center', gap: 8,
                        width: '100%', padding: '10px 14px',
                        background: 'none', border: 'none', cursor: 'pointer',
                        fontSize: 13, color: '#991B1B', textAlign: 'left',
                        borderTop: '1px solid rgba(184,137,42,0.10)',
                        transition: 'background 0.14s',
                      }}
                      onMouseEnter={e => e.currentTarget.style.background = 'rgba(185,28,28,0.05)'}
                      onMouseLeave={e => e.currentTarget.style.background = 'none'}
                    >
                      <LogOut size={13}/> Sign Out
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </header>

        {/* ── Page content ── */}
        <main className="glm-page-main">
          <Outlet />
        </main>
      </div>

      {/* ── Mobile bottom nav ── */}
      <MobileBottomNav menuItems={ADMIN_MENU} />

      <style>{`
        @keyframes spin  { to { transform: rotate(360deg) } }
        @keyframes pulse { 0%,100% { opacity:1 } 50% { opacity:0.35 } }
      `}</style>
    </div>
  );
};

export default AdminLayout;