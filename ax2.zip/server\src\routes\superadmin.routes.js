// src/routes/superadmin.routes.js
const express = require('express');
const router  = express.Router();
const { protect, authorize } = require('../middlewares/auth.middleware');
const {
  getStats, getSalons, getSalon, createSalon, updateSalon,
  suspendSalon, unsuspendSalon, deleteSalon, getUsers,
} = require('../controllers/superadmin.controller');

// All super admin routes require valid JWT + super_admin role
router.use(protect, authorize('super_admin'));

router.get('/stats',                    getStats);
router.get('/salons',                   getSalons);
router.get('/salons/:id',               getSalon);
router.post('/salons',                  createSalon);
router.put('/salons/:id',               updateSalon);
router.post('/salons/:id/suspend',      suspendSalon);
router.post('/salons/:id/unsuspend',    unsuspendSalon);
router.delete('/salons/:id',            deleteSalon);
router.get('/users',                    getUsers);

module.exports = router;
