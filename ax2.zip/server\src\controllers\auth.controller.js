// src/controllers/auth.controller.js
// ─────────────────────────────────────────────────────────────────────────────
// Phase 1 changes:
//  • login  — fetches salonId + franchiseId from User, embeds in JWT.
//             Also checks that the user's salon is active and not suspended.
//  • refresh — carries salonId + franchiseId forward on rotation.
//  • register — unchanged (customers self-register with no salonId initially).
//  • logout / getMe — unchanged.
// ─────────────────────────────────────────────────────────────────────────────
const User  = require('../models/User');
const Salon = require('../models/Salon');
const { AppError } = require('../middlewares/errorHandler');
const {
  generateAccessToken,
  generateRefreshToken,
  verifyRefreshToken,
  setRefreshTokenCookie,
  clearRefreshTokenCookie,
} = require('../utils/token');

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/auth/register
// Self-registration for customers. No salonId assigned here.
// ─────────────────────────────────────────────────────────────────────────────
const register = async (req, res, next) => {
  try {
    const { name, email, phone, password } = req.body;

    if (!name || !email || !password) {
      throw new AppError('Name, email and password are required', 400);
    }

    const existing = await User.findOne({ email });
    if (existing) {
      throw new AppError('An account with this email already exists', 409);
    }

    const user = await User.create({ name, email, phone, password });

    const accessToken  = generateAccessToken(user._id, user.role, null, null);
    const refreshToken = generateRefreshToken(user._id, user.role, null, null);

    await User.findByIdAndUpdate(user._id, { $push: { refreshTokens: refreshToken } });

    setRefreshTokenCookie(res, refreshToken);

    res.status(201).json({
      success: true,
      message: 'Account created successfully',
      accessToken,
      user: user.toSafeObject(),
    });
  } catch (error) {
    next(error);
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/auth/login
// ─────────────────────────────────────────────────────────────────────────────
const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      throw new AppError('Email and password are required', 400);
    }

    const user = await User
      .findOne({ email })
      .select('+password +refreshTokens');

    if (!user) {
      throw new AppError('Invalid email or password', 401);
    }

    if (!user.isActive) {
      throw new AppError('Your account has been deactivated. Please contact support.', 403);
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      throw new AppError('Invalid email or password', 401);
    }

    // ── Tenant check: verify the assigned salon is active ────────────────
    // super_admin has no salonId — skip this check for them.
    if (user.salonId && user.role !== 'super_admin') {
      const salon = await Salon
        .findById(user.salonId)
        .select('isActive isSuspended suspendReason name')
        .lean();

      if (!salon || !salon.isActive) {
        throw new AppError('Your salon account is no longer active. Please contact support.', 403);
      }
      if (salon.isSuspended) {
        const reason = salon.suspendReason
          ? ` Reason: ${salon.suspendReason}`
          : '';
        throw new AppError(`Your salon (${salon.name}) has been suspended.${reason}`, 403);
      }
    }

    // ── Issue tokens with tenant context ────────────────────────────────
    const accessToken  = generateAccessToken(user._id, user.role, user.salonId, user.franchiseId);
    const refreshToken = generateRefreshToken(user._id, user.role, user.salonId, user.franchiseId);

    await User.findByIdAndUpdate(user._id, { $push: { refreshTokens: refreshToken } });

    setRefreshTokenCookie(res, refreshToken);

    res.status(200).json({
      success: true,
      message: 'Login successful',
      accessToken,
      user: user.toSafeObject(),
    });
  } catch (error) {
    next(error);
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/auth/logout
// ─────────────────────────────────────────────────────────────────────────────
const logout = async (req, res, next) => {
  try {
    const refreshToken = req.cookies?.refreshToken;

    if (refreshToken) {
      await User.findByIdAndUpdate(req.user.userId, {
        $pull: { refreshTokens: refreshToken },
      });
    }

    clearRefreshTokenCookie(res);

    res.status(200).json({ success: true, message: 'Logged out successfully' });
  } catch (error) {
    next(error);
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/auth/refresh
// Rotates the refresh token and preserves salonId + franchiseId.
// ─────────────────────────────────────────────────────────────────────────────
const refreshAccessToken = async (req, res, next) => {
  try {
    const refreshToken = req.cookies?.refreshToken;
    if (!refreshToken) throw new AppError('No refresh token provided', 401);

    let decoded;
    try {
      decoded = verifyRefreshToken(refreshToken);
    } catch {
      throw new AppError('Invalid or expired refresh token', 401);
    }

    const user = await User.findById(decoded.userId).select('+refreshTokens');
    if (!user || !user.refreshTokens.includes(refreshToken)) {
      throw new AppError('Refresh token not recognised', 401);
    }
    if (!user.isActive) {
      throw new AppError('Account is deactivated', 403);
    }

    // Rotate — always re-read salonId/franchiseId from DB so stale tokens
    // automatically pick up any admin reassignment.
    const newAccessToken  = generateAccessToken(user._id, user.role, user.salonId, user.franchiseId);
    const newRefreshToken = generateRefreshToken(user._id, user.role, user.salonId, user.franchiseId);

    await User.findByIdAndUpdate(user._id, {
      $pull: { refreshTokens: refreshToken },
      $push: { refreshTokens: newRefreshToken },
    });

    setRefreshTokenCookie(res, newRefreshToken);

    res.status(200).json({ success: true, accessToken: newAccessToken });
  } catch (error) {
    next(error);
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/auth/me
// ─────────────────────────────────────────────────────────────────────────────
const getMe = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.userId);
    if (!user) throw new AppError('User not found', 404);

    res.status(200).json({ success: true, user: user.toSafeObject() });
  } catch (error) {
    next(error);
  }
};

module.exports = { register, login, logout, refreshAccessToken, getMe };
