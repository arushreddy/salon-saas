// src/middlewares/tenant.middleware.js
// ─────────────────────────────────────────────────────────────────────────────
// Resolves which salon a request belongs to.
//
// Used by TWO types of routes:
//
//   1. Internal dashboard routes (admin / staff / receptionist)
//      The JWT already contains salonId → guardTenant() sets req.salonId.
//      resolveTenant is NOT needed here (Phase 2+ wires it for extra safety).
//
//   2. Public booking website routes (/api/public/*)
//      No JWT. Salon is identified by:
//        a) X-Salon-Slug header  (e.g. "royalcuts")
//        b) Host subdomain       (e.g. royalcuts.yourplatform.com)
//        c) Custom domain match  (e.g. royalcuts.com)
//
// After this middleware runs, req.salonId, req.franchiseId and req.salonData
// are available to all downstream handlers.
// ─────────────────────────────────────────────────────────────────────────────
const Salon   = require('../models/Salon');
const { AppError } = require('./errorHandler');

const PLATFORM_DOMAIN = process.env.PLATFORM_DOMAIN || 'yourplatform.com';

const resolveTenant = async (req, res, next) => {
  try {
    // ── 1. Super admin: skip tenant resolution ───────────────────────────
    if (req.isSuperAdmin) return next();

    // ── 2. Already resolved by guardTenant (JWT path) ───────────────────
    if (req.salonId) return next();

    // ── 3. Public path: resolve from headers ────────────────────────────
    const slugHeader = req.headers['x-salon-slug'];
    const host       = (req.headers['host'] || '').toLowerCase().split(':')[0]; // strip port

    let salon = null;

    // Priority a) explicit slug header (used by SPA booking pages)
    if (slugHeader) {
      salon = await Salon.findOne({ slug: slugHeader.toLowerCase(), isActive: true }).lean();
    }

    // Priority b) exact custom domain match
    if (!salon && host) {
      salon = await Salon.findOne({ customDomain: host, isActive: true }).lean();
    }

    // Priority c) subdomain — extract "royalcuts" from "royalcuts.yourplatform.com"
    if (!salon && host && host.endsWith(`.${PLATFORM_DOMAIN}`)) {
      const sub = host.replace(`.${PLATFORM_DOMAIN}`, '');
      if (sub && sub !== 'www' && sub !== 'api') {
        salon = await Salon.findOne({ slug: sub, isActive: true }).lean();
      }
    }

    if (!salon) {
      return next(new AppError('Salon not found. Check the URL or slug.', 404));
    }

    if (salon.isSuspended) {
      return next(new AppError('This salon account is currently suspended. Please contact support.', 403));
    }

    // Attach tenant context to request
    req.salonId     = salon._id.toString();
    req.franchiseId = salon.franchiseId ? salon.franchiseId.toString() : null;
    req.salonData   = salon; // full doc available for feature-flag checks downstream

    next();
  } catch (err) {
    next(err);
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// planGuard
// Feature-flag check based on the salon's subscription plan.
// Used on routes that require Plan 2 or Plan 3 features.
//
// Usage: router.post('/book', resolveTenant, planGuard('onlineBooking'), handler)
// ─────────────────────────────────────────────────────────────────────────────
const PLAN_FEATURES = {
  plan1: ['adminDashboard', 'inventory', 'staffMgmt', 'walkIns', 'reports', 'whatsapp', 'invoices'],
  plan2: ['adminDashboard', 'inventory', 'staffMgmt', 'walkIns', 'reports', 'whatsapp', 'invoices',
          'onlineBooking', 'customDomain', 'customerWebsite'],
  plan3: ['adminDashboard', 'inventory', 'staffMgmt', 'walkIns', 'reports', 'whatsapp', 'invoices',
          'onlineBooking', 'customDomain', 'customerWebsite', 'franchiseAccess'],
};

const planGuard = (feature) => async (req, res, next) => {
  try {
    if (req.isSuperAdmin) return next();

    // Use salonData if already loaded, else fetch
    let salon = req.salonData;
    if (!salon) {
      const Salon = require('../models/Salon');
      salon = await Salon.findById(req.salonId).select('plan subscriptionExpiry isSuspended').lean();
    }

    if (!salon) return next(new AppError('Salon not found', 404));

    // Check subscription expiry
    if (salon.subscriptionExpiry && new Date(salon.subscriptionExpiry) < new Date()) {
      return next(new AppError('Subscription has expired. Please renew your plan.', 403));
    }

    const allowed = PLAN_FEATURES[salon.plan] || PLAN_FEATURES.plan1;
    if (!allowed.includes(feature)) {
      return next(new AppError(`This feature (${feature}) requires a higher subscription plan.`, 403));
    }

    next();
  } catch (err) {
    next(err);
  }
};

module.exports = { resolveTenant, planGuard };
