// src/controllers/superadmin.controller.js
// All routes protected by authorize('super_admin')
const Salon        = require('../models/Salon');
const Franchise    = require('../models/Franchise');
const User         = require('../models/User');
const { AppError } = require('../middlewares/errorHandler');

// ── GET /api/superadmin/stats ─────────────────────────────────────────────────
const getStats = async (req, res, next) => {
  try {
    const [totalSalons, activeSalons, suspendedSalons, totalUsers, totalFranchises] = await Promise.all([
      Salon.countDocuments(),
      Salon.countDocuments({ isActive: true, isSuspended: false }),
      Salon.countDocuments({ isSuspended: true }),
      User.countDocuments(),
      Franchise.countDocuments(),
    ]);

    const planBreakdown = await Salon.aggregate([
      { $group: { _id: '$plan', count: { $sum: 1 } } },
    ]);

    res.status(200).json({
      success: true,
      stats: {
        totalSalons, activeSalons, suspendedSalons, totalUsers, totalFranchises,
        planBreakdown: planBreakdown.reduce((acc, p) => { acc[p._id] = p.count; return acc; }, {}),
      },
    });
  } catch (e) { next(e); }
};

// ── GET /api/superadmin/salons ────────────────────────────────────────────────
const getSalons = async (req, res, next) => {
  try {
    const { search, plan, status, page = 1, limit = 20 } = req.query;
    const filter = {};
    if (plan)   filter.plan = plan;
    if (status === 'active')    { filter.isActive = true;  filter.isSuspended = false; }
    if (status === 'suspended') { filter.isSuspended = true; }
    if (status === 'inactive')  { filter.isActive = false; }
    if (search) filter.$or = [
      { name:  { $regex: search, $options: 'i' } },
      { slug:  { $regex: search, $options: 'i' } },
      { email: { $regex: search, $options: 'i' } },
    ];

    const [salons, total] = await Promise.all([
      Salon.find(filter)
        .populate('admin', 'name email phone')
        .populate('franchiseId', 'name slug')
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(parseInt(limit)),
      Salon.countDocuments(filter),
    ]);

    res.status(200).json({
      success: true, salons,
      pagination: { total, page: parseInt(page), pages: Math.ceil(total / limit) },
    });
  } catch (e) { next(e); }
};

// ── GET /api/superadmin/salons/:id ────────────────────────────────────────────
const getSalon = async (req, res, next) => {
  try {
    const salon = await Salon.findById(req.params.id)
      .populate('admin', 'name email phone role')
      .populate('franchiseId', 'name slug');
    if (!salon) throw new AppError('Salon not found', 404);
    res.status(200).json({ success: true, salon });
  } catch (e) { next(e); }
};

// ── POST /api/superadmin/salons ───────────────────────────────────────────────
const createSalon = async (req, res, next) => {
  try {
    const { name, slug, adminEmail, adminName, adminPhone, adminPassword, plan, franchiseId } = req.body;
    if (!name || !slug || !adminEmail || !adminPassword)
      throw new AppError('name, slug, adminEmail and adminPassword are required', 400);

    if (await Salon.findOne({ slug: slug.toLowerCase() }))
      throw new AppError('Slug already taken', 409);

    let adminUser = await User.findOne({ email: adminEmail });
    if (!adminUser) {
      adminUser = await User.create({
        name: adminName || adminEmail.split('@')[0],
        email: adminEmail,
        phone: adminPhone || '',
        password: adminPassword,
        role: 'admin',
      });
    }

    const salon = await Salon.create({
      name, slug: slug.toLowerCase(),
      admin: adminUser._id,
      plan: plan || 'plan1',
      franchiseId: franchiseId || null,
      isActive: true,
      createdBy: req.user.userId,
    });

    await User.findByIdAndUpdate(adminUser._id, { salonId: salon._id });

    const populated = await Salon.findById(salon._id).populate('admin', 'name email');
    res.status(201).json({ success: true, message: 'Salon created', salon: populated });
  } catch (e) { next(e); }
};

// ── PUT /api/superadmin/salons/:id ────────────────────────────────────────────
const updateSalon = async (req, res, next) => {
  try {
    const salon = await Salon.findById(req.params.id);
    if (!salon) throw new AppError('Salon not found', 404);

    const allowed = ['name', 'plan', 'subscriptionExpiry', 'isActive', 'phone', 'email', 'logo', 'customDomain', 'features'];
    allowed.forEach(k => { if (req.body[k] !== undefined) salon[k] = req.body[k]; });
    await salon.save();

    const updated = await Salon.findById(salon._id).populate('admin', 'name email');
    res.status(200).json({ success: true, message: 'Salon updated', salon: updated });
  } catch (e) { next(e); }
};

// ── POST /api/superadmin/salons/:id/suspend ───────────────────────────────────
const suspendSalon = async (req, res, next) => {
  try {
    const { reason } = req.body;
    const salon = await Salon.findById(req.params.id);
    if (!salon) throw new AppError('Salon not found', 404);
    salon.isSuspended   = true;
    salon.suspendReason = reason || '';
    await salon.save();
    res.status(200).json({ success: true, message: 'Salon suspended' });
  } catch (e) { next(e); }
};

// ── POST /api/superadmin/salons/:id/unsuspend ─────────────────────────────────
const unsuspendSalon = async (req, res, next) => {
  try {
    const salon = await Salon.findById(req.params.id);
    if (!salon) throw new AppError('Salon not found', 404);
    salon.isSuspended   = false;
    salon.suspendReason = '';
    await salon.save();
    res.status(200).json({ success: true, message: 'Salon reinstated' });
  } catch (e) { next(e); }
};

// ── DELETE /api/superadmin/salons/:id ─────────────────────────────────────────
const deleteSalon = async (req, res, next) => {
  try {
    const salon = await Salon.findById(req.params.id);
    if (!salon) throw new AppError('Salon not found', 404);
    salon.isActive = false;
    await salon.save();
    res.status(200).json({ success: true, message: 'Salon deactivated' });
  } catch (e) { next(e); }
};

// ── GET /api/superadmin/users ─────────────────────────────────────────────────
const getUsers = async (req, res, next) => {
  try {
    const { search, role, page = 1, limit = 30 } = req.query;
    const filter = {};
    if (role)   filter.role = role;
    if (search) filter.$or = [
      { name:  { $regex: search, $options: 'i' } },
      { email: { $regex: search, $options: 'i' } },
    ];
    const [users, total] = await Promise.all([
      User.find(filter)
        .populate('salonId', 'name slug')
        .select('-password -refreshTokens')
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(parseInt(limit)),
      User.countDocuments(filter),
    ]);
    res.status(200).json({
      success: true, users,
      pagination: { total, page: parseInt(page), pages: Math.ceil(total / limit) },
    });
  } catch (e) { next(e); }
};

module.exports = {
  getStats, getSalons, getSalon, createSalon, updateSalon,
  suspendSalon, unsuspendSalon, deleteSalon, getUsers,
};
