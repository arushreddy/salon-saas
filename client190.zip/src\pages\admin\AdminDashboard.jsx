/**
 * AdminDashboard.jsx — Glamour Salon
 * Cream · Gold · Ink  |  Dark luxury hero
 *
 * SYNC MAP
 * ─────────────────────────────────────────────────────────────────────────
 * DataStore (45s poll + BroadcastChannel):
 *   stats       ← /bookings/today/stats
 *   bookings    ← /bookings?date=today
 *   liveStatus  ← /staff/live-status
 *   inventory   ← /inventory  (3 min)
 *
 * Local (30s poll via fetchExtra):
 *   /analytics/overview          → monthly KPIs
 *   /analytics/revenue-chart     → chart
 *   /analytics/top-services      → top services
 *   /cash-transactions/summary   → cash counter (server-computed, NOT localStorage)
 *   /attendance/report           → monthly attendance
 *   /staff                       → staff list (WA panel)
 *   /users?role=customer         → customers (WA panel)
 *   /users?role=receptionist     → receptionists (WA panel)
 *
 * BroadcastChannels:
 *   glamour_bookings_sync → DataStore handles
 *   glamour_cash_sync     → re-fetches /cash-transactions/summary
 * ─────────────────────────────────────────────────────────────────────────
 */

import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '@/context/AuthContext';
import { useDataStore } from '@/context/DataStore';
import api from '@/services/api';
import { useNavigate } from 'react-router-dom';
import {
  AreaChart, Area, ComposedChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';
import {
  Calendar, Users, IndianRupee, TrendingUp, TrendingDown,
  Plus, UserPlus, Scissors, Gift, RefreshCw, ChevronRight,
  Activity, BarChart3, Package, Loader2, Sparkles,
  CreditCard, MessageCircle, Send, Phone,
  Download, Award, Bell, X, Search,
  Percent, UserCheck, Check, Wallet,
} from 'lucide-react';

/* ─── Design Tokens ──────────────────────────────────────────────────── */
const C = {
  pageBg:'#F5EDE0', cardBg:'#FDFAF4', s1:'#F5EFE3', s2:'#EDE3D0',
  border:'#DFD0A8', borderB:'#C8B480',
  heroBg:'#0E0B06', heroBg2:'#1C1608',
  gold:'#B8860B', goldLight:'#D4A017', goldBright:'#F0C040',
  goldPale:'#FFF8E7', goldDeep:'#8B6914', goldFog:'rgba(184,134,11,0.09)',
  ink:'#1A1208', inkMid:'#5C4A2A', inkLight:'#9C8660', inkGhost:'#C8B090',
  green:'#15803D', greenPale:'#DCFCE7', greenBorder:'#86EFAC',
  red:'#991B1B',   redPale:'#FEF2F2',   redBorder:'#FECACA',
  amber:'#92400E', amberPale:'#FFFBEB', amberBorder:'#FDE68A',
  blue:'#1D4ED8',  bluePale:'#EFF6FF',  blueBorder:'#BFDBFE',
  purple:'#6D28D9',purplePale:'#F5F3FF',purpleBorder:'#DDD6FE',
  teal:'#0F766E',  tealPale:'#F0FDFA',  tealBorder:'#99F6E4',
  wa:'#25D366', waPale:'#D7F5E0',
};

/* ─── Helpers ─────────────────────────────────────────────────────────── */
const fmt   = n => Number(n||0).toLocaleString('en-IN');
const fmtRs = n => '₹'+fmt(n);
const fmtK  = n => {
  if(!n) return '₹0';
  if(n>=1e7) return '₹'+(n/1e7).toFixed(2)+'Cr';
  if(n>=1e5) return '₹'+(n/1e5).toFixed(1)+'L';
  if(n>=1e3) return '₹'+(n/1e3).toFixed(1)+'K';
  return fmtRs(n);
};
const initials = (n='') => n.split(' ').slice(0,2).map(w=>w[0]).join('').toUpperCase()||'?';
const IST      = 5.5*3600000;
const todayIST = () => new Date(Date.now()+IST).toISOString().split('T')[0];
const fmtAgo   = ms => {
  const s=Math.floor(ms/1000);
  if(s<10) return 'just now';
  if(s<60) return s+'s ago';
  if(s<3600) return Math.floor(s/60)+'m ago';
  return Math.floor(s/3600)+'h ago';
};
const AV = ['#B8860B','#8B6914','#C9952A','#6B4F12','#DAA520','#A07830','#D4A020'];
const avCol = (n='') => AV[n.charCodeAt(0)%AV.length];

const exportCSV = (rows, headers, fname) => {
  const lines=[headers.join(','),...rows.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(','))];
  const url=URL.createObjectURL(new Blob([lines.join('\n')],{type:'text/csv'}));
  const a=document.createElement('a'); a.href=url; a.download=fname; a.click(); URL.revokeObjectURL(url);
};

const BS = {
  confirmed:     {label:'Confirmed',   dot:'#F59E0B',bg:'#FFFBEB',text:'#92400E',border:'#FDE68A'},
  'in-progress': {label:'In Progress', dot:'#10B981',bg:'#ECFDF5',text:'#065F46',border:'#A7F3D0'},
  completed:     {label:'Completed',   dot:'#3B82F6',bg:'#EFF6FF',text:'#1E40AF',border:'#BFDBFE'},
  cancelled:     {label:'Cancelled',   dot:'#EF4444',bg:'#FEF2F2',text:'#991B1B',border:'#FECACA'},
  'no-show':     {label:'No Show',     dot:'#9CA3AF',bg:'#F9FAFB',text:'#374151',border:'#E5E7EB'},
  pending:       {label:'Pending',     dot:'#F59E0B',bg:'#FFFBEB',text:'#92400E',border:'#FDE68A'},
};
const FS = {
  available:          {label:'Available',   dot:'#22C55E',bg:'#DCFCE7',text:'#166534',border:'#86EFAC'},
  busy:               {label:'With Client', dot:'#F59E0B',bg:'#FFFBEB',text:'#92400E',border:'#FDE68A'},
  'temp-unavailable': {label:'Stepped Out', dot:'#F97316',bg:'#FFF7ED',text:'#C2410C',border:'#FDBA74'},
  'off-duty':         {label:'Off Duty',    dot:'#D1D5DB',bg:'#F9FAFB',text:'#6B7280',border:'#E5E7EB'},
  absent:             {label:'Absent',      dot:'#EF4444',bg:'#FEF2F2',text:'#991B1B',border:'#FECACA'},
};

const WA_TPL = {
  customers:[
    {id:'reminder',label:'Appointment Reminder',msg:'Hi {name}! Your appointment is scheduled. We look forward to seeing you!'},
    {id:'offer',   label:'Special Offer',        msg:'Hi {name}! Exclusive offer — 20% off on all hair services this week. Book now!'},
    {id:'feedback',label:'Feedback Request',     msg:'Hi {name}! Thank you for visiting us today. How was your experience?'},
    {id:'birthday',label:'Birthday Wishes',      msg:'Dear {name}! Happy Birthday! Celebrate with us — special birthday discount on your next visit!'},
    {id:'custom',  label:'Custom Message',       msg:''},
  ],
  staff:[
    {id:'schedule',label:'Schedule Update',    msg:'Hi {name}! Please note your schedule for tomorrow. Confirm receipt.'},
    {id:'meeting', label:'Team Meeting',       msg:'Hi {name}! Team meeting scheduled. Please ensure your attendance.'},
    {id:'attend',  label:'Attendance Reminder',msg:'Hi {name}! Reminder to mark your attendance when you arrive.'},
    {id:'custom',  label:'Custom Message',     msg:''},
  ],
  receptionists:[
    {id:'briefing',label:'Daily Briefing', msg:"Hi {name}! Good morning! Please review today's appointment schedule."},
    {id:'stock',   label:'Inventory Alert',msg:'Hi {name}! Please check inventory for low-stock items. Thank you!'},
    {id:'custom',  label:'Custom Message', msg:''},
  ],
};

const ease    = [0.22,0.61,0.36,1];
const fade    = {hidden:{opacity:0,y:14},show:{opacity:1,y:0,transition:{duration:0.4,ease}}};
const stagger = {hidden:{opacity:0},show:{opacity:1,transition:{staggerChildren:0.05}}};

/* ─── Atoms ──────────────────────────────────────────────────────────── */
function Pulse({color='#22C55E',size=7}) {
  return <span style={{display:'inline-block',width:size,height:size,borderRadius:'50%',
    background:color,animation:'pulseDot 2s ease-in-out infinite',boxShadow:'0 0 6px '+color+'88'}}/>;
}

function GrowthBadge({value}) {
  if(value==null) return null;
  const up=value>=0;
  const Icon=up?TrendingUp:TrendingDown;
  return <span style={{display:'inline-flex',alignItems:'center',gap:3,padding:'2px 7px',borderRadius:100,
    fontSize:10,fontWeight:700,background:up?C.greenPale:C.redPale,color:up?C.green:C.red,
    border:'1px solid '+(up?C.greenBorder:C.redBorder)}}>
    <Icon size={9}/>{up?'+':''}{value}%
  </span>;
}

function SectionHead({title,badge,badgeBg,badgeColor,action,live=false,icon:Icon}) {
  return <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',
    padding:'16px 20px',borderBottom:'1px solid '+C.border}}>
    <div style={{display:'flex',alignItems:'center',gap:9}}>
      {live&&<Pulse size={7}/>}
      {Icon&&<Icon size={15} color={C.gold}/>}
      <h3 style={{fontFamily:'Playfair Display,serif',fontSize:15,fontWeight:700,color:C.ink,margin:0}}>{title}</h3>
      {badge!=null&&<span style={{padding:'2px 9px',borderRadius:100,fontSize:11,fontWeight:700,
        background:badgeBg||C.goldPale,color:badgeColor||C.gold,border:'1px solid '+C.border}}>{badge}</span>}
    </div>
    {action}
  </div>;
}

function KpiCard({icon:Icon,label,value,sub,growth,color,bg,border,onClick,loading}) {
  const accent=color||C.gold;
  return <motion.div variants={fade} whileHover={{y:-4,boxShadow:'0 20px 48px '+accent+'22'}} onClick={onClick}
    style={{background:C.cardBg,border:'1px solid '+(border||C.border),borderRadius:20,
      padding:'20px 20px 16px',cursor:onClick?'pointer':'default',
      boxShadow:'0 2px 16px '+accent+'0A',position:'relative',overflow:'hidden'}}>
    <div style={{position:'absolute',top:-20,right:-20,width:80,height:80,borderRadius:'50%',
      background:accent+'12',pointerEvents:'none'}}/>
    <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:14}}>
      <div style={{width:42,height:42,borderRadius:14,display:'flex',alignItems:'center',justifyContent:'center',
        background:bg||C.goldPale,border:'1px solid '+(border||C.border)}}><Icon size={19} color={accent}/></div>
      <span style={{display:'flex',alignItems:'center',gap:4,padding:'3px 8px',borderRadius:100,
        fontSize:10,fontWeight:700,background:C.goldPale,color:C.gold,border:'1px solid '+C.border}}>
        <Pulse color={C.goldLight} size={5}/> LIVE
      </span>
    </div>
    <div style={{fontSize:30,fontWeight:800,color:C.ink,lineHeight:1,fontFamily:'Playfair Display,serif',marginBottom:4}}>
      {loading?<span style={{color:C.inkGhost}}>—</span>:value}
    </div>
    <div style={{fontSize:12,fontWeight:700,color:C.inkMid,marginBottom:5}}>{label}</div>
    <div style={{display:'flex',alignItems:'center',gap:6}}>
      <span style={{fontSize:11,color:C.inkLight}}>{sub}</span>
      <GrowthBadge value={growth}/>
    </div>
    <div style={{marginTop:14,height:2,borderRadius:2,background:'linear-gradient(to right, '+accent+', transparent)'}}/>
  </motion.div>;
}

function RevTooltip({active,payload,label}) {
  if(!active||!payload?.length) return null;
  return <div style={{background:C.heroBg2,border:'1px solid #3A280C',borderRadius:12,padding:'10px 14px',
    boxShadow:'0 8px 32px rgba(0,0,0,0.4)'}}>
    <div style={{fontSize:11,color:C.inkLight,marginBottom:4}}>{label}</div>
    {payload.map(p=><div key={p.dataKey} style={{fontSize:14,fontWeight:700,color:C.goldBright}}>
      {p.dataKey==='revenue'?fmtRs(p.value):p.value+' bookings'}
    </div>)}
  </div>;
}

function PipelineBar({stats}) {
  const total=Math.max(stats?.total||0,1);
  const segs=[
    {k:'confirmed', v:stats?.confirmed||0,  c:'#F59E0B',label:'Confirmed'},
    {k:'inProgress',v:stats?.inProgress||0, c:'#10B981',label:'Active'},
    {k:'completed', v:stats?.completed||0,  c:'#3B82F6',label:'Done'},
    {k:'cancelled', v:stats?.cancelled||0,  c:'#EF4444',label:'Cancelled'},
  ];
  return <div>
    <div style={{display:'flex',height:8,borderRadius:4,overflow:'hidden',gap:2,marginBottom:10}}>
      {segs.map(s=><div key={s.k} style={{flex:s.v/total,background:s.c,minWidth:s.v>0?4:0,transition:'flex 0.6s ease',borderRadius:2}}/>)}
    </div>
    <div style={{display:'flex',flexWrap:'wrap',gap:12}}>
      {segs.map(s=><div key={s.k} style={{display:'flex',alignItems:'center',gap:5}}>
        <span style={{width:8,height:8,borderRadius:2,background:s.c}}/>
        <span style={{fontSize:11,color:'rgba(255,255,255,0.45)'}}>{s.label}</span>
        <span style={{fontSize:12,fontWeight:700,color:'rgba(255,255,255,0.9)'}}>{s.v}</span>
      </div>)}
    </div>
  </div>;
}

/* ─── Cash Counter Modal ─────────────────────────────────────────────── */
function CashCounterModal({cashData,onClose}) {
  const balance=cashData?.balance||0, cashIn=cashData?.cashIn||0, manualIn=cashData?.manualIn||0;
  const withdrawn=cashData?.withdrawn||0, expenses=cashData?.expenses||0, advances=cashData?.advances||0;
  const todayCash=cashData?.todayCash||0, cashCount=cashData?.cashCount||0;
  const recentBookings=cashData?.recentBookings||[];
  return <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={onClose}
    style={{position:'fixed',inset:0,zIndex:1000,background:'rgba(15,12,7,0.72)',backdropFilter:'blur(8px)',
      display:'flex',alignItems:'center',justifyContent:'center',padding:20}}>
    <motion.div initial={{scale:0.94,y:20}} animate={{scale:1,y:0}} exit={{scale:0.94,y:20}} onClick={e=>e.stopPropagation()}
      style={{width:480,background:C.cardBg,borderRadius:24,border:'1px solid '+C.border,
        boxShadow:'0 32px 80px rgba(0,0,0,0.4)',overflow:'hidden'}}>
      <div style={{padding:'20px 24px',borderBottom:'1px solid '+C.border,
        background:'linear-gradient(135deg,#1c1408,#2d2010)',position:'relative',overflow:'hidden'}}>
        <div style={{position:'absolute',top:-30,right:-30,width:120,height:120,borderRadius:'50%',
          background:'radial-gradient(circle,rgba(218,165,32,0.15) 0%,transparent 70%)'}}/>
        <div style={{position:'relative',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
          <div style={{display:'flex',alignItems:'center',gap:12}}>
            <div style={{width:44,height:44,borderRadius:14,
              background:'linear-gradient(135deg,'+C.gold+','+C.goldLight+')',
              display:'flex',alignItems:'center',justifyContent:'center',
              boxShadow:'0 4px 16px '+C.gold+'40'}}><Wallet size={22} color='#fff'/></div>
            <div>
              <h2 style={{fontSize:18,fontWeight:800,color:'#fff',margin:0,fontFamily:'Playfair Display,serif'}}>Cash Counter</h2>
              <p style={{fontSize:12,color:'#7a6040',margin:0}}>Current shift · server-computed</p>
            </div>
          </div>
          <button onClick={onClose} style={{width:32,height:32,borderRadius:10,
            border:'1px solid rgba(255,255,255,0.15)',background:'rgba(255,255,255,0.08)',
            cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}>
            <X size={16} color='#fff'/></button>
        </div>
      </div>
      <div style={{padding:'22px 24px'}}>
        <div style={{textAlign:'center',padding:'24px 20px',borderRadius:20,marginBottom:16,
          background:'linear-gradient(135deg,'+C.goldPale+',#FFF5D6)',border:'2px solid '+C.gold+'30'}}>
          <div style={{fontSize:11,fontWeight:800,textTransform:'uppercase',letterSpacing:'0.14em',color:C.gold,marginBottom:8}}>
            Current Counter Balance</div>
          <div style={{fontSize:48,fontWeight:800,color:C.ink,lineHeight:1,fontFamily:'Playfair Display,serif'}}>{fmtRs(balance)}</div>
          <div style={{fontSize:12,color:C.inkLight,marginTop:8}}>
            Since last shift close · +{fmtRs(todayCash)} today ({cashCount} bookings)</div>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:16}}>
          {[
            {l:'Cash from Bookings',v:cashIn,    c:C.green,   bg:C.greenPale, br:C.greenBorder, s:'+'},
            {l:'Manual Cash In',   v:manualIn,  c:C.blue,    bg:C.bluePale,  br:C.blueBorder,  s:'+'},
            {l:'Withdrawals',      v:withdrawn, c:C.red,     bg:C.redPale,   br:C.redBorder,   s:'−'},
            {l:'Expenses',         v:expenses,  c:'#F97316', bg:C.amberPale, br:C.amberBorder, s:'−'},
            ...(advances>0?[{l:'Salary Advances',v:advances,c:C.purple,bg:C.purplePale,br:C.purpleBorder,s:'−'}]:[]),
          ].map(({l,v,c,bg,br,s})=><div key={l} style={{padding:'11px 14px',borderRadius:12,background:bg,border:'1px solid '+br}}>
            <div style={{fontSize:10,fontWeight:700,color:c,textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:4}}>{s} {l}</div>
            <div style={{fontSize:18,fontWeight:800,color:C.ink,fontFamily:'Playfair Display,serif'}}>{fmtRs(v)}</div>
          </div>)}
        </div>
        {recentBookings.length>0&&<div>
          <div style={{fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'0.1em',color:C.inkLight,marginBottom:8}}>Recent Cash Bookings</div>
          <div style={{display:'flex',flexDirection:'column',gap:5,maxHeight:150,overflowY:'auto'}}>
            {recentBookings.slice(0,6).map((b,i)=><div key={b._id||i}
              style={{display:'flex',alignItems:'center',justifyContent:'space-between',
                padding:'8px 12px',borderRadius:10,background:C.pageBg,border:'1px solid '+C.border}}>
              <div>
                <div style={{fontSize:12,fontWeight:700,color:C.ink}}>{b.customer?.name||'Walk-in'}</div>
                <div style={{fontSize:10,color:C.inkLight}}>{b.service?.name||b.timeSlot?.start||'—'}</div>
              </div>
              <div style={{fontSize:14,fontWeight:800,color:C.green,fontFamily:'Playfair Display,serif'}}>
                {fmtRs(b.finalAmount||b.totalAmount||0)}</div>
            </div>)}
          </div>
        </div>}
        {recentBookings.length===0&&<div style={{padding:16,textAlign:'center',color:C.inkLight,fontSize:12,
          background:C.pageBg,borderRadius:12,border:'1px solid '+C.border}}>
          No cash bookings this shift — balance carried forward</div>}
      </div>
    </motion.div>
  </motion.div>;
}

/* ─── WhatsApp Panel ─────────────────────────────────────────────────── */
function WhatsAppPanel({onClose,customers:initC=[],staff=[],receptionists=[]}) {
  const [tab,setTab]=useState('customers');
  const [search,setSearch]=useState('');
  const [selected,setSelected]=useState([]);
  const [tplId,setTplId]=useState('custom');
  const [msg,setMsg]=useState('');
  const [sent,setSent]=useState(false);
  const [onlyPhone,setOnlyPhone]=useState(true);
  const [customers,setCustomers]=useState(initC);
  const [loadingC,setLoadingC]=useState(false);

  useEffect(()=>{
    setLoadingC(true);
    api.get('/users',{params:{role:'customer',limit:1000}})
      .then(r=>setCustomers(r.data.users||[])).catch(()=>{}).finally(()=>setLoadingC(false));
  },[]);

  const ALL={customers,staff,receptionists};
  const TPLS=WA_TPL[tab]||[];

  const filtered=useMemo(()=>{
    let list=(ALL[tab]||[]).filter(c=>(c.name||'').toLowerCase().includes(search.toLowerCase())||(c.phone||'').includes(search));
    if(onlyPhone) list=list.filter(c=>(c.phone||'').replace(/\D/g,'').length>=10);
    return list;
  },[tab,search,customers,staff,receptionists,onlyPhone]);

  const withPhoneCnt=(ALL[tab]||[]).filter(c=>(c.phone||'').replace(/\D/g,'').length>=10).length;
  const totalCnt=(ALL[tab]||[]).length;
  const toggle=id=>setSelected(s=>s.includes(id)?s.filter(x=>x!==id):[...s,id]);
  const toggleAll=()=>setSelected(s=>s.length===filtered.length?[]:filtered.map(c=>c._id));
  const handleTpl=t=>{setTplId(t.id);setMsg(t.id!=='custom'?t.msg:'');};

  const sendAll=()=>{
    const contacts=filtered.filter(c=>selected.includes(c._id));
    if(!contacts.length) return;
    let opened=0;
    contacts.forEach(c=>{
      const raw=(c.phone||'').replace(/\D/g,'');
      if(!raw||raw.length<10) return;
      const ph=raw.length===10?'91'+raw:raw.length===12&&raw.startsWith('91')?raw:'91'+raw.slice(-10);
      const m=msg.replace(/{name}/g,c.name||'there').replace(/{date}/g,new Date().toLocaleDateString('en-IN'))
        .replace(/{time}/g,new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'}))
        .replace(/{notes}/g,'Check dashboard');
      window.open('https://wa.me/'+ph+'?text='+encodeURIComponent(m),'_blank');
      opened++;
    });
    if(opened>0){setSent(true);setTimeout(()=>setSent(false),3000);}
    else alert('No valid phone numbers in selection');
  };

  const tabSty=t=>({padding:'7px 14px',borderRadius:10,fontSize:12,fontWeight:700,cursor:'pointer',
    border:'none',transition:'all 0.15s',background:tab===t?C.ink:'transparent',color:tab===t?'#fff':C.inkMid});

  return <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}
    style={{position:'fixed',inset:0,zIndex:1000,display:'flex',alignItems:'center',justifyContent:'center',
      background:'rgba(15,12,7,0.72)',backdropFilter:'blur(8px)'}} onClick={onClose}>
    <motion.div initial={{scale:0.94,y:20}} animate={{scale:1,y:0}} exit={{scale:0.94,y:20}}
      transition={{duration:0.22}} onClick={e=>e.stopPropagation()}
      style={{width:700,maxHeight:'90vh',background:C.cardBg,borderRadius:24,
        boxShadow:'0 32px 80px rgba(0,0,0,0.4)',border:'1px solid '+C.border,
        display:'flex',flexDirection:'column',overflow:'hidden'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',
        padding:'20px 24px',borderBottom:'1px solid '+C.border,
        background:'linear-gradient(135deg,'+C.wa+'18,'+C.waPale+')'}}>
        <div style={{display:'flex',alignItems:'center',gap:12}}>
          <div style={{width:44,height:44,borderRadius:14,background:C.wa,display:'flex',
            alignItems:'center',justifyContent:'center',boxShadow:'0 4px 16px '+C.wa+'40'}}>
            <MessageCircle size={22} color='#fff'/></div>
          <div>
            <h2 style={{fontSize:18,fontWeight:800,color:C.ink,margin:0,fontFamily:'Playfair Display,serif'}}>WhatsApp Messaging</h2>
            <p style={{fontSize:12,color:C.inkLight,margin:0}}>Send personalised messages to your contacts</p>
          </div>
        </div>
        <button onClick={onClose} style={{width:32,height:32,borderRadius:10,border:'1px solid '+C.border,
          background:'transparent',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}>
          <X size={16} color={C.inkMid}/></button>
      </div>
      <div style={{display:'flex',flex:1,overflow:'hidden'}}>
        <div style={{width:280,borderRight:'1px solid '+C.border,display:'flex',flexDirection:'column',overflow:'hidden'}}>
          <div style={{display:'flex',gap:4,padding:'12px 12px 8px',borderBottom:'1px solid '+C.border}}>
            {['customers','staff','receptionists'].map(t=><button key={t} style={tabSty(t)}
              onClick={()=>{setTab(t);setSelected([]);}}>
              {t==='customers'?'Clients':t==='receptionists'?'Recept.':'Staff'}
              <span style={{marginLeft:4,fontSize:10,opacity:0.7}}>({(ALL[t]||[]).length})</span>
            </button>)}
          </div>
          <div style={{padding:'8px 12px',borderBottom:'1px solid '+C.border}}>
            <div style={{display:'flex',alignItems:'center',gap:8,background:C.pageBg,borderRadius:10,
              padding:'7px 10px',border:'1px solid '+C.border}}>
              <Search size={13} color={C.inkLight}/>
              <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search…"
                style={{flex:1,border:'none',background:'transparent',fontSize:12,color:C.ink,outline:'none'}}/>
            </div>
          </div>
          <div style={{padding:'6px 12px',borderBottom:'1px solid '+C.border,background:C.pageBg,
            display:'flex',alignItems:'center',justifyContent:'space-between'}}>
            <label style={{display:'flex',alignItems:'center',gap:5,fontSize:10,fontWeight:600,color:C.inkMid,cursor:'pointer'}}>
              <input type='checkbox' checked={onlyPhone} onChange={e=>{setOnlyPhone(e.target.checked);setSelected([]);}}
                style={{accentColor:C.wa}}/> With phone only</label>
            <span style={{fontSize:10,color:C.inkLight}}>📱 {withPhoneCnt}/{totalCnt}</span>
          </div>
          <div style={{padding:'8px 12px',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
            <label style={{display:'flex',alignItems:'center',gap:6,fontSize:11,fontWeight:600,color:C.inkMid,cursor:'pointer'}}>
              <input type='checkbox' checked={selected.length===filtered.length&&filtered.length>0}
                onChange={toggleAll} style={{accentColor:C.gold}}/> All ({filtered.length})</label>
            {selected.length>0&&<span style={{fontSize:11,fontWeight:700,color:C.gold}}>{selected.length} selected</span>}
          </div>
          <div style={{flex:1,overflowY:'auto',padding:'0 8px 8px'}}>
            {loadingC&&tab==='customers'?<div style={{padding:24,textAlign:'center'}}>
              <Loader2 size={16} color={C.gold} style={{animation:'spin 0.8s linear infinite'}}/>
              <div style={{fontSize:11,color:C.inkLight,marginTop:8}}>Loading…</div>
            </div>:filtered.length===0?<div style={{padding:24,textAlign:'center',color:C.inkLight,fontSize:12}}>
              {totalCnt===0?'No contacts loaded':onlyPhone?'No contacts with phones':'No results'}
            </div>:filtered.map(c=>{
              const hasPhone=(c.phone||'').replace(/\D/g,'').length>=10;
              return <div key={c._id} onClick={()=>toggle(c._id)}
                style={{display:'flex',alignItems:'center',gap:10,padding:'8px 10px',borderRadius:10,
                  cursor:'pointer',marginBottom:3,transition:'all 0.12s',
                  background:selected.includes(c._id)?C.wa+'15':'transparent',
                  border:selected.includes(c._id)?'1px solid '+C.wa+'40':'1px solid transparent'}}>
                <input type='checkbox' checked={selected.includes(c._id)} onChange={()=>toggle(c._id)}
                  style={{accentColor:C.wa,flexShrink:0}}/>
                <div style={{width:30,height:30,borderRadius:10,flexShrink:0,background:avCol(c.name),
                  display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:700,color:'#fff'}}>
                  {initials(c.name)}</div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:12,fontWeight:700,color:C.ink,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>{c.name}</div>
                  <div style={{fontSize:10,color:hasPhone?C.inkMid:C.inkGhost}}>{hasPhone?c.phone:'No phone'}</div>
                </div>
                {hasPhone?<Phone size={11} color={C.wa}/>:<span style={{fontSize:9,color:C.inkGhost}}>—</span>}
              </div>;
            })}
          </div>
        </div>
        <div style={{flex:1,display:'flex',flexDirection:'column',padding:20,overflow:'auto'}}>
          <div style={{marginBottom:14}}>
            <div style={{fontSize:11,fontWeight:700,color:C.inkLight,textTransform:'uppercase',letterSpacing:'0.1em',marginBottom:8}}>Template</div>
            <div style={{display:'flex',flexWrap:'wrap',gap:7}}>
              {TPLS.map(t=><button key={t.id} onClick={()=>handleTpl(t)}
                style={{padding:'6px 12px',borderRadius:10,fontSize:11,fontWeight:600,cursor:'pointer',
                  transition:'all 0.12s',border:'1px solid '+C.border,
                  background:tplId===t.id?C.ink:C.cardBg,color:tplId===t.id?'#fff':C.inkMid}}>{t.label}</button>)}
            </div>
          </div>
          <div style={{fontSize:11,fontWeight:700,color:C.inkLight,textTransform:'uppercase',letterSpacing:'0.1em',
            marginBottom:8,display:'flex',justifyContent:'space-between'}}>
            <span>Message</span>
            <span style={{textTransform:'none',fontWeight:400,color:C.inkGhost,fontSize:10}}>{'Variables: {name} {date} {time}'}</span>
          </div>
          <textarea value={msg} onChange={e=>setMsg(e.target.value)} placeholder="Type your message here…"
            style={{flex:1,minHeight:130,padding:'12px 14px',borderRadius:14,border:'2px solid '+C.border,
              background:C.pageBg,color:C.ink,fontSize:13,fontFamily:'inherit',resize:'none',outline:'none',lineHeight:1.6}}
            onFocus={e=>e.target.style.borderColor=C.gold} onBlur={e=>e.target.style.borderColor=C.border}/>
          {msg&&<div style={{marginTop:10,padding:'12px 14px',borderRadius:12,background:C.wa+'12',border:'1px solid '+C.wa+'30'}}>
            <div style={{fontSize:10,fontWeight:700,color:C.wa,textTransform:'uppercase',letterSpacing:'0.1em',marginBottom:5}}>Preview</div>
            <div style={{fontSize:12,color:C.inkMid,lineHeight:1.6,whiteSpace:'pre-wrap'}}>
              {msg.replace(/{name}/g,'Customer').replace(/{date}/g,'Today').replace(/{time}/g,'10:00 AM')}</div>
          </div>}
          <button onClick={sendAll} disabled={!selected.length||!msg}
            style={{marginTop:14,display:'flex',alignItems:'center',justifyContent:'center',gap:8,padding:13,
              borderRadius:14,border:'none',background:selected.length&&msg?C.wa:C.border,color:'#fff',
              fontSize:13,fontWeight:700,cursor:selected.length&&msg?'pointer':'not-allowed',
              boxShadow:selected.length&&msg?'0 6px 20px '+C.wa+'40':'none'}}>
            {sent?<><Check size={16}/> Opened!</>:<><Send size={16}/> Send to {selected.length} contact{selected.length!==1?'s':''}</>}
          </button>
          <p style={{fontSize:11,color:C.inkGhost,textAlign:'center',margin:'8px 0 0'}}>Opens individual WhatsApp chats</p>
        </div>
      </div>
    </motion.div>
  </motion.div>;
}

/* ══════════════════════════════════════════════════════════════════════════
   MAIN DASHBOARD
   ══════════════════════════════════════════════════════════════════════════ */
export default function AdminDashboard() {
  const {user}=useAuth();
  const navigate=useNavigate();
  const {stats,bookings:allBookings,liveStatus,syncing,refresh,inventory:dsInventory}=useDataStore();

  const [overview,   setOverview]   = useState(null);
  const [chartData,  setChartData]  = useState([]);
  const [chartPeriod,setChartPeriod]= useState('last7');
  const [topServices,setTopServices]= useState([]);
  const [customers,  setCustomers]  = useState([]);
  const [staffList,  setStaffList]  = useState([]);
  const [receptions, setReceptions] = useState([]);
  const [inventory,  setInventory]  = useState([]);
  const [cashData,   setCashData]   = useState(null);
  const [cashModal,  setCashModal]  = useState(false);
  const [attendance, setAttendance] = useState([]);
  const [extraLoad,  setExtraLoad]  = useState(true);
  const [chartLoad,  setChartLoad]  = useState(false);
  const [lastFetchAt,setLastFetchAt]= useState(null);
  const [agoText,    setAgoText]    = useState('just now');
  const [time,       setTime]       = useState(new Date());
  const [manRefresh, setManRefresh] = useState(false);
  const [waOpen,     setWaOpen]     = useState(false);
  const [search,     setSearch]     = useState('');
  const [statusF,    setStatusF]    = useState('all');
  const [showAlerts, setShowAlerts] = useState(true);
  const extraRef=useRef(null);

  useEffect(()=>{if(dsInventory?.length) setInventory(dsInventory);},[dsInventory]);

  const today=todayIST();
  const todayB=useMemo(()=>allBookings.filter(b=>{
    if(!b.date) return false;
    return new Date(b.date).toISOString().split('T')[0]===today;
  }),[allBookings,today]);

  const filteredB=useMemo(()=>{
    let b=todayB;
    if(statusF!=='all') b=b.filter(x=>x.status===statusF);
    if(search) b=b.filter(x=>(x.customer?.name||'').toLowerCase().includes(search.toLowerCase())||(x.service?.name||'').toLowerCase().includes(search.toLowerCase()));
    return b;
  },[todayB,statusF,search]);

  const hour=time.getHours();
  const greeting=hour<12?'Good Morning':hour<17?'Good Afternoon':'Good Evening';
  const dateStr=time.toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
  const timeStr=time.toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true});

  const floorCounts=useMemo(()=>{
    const c={available:0,busy:0,'temp-unavailable':0,'off-duty':0,absent:0};
    (liveStatus||[]).forEach(s=>{const k=s.liveStatus||'off-duty';if(k in c) c[k]++;});
    return c;
  },[liveStatus]);

  const lowStock=useMemo(()=>inventory.filter(i=>(i.quantity||0)<=(i.lowStockThreshold||i.minStock||5)),[inventory]);
  const pendingPayCnt=stats?.pendingPayCount||0, pendingPayAmt=stats?.pendingPayment||0;
  const totalCustomers=overview?.customers?.total??null;
  const monthRevenue=overview?.revenue?.current??null, revenueGrowth=overview?.revenue?.growth??null;
  const bookingGrowth=overview?.bookings?.growth??null;
  const _totalB=overview?.bookings?.total??overview?.bookings?.current??0;
  const convRate=_totalB?Math.round((overview.bookings.completed/_totalB)*100):null;

  useEffect(()=>{const id=setInterval(()=>setTime(new Date()),1000);return()=>clearInterval(id);},[]);
  useEffect(()=>{
    if(!lastFetchAt) return;
    const id=setInterval(()=>setAgoText(fmtAgo(Date.now()-lastFetchAt)),5000);
    return()=>clearInterval(id);
  },[lastFetchAt]);

  const parseCash=s=>({
    balance:   s.balance   ||s.counterBalance||0,
    cashIn:    s.cashIn    ||s.bookingCash   ||0,
    manualIn:  s.manualIn  ||0,
    withdrawn: s.withdrawn ||s.withdrawals   ||0,
    expenses:  s.expenses  ||0, advances:s.advances||0,
    todayCash: s.todayCash ||s.todayTotal    ||0,
    cashCount: s.cashCount ||s.todayCount    ||0,
    recentBookings:s.recentBookings||[],
  });

  const fetchExtra=useCallback(async()=>{
    try{
      const [ov,svc,cust,inv,cash,attR,staffR,recR]=await Promise.allSettled([
        api.get('/analytics/overview',{params:{period:'thisMonth'}}),
        api.get('/analytics/top-services',{params:{period:'thisMonth'}}),
        api.get('/users',{params:{role:'customer',limit:1000}}),
        api.get('/inventory',{params:{limit:500}}),
        api.get('/cash-transactions/summary'),   /* ★ server-computed, not localStorage */
        api.get('/attendance/report',{params:{year:new Date().getFullYear(),month:new Date().getMonth()+1}}),
        api.get('/staff',{params:{limit:200}}),
        api.get('/users',{params:{role:'receptionist',limit:50}}),
      ]);
      if(ov.status  ==='fulfilled') setOverview(ov.value.data.overview);
      if(svc.status ==='fulfilled') setTopServices((svc.value.data.services||svc.value.data.serviceStats||[]).slice(0,8));
      if(cust.status==='fulfilled') setCustomers(cust.value.data.users||[]);
      if(inv.status ==='fulfilled') setInventory(inv.value.data.products||inv.value.data.inventory||[]);
      if(cash.status==='fulfilled') setCashData(parseCash(cash.value.data.summary||cash.value.data||{}));
      if(attR.status==='fulfilled') setAttendance(attR.value.data.summary||[]);
      if(staffR.status==='fulfilled'){
        const raw=staffR.value.data.staff||staffR.value.data.users||[];
        setStaffList(raw.filter(u=>u.role!=='receptionist'));
      }
      if(recR.status==='fulfilled') setReceptions(recR.value.data.users||[]);
    }catch{}
    setExtraLoad(false); setLastFetchAt(Date.now()); setAgoText('just now');
  },[]);

  const fetchChart=useCallback(async(period)=>{
    setChartLoad(true);
    try{
      const{data}=await api.get('/analytics/revenue-chart',{params:{period}});
      const chartArr = data.chart || [];
      // fallback: server returned old revenueData format
      const MONTHS=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      const rows = chartArr.length > 0 ? chartArr : (data.revenueData||[]).map(r=>({
        label:r._id.day+' '+MONTHS[r._id.month-1], date:'', revenue:r.revenue||0, bookings:r.count||0,
      }));
      setChartData(rows.map(d=>({day:d.label||d.date||'',revenue:d.revenue||0,bookings:d.bookings||0})));
    }catch{}
    setChartLoad(false);
  },[]);

  useEffect(()=>{fetchExtra();fetchChart('last7');},[fetchExtra,fetchChart]);
  useEffect(()=>{fetchChart(chartPeriod);},[chartPeriod,fetchChart]);
  useEffect(()=>{
    extraRef.current=setInterval(()=>{if(!document.hidden){fetchExtra();fetchChart(chartPeriod);}},30000);
    return()=>clearInterval(extraRef.current);
  },[fetchExtra,chartPeriod,fetchChart]);

  /* Listen for cash mutations from ReceptionistCash / AdminPayments */
  useEffect(()=>{
    let bc=null;
    try{
      bc=new BroadcastChannel('glamour_cash_sync');
      bc.onmessage=()=>{
        api.get('/cash-transactions/summary')
          .then(r=>setCashData(parseCash(r.data.summary||r.data||{}))).catch(()=>{});
      };
    }catch{}
    return()=>{try{bc?.close();}catch{}};
  },[]);

  const handleRefresh=async()=>{
    setManRefresh(true);
    await Promise.allSettled([refresh(false),fetchExtra(),fetchChart(chartPeriod)]);
    setManRefresh(false);
  };

  const exportBookings=()=>exportCSV(
    filteredB.map(b=>[b.customer?.name||'Walk-in',b.customer?.phone||'',b.service?.name||'',
      b.staff?.name||'',b.date||'',b.timeSlot?.start||'',b.status||'',b.finalAmount||b.totalAmount||0]),
    ['Customer','Phone','Service','Stylist','Date','Time','Status','Amount(₹)'],
    'bookings-'+today+'.csv');

  const exportRevenue=()=>exportCSV(chartData.map(d=>[d.day,d.revenue,d.bookings]),
    ['Date','Revenue(₹)','Bookings'],'revenue-'+today+'.csv');

  return <motion.div variants={stagger} initial='hidden' animate='show'
    className='glm-dash-page' style={{fontFamily:'DM Sans,sans-serif'}}>

    <style>{`
      @keyframes spin     { to { transform:rotate(360deg) } }
      @keyframes pulseDot { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:0.4;transform:scale(0.85)} }
      @media(max-width:900px){.glm-dash-split{grid-template-columns:1fr !important}.glm-dash-4col{grid-template-columns:1fr 1fr !important}}
      @media(max-width:500px){.glm-dash-4col{grid-template-columns:1fr !important}}
    `}</style>

    <AnimatePresence>
      {waOpen&&<WhatsAppPanel onClose={()=>setWaOpen(false)} customers={customers} staff={staffList} receptionists={receptions}/>}
      {cashModal&&<CashCounterModal cashData={cashData} onClose={()=>setCashModal(false)}/>}
    </AnimatePresence>

    {/* HERO */}
    <motion.div variants={fade} style={{position:'relative',overflow:'hidden',borderRadius:28,marginBottom:20,
      background:'linear-gradient(145deg,'+C.heroBg+' 0%,'+C.heroBg2+' 55%,#120D04 100%)',
      border:'1px solid #2E2410',boxShadow:'0 12px 48px rgba(0,0,0,0.45)'}}>
      <div style={{position:'absolute',inset:0,pointerEvents:'none',
        backgroundImage:'repeating-linear-gradient(45deg,#B8860B 0,#B8860B 1px,transparent 0,transparent 50%)',
        backgroundSize:'20px 20px',opacity:0.05}}/>
      <div style={{position:'absolute',top:-80,right:-60,width:360,height:360,borderRadius:'50%',
        background:'radial-gradient(circle,rgba(218,165,32,0.12) 0%,transparent 70%)',pointerEvents:'none'}}/>
      <div style={{position:'absolute',bottom:-60,left:60,width:200,height:200,borderRadius:'50%',
        background:'radial-gradient(circle,rgba(184,134,11,0.07) 0%,transparent 70%)',pointerEvents:'none'}}/>
      <div style={{position:'relative',padding:'28px 30px'}}>
        <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',flexWrap:'wrap',gap:14,marginBottom:22}}>
          <div>
            <div style={{display:'flex',alignItems:'center',gap:7,marginBottom:10}}>
              <Sparkles size={10} color='#F0D878'/>
              <span style={{fontSize:10,fontWeight:800,letterSpacing:'0.22em',textTransform:'uppercase',color:'#F0D878'}}>Admin Command Center</span>
            </div>
            <h1 style={{fontFamily:'Playfair Display,serif',fontSize:32,fontWeight:700,color:'#fff',margin:0,lineHeight:1.15}}>
              {greeting}, <span style={{color:'#D4A017'}}>{user?.name?.split(' ')[0]}</span> 👋
            </h1>
            <p style={{fontSize:13,color:'#5A4020',margin:'6px 0 0'}}>{dateStr}</p>
          </div>
          <div style={{display:'flex',flexDirection:'column',alignItems:'flex-end',gap:10}}>
            <div style={{fontFamily:'Courier New,monospace',fontSize:26,fontWeight:700,color:'#D4A017',letterSpacing:'0.06em',lineHeight:1}}>{timeStr}</div>
            <div style={{display:'flex',alignItems:'center',gap:8,flexWrap:'wrap'}}>
              <div style={{display:'flex',alignItems:'center',gap:6,padding:'6px 12px',borderRadius:100,
                background:'rgba(34,197,94,0.1)',border:'1px solid rgba(34,197,94,0.2)',color:'#6EE7B7',fontSize:11,fontWeight:600}}>
                <Pulse color='#22C55E' size={6}/> System Live</div>
              {lastFetchAt&&<div style={{fontSize:11,color:'#5A4030',padding:'5px 10px',borderRadius:100,
                background:'rgba(255,255,255,0.04)',border:'1px solid rgba(255,255,255,0.07)'}}>Synced {agoText}</div>}
              <button onClick={handleRefresh} disabled={manRefresh||syncing}
                style={{display:'flex',alignItems:'center',gap:6,padding:'6px 14px',borderRadius:100,
                  border:'1px solid rgba(255,255,255,0.13)',background:'rgba(255,255,255,0.07)',color:'#fff',
                  fontSize:12,fontWeight:600,cursor:'pointer',opacity:(manRefresh||syncing)?0.5:1}}>
                <RefreshCw size={12} style={{animation:(manRefresh||syncing)?'spin 0.8s linear infinite':'none'}}/> Refresh
              </button>
            </div>
          </div>
        </div>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',flexWrap:'wrap',gap:14}}>
          <div style={{flex:1,minWidth:260}}>
            <div style={{fontSize:10,fontWeight:700,color:'#6B5030',textTransform:'uppercase',letterSpacing:'0.12em',marginBottom:10}}>Today's Appointment Pipeline</div>
            <PipelineBar stats={stats}/>
          </div>
          <div style={{display:'flex',gap:10,flexWrap:'wrap'}}>
            <button onClick={()=>navigate('/admin/appointments')}
              style={{display:'flex',alignItems:'center',gap:8,padding:'11px 18px',borderRadius:14,border:'none',cursor:'pointer',
                fontWeight:700,fontSize:13,background:'linear-gradient(135deg,#DAA520,#B8860B)',color:'#fff',boxShadow:'0 6px 20px rgba(184,134,11,0.4)'}}>
              <Plus size={15}/> New Booking</button>
            <button onClick={()=>setWaOpen(true)}
              style={{display:'flex',alignItems:'center',gap:8,padding:'11px 18px',borderRadius:14,border:'none',cursor:'pointer',
                fontWeight:700,fontSize:13,background:'linear-gradient(135deg,'+C.wa+',#1DA855)',color:'#fff',boxShadow:'0 6px 20px '+C.wa+'50'}}>
              <MessageCircle size={15}/> WhatsApp</button>
            <button onClick={exportBookings}
              style={{display:'flex',alignItems:'center',gap:8,padding:'11px 18px',borderRadius:14,cursor:'pointer',
                border:'1px solid rgba(255,255,255,0.15)',background:'rgba(255,255,255,0.07)',color:'#fff',fontWeight:600,fontSize:13}}>
              <Download size={15}/> Export</button>
          </div>
        </div>
      </div>
    </motion.div>

    {/* ALERTS */}
    <AnimatePresence>
      {showAlerts&&(pendingPayCnt>0||lowStock.length>0)&&<motion.div variants={fade} exit={{opacity:0,height:0}} style={{marginBottom:18}}>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:8}}>
          <div style={{fontSize:10,fontWeight:800,letterSpacing:'0.15em',textTransform:'uppercase',color:C.inkLight,display:'flex',alignItems:'center',gap:6}}>
            <Bell size={11}/> Active Alerts</div>
          <button onClick={()=>setShowAlerts(false)} style={{border:'none',background:'none',cursor:'pointer',color:C.inkGhost,fontSize:11}}>Dismiss</button>
        </div>
        <div style={{display:'flex',gap:10,flexWrap:'wrap'}}>
          {pendingPayCnt>0&&<div onClick={()=>navigate('/admin/payments')}
            style={{flex:1,minWidth:240,display:'flex',alignItems:'center',justifyContent:'space-between',
              padding:'12px 16px',borderRadius:14,background:C.amberPale,border:'1px solid '+C.amberBorder,cursor:'pointer'}}>
            <div style={{display:'flex',alignItems:'center',gap:10}}>
              <div style={{width:36,height:36,borderRadius:10,background:'#FDE68A',display:'flex',alignItems:'center',justifyContent:'center'}}><CreditCard size={16} color={C.amber}/></div>
              <div>
                <div style={{fontSize:13,fontWeight:700,color:C.amber}}>{pendingPayCnt} pending payment{pendingPayCnt>1?'s':''}</div>
                <div style={{fontSize:11,color:'#B45309'}}>{fmtRs(pendingPayAmt)} awaiting collection</div>
              </div>
            </div>
            <ChevronRight size={14} color={C.amber}/></div>}
          {lowStock.length>0&&<div onClick={()=>navigate('/admin/inventory')}
            style={{flex:1,minWidth:240,display:'flex',alignItems:'center',justifyContent:'space-between',
              padding:'12px 16px',borderRadius:14,background:C.redPale,border:'1px solid '+C.redBorder,cursor:'pointer'}}>
            <div style={{display:'flex',alignItems:'center',gap:10}}>
              <div style={{width:36,height:36,borderRadius:10,background:'#FECACA',display:'flex',alignItems:'center',justifyContent:'center'}}><Package size={16} color={C.red}/></div>
              <div>
                <div style={{fontSize:13,fontWeight:700,color:C.red}}>{lowStock.length} low stock item{lowStock.length>1?'s':''}</div>
                <div style={{fontSize:11,color:'#B91C1C'}}>{lowStock.slice(0,2).map(i=>i.name||'Item').join(', ')}{lowStock.length>2?` +${lowStock.length-2} more`:''}</div>
              </div>
            </div>
            <ChevronRight size={14} color={C.red}/></div>}
        </div>
      </motion.div>}
    </AnimatePresence>

    {/* KPI CARDS */}
    <motion.div variants={stagger} style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(195px,1fr))',gap:13,marginBottom:20}}>
      <KpiCard icon={Calendar}    label="Today's Bookings"  value={stats?String(stats.total):'—'}      sub={stats?stats.confirmed+' confirmed':'…'} growth={bookingGrowth} onClick={()=>navigate('/admin/appointments')} loading={!stats}/>
      <KpiCard icon={IndianRupee} label="Today's Revenue"   value={stats?fmtK(stats.todayRevenue||stats.revenue||0):'—'} sub={stats?stats.completed+' completed':'…'} color={C.green} bg={C.greenPale} border={C.greenBorder} onClick={()=>navigate('/admin/payments')} loading={!stats}/>
      <KpiCard icon={TrendingUp}  label="Monthly Revenue"   value={monthRevenue!=null?fmtK(monthRevenue):'—'} sub="vs last month" growth={revenueGrowth} color={C.blue} bg={C.bluePale} border={C.blueBorder} onClick={()=>navigate('/admin/analytics')} loading={extraLoad}/>
      <KpiCard icon={Users}       label="Total Customers"   value={totalCustomers!=null?fmt(totalCustomers):'—'} sub={overview?.customers?.new?'+'+overview.customers.new+' this month':'Registered'} growth={overview?.customers?.growth} onClick={()=>navigate('/admin/customers')} loading={extraLoad}/>
      <KpiCard icon={UserCheck}   label="Active Staff"      value={String(floorCounts.available+floorCounts.busy)} sub={floorCounts.busy+' with clients'} color={C.purple} bg={C.purplePale} border={C.purpleBorder} onClick={()=>navigate('/admin/staff')}/>
      <KpiCard icon={Percent}     label="Conversion Rate"   value={convRate!=null?convRate+'%':'—'} sub="bookings → completed" color={C.teal} bg={C.tealPale} border={C.tealBorder} onClick={()=>navigate('/admin/analytics')} loading={extraLoad}/>
      {/* Cash Counter */}
      <motion.div variants={fade} whileHover={{y:-4,boxShadow:'0 20px 48px '+C.green+'22'}} onClick={()=>setCashModal(true)}
        style={{background:C.cardBg,border:'1px solid '+C.greenBorder,borderRadius:20,
          padding:'20px 20px 16px',cursor:'pointer',boxShadow:'0 2px 16px '+C.green+'0A',position:'relative',overflow:'hidden'}}>
        <div style={{position:'absolute',top:-20,right:-20,width:80,height:80,borderRadius:'50%',background:C.green+'12',pointerEvents:'none'}}/>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:14}}>
          <div style={{width:42,height:42,borderRadius:14,display:'flex',alignItems:'center',justifyContent:'center',background:C.greenPale,border:'1px solid '+C.greenBorder}}><Wallet size={19} color={C.green}/></div>
          <span style={{display:'flex',alignItems:'center',gap:4,padding:'3px 8px',borderRadius:100,fontSize:10,fontWeight:700,background:C.greenPale,color:C.green,border:'1px solid '+C.greenBorder}}>
            <Pulse color={C.green} size={5}/> LIVE</span>
        </div>
        <div style={{fontSize:30,fontWeight:800,color:C.ink,lineHeight:1,fontFamily:'Playfair Display,serif',marginBottom:4}}>
          {extraLoad?<span style={{color:C.inkGhost}}>—</span>:fmtK(cashData?.balance||0)}</div>
        <div style={{fontSize:12,fontWeight:700,color:C.inkMid,marginBottom:5}}>Cash Counter Balance</div>
        <div style={{fontSize:11,color:C.inkLight}}>+{fmtRs(cashData?.todayCash||0)} today · {cashData?.cashCount||0} bookings</div>
        <div style={{marginTop:14,height:2,borderRadius:2,background:'linear-gradient(to right, '+C.green+', transparent)'}}/>
      </motion.div>
    </motion.div>

    {/* CHART + STAFF FLOOR */}
    <motion.div variants={fade} style={{display:'grid',gridTemplateColumns:'1fr 300px',gap:15,marginBottom:20}} className='glm-dash-split'>
      <div style={{background:C.cardBg,border:'1px solid '+C.border,borderRadius:22,overflow:'hidden'}}>
        <SectionHead title="Revenue Trend" icon={BarChart3} live action={
          <div style={{display:'flex',gap:6,alignItems:'center'}}>
            {[['last7','7D'],['last30','30D'],['thisMonth','MTD']].map(([p,l])=>
              <button key={p} onClick={()=>setChartPeriod(p)}
                style={{padding:'5px 11px',borderRadius:10,fontSize:11,fontWeight:700,cursor:'pointer',
                  border:'1px solid '+C.border,background:chartPeriod===p?C.ink:'transparent',color:chartPeriod===p?'#fff':C.inkMid}}>{l}</button>)}
            <button onClick={exportRevenue} style={{padding:'5px 10px',borderRadius:10,border:'1px solid '+C.border,
              background:'transparent',cursor:'pointer',display:'flex',alignItems:'center',gap:4,fontSize:11,fontWeight:600,color:C.inkMid}}>
              <Download size={11}/> CSV</button>
          </div>}/>
        <div style={{padding:'18px 20px 14px'}}>
          <div style={{display:'flex',gap:24,marginBottom:14}}>
            <div>
              <div style={{fontSize:10,color:C.inkLight,textTransform:'uppercase',letterSpacing:'0.08em',fontWeight:600,marginBottom:2}}>Period Total</div>
              <div style={{fontSize:22,fontWeight:800,color:C.ink,fontFamily:'Playfair Display,serif'}}>{fmtK(chartData.reduce((a,d)=>a+(d.revenue||0),0))}</div>
            </div>
            <div>
              <div style={{fontSize:10,color:C.inkLight,textTransform:'uppercase',letterSpacing:'0.08em',fontWeight:600,marginBottom:2}}>Daily Avg</div>
              <div style={{fontSize:22,fontWeight:800,color:C.ink,fontFamily:'Playfair Display,serif'}}>{fmtK(Math.round(chartData.reduce((a,d)=>a+(d.revenue||0),0)/(chartData.length||1)))}</div>
            </div>
            {revenueGrowth!=null&&<div style={{marginLeft:'auto',display:'flex',alignItems:'flex-end',paddingBottom:2}}><GrowthBadge value={revenueGrowth}/></div>}
          </div>
          {chartLoad?<div style={{height:160,display:'flex',alignItems:'center',justifyContent:'center'}}><Loader2 size={22} color={C.gold} style={{animation:'spin 0.8s linear infinite'}}/></div>
          :chartData.length===0?<div style={{height:160,display:'flex',alignItems:'center',justifyContent:'center',color:C.inkLight,fontSize:13}}>No data for this period</div>
          :<ResponsiveContainer width='100%' height={160}>
            <ComposedChart data={chartData} margin={{top:4,right:4,left:0,bottom:0}}>
              <defs><linearGradient id='rg' x1='0' y1='0' x2='0' y2='1'>
                <stop offset='0%' stopColor={C.gold} stopOpacity={0.28}/>
                <stop offset='100%' stopColor={C.gold} stopOpacity={0.02}/>
              </linearGradient></defs>
              <CartesianGrid strokeDasharray='3 3' stroke={C.border} vertical={false}/>
              <XAxis dataKey='day' tick={{fontSize:10,fill:C.inkGhost}} axisLine={false} tickLine={false}/>
              <YAxis hide/><Tooltip content={<RevTooltip/>}/>
              <Bar dataKey='bookings' fill={C.gold+'25'} radius={[3,3,0,0]} yAxisId={1}/><YAxis yAxisId={1} hide/>
              <Area dataKey='revenue' fill='url(#rg)' stroke={C.gold} strokeWidth={2.5} dot={false} activeDot={{r:5,fill:C.gold}}/>
            </ComposedChart>
          </ResponsiveContainer>}
        </div>
      </div>

      <div style={{background:C.cardBg,border:'1px solid '+C.border,borderRadius:22,overflow:'hidden'}}>
        <SectionHead title="Staff Floor" icon={Activity} live action={
          <button onClick={()=>navigate('/admin/staff')} style={{fontSize:12,fontWeight:700,color:C.gold,background:'none',border:'none',cursor:'pointer',display:'flex',alignItems:'center',gap:3}}>
            Manage <ChevronRight size={13}/></button>}/>
        <div style={{padding:'12px 13px'}}>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:7,marginBottom:12}}>
            {Object.entries(FS).filter(([k])=>k!=='absent').map(([k,cfg])=><div key={k}
              style={{display:'flex',alignItems:'center',gap:8,padding:'9px 11px',borderRadius:12,background:cfg.bg,border:'1px solid '+cfg.border}}>
              <span style={{width:8,height:8,borderRadius:'50%',background:cfg.dot,flexShrink:0,animation:k==='available'?'pulseDot 2s infinite':'none'}}/>
              <div>
                <div style={{fontSize:18,fontWeight:800,color:C.ink,lineHeight:1}}>{floorCounts[k]||0}</div>
                <div style={{fontSize:9,fontWeight:700,color:cfg.text,textTransform:'uppercase',letterSpacing:'0.06em'}}>{cfg.label}</div>
              </div>
            </div>)}
          </div>
          <div style={{display:'flex',flexDirection:'column',gap:5}}>
            {(liveStatus||[]).slice(0,7).map(s=>{
              const ls=s.liveStatus||'off-duty', cfg=FS[ls]||FS['off-duty'];
              return <div key={s._id} onClick={()=>navigate('/admin/staff')}
                style={{display:'flex',alignItems:'center',gap:9,padding:'8px 10px',borderRadius:11,
                  background:cfg.bg,border:'1px solid '+cfg.border,cursor:'pointer',transition:'opacity 0.15s'}}
                onMouseEnter={e=>e.currentTarget.style.opacity='0.8'} onMouseLeave={e=>e.currentTarget.style.opacity='1'}>
                <div style={{position:'relative',flexShrink:0}}>
                  <div style={{width:30,height:30,borderRadius:10,background:avCol(s.name),display:'flex',
                    alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:700,color:'#fff'}}>{initials(s.name)}</div>
                  <span style={{position:'absolute',bottom:-1,right:-1,width:9,height:9,borderRadius:'50%',background:cfg.dot,border:'1.5px solid #fff'}}/>
                </div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:12,fontWeight:700,color:C.ink,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>{s.name}</div>
                  <div style={{fontSize:10,color:cfg.text,fontWeight:600}}>{cfg.label}{ls==='busy'&&s.currentBooking?.service?' · '+s.currentBooking.service:''}</div>
                </div>
                {s.phone&&<button onClick={e=>{e.stopPropagation();window.open('https://wa.me/91'+s.phone.replace(/\D/g,''),'_blank');}}
                  style={{width:26,height:26,borderRadius:8,border:'1px solid '+C.wa+'30',background:C.wa+'15',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}>
                  <MessageCircle size={12} color={C.wa}/></button>}
              </div>;
            })}
            {!(liveStatus?.length)&&<div style={{padding:16,textAlign:'center',color:C.inkLight,fontSize:12}}>No staff data yet</div>}
          </div>
        </div>
      </div>
    </motion.div>

    {/* QUICK ACTIONS */}
    <motion.div variants={fade} style={{marginBottom:20}}>
      <div style={{display:'flex',alignItems:'center',gap:12,marginBottom:12}}>
        <span style={{fontSize:10,fontWeight:800,letterSpacing:'0.18em',textTransform:'uppercase',color:C.inkLight}}>Quick Actions</span>
        <div style={{flex:1,height:1,background:C.border}}/>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(155px,1fr))',gap:11}}>
        {[
          {label:'New Booking', sub:'Schedule now',    icon:Plus,      path:'/admin/appointments',s:'gold'},
          {label:'Add Customer',sub:'Register client', icon:UserPlus,  path:'/admin/customers',  s:'dark'},
          {label:'Add Service', sub:'Create listing',  icon:Scissors,  path:'/admin/services',   s:'gold'},
          {label:'Coupons',     sub:'Deals & offers',  icon:Gift,      path:'/admin/coupons',    s:'dark'},
          {label:'Analytics',   sub:'Full reports',    icon:BarChart3, path:'/admin/analytics',  s:'blue'},
          {label:'Inventory',   sub:'Stock management',icon:Package,   path:'/admin/inventory',  s:'dark'},
        ].map(a=>{
          const Icon=a.icon;
          const bg=a.s==='gold'?'linear-gradient(140deg,'+C.gold+','+C.goldLight+')':a.s==='blue'?'linear-gradient(140deg,'+C.blue+',#3B82F6)':'linear-gradient(140deg,'+C.ink+',#2D2510)';
          return <motion.button key={a.label} whileHover={{y:-3,boxShadow:'0 14px 32px '+C.gold+'2A'}} whileTap={{scale:0.97}}
            onClick={()=>navigate(a.path)}
            style={{position:'relative',overflow:'hidden',borderRadius:18,padding:17,textAlign:'left',border:'none',cursor:'pointer',
              display:'flex',flexDirection:'column',gap:9,background:bg}}>
            <div style={{position:'absolute',bottom:-8,right:-8,width:55,height:55,borderRadius:'50%',background:'rgba(255,255,255,0.08)'}}/>
            <div style={{width:35,height:35,borderRadius:11,display:'flex',alignItems:'center',justifyContent:'center',background:'rgba(255,255,255,0.15)'}}><Icon size={16} color='#fff'/></div>
            <div>
              <div style={{fontSize:13,fontWeight:700,color:'#fff'}}>{a.label}</div>
              <div style={{fontSize:10,color:'rgba(255,255,255,0.5)',marginTop:2}}>{a.sub}</div>
            </div>
          </motion.button>;
        })}
      </div>
    </motion.div>

    {/* APPOINTMENTS + TOP SERVICES */}
    <motion.div variants={fade} style={{display:'grid',gridTemplateColumns:'1fr 295px',gap:15,marginBottom:20}} className='glm-dash-split'>
      <div style={{background:C.cardBg,border:'1px solid '+C.border,borderRadius:22,overflow:'hidden'}}>
        <SectionHead title="Today's Appointments" badge={todayB.length} live icon={Calendar} action={
          <div style={{display:'flex',gap:8,alignItems:'center'}}>
            <button onClick={exportBookings} style={{display:'flex',alignItems:'center',gap:4,padding:'6px 11px',borderRadius:10,border:'1px solid '+C.border,background:'transparent',cursor:'pointer',fontSize:11,fontWeight:600,color:C.inkMid}}><Download size={11}/> CSV</button>
            <button onClick={()=>navigate('/admin/appointments')} style={{display:'flex',alignItems:'center',gap:4,padding:'6px 13px',borderRadius:10,border:'none',background:C.ink,color:'#fff',fontSize:12,fontWeight:700,cursor:'pointer'}}>All <ChevronRight size={12}/></button>
          </div>}/>
        <div style={{display:'flex',gap:8,padding:'11px 16px',borderBottom:'1px solid '+C.border,flexWrap:'wrap'}}>
          <div style={{display:'flex',alignItems:'center',gap:7,flex:1,background:C.pageBg,borderRadius:10,padding:'7px 11px',border:'1px solid '+C.border}}>
            <Search size={13} color={C.inkLight}/>
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search client or service…"
              style={{border:'none',background:'transparent',fontSize:12,color:C.ink,outline:'none',flex:1}}/>
          </div>
          <select value={statusF} onChange={e=>setStatusF(e.target.value)}
            style={{padding:'7px 11px',borderRadius:10,border:'1px solid '+C.border,background:C.pageBg,color:C.inkMid,fontSize:12,cursor:'pointer'}}>
            <option value='all'>All</option>
            {Object.entries(BS).map(([k,v])=><option key={k} value={k}>{v.label}</option>)}
          </select>
        </div>
        {filteredB.length===0?<div style={{padding:'44px 24px',textAlign:'center'}}>
          <div style={{width:54,height:54,borderRadius:16,background:C.goldPale,border:'1px solid '+C.border,display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 12px'}}><Calendar size={22} color={C.gold}/></div>
          <div style={{fontSize:14,fontWeight:700,color:C.ink,marginBottom:4}}>No appointments found</div>
          <div style={{fontSize:12,color:C.inkLight}}>{search||statusF!=='all'?'Try adjusting filters':'Bookings will appear here'}</div>
        </div>:<div style={{overflowX:'auto'}}>
          <table style={{width:'100%',borderCollapse:'collapse'}}>
            <thead><tr style={{background:C.pageBg}}>
              {['Client','Service','Stylist','Time','Amount','Status','WA'].map(h=><th key={h}
                style={{padding:'10px 13px',textAlign:'left',fontSize:10,fontWeight:700,textTransform:'uppercase',letterSpacing:'0.12em',color:C.inkLight,whiteSpace:'nowrap'}}>{h}</th>)}
            </tr></thead>
            <tbody>
              {filteredB.slice(0,15).map(b=>{
                const st=BS[b.status]||BS.confirmed, cn=b.customer?.name||'Walk-in', ph=b.customer?.phone;
                return <tr key={b._id} style={{borderTop:'1px solid '+C.border,cursor:'pointer',transition:'background 0.12s'}}
                  onMouseEnter={e=>e.currentTarget.style.background=C.pageBg} onMouseLeave={e=>e.currentTarget.style.background='transparent'}
                  onClick={()=>navigate('/admin/appointments')}>
                  <td style={{padding:'11px 13px'}}>
                    <div style={{display:'flex',alignItems:'center',gap:8}}>
                      <div style={{width:30,height:30,borderRadius:9,background:avCol(cn),display:'flex',alignItems:'center',justifyContent:'center',fontSize:10,fontWeight:700,color:'#fff',flexShrink:0}}>{initials(cn)}</div>
                      <span style={{fontSize:12,fontWeight:700,color:C.ink,whiteSpace:'nowrap'}}>{cn}</span>
                    </div>
                  </td>
                  <td style={{padding:'11px 13px',fontSize:12,color:C.inkMid,whiteSpace:'nowrap'}}>{b.service?.name||'—'}</td>
                  <td style={{padding:'11px 13px'}}>
                    <div style={{display:'flex',alignItems:'center',gap:6}}>
                      <div style={{width:22,height:22,borderRadius:'50%',background:C.goldPale,display:'flex',alignItems:'center',justifyContent:'center',fontSize:9,fontWeight:700,color:C.gold}}>{(b.staff?.name||'A').charAt(0)}</div>
                      <span style={{fontSize:11,color:C.inkMid}}>{b.staff?.name||'Any'}</span>
                    </div>
                  </td>
                  <td style={{padding:'11px 13px',fontSize:12,fontWeight:700,color:C.ink,whiteSpace:'nowrap'}}>{b.timeSlot?.start||'—'}</td>
                  <td style={{padding:'11px 13px',fontSize:12,fontWeight:700,color:C.gold,whiteSpace:'nowrap'}}>{fmtRs(b.finalAmount||b.totalAmount||0)}</td>
                  <td style={{padding:'11px 13px'}}>
                    <span style={{display:'inline-flex',alignItems:'center',gap:5,padding:'4px 9px',borderRadius:100,fontSize:11,fontWeight:600,
                      background:st.bg,border:'1px solid '+st.border,color:st.text}}>
                      <span style={{width:5,height:5,borderRadius:'50%',background:st.dot}}/>{st.label}</span>
                  </td>
                  <td style={{padding:'11px 13px'}}>
                    {ph&&<button onClick={e=>{e.stopPropagation();window.open('https://wa.me/91'+ph.replace(/\D/g,''),'_blank');}}
                      style={{width:28,height:28,borderRadius:8,border:'1px solid '+C.wa+'30',background:C.wa+'15',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}>
                      <MessageCircle size={12} color={C.wa}/></button>}
                  </td>
                </tr>;
              })}
            </tbody>
          </table>
          {filteredB.length>15&&<div style={{padding:'11px 16px',borderTop:'1px solid '+C.border,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
            <span style={{fontSize:11,color:C.inkLight}}>Showing 15 of {filteredB.length}</span>
            <button onClick={()=>navigate('/admin/appointments')} style={{fontSize:12,fontWeight:700,color:C.gold,background:'none',border:'none',cursor:'pointer',display:'flex',alignItems:'center',gap:4}}>View all <ChevronRight size={12}/></button>
          </div>}
        </div>}
      </div>

      <div style={{background:C.cardBg,border:'1px solid '+C.border,borderRadius:22,overflow:'hidden'}}>
        <SectionHead title="Top Services" icon={Award} badge="This Month" badgeBg={C.bluePale} badgeColor={C.blue} action={
          <button onClick={()=>navigate('/admin/analytics')} style={{fontSize:11,fontWeight:700,color:C.gold,background:'none',border:'none',cursor:'pointer'}}><ChevronRight size={13}/></button>}/>
        <div style={{padding:'13px 15px'}}>
          {extraLoad?<div style={{padding:32,textAlign:'center'}}><Loader2 size={18} color={C.gold} style={{animation:'spin 0.8s linear infinite'}}/></div>
          :topServices.length===0?<div style={{padding:'32px 16px',textAlign:'center',color:C.inkLight,fontSize:12}}>No data yet</div>
          :<div style={{display:'flex',flexDirection:'column',gap:8}}>
            {topServices.map((s,i)=>{
              const maxR=topServices[0]?.revenue||1, pct=Math.round((s.revenue/maxR)*100);
              return <div key={s._id||i} style={{padding:'10px 12px',borderRadius:14,
                background:i===0?C.goldPale:'#F5EFE4',border:'1px solid '+(i===0?C.border:'#E8DFC8')}}>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:7}}>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:12,fontWeight:700,color:C.ink,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>
                      {['🥇','🥈','🥉'][i]||i+1+'.'} {s.name}</div>
                    <div style={{fontSize:10,color:C.inkLight,marginTop:1}}>{s.category||'—'} · {s.bookings||s.bookingCount||0} bookings</div>
                  </div>
                  <div style={{fontSize:13,fontWeight:800,color:C.gold,flexShrink:0,marginLeft:8}}>{fmtK(s.revenue)}</div>
                </div>
                <div style={{height:4,borderRadius:2,background:C.border}}>
                  <div style={{height:'100%',width:pct+'%',borderRadius:2,
                    background:i===0?'linear-gradient(90deg,'+C.gold+','+C.goldLight+')':'#C9B07A',transition:'width 0.8s ease'}}/>
                </div>
              </div>;
            })}
          </div>}
        </div>
      </div>
    </motion.div>

    {/* STATUS PILLS */}
    <motion.div variants={fade} style={{marginBottom:20}}>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(148px,1fr))',gap:10}}>
        {[
          {label:'Confirmed',   v:todayB.filter(b=>b.status==='confirmed').length,   dot:'#F59E0B',bg:'#FFFBEB',border:'#FDE68A',color:'#92400E'},
          {label:'In Progress', v:todayB.filter(b=>b.status==='in-progress').length, dot:'#10B981',bg:'#ECFDF5',border:'#A7F3D0',color:'#065F46'},
          {label:'Completed',   v:todayB.filter(b=>b.status==='completed').length,   dot:'#3B82F6',bg:'#EFF6FF',border:'#BFDBFE',color:'#1E40AF'},
          {label:'Cancelled',   v:todayB.filter(b=>b.status==='cancelled').length,   dot:'#EF4444',bg:'#FEF2F2',border:'#FECACA',color:'#991B1B'},
          {label:'Pending Pay', v:todayB.filter(b=>b.paymentStatus!=='paid'&&!['cancelled','no-show'].includes(b.status)).length,dot:'#F97316',bg:'#FFF7ED',border:'#FDBA74',color:'#C2410C'},
          {label:'No Show',     v:todayB.filter(b=>b.status==='no-show').length,     dot:'#9CA3AF',bg:'#F9FAFB',border:'#E5E7EB',color:'#374151'},
        ].map(({label,v,dot,bg,border,color})=><div key={label}
          style={{padding:'13px 15px',borderRadius:14,background:bg,border:'1px solid '+border,display:'flex',alignItems:'center',gap:10}}>
          <span style={{width:8,height:8,borderRadius:'50%',background:dot,flexShrink:0}}/>
          <div>
            <div style={{fontSize:22,fontWeight:800,color:C.ink,lineHeight:1}}>{v}</div>
            <div style={{fontSize:10,fontWeight:700,color,textTransform:'uppercase',letterSpacing:'0.07em',marginTop:2}}>{label}</div>
          </div>
        </div>)}
      </div>
    </motion.div>

    {/* ATTENDANCE OVERVIEW */}
    <motion.div variants={fade}>
      <div style={{background:C.cardBg,border:'1px solid '+C.border,borderRadius:22,overflow:'hidden'}}>
        <SectionHead title="This Month's Attendance" icon={UserCheck} live action={
          <button onClick={()=>navigate('/admin/attendance')} style={{fontSize:12,fontWeight:700,color:C.gold,background:'none',border:'none',cursor:'pointer',display:'flex',alignItems:'center',gap:3}}>
            Full View <ChevronRight size={13}/></button>}/>
        <div style={{padding:'14px 16px'}}>
          {attendance.length===0?<div style={{padding:'24px 16px',textAlign:'center',color:C.inkLight,fontSize:12}}>No attendance data for this month</div>
          :<div style={{display:'flex',flexDirection:'column',gap:8}}>
            {attendance.map((s,i)=>{
              const total=s.present+s.late+s.absent+s.halfDay+s.leave;
              const present=s.present+s.late, pct=total>0?Math.round((present/total)*100):0;
              const color=pct>=80?C.green:pct>=60?'#B45309':C.red;
              const bg=pct>=80?C.greenPale:pct>=60?C.amberPale:C.redPale;
              const bdr=pct>=80?C.greenBorder:pct>=60?C.amberBorder:C.redBorder;
              return <div key={i} onClick={()=>navigate('/admin/attendance')}
                style={{display:'flex',alignItems:'center',gap:12,padding:'10px 14px',borderRadius:14,
                  background:bg,border:'1px solid '+bdr,cursor:'pointer',transition:'opacity 0.15s'}}
                onMouseEnter={e=>e.currentTarget.style.opacity='0.8'} onMouseLeave={e=>e.currentTarget.style.opacity='1'}>
                <div style={{width:36,height:36,borderRadius:12,flexShrink:0,background:avCol(s.staff?.name||''),
                  display:'flex',alignItems:'center',justifyContent:'center',fontSize:13,fontWeight:700,color:'#fff'}}>
                  {initials(s.staff?.name||'?')}</div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:13,fontWeight:700,color:C.ink,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>{s.staff?.name}</div>
                  <div style={{display:'flex',gap:8,marginTop:3,flexWrap:'wrap'}}>
                    {[{l:present+'P',c:C.green},
                      s.absent>0&&{l:s.absent+'A',c:C.red},s.halfDay>0&&{l:s.halfDay+'H',c:C.blue},
                      s.leave>0&&{l:s.leave+'L',c:'#6D28D9'},s.late>0&&{l:s.late+'Late',c:'#92400E'},
                    ].filter(Boolean).map(({l,c})=><span key={l} style={{fontSize:10,fontWeight:700,color:c}}>{l}</span>)}
                  </div>
                </div>
                <div style={{minWidth:80}}>
                  <div style={{display:'flex',justifyContent:'space-between',marginBottom:4}}>
                    <span style={{fontSize:10,color:C.inkLight}}>{present}/{total} days</span>
                    <span style={{fontSize:12,fontWeight:800,color,fontFamily:'Playfair Display,serif'}}>{pct}%</span>
                  </div>
                  <div style={{height:5,borderRadius:3,background:'rgba(0,0,0,0.08)',overflow:'hidden'}}>
                    <div style={{height:'100%',width:pct+'%',borderRadius:3,
                      background:'linear-gradient(90deg,'+color+','+(pct>=80?'#34D399':pct>=60?'#FCD34D':'#FCA5A5')+')',transition:'width 0.8s ease'}}/>
                  </div>
                  {(s.totalDeductions||0)>0&&<div style={{fontSize:9,fontWeight:700,color:C.red,marginTop:3,textAlign:'right'}}>−{fmtRs(s.totalDeductions)}</div>}
                </div>
              </div>;
            })}
          </div>}
        </div>
      </div>
    </motion.div>
  </motion.div>;
}