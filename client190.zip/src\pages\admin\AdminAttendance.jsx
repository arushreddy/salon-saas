/**
 * AdminAttendance.jsx — Fixed
 * ✅ Floor status now persists (server saves liveStatus field; client sends staffProfileId)
 * ✅ Monthly view fully clickable — DayPanel opens on any row/cell click
 * ✅ Deduction accessible from Summary cards + DayPanel + day-list rows
 */

import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Calendar, Users, Download, Search, ChevronLeft, ChevronRight,
  CheckCircle2, AlertCircle, XCircle, Loader2, RefreshCw, LogIn, LogOut,
  UserCheck, Timer, IndianRupee, Minus, Sun, Coffee, Check, X,
  BarChart3, List, Grid3X3, Activity, Edit2, Zap, ArrowUpDown,
} from 'lucide-react';
import api from '@/services/api';
import { useDataStore, broadcastChange } from '@/context/DataStore';

/* ── Tokens ─────────────────────────────────────────────────────────────────── */
const C = {
  bg:'#F4EDE0', card:'#FFFDF7', cardAlt:'#FDF8EE',
  gold:'#B8860B', goldLight:'#D4A017', goldPale:'#FFF8E7', goldDeep:'#8B6914',
  ink:'#1A1208', inkMid:'#5C4A2A', inkLight:'#9C8660', inkGhost:'#C8B090',
  border:'#DFD0A8', borderLight:'#EDE5C8',
  green:'#065F46', greenPale:'#ECFDF5', greenBorder:'#A7F3D0',
  red:'#991B1B', redPale:'#FEF2F2', redBorder:'#FECACA',
  amber:'#92400E', amberPale:'#FFFBEB', amberBorder:'#FDE68A',
  blue:'#1E40AF', bluePale:'#EFF6FF', blueBorder:'#BFDBFE',
  purple:'#6D28D9', purplePale:'#F5F3FF', purpleBorder:'#DDD6FE',
  gray:'#374151', grayPale:'#F9FAFB', grayBorder:'#E5E7EB',
};

const ST = {
  present:    { label:'Present',  dot:'#10B981', bg:C.greenPale,  border:C.greenBorder,  text:C.green,  icon:CheckCircle2 },
  late:       { label:'Late',     dot:'#F59E0B', bg:C.amberPale,  border:C.amberBorder,  text:C.amber,  icon:AlertCircle  },
  absent:     { label:'Absent',   dot:'#EF4444', bg:C.redPale,    border:C.redBorder,    text:C.red,    icon:XCircle      },
  'half-day': { label:'Half Day', dot:'#3B82F6', bg:C.bluePale,   border:C.blueBorder,   text:C.blue,   icon:Minus        },
  leave:      { label:'Leave',    dot:'#7C3AED', bg:C.purplePale, border:C.purpleBorder, text:C.purple, icon:Sun          },
  holiday:    { label:'Holiday',  dot:'#9CA3AF', bg:C.grayPale,   border:C.grayBorder,   text:C.gray,   icon:Coffee       },
};

const LIVE = {
  available:  { label:'Available', dot:'#10B981', bg:C.greenPale,  border:C.greenBorder,  text:C.green  },
  busy:       { label:'Busy',      dot:'#F59E0B', bg:C.amberPale,  border:C.amberBorder,  text:C.amber  },
  'off-duty': { label:'Off Duty',  dot:'#9CA3AF', bg:C.grayPale,   border:C.grayBorder,   text:C.gray   },
  absent:     { label:'Absent',    dot:'#EF4444', bg:C.redPale,    border:C.redBorder,    text:C.red    },
};

const LIVE_OPTIONS = ['available','busy','off-duty'];
const DAYS = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
const IST  = 5.5 * 3600000;

const todayKey  = () => new Date(Date.now()+IST).toISOString().split('T')[0];
const fmtHM     = m => { if(!m||m<=0) return '—'; const h=Math.floor(m/60),r=m%60; return h>0?`${h}h ${r}m`:`${r}m`; };
const fmtTime   = d => d ? new Date(d).toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit',hour12:true}) : '—';
const fmtRs     = n => '₹'+Number(n||0).toLocaleString('en-IN');
const monthLbl  = (y,m) => new Date(`${y}-${String(m).padStart(2,'0')}-01`).toLocaleDateString('en-IN',{month:'long',year:'numeric'});

/* ── Pill ───────────────────────────────────────────────────────────────────── */
function Pill({ status, size='sm' }) {
  const s = ST[status]||ST.absent;
  return (
    <span style={{display:'inline-flex',alignItems:'center',gap:4,padding:size==='lg'?'4px 12px':'2px 8px',borderRadius:100,fontSize:size==='lg'?12:10,fontWeight:700,background:s.bg,border:`1px solid ${s.border}`,color:s.text}}>
      <span style={{width:5,height:5,borderRadius:'50%',background:s.dot}}/>{s.label}
    </span>
  );
}

/* ── Floor Status Modal ─────────────────────────────────────────────────────── */
function FloorModal({ member, onClose, onSaved }) {
  const [status, setStatus] = useState(member.liveStatus||'off-duty');
  const [saving, setSaving] = useState(false);
  const [err,    setErr]    = useState('');

  const save = async () => {
    setSaving(true); setErr('');
    try {
      // member.staffProfileId = Staff._id (what the PATCH route requires)
      // member._id            = User._id
      const id = member.staffProfileId || member.staffId || member._id;
      console.log('[FloorStatus] name:', member.name, 'staffProfileId:', member.staffProfileId, 'staffId:', member.staffId, 'using id:', id);
      await api.patch(`/staff/${id}/floor-status`, { status });
      broadcastChange();
      onSaved(member._id, status);
      onClose();
    } catch(e) { setErr(e.response?.data?.message||'Failed to update status'); }
    finally { setSaving(false); }
  };

  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={onClose}
      style={{position:'fixed',inset:0,zIndex:700,background:'rgba(26,18,8,0.6)',backdropFilter:'blur(6px)',display:'flex',alignItems:'center',justifyContent:'center',padding:20}}>
      <motion.div initial={{scale:0.92,y:16}} animate={{scale:1,y:0}} exit={{scale:0.92}} onClick={e=>e.stopPropagation()}
        style={{width:'100%',maxWidth:380,background:C.card,borderRadius:24,boxShadow:'0 40px 100px rgba(26,18,8,0.4)',border:`1px solid ${C.border}`,overflow:'hidden'}}>
        <div style={{padding:'20px 24px',borderBottom:`1px solid ${C.border}`,display:'flex',justifyContent:'space-between',alignItems:'center',background:C.cardAlt}}>
          <div>
            <p style={{fontSize:16,fontWeight:800,color:C.ink,fontFamily:"'Playfair Display',serif"}}>Update Floor Status</p>
            <p style={{fontSize:12,color:C.inkMid,marginTop:2}}>{member.name}</p>
          </div>
          <button onClick={onClose} style={{width:30,height:30,borderRadius:9,border:`1px solid ${C.border}`,background:C.card,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}>
            <X size={13} style={{color:C.inkMid}}/>
          </button>
        </div>
        <div style={{padding:'20px 24px'}}>
          {LIVE_OPTIONS.map(s => {
            const cfg=LIVE[s]; const sel=status===s;
            return (
              <button key={s} onClick={()=>setStatus(s)}
                style={{width:'100%',display:'flex',alignItems:'center',gap:10,padding:'12px 16px',borderRadius:12,border:`2px solid ${sel?cfg.dot:C.border}`,background:sel?cfg.bg:C.card,cursor:'pointer',marginBottom:8,textAlign:'left',transition:'all 0.15s'}}>
                <span style={{width:10,height:10,borderRadius:'50%',background:sel?cfg.dot:C.inkGhost}}/>
                <span style={{fontSize:13,fontWeight:700,color:sel?cfg.text:C.inkMid}}>{cfg.label}</span>
                {sel && <Check size={14} style={{color:cfg.text,marginLeft:'auto'}}/>}
              </button>
            );
          })}
          {err && <p style={{fontSize:12,color:C.red,marginBottom:8,padding:'8px 12px',background:C.redPale,borderRadius:8}}>{err}</p>}
          <div style={{display:'flex',gap:8,marginTop:4}}>
            <button onClick={onClose} style={{flex:1,padding:'11px',borderRadius:12,border:`1px solid ${C.border}`,background:'transparent',color:C.inkMid,fontSize:13,fontWeight:700,cursor:'pointer'}}>Cancel</button>
            <button onClick={save} disabled={saving}
              style={{flex:2,padding:'11px',borderRadius:12,border:'none',background:`linear-gradient(135deg,${C.gold},${C.goldLight})`,color:'#fff',fontSize:13,fontWeight:700,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:7,opacity:saving?0.7:1}}>
              {saving?<Loader2 size={14} className="animate-spin"/>:<Zap size={14}/>} Update Status
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ── Mark Attendance Modal ───────────────────────────────────────────────────── */
function MarkModal({ staffUser, date, existing, onClose, onSaved }) {
  const [status, setStatus] = useState(existing?.status||'present');
  const [notes,  setNotes]  = useState(existing?.notes||'');
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    try {
      await api.post('/attendance/mark',{ staffId:staffUser._id, date, status, notes });
      broadcastChange();
      onSaved(); onClose();
    } catch(e) { alert(e.response?.data?.message||'Failed'); }
    finally { setSaving(false); }
  };

  const dateLabel = new Date(date+'T12:00:00').toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long'});
  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={onClose}
      style={{position:'fixed',inset:0,zIndex:700,background:'rgba(26,18,8,0.6)',backdropFilter:'blur(6px)',display:'flex',alignItems:'center',justifyContent:'center',padding:20}}>
      <motion.div initial={{scale:0.92,y:16}} animate={{scale:1,y:0}} exit={{scale:0.92}} onClick={e=>e.stopPropagation()}
        style={{width:'100%',maxWidth:420,background:C.card,borderRadius:24,boxShadow:'0 40px 100px rgba(26,18,8,0.4)',border:`1px solid ${C.border}`,overflow:'hidden'}}>
        <div style={{padding:'20px 24px',borderBottom:`1px solid ${C.border}`,background:C.cardAlt,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <div>
            <p style={{fontSize:16,fontWeight:800,color:C.ink,fontFamily:"'Playfair Display',serif"}}>{existing?'Update':'Mark'} Attendance</p>
            <p style={{fontSize:12,color:C.inkMid,marginTop:2}}>{staffUser.name} · {dateLabel}</p>
          </div>
          <button onClick={onClose} style={{width:30,height:30,borderRadius:9,border:`1px solid ${C.border}`,background:C.card,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}><X size={13}/></button>
        </div>
        <div style={{padding:'20px 24px'}}>
          <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:8,marginBottom:18}}>
            {Object.entries(ST).map(([k,cfg])=>{
              const Icon=cfg.icon; const sel=status===k;
              return (
                <button key={k} onClick={()=>setStatus(k)}
                  style={{padding:'11px 8px',borderRadius:12,border:`2px solid ${sel?cfg.dot:C.border}`,background:sel?cfg.bg:C.card,cursor:'pointer',textAlign:'center',transition:'all 0.15s'}}>
                  <Icon size={15} style={{color:sel?cfg.text:C.inkLight,margin:'0 auto 4px',display:'block'}}/>
                  <p style={{fontSize:10,fontWeight:700,color:sel?cfg.text:C.inkMid}}>{cfg.label}</p>
                </button>
              );
            })}
          </div>
          <input value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Notes (optional)"
            style={{width:'100%',padding:'10px 14px',borderRadius:10,border:`1px solid ${C.border}`,background:C.card,fontSize:12,color:C.ink,outline:'none',boxSizing:'border-box',marginBottom:16}}/>
          <div style={{display:'flex',gap:8}}>
            <button onClick={onClose} style={{flex:1,padding:'11px',borderRadius:12,border:`1px solid ${C.border}`,background:'transparent',color:C.inkMid,fontSize:13,fontWeight:700,cursor:'pointer'}}>Cancel</button>
            <button onClick={save} disabled={saving}
              style={{flex:2,padding:'11px',borderRadius:12,border:'none',background:`linear-gradient(135deg,${C.gold},${C.goldLight})`,color:'#fff',fontSize:13,fontWeight:700,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:7,opacity:saving?0.7:1}}>
              {saving?<Loader2 size={14} className="animate-spin"/>:<Check size={14}/>} Save
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ── Deduction Modal ────────────────────────────────────────────────────────── */
function DeductModal({ record, staffInfo, onClose, onSaved }) {
  const base    = staffInfo?.salary?.base||0;
  const perDay  = base>0 ? base/26 : 0;
  const perHalf = perDay/2;
  const [mode,   setMode]   = useState('auto');
  const [type,   setType]   = useState('full');
  const [manual, setManual] = useState('');
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);
  const [saved,  setSaved]  = useState(false);

  const amt       = mode==='auto' ? Math.round(type==='full'?perDay:perHalf) : Number(manual)||0;
  const staffName = staffInfo?.name||record?.staff?.name||'Staff';
  const dateStr   = record?.date ? new Date(record.date).toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long'}) : '';

  const save = async () => {
    if(amt<=0) return;
    setSaving(true);
    try {
      await api.post('/attendance/deduction',{
        staffId:      record.staff?._id||record.staff,
        date:         new Date(record.date).toISOString().split('T')[0],
        attendanceId: record._id,
        amount:       amt,
        mode,
        autoType:     mode==='auto'?type:null,
        reason:       reason||(ST[record.status]?.label||record.status)+' deduction',
      });
      setSaved(true);
      setTimeout(()=>{ onSaved(); onClose(); },900);
    } catch(e) { alert(e.response?.data?.message||'Failed'); }
    finally { setSaving(false); }
  };

  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={onClose}
      style={{position:'fixed',inset:0,zIndex:700,background:'rgba(26,18,8,0.72)',backdropFilter:'blur(8px)',display:'flex',alignItems:'center',justifyContent:'center',padding:20}}>
      <motion.div initial={{scale:0.92,y:16}} animate={{scale:1,y:0}} exit={{scale:0.92}} onClick={e=>e.stopPropagation()}
        style={{width:'100%',maxWidth:460,background:C.card,borderRadius:24,boxShadow:'0 40px 100px rgba(26,18,8,0.45)',border:`1px solid ${C.border}`,overflow:'hidden',display:'flex',flexDirection:'column',maxHeight:'calc(100vh - 40px)'}}>
        <div style={{padding:'20px 24px',borderBottom:`1px solid ${C.border}`,background:`linear-gradient(135deg,${C.redPale},#FFF5F5)`,display:'flex',alignItems:'flex-start',justifyContent:'space-between'}}>
          <div>
            <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:6}}>
              <div style={{width:36,height:36,borderRadius:12,background:`linear-gradient(135deg,${C.red},#DC2626)`,display:'flex',alignItems:'center',justifyContent:'center'}}>
                <IndianRupee size={16} color="#fff"/>
              </div>
              <div>
                <p style={{fontSize:16,fontWeight:800,color:C.ink,fontFamily:"'Playfair Display',serif"}}>Salary Deduction</p>
                <p style={{fontSize:11,color:C.inkMid}}>{staffName}{dateStr?` · ${dateStr}`:''}</p>
              </div>
            </div>
            {record?.status && <div style={{marginLeft:46}}><Pill status={record.status} size="lg"/></div>}
          </div>
          <button onClick={onClose} style={{width:30,height:30,borderRadius:9,border:`1px solid ${C.border}`,background:C.card,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}><X size={13}/></button>
        </div>
        <div style={{padding:'22px 24px',overflowY:'auto',flex:1}}>
          {saved ? (
            <div style={{textAlign:'center',padding:'30px 0'}}>
              <div style={{width:56,height:56,borderRadius:'50%',background:C.greenPale,border:`2px solid ${C.greenBorder}`,display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 12px'}}>
                <Check size={24} style={{color:C.green}}/>
              </div>
              <p style={{fontSize:16,fontWeight:800,color:C.green}}>Deduction Applied!</p>
              <p style={{fontSize:12,color:C.inkLight,marginTop:4}}>{fmtRs(amt)} deducted from {staffName}'s salary</p>
            </div>
          ) : (
            <>
              {base>0 ? (
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:8,marginBottom:20}}>
                  {[{l:'Base Salary',v:fmtRs(base),c:C.gold},{l:'Per Day (÷26)',v:fmtRs(Math.round(perDay)),c:C.amber},{l:'Half Day',v:fmtRs(Math.round(perHalf)),c:C.blue}].map(({l,v,c})=>(
                    <div key={l} style={{padding:'10px 12px',borderRadius:12,background:C.cardAlt,border:`1px solid ${C.border}`,textAlign:'center'}}>
                      <p style={{fontSize:15,fontWeight:800,color:c,fontFamily:"'Playfair Display',serif"}}>{v}</p>
                      <p style={{fontSize:9,fontWeight:600,color:C.inkLight,textTransform:'uppercase',letterSpacing:'0.08em',marginTop:2}}>{l}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div style={{padding:'10px 14px',borderRadius:10,background:C.amberPale,border:`1px solid ${C.amberBorder}`,marginBottom:16}}>
                  <p style={{fontSize:12,color:C.amber,fontWeight:600}}>No base salary set. Use manual mode or configure salary in Staff settings.</p>
                </div>
              )}
              <p style={{fontSize:10,fontWeight:700,textTransform:'uppercase',letterSpacing:'0.1em',color:C.inkLight,marginBottom:8}}>Deduction Mode</p>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:16}}>
                {[['auto','⚡ Auto (from salary)'],['manual','✏️ Manual amount']].map(([v,l])=>(
                  <button key={v} onClick={()=>setMode(v)} style={{padding:'11px 14px',borderRadius:12,border:`1.5px solid ${mode===v?C.gold:C.border}`,background:mode===v?C.goldPale:C.card,color:mode===v?C.goldDeep:C.inkMid,fontSize:12,fontWeight:700,cursor:'pointer'}}>{l}</button>
                ))}
              </div>
              {mode==='auto' ? (
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:16}}>
                  {[['full','1 Full Day',Math.round(perDay)],['half','½ Half Day',Math.round(perHalf)]].map(([v,l,a])=>(
                    <button key={v} onClick={()=>setType(v)} style={{padding:'14px',borderRadius:12,border:`1.5px solid ${type===v?C.red:C.border}`,background:type===v?C.redPale:C.card,cursor:'pointer',textAlign:'left'}}>
                      <p style={{fontSize:12,fontWeight:700,color:type===v?C.red:C.inkMid}}>{l}</p>
                      <p style={{fontSize:18,fontWeight:800,color:type===v?C.red:C.gold,fontFamily:"'Playfair Display',serif",marginTop:4}}>{fmtRs(a)}</p>
                    </button>
                  ))}
                </div>
              ) : (
                <div style={{marginBottom:16}}>
                  <div style={{display:'flex',alignItems:'center',borderRadius:12,border:`1.5px solid ${C.border}`,background:C.card,overflow:'hidden'}}>
                    <span style={{padding:'10px 14px',background:C.goldPale,borderRight:`1px solid ${C.border}`,fontSize:14,fontWeight:800,color:C.gold}}>₹</span>
                    <input type="number" min="0" value={manual} onChange={e=>setManual(e.target.value)} placeholder="Enter amount"
                      style={{flex:1,padding:'10px 14px',border:'none',outline:'none',fontSize:15,fontWeight:700,color:C.ink,background:'transparent'}}/>
                  </div>
                </div>
              )}
              <input value={reason} onChange={e=>setReason(e.target.value)} placeholder="Reason (optional)"
                style={{width:'100%',padding:'10px 14px',borderRadius:12,border:`1px solid ${C.border}`,background:C.card,fontSize:12,color:C.ink,outline:'none',boxSizing:'border-box',marginBottom:16}}/>
              <div style={{padding:'14px 18px',borderRadius:14,background:amt>0?C.redPale:C.grayPale,border:`1px solid ${amt>0?C.redBorder:C.grayBorder}`,marginBottom:18,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                <p style={{fontSize:11,color:amt>0?C.red:C.gray,fontWeight:600}}>Total deduction — {staffName}</p>
                <p style={{fontSize:26,fontWeight:800,color:amt>0?C.red:C.gray,fontFamily:"'Playfair Display',serif"}}>{amt>0?fmtRs(amt):'—'}</p>
              </div>
              <button onClick={save} disabled={saving||amt<=0}
                style={{width:'100%',padding:'14px',borderRadius:14,border:'none',cursor:saving||amt<=0?'not-allowed':'pointer',background:amt>0?`linear-gradient(135deg,${C.red},#DC2626)`:C.grayBorder,color:'#fff',fontSize:13,fontWeight:700,opacity:saving?0.7:1,display:'flex',alignItems:'center',justifyContent:'center',gap:8}}>
                {saving?<Loader2 size={14} className="animate-spin"/>:<IndianRupee size={14}/>}
                {saving?'Applying…':`Apply ${amt>0?fmtRs(amt):''} Deduction`}
              </button>
            </>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ── Today Staff Card ───────────────────────────────────────────────────────── */
function TodayCard({ s, liveInfo, todayRecord, onMark, onStatus, onDeduct }) {
  const [hov, setHov] = useState(false);
  const cfg     = todayRecord ? (ST[todayRecord.status]||ST.absent) : null;
  const liveCfg = (liveInfo ? LIVE[liveInfo.liveStatus] : null) || LIVE['off-duty'];
  const canDeduct = todayRecord && ['absent','half-day','late'].includes(todayRecord.status);

  // Build the target for FloorModal — must carry staffProfileId
  const floorTarget = liveInfo
    ? liveInfo
    : { _id:s._id, staffProfileId:s.staffProfileId||s.staffId, name:s.name, liveStatus:'off-duty' };

  return (
    <motion.div layout onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{background:C.card,borderRadius:16,padding:16,boxShadow:hov?'0 8px 28px rgba(0,0,0,0.09)':'0 1px 4px rgba(0,0,0,0.06)',transition:'all 0.2s',border:`1px solid ${hov?C.gold+'44':C.borderLight}`}}>
      {/* Header */}
      <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:12}}>
        <div style={{width:42,height:42,borderRadius:13,background:`linear-gradient(135deg,${C.gold},${C.goldLight})`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:16,fontWeight:800,color:'#fff',flexShrink:0}}>
          {(s.name||'?')[0].toUpperCase()}
        </div>
        <div style={{flex:1}}>
          <p style={{fontSize:14,fontWeight:700,color:C.ink}}>{s.name}</p>
          <p style={{fontSize:11,color:C.inkLight,marginTop:1}}>{s.designation||s.role||'Staff'}</p>
        </div>
        {/* Live status chip — clickable to update */}
        <button onClick={()=>onStatus(floorTarget)}
          style={{display:'flex',alignItems:'center',gap:5,padding:'4px 10px',borderRadius:999,background:liveCfg.bg,border:`1px solid ${liveCfg.border}`,cursor:'pointer',transition:'all 0.15s'}}>
          <span style={{width:6,height:6,borderRadius:'50%',background:liveCfg.dot}}/>
          <span style={{fontSize:10,fontWeight:700,color:liveCfg.text}}>{liveCfg.label}</span>
          <ArrowUpDown size={9} style={{color:liveCfg.text,opacity:0.6}}/>
        </button>
      </div>

      {/* Attendance row */}
      {cfg ? (
        <div style={{padding:'9px 12px',borderRadius:10,background:cfg.bg,border:`1px solid ${cfg.border}`,display:'flex',alignItems:'center',justifyContent:'space-between',flexWrap:'wrap',gap:6}}>
          <Pill status={todayRecord.status}/>
          <div style={{display:'flex',gap:8,fontSize:11,color:cfg.text,fontFamily:'monospace',fontWeight:600}}>
            {(todayRecord.sessions||[]).map((ss,i)=>(
              <span key={i}>{fmtTime(ss.clockIn)}{ss.clockOut?` → ${fmtTime(ss.clockOut)}`:' (active)'}</span>
            ))}
          </div>
          <div style={{display:'flex',gap:5}}>
            {canDeduct && (
              <button onClick={()=>onDeduct(todayRecord)}
                style={{display:'flex',alignItems:'center',gap:4,padding:'4px 9px',borderRadius:999,border:`1px solid ${C.redBorder}`,background:C.redPale,color:C.red,fontSize:10,fontWeight:700,cursor:'pointer'}}>
                <IndianRupee size={9}/> Deduct
              </button>
            )}
            <button onClick={()=>onMark(s,todayRecord)}
              style={{display:'flex',alignItems:'center',gap:4,padding:'4px 11px',borderRadius:999,border:`1px solid ${cfg.border}`,background:'#fff',color:cfg.text,fontSize:10,fontWeight:700,cursor:'pointer'}}>
              <Edit2 size={10}/> Edit
            </button>
          </div>
        </div>
      ) : (
        <div style={{padding:'9px 12px',borderRadius:10,background:C.grayPale,border:`1px solid ${C.grayBorder}`,display:'flex',alignItems:'center',justifyContent:'space-between'}}>
          <div style={{display:'flex',alignItems:'center',gap:6}}>
            <span style={{width:6,height:6,borderRadius:'50%',background:C.inkGhost}}/>
            <span style={{fontSize:12,color:C.inkLight,fontWeight:500}}>Not marked today</span>
          </div>
          <button onClick={()=>onMark(s,null)}
            style={{display:'flex',alignItems:'center',gap:5,padding:'5px 12px',borderRadius:999,border:'none',background:`linear-gradient(135deg,${C.gold},${C.goldLight})`,color:'#fff',fontSize:11,fontWeight:700,cursor:'pointer'}}>
            <Check size={10}/> Mark
          </button>
        </div>
      )}
    </motion.div>
  );
}

/* ── Month Calendar ─────────────────────────────────────────────────────────── */
function MonthCal({ records, year, month, selectedDate, onDayClick }) {
  const daysInMonth = new Date(year,month,0).getDate();
  let startDow = new Date(year,month-1,1).getDay();
  startDow = startDow===0?6:startDow-1;
  const today  = todayKey();
  const recMap = {};
  records.forEach(r=>{ recMap[new Date(r.date).toISOString().split('T')[0]]=r; });
  const cells=[];
  for(let i=0;i<startDow;i++) cells.push(null);
  for(let d=1;d<=daysInMonth;d++){
    const key=`${year}-${String(month).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    cells.push({d,key,rec:recMap[key]||null});
  }
  return (
    <div style={{background:C.card,borderRadius:20,border:`1px solid ${C.border}`,overflow:'hidden'}}>
      <div style={{display:'grid',gridTemplateColumns:'repeat(7,1fr)',background:`linear-gradient(135deg,${C.goldPale},#FFF5D6)`,borderBottom:`1px solid ${C.border}`}}>
        {DAYS.map(d=><div key={d} style={{padding:'10px 4px',textAlign:'center',fontSize:10,fontWeight:800,color:C.gold,textTransform:'uppercase',letterSpacing:'0.1em'}}>{d}</div>)}
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(7,1fr)',gap:3,padding:'10px 10px 6px',background:'#FAF5EC'}}>
        {cells.map((cell,i)=>{
          if(!cell) return <div key={i} style={{aspectRatio:'1'}}/>;
          const{d,key,rec}=cell;
          const isToday=key===today, isSel=key===selectedDate;
          const s=rec?ST[rec.status]:null;
          return (
            <motion.button key={key} onClick={()=>onDayClick(key,rec)} whileHover={{scale:1.08}} whileTap={{scale:0.95}}
              style={{aspectRatio:'1',borderRadius:12,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',position:'relative',
                background:isSel?`linear-gradient(135deg,${C.gold},${C.goldLight})`:s?s.bg:isToday?C.goldPale:C.card,
                border:`2px solid ${isSel?C.goldDeep:isToday?C.gold:s?s.border:C.borderLight}`,
                cursor:'pointer',minHeight:40,transition:'all 0.15s',boxShadow:isSel?`0 4px 14px ${C.gold}40`:'none'}}>
              <span style={{fontSize:13,fontWeight:isSel||isToday?800:600,color:isSel?'#fff':s?s.text:isToday?C.gold:C.inkLight}}>{d}</span>
              {s&&!isSel&&<span style={{width:4,height:4,borderRadius:'50%',background:s.dot,marginTop:2}}/>}
              {rec?.deduction>0&&!isSel&&<span style={{position:'absolute',top:2,right:3,width:6,height:6,borderRadius:'50%',background:C.red,border:'1px solid white'}}/>}
            </motion.button>
          );
        })}
      </div>
      <div style={{display:'flex',flexWrap:'wrap',gap:10,padding:'10px 14px',borderTop:`1px solid ${C.border}`,background:C.cardAlt}}>
        {Object.entries(ST).map(([k,s])=>(
          <div key={k} style={{display:'flex',alignItems:'center',gap:4}}>
            <span style={{width:6,height:6,borderRadius:3,background:s.dot}}/><span style={{fontSize:10,color:C.inkLight,fontWeight:500}}>{s.label}</span>
          </div>
        ))}
        <span style={{fontSize:10,color:C.red,fontWeight:600,marginLeft:'auto'}}>● red dot = deduction applied</span>
      </div>
    </div>
  );
}

/* ── Day Panel (side panel shown after clicking a date) ─────────────────────── */
function DayPanel({ dateKey, record, staffName, onClose, onDeduct, onRefresh }) {
  const [newStatus,  setNewStatus]  = useState(record?.status||'absent');
  const [saving,     setSaving]     = useState(false);
  const [localRec,   setLocalRec]   = useState(record);

  useEffect(()=>{ setLocalRec(record); setNewStatus(record?.status||'absent'); },[record]);

  const s        = ST[localRec?.status||'absent']||ST.absent;
  const sessions = localRec?.sessions||[];
  const canDeduct= ['absent','half-day','late'].includes(localRec?.status);

  const save = async (st) => {
    setSaving(true);
    try {
      await api.post('/attendance/mark',{
        staffId: localRec?.staff?._id||localRec?.staff,
        date:    dateKey,
        status:  st,
      });
      broadcastChange();
      setLocalRec(r=>({...r,status:st}));
      setNewStatus(st);
      onRefresh();
    } catch(e) { alert(e.response?.data?.message||'Failed'); }
    finally { setSaving(false); }
  };

  const dateLabel = new Date(dateKey+'T12:00:00').toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'});

  return (
    <motion.div initial={{opacity:0,x:20}} animate={{opacity:1,x:0}} exit={{opacity:0,x:20}}
      style={{background:C.card,borderRadius:20,border:`1.5px solid ${s.border}`,overflow:'hidden',position:'sticky',top:16}}>
      <div style={{padding:'16px 20px',background:s.bg,borderBottom:`1px solid ${s.border}`,display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
        <div>
          <p style={{fontSize:13,fontWeight:800,color:s.text,fontFamily:"'Playfair Display',serif",marginBottom:6}}>{dateLabel}</p>
          <Pill status={localRec?.status||'absent'} size="lg"/>
          {staffName && <p style={{fontSize:11,color:s.text,opacity:0.7,marginTop:4}}>{staffName}</p>}
        </div>
        <button onClick={onClose} style={{width:28,height:28,borderRadius:8,border:`1px solid ${s.border}`,background:'white',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}>
          <X size={12} style={{color:s.text}}/>
        </button>
      </div>
      <div style={{padding:'16px 20px'}}>
        {sessions.length>0 && (
          <div style={{marginBottom:16}}>
            <p style={{fontSize:10,fontWeight:700,textTransform:'uppercase',letterSpacing:'0.1em',color:C.inkLight,marginBottom:8}}>Sessions ({sessions.length})</p>
            {sessions.map((ss,i)=>(
              <div key={i} style={{display:'flex',alignItems:'center',gap:8,padding:'8px 12px',borderRadius:10,background:C.greenPale,border:`1px solid ${C.greenBorder}`,marginBottom:4}}>
                <span style={{fontSize:10,fontWeight:700,color:C.inkLight,background:'white',padding:'2px 6px',borderRadius:6}}>#{i+1}</span>
                <LogIn size={11} style={{color:C.green}}/><span style={{fontSize:12,fontWeight:600,color:C.ink}}>{fmtTime(ss.clockIn)}</span>
                <span style={{color:C.inkLight,fontSize:10}}>→</span>
                <LogOut size={11} style={{color:C.red}}/><span style={{fontSize:12,fontWeight:600,color:C.ink}}>{ss.clockOut?fmtTime(ss.clockOut):<span style={{color:C.green,fontSize:11}}>Active</span>}</span>
                {ss.durationMinutes>0 && <span style={{marginLeft:'auto',fontSize:11,fontWeight:700,color:C.gold}}>{fmtHM(ss.durationMinutes)}</span>}
              </div>
            ))}
            <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:6,marginTop:8}}>
              {[{l:'Total',v:fmtHM(localRec?.totalMinutes),c:C.gold},{l:'Overtime',v:fmtHM(localRec?.overtimeMinutes),c:C.purple},{l:'Late By',v:localRec?.lateByMinutes>0?fmtHM(localRec?.lateByMinutes):'—',c:C.amber}].map(({l,v,c})=>(
                <div key={l} style={{padding:'8px',borderRadius:8,background:C.cardAlt,border:`1px solid ${C.border}`,textAlign:'center'}}>
                  <p style={{fontSize:14,fontWeight:800,color:c,fontFamily:"'Playfair Display',serif"}}>{v}</p>
                  <p style={{fontSize:9,color:C.inkLight}}>{l}</p>
                </div>
              ))}
            </div>
            {localRec?.deduction>0 && (
              <div style={{marginTop:8,padding:'8px 12px',borderRadius:8,background:C.redPale,border:`1px solid ${C.redBorder}`,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                <span style={{fontSize:11,color:C.red,fontWeight:600}}>Deduction applied</span>
                <span style={{fontSize:14,fontWeight:800,color:C.red}}>{fmtRs(localRec.deduction)}</span>
              </div>
            )}
          </div>
        )}

        {/* Change Status */}
        <div style={{marginBottom:12}}>
          <p style={{fontSize:10,fontWeight:700,textTransform:'uppercase',letterSpacing:'0.1em',color:C.inkLight,marginBottom:8}}>Change Status</p>
          <div style={{display:'flex',flexWrap:'wrap',gap:5,marginBottom:8}}>
            {Object.entries(ST).map(([k,cfg])=>(
              <button key={k} onClick={()=>setNewStatus(k)}
                style={{padding:'5px 10px',borderRadius:100,fontSize:10,fontWeight:700,cursor:'pointer',border:`1.5px solid ${newStatus===k?cfg.dot:C.border}`,background:newStatus===k?cfg.bg:C.card,color:newStatus===k?cfg.text:C.inkMid}}>
                {cfg.label}
              </button>
            ))}
          </div>
          {newStatus!==(localRec?.status||'absent') && (
            <button onClick={()=>save(newStatus)} disabled={saving}
              style={{width:'100%',padding:'9px',borderRadius:10,border:'none',cursor:'pointer',background:`linear-gradient(135deg,${C.gold},${C.goldLight})`,color:'#fff',fontSize:12,fontWeight:700,display:'flex',alignItems:'center',justifyContent:'center',gap:6}}>
              {saving?<Loader2 size={12} className="animate-spin"/>:<Check size={12}/>}
              Save as {ST[newStatus]?.label}
            </button>
          )}
        </div>

        {/* Salary Deduction */}
        {localRec && (
          <button onClick={()=>onDeduct(localRec)}
            style={{width:'100%',padding:'11px 14px',borderRadius:12,border:`1.5px solid ${canDeduct?C.redBorder:C.border}`,background:canDeduct?C.redPale:C.grayPale,color:canDeduct?C.red:C.inkLight,fontSize:12,fontWeight:700,cursor:canDeduct?'pointer':'default',display:'flex',alignItems:'center',justifyContent:'center',gap:6,opacity:canDeduct?1:0.5}}>
            <IndianRupee size={13}/> Apply Salary Deduction
            {!canDeduct && <span style={{fontSize:10,fontWeight:400}}>(only for absent/late/half-day)</span>}
          </button>
        )}
      </div>
    </motion.div>
  );
}

/* ── Summary Card (monthly) ─────────────────────────────────────────────────── */
function SummaryCard({ s, liveMap, onSelect, onMark, onFloor, onDeductStaff, active }) {
  const total = s.present+s.late+s.absent+s.halfDay+s.leave;
  const pct   = total>0 ? Math.round(((s.present+s.late)/total)*100) : 0;
  const color = pct>=80?C.green:pct>=60?C.amber:C.red;
  const liveInfo = liveMap[String(s.staff?._id)]||null;
  const liveCfg  = liveInfo?(LIVE[liveInfo.liveStatus]||LIVE['off-duty']):null;

  return (
    <motion.div whileHover={{y:-2,boxShadow:`0 8px 30px ${C.gold}20`}}
      style={{background:active?C.goldPale:C.card,border:`1.5px solid ${active?C.gold:C.border}`,borderRadius:18,padding:'16px 18px',transition:'all 0.2s'}}>
      <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:12}}>
        <div style={{width:42,height:42,borderRadius:14,background:`linear-gradient(135deg,${C.gold},${C.goldLight})`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:16,fontWeight:800,color:'#fff',flexShrink:0}}>
          {(s.staff?.name||'?')[0].toUpperCase()}
        </div>
        <div style={{flex:1,minWidth:0}}>
          <p style={{fontSize:14,fontWeight:700,color:C.ink,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{s.staff?.name}</p>
          <p style={{fontSize:10,color:C.inkLight}}>{s.staff?.phone||'No phone'}</p>
        </div>
        <div style={{textAlign:'right'}}>
          <p style={{fontSize:22,fontWeight:800,fontFamily:"'Playfair Display',serif",lineHeight:1,color}}>{pct}%</p>
          <p style={{fontSize:9,color:C.inkLight}}>attendance</p>
        </div>
      </div>

      <div style={{display:'flex',flexWrap:'wrap',gap:4,marginBottom:10}}>
        {[{k:'present',v:s.present+s.late,cfg:ST.present},{k:'absent',v:s.absent,cfg:ST.absent},{k:'halfDay',v:s.halfDay,cfg:ST['half-day']},{k:'leave',v:s.leave,cfg:ST.leave}].filter(x=>x.v>0).map(x=>(
          <span key={x.k} style={{fontSize:10,fontWeight:700,padding:'2px 8px',borderRadius:100,background:x.cfg.bg,border:`1px solid ${x.cfg.border}`,color:x.cfg.text}}>{x.v} {x.cfg.label}</span>
        ))}
      </div>

      <div style={{height:5,borderRadius:3,background:C.border,overflow:'hidden',marginBottom:8}}>
        <div style={{height:'100%',width:`${pct}%`,borderRadius:3,background:`linear-gradient(90deg,${color},${pct>=80?'#34D399':pct>=60?'#FCD34D':'#FCA5A5'})`}}/>
      </div>

      <div style={{display:'flex',justifyContent:'space-between',fontSize:10,color:C.inkLight,marginBottom:14}}>
        <span>{fmtHM(s.totalMinutes)} worked</span>
        {(s.totalDeductions||0)>0&&<span style={{color:C.red,fontWeight:700}}>−{fmtRs(s.totalDeductions)} deducted</span>}
      </div>

      <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
        <button onClick={()=>onSelect(String(s.staff?._id))}
          style={{flex:1,padding:'8px 10px',borderRadius:10,border:`1px solid ${C.border}`,background:C.card,color:C.inkMid,fontSize:11,fontWeight:700,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:5}}>
          <Calendar size={11}/> View Month
        </button>
        <button onClick={()=>onMark(s.staff)}
          style={{flex:1,padding:'8px 10px',borderRadius:10,border:'none',background:`linear-gradient(135deg,${C.gold},${C.goldLight})`,color:'#fff',fontSize:11,fontWeight:700,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:5}}>
          <UserCheck size={11}/> Mark Today
        </button>
        <button onClick={()=>onDeductStaff(s.staff)}
          style={{flex:1,padding:'8px 10px',borderRadius:10,border:`1.5px solid ${C.redBorder}`,background:C.redPale,color:C.red,fontSize:11,fontWeight:700,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:5}}>
          <IndianRupee size={11}/> Deduct
        </button>
        {liveInfo && (
          <button onClick={()=>onFloor(liveInfo)}
            style={{padding:'8px 10px',borderRadius:10,border:`1px solid ${liveCfg.border}`,background:liveCfg.bg,color:liveCfg.text,fontSize:11,fontWeight:700,cursor:'pointer',display:'flex',alignItems:'center',gap:5}}>
            <span style={{width:6,height:6,borderRadius:'50%',background:liveCfg.dot}}/>{liveCfg.label}<Edit2 size={10}/>
          </button>
        )}
      </div>
    </motion.div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════════
   Main
══════════════════════════════════════════════════════════════════════════════ */
export default function AdminAttendance() {
  const { staff:dsStaff, refreshStaff } = useDataStore();
  const n = new Date(Date.now()+IST);

  /* tabs */
  const [tab, setTab] = useState('today');

  /* today */
  const [todayRecs,    setTodayRecs]    = useState([]);
  const [loadingToday, setLoadingToday] = useState(true);
  const [syncing,      setSyncing]      = useState(false);

  /* monthly */
  const [year,    setYear]    = useState(n.getFullYear());
  const [month,   setMonth]   = useState(n.getMonth()+1);
  const [staffId, setStaffId] = useState('');
  const [staffList,  setStaffList]  = useState([]);
  const [salaryMap,  setSalaryMap]  = useState({});
  const [records,    setRecords]    = useState([]);
  const [summary,    setSummary]    = useState([]);
  const [loading,    setLoading]    = useState(false);
  const [view,       setView]       = useState('summary');
  const [search,     setSearch]     = useState('');
  const [statusF,    setStatusF]    = useState('');
  const [selDate,    setSelDate]    = useState(null);
  const [selRecord,  setSelRecord]  = useState(null);

  /* live */
  const [liveStaff,  setLiveStaff]  = useState([]);
  const [liveMap,    setLiveMap]    = useState({});
  const [liveSummary,setLiveSummary]= useState(null);

  /* modals */
  const [floorModal,  setFloorModal]  = useState(null);
  const [markModal,   setMarkModal]   = useState(null);
  const [deductModal, setDeductModal] = useState(null); // { record, staffInfo }
  const [toast,       setToast]       = useState(null);

  const pollRef = useRef(null);
  const showToast = (msg,ok=true) => { setToast({msg,ok}); setTimeout(()=>setToast(null),3500); };

  /* ── fetches ─────────────────────────────────────────────────────────────── */
  const fetchLive = useCallback(async()=>{
    try {
      const{data}=await api.get('/staff/live-status');
      const list=data.staff||[];
      setLiveStaff(list);
      setLiveSummary(data.summary||null);
      const m={};
      list.forEach(s=>{ m[String(s._id)]=s; });
      setLiveMap(m);
    } catch{}
  },[]);

  const loadToday = useCallback(async(silent=false)=>{
    if(!silent) setLoadingToday(true); else setSyncing(true);
    try{ const{data}=await api.get('/attendance/today'); setTodayRecs(data.attendance||[]); }
    catch{ setTodayRecs([]); }
    finally{ setLoadingToday(false); setSyncing(false); }
  },[]);

  const fetchReport = useCallback(async(silent=false)=>{
    if(!silent) setLoading(true);
    try{
      const params={year,month};
      if(staffId) params.staffId=staffId;
      const{data}=await api.get('/attendance/report',{params});
      setRecords(data.records||[]);
      setSummary(data.summary||[]);
    }catch{}
    finally{ setLoading(false); }
  },[year,month,staffId]);

  useEffect(()=>{
    api.get('/attendance/staff-list').then(r=>{
      const list=r.data.staff||[];
      setStaffList(list);
      const sm={};
      list.forEach(s=>{ sm[String(s._id)]=s; });
      setSalaryMap(sm);
    }).catch(()=>{});
  },[]);

  useEffect(()=>{ loadToday(); fetchLive(); },[loadToday,fetchLive]);
  useEffect(()=>{ if(tab==='monthly') fetchReport(); },[tab,fetchReport]);

  useEffect(()=>{
    pollRef.current=setInterval(()=>{
      fetchLive();
      if(tab==='today'){ loadToday(true); refreshStaff?.(); }
      else fetchReport(true);
    },30000);
    return()=>clearInterval(pollRef.current);
  },[tab,fetchLive,loadToday,fetchReport,refreshStaff]);

  useEffect(()=>{
    let bc=null;
    try{ bc=new BroadcastChannel('glamour_bookings_sync'); }catch{ return; }
    let timer=null;
    const handler=(e)=>{
      if(e.data?.type!=='refresh') return;
      clearTimeout(timer);
      timer=setTimeout(()=>{
        fetchLive();
        if(tab==='today'){ loadToday(true); refreshStaff?.(); }
        else fetchReport(true);
      },600);
    };
    bc.addEventListener('message',handler);
    return()=>{ bc.removeEventListener('message',handler); bc.close(); clearTimeout(timer); };
  },[tab,fetchLive,loadToday,fetchReport,refreshStaff]);

  /* ── helpers ─────────────────────────────────────────────────────────────── */
  const getTodayRec = useCallback((staffUser)=>{
    const uid=String(staffUser._id);
    return todayRecs.find(r=>String(r.staff?._id||r.staff||r.staffId)===uid)||null;
  },[todayRecs]);

  const todaySummary = useMemo(()=>({
    present:  todayRecs.filter(r=>r.status==='present').length,
    late:     todayRecs.filter(r=>r.status==='late').length,
    absent:   todayRecs.filter(r=>r.status==='absent').length,
    leave:    todayRecs.filter(r=>['leave','holiday','half-day'].includes(r.status)).length,
    total:    (dsStaff||[]).length,
    unmarked: (dsStaff||[]).filter(s=>!getTodayRec(s)).length,
  }),[todayRecs,dsStaff,getTodayRec]);

  const overall = useMemo(()=>({
    present:         summary.reduce((s,x)=>s+x.present,0),
    late:            summary.reduce((s,x)=>s+x.late,0),
    absent:          summary.reduce((s,x)=>s+x.absent,0),
    halfDay:         summary.reduce((s,x)=>s+x.halfDay,0),
    leave:           summary.reduce((s,x)=>s+x.leave,0),
    totalMinutes:    summary.reduce((s,x)=>s+x.totalMinutes,0),
    totalDeductions: summary.reduce((s,x)=>s+(x.totalDeductions||0),0),
  }),[summary]);

  const filtered = useMemo(()=>{
    let r=records;
    if(statusF) r=r.filter(x=>x.status===statusF);
    if(search){ const q=search.toLowerCase(); r=r.filter(x=>x.staff?.name?.toLowerCase().includes(q)||x.staff?.phone?.includes(q)); }
    return r;
  },[records,search,statusF]);

  const byDate = useMemo(()=>{
    const map={};
    filtered.forEach(r=>{ const ds=new Date(r.date).toISOString().split('T')[0]; if(!map[ds]) map[ds]=[]; map[ds].push(r); });
    return Object.entries(map).sort(([a],[b])=>b.localeCompare(a));
  },[filtered]);

  const panelStaffName = useMemo(()=>{
    if(staffId) return salaryMap[String(staffId)]?.name||'';
    if(selRecord) return selRecord.staff?.name||'';
    return '';
  },[staffId,selRecord,salaryMap]);

  /* open deduction modal — builds a minimal record if only staff supplied */
  const openDeduct = useCallback((recordOrStaff)=>{
    // If it has a 'status' field, it's a full record
    if(recordOrStaff?.status){
      const staffInfo = salaryMap[String(recordOrStaff.staff?._id||recordOrStaff.staff)];
      setDeductModal({ record:recordOrStaff, staffInfo });
    } else {
      // It's a staff user obj — use today's record if exists, else dummy
      const uid = String(recordOrStaff?._id||recordOrStaff);
      const todayRecord = getTodayRec(recordOrStaff) || {
        staff: recordOrStaff,
        date:  new Date(),
        status:'absent',
        sessions:[],
        _id: null,
      };
      const staffInfo = salaryMap[uid];
      setDeductModal({ record:todayRecord, staffInfo });
    }
  },[salaryMap,getTodayRec]);

  const prevMonth=()=>{ if(month===1){setMonth(12);setYear(y=>y-1);}else setMonth(m=>m-1); };
  const nextMonth=()=>{ if(month===12){setMonth(1);setYear(y=>y+1);}else setMonth(m=>m+1); };

  const exportCSV=()=>{
    const rows=[['Date','Staff','Status','Clock In','Clock Out','Total Hours','Deduction','Notes']];
    records.forEach(r=>{
      const ss=r.sessions||[]; const fi=ss[0]?.clockIn; const lo=ss.filter(s=>s.clockOut).slice(-1)[0]?.clockOut;
      rows.push([new Date(r.date).toISOString().split('T')[0],`"${r.staff?.name||''}"`,r.status,fi?fmtTime(fi):'',lo?fmtTime(lo):'',fmtHM(r.totalMinutes),r.deduction||0,`"${r.notes||''}"`]);
    });
    const a=document.createElement('a');
    a.href=URL.createObjectURL(new Blob([rows.map(r=>r.join(',')).join('\n')],{type:'text/csv'}));
    a.download=`attendance_${year}_${String(month).padStart(2,'0')}.csv`;
    a.click();
  };

  /* ── render ──────────────────────────────────────────────────────────────── */
  return (
    <div style={{fontFamily:"'DM Sans',sans-serif",maxWidth:1140,margin:'0 auto',paddingBottom:40}}>
      <style>{`
        @keyframes spin  {from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
        @keyframes pulse {0%,100%{opacity:1}50%{opacity:0.5}}
        .animate-spin  {animation:spin 1s linear infinite}
        .animate-pulse {animation:pulse 2s infinite}
        @media(max-width:860px){.att-split{grid-template-columns:1fr!important}}
      `}</style>

      {/* Toast */}
      <AnimatePresence>
        {toast&&(
          <motion.div initial={{opacity:0,y:-12,x:'-50%'}} animate={{opacity:1,y:0,x:'-50%'}} exit={{opacity:0,y:-12,x:'-50%'}}
            style={{position:'fixed',top:70,left:'50%',zIndex:999,padding:'10px 20px',borderRadius:14,background:toast.ok?C.greenPale:C.redPale,color:toast.ok?C.green:C.red,fontWeight:700,fontSize:13,boxShadow:'0 4px 20px rgba(0,0,0,0.12)',border:`1px solid ${toast.ok?C.greenBorder:C.redBorder}`,display:'flex',alignItems:'center',gap:7,whiteSpace:'nowrap'}}>
            {toast.ok?<Check size={13}/>:<AlertCircle size={13}/>} {toast.msg}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero */}
      <div style={{borderRadius:24,padding:'24px 28px',marginBottom:20,background:'linear-gradient(135deg,#1c1408,#2d2010,#1a0e06)',position:'relative',overflow:'hidden'}}>
        <div style={{position:'absolute',inset:0,opacity:0.04,backgroundImage:'repeating-linear-gradient(45deg,#B8860B 0,#B8860B 1px,transparent 0,transparent 50%)',backgroundSize:'14px 14px'}}/>
        <div style={{position:'relative',display:'flex',alignItems:'flex-start',justifyContent:'space-between',flexWrap:'wrap',gap:16}}>
          <div>
            <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
              <Activity size={11} style={{color:'#F0D878'}}/>
              <span style={{fontSize:10,fontWeight:800,textTransform:'uppercase',letterSpacing:'0.14em',color:'#F0D878'}}>Attendance Command Centre</span>
              {syncing&&<span style={{width:8,height:8,borderRadius:'50%',background:C.goldLight,display:'inline-block'}} className="animate-pulse"/>}
            </div>
            <h1 style={{fontSize:26,fontWeight:800,color:'#fff',fontFamily:"'Playfair Display',serif",margin:0}}>
              {new Date().toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'})}
            </h1>
            <p style={{fontSize:12,color:'#7a6040',marginTop:4}}>Mark attendance · Update live floor status · Salary deductions</p>
          </div>
          <div style={{display:'flex',flexWrap:'wrap',gap:8}}>
            {[{l:'Present',v:todaySummary.present,dot:'#10B981'},{l:'Late',v:todaySummary.late,dot:'#F59E0B'},{l:'Absent',v:todaySummary.absent,dot:'#EF4444'},{l:'On Leave',v:todaySummary.leave,dot:'#7C3AED'},{l:'Unmarked',v:todaySummary.unmarked,dot:'#9CA3AF'}].map(p=>(
              <div key={p.l} style={{textAlign:'center',padding:'8px 14px',borderRadius:12,background:'rgba(255,255,255,0.08)',border:'1px solid rgba(255,255,255,0.1)'}}>
                <p style={{fontSize:20,fontWeight:800,color:p.dot,lineHeight:1,fontFamily:"'Playfair Display',serif"}}>{p.v}</p>
                <p style={{fontSize:9,fontWeight:700,textTransform:'uppercase',color:'rgba(255,255,255,0.4)',marginTop:2}}>{p.l}</p>
              </div>
            ))}
          </div>
        </div>
        {/* Tab switcher */}
        <div style={{display:'flex',gap:4,marginTop:20,background:'rgba(255,255,255,0.07)',borderRadius:12,padding:4,width:'fit-content'}}>
          {[['today',<Activity size={13} key="a"/>,"Today's Attendance"],['monthly',<Calendar size={13} key="b"/>,'Monthly Reports']].map(([v,icon,label])=>(
            <button key={v} onClick={()=>setTab(v)}
              style={{display:'flex',alignItems:'center',gap:6,padding:'8px 18px',borderRadius:9,border:'none',background:tab===v?'rgba(184,134,11,0.9)':'transparent',color:tab===v?'#fff':'rgba(255,255,255,0.5)',fontSize:12,fontWeight:tab===v?700:500,cursor:'pointer',transition:'all 0.2s'}}>
              {icon}{label}
            </button>
          ))}
        </div>
      </div>

      {/* ══ TODAY TAB ══════════════════════════════════════════════════════════ */}
      <AnimatePresence mode="wait">
      {tab==='today'&&(
        <motion.div key="today" initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0}}>
          {/* Summary row */}
          <div style={{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:10,marginBottom:20}}>
            {[{label:'Total Staff',val:todaySummary.total,bg:C.card,border:C.border,text:C.inkMid},{label:'Present',val:todaySummary.present,bg:C.greenPale,border:C.greenBorder,text:C.green},{label:'Late',val:todaySummary.late,bg:C.amberPale,border:C.amberBorder,text:C.amber},{label:'Absent',val:todaySummary.absent,bg:C.redPale,border:C.redBorder,text:C.red},{label:'On Leave',val:todaySummary.leave,bg:C.purplePale,border:C.purpleBorder,text:C.purple}].map(({label,val,bg,border,text})=>(
              <div key={label} style={{background:bg,border:`1px solid ${border}`,borderRadius:14,padding:'14px 16px',textAlign:'center'}}>
                <p style={{fontSize:26,fontWeight:800,color:text,fontFamily:"'Playfair Display',serif",lineHeight:1}}>{val}</p>
                <p style={{fontSize:10,color:text,opacity:0.75,marginTop:4,fontWeight:700,textTransform:'uppercase',letterSpacing:'0.06em'}}>{label}</p>
              </div>
            ))}
          </div>

          <AnimatePresence>
            {todaySummary.unmarked>0&&(
              <motion.div initial={{opacity:0,y:-6}} animate={{opacity:1,y:0}} exit={{opacity:0}}
                style={{marginBottom:16,padding:'12px 18px',background:C.amberPale,border:`1px solid ${C.amberBorder}`,borderRadius:13,display:'flex',alignItems:'center',gap:8}}>
                <AlertCircle size={15} style={{color:C.amber,flexShrink:0}}/>
                <p style={{fontSize:13,fontWeight:600,color:C.amber}}>{todaySummary.unmarked} staff not yet marked for today</p>
              </motion.div>
            )}
          </AnimatePresence>

          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:16,flexWrap:'wrap',gap:8}}>
            <p style={{fontSize:13,fontWeight:700,color:C.ink}}>Staff Attendance · Today</p>
            <button onClick={()=>{ loadToday(true); fetchLive(); refreshStaff?.(); }}
              style={{display:'flex',alignItems:'center',gap:6,padding:'8px 16px',borderRadius:999,border:`1px solid ${C.border}`,background:C.card,color:C.inkMid,fontSize:12,fontWeight:600,cursor:'pointer'}}>
              <RefreshCw size={12} className={syncing?'animate-spin':''}/> Refresh
            </button>
          </div>

          {loadingToday?(
            <div style={{textAlign:'center',padding:'60px 0'}}><Loader2 size={26} className="animate-spin" style={{color:C.gold,margin:'0 auto'}}/></div>
          ):(dsStaff||[]).length===0?(
            <div style={{textAlign:'center',padding:'60px 0',color:C.inkLight}}><Users size={28} style={{margin:'0 auto 12px',opacity:0.3}}/><p>No staff found</p></div>
          ):(
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(320px,1fr))',gap:12,marginBottom:20}}>
              {(dsStaff||[]).map(s=>{
                const liveInfo=liveMap[String(s._id)]||null;
                return (
                  <TodayCard key={s._id}
                    s={{...s,staffProfileId:liveInfo?.staffProfileId}}
                    liveInfo={liveInfo}
                    todayRecord={getTodayRec(s)}
                    onMark={(su,ex)=>setMarkModal({staffUser:su,date:todayKey(),existing:ex})}
                    onStatus={(target)=>setFloorModal(target)}
                    onDeduct={(rec)=>openDeduct(rec)}
                  />
                );
              })}
            </div>
          )}

          {/* Live floor strip */}
          {!loadingToday&&liveStaff.length>0&&(
            <div style={{background:C.card,borderRadius:16,border:`1px solid ${C.border}`,overflow:'hidden'}}>
              <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 18px',borderBottom:`1px solid ${C.border}`}}>
                <div style={{display:'flex',alignItems:'center',gap:8}}>
                  <span style={{width:8,height:8,borderRadius:'50%',background:'#10B981',display:'inline-block'}} className="animate-pulse"/>
                  <p style={{fontSize:11,fontWeight:800,textTransform:'uppercase',letterSpacing:'0.1em',color:C.inkMid}}>Live Floor Status · click to update</p>
                </div>
                {liveSummary&&(
                  <div style={{display:'flex',gap:6}}>
                    {[['available','#10B981',C.greenPale,C.green],['busy','#F59E0B',C.amberPale,C.amber],['absent','#EF4444',C.redPale,C.red]].map(([k,dot,bg,text])=>(
                      <span key={k} style={{fontSize:10,fontWeight:700,padding:'3px 10px',borderRadius:100,background:bg,color:text,border:`1px solid ${dot}33`,display:'flex',alignItems:'center',gap:4}}>
                        <span style={{width:5,height:5,borderRadius:'50%',background:dot}}/>{liveSummary[k]??0} {k}
                      </span>
                    ))}
                  </div>
                )}
              </div>
              <div style={{display:'flex',flexWrap:'wrap',gap:8,padding:'12px 18px'}}>
                {liveStaff.map(s=>{
                  const cfg=LIVE[s.liveStatus]||LIVE['off-duty'];
                  return (
                    <button key={s._id} onClick={()=>setFloorModal(s)}
                      style={{display:'flex',alignItems:'center',gap:6,padding:'6px 12px',borderRadius:10,background:cfg.bg,border:`1px solid ${cfg.border}`,cursor:'pointer',transition:'all 0.15s'}}>
                      <span style={{width:6,height:6,borderRadius:'50%',background:cfg.dot}}/>
                      <span style={{fontSize:12,fontWeight:700,color:C.ink}}>{s.name}</span>
                      <span style={{fontSize:10,color:cfg.text}}>{cfg.label}</span>
                      <Edit2 size={9} style={{color:cfg.text,opacity:0.6}}/>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </motion.div>
      )}

      {/* ══ MONTHLY TAB ════════════════════════════════════════════════════════ */}
      {tab==='monthly'&&(
        <motion.div key="monthly" initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0}}>

          {/* KPI row */}
          <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(120px,1fr))',gap:10,marginBottom:20}}>
            {[
              {l:'Hours Worked',v:fmtHM(overall.totalMinutes),  icon:Timer,       c:C.gold,   bg:C.goldPale  },
              {l:'Present',     v:overall.present+overall.late, icon:UserCheck,   c:C.green,  bg:C.greenPale },
              {l:'Absent',      v:overall.absent,               icon:XCircle,     c:C.red,    bg:C.redPale   },
              {l:'Half Days',   v:overall.halfDay,              icon:Minus,       c:C.blue,   bg:C.bluePale  },
              {l:'Leave',       v:overall.leave,                icon:Sun,         c:C.purple, bg:C.purplePale},
              {l:'Deductions',  v:fmtRs(overall.totalDeductions),icon:IndianRupee,c:C.red,    bg:C.redPale   },
            ].map(({l,v,icon:Icon,c,bg})=>(
              <div key={l} style={{borderRadius:14,padding:'12px 14px',background:bg,border:`1.5px solid ${c}20`}}>
                <div style={{width:28,height:28,borderRadius:8,background:`${c}18`,display:'flex',alignItems:'center',justifyContent:'center',marginBottom:6}}>
                  <Icon size={13} style={{color:c}}/>
                </div>
                <p style={{fontSize:18,fontWeight:800,color:c,fontFamily:"'Playfair Display',serif",lineHeight:1}}>{v}</p>
                <p style={{fontSize:9,fontWeight:700,color:`${c}88`,textTransform:'uppercase',letterSpacing:'0.08em',marginTop:3}}>{l}</p>
              </div>
            ))}
          </div>

          {/* Controls */}
          <div style={{display:'flex',flexWrap:'wrap',gap:10,alignItems:'center',marginBottom:16}}>
            <div style={{display:'flex',alignItems:'center',gap:2,background:C.card,border:`1px solid ${C.border}`,borderRadius:12,overflow:'hidden'}}>
              <button onClick={prevMonth} style={{padding:'8px 12px',background:'none',border:'none',cursor:'pointer'}}><ChevronLeft size={14} style={{color:C.inkMid}}/></button>
              <span style={{fontSize:12,fontWeight:700,color:C.ink,padding:'0 4px',whiteSpace:'nowrap'}}>{monthLbl(year,month)}</span>
              <button onClick={nextMonth} style={{padding:'8px 12px',background:'none',border:'none',cursor:'pointer'}}><ChevronRight size={14} style={{color:C.inkMid}}/></button>
            </div>
            <select value={staffId} onChange={e=>{ setStaffId(e.target.value); setSelDate(null); setSelRecord(null); }}
              style={{padding:'8px 14px',borderRadius:12,border:`1px solid ${C.border}`,background:C.card,fontSize:12,fontWeight:700,color:C.ink,outline:'none',cursor:'pointer'}}>
              <option value="">All Staff</option>
              {staffList.map(s=><option key={String(s._id)} value={String(s._id)}>{s.name}</option>)}
            </select>
            <div style={{position:'relative',flex:1,minWidth:160}}>
              <Search size={12} style={{position:'absolute',left:12,top:'50%',transform:'translateY(-50%)',color:C.inkLight}}/>
              <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search staff…"
                style={{width:'100%',paddingLeft:32,paddingRight:12,paddingTop:8,paddingBottom:8,borderRadius:12,border:`1px solid ${C.border}`,background:C.card,fontSize:12,color:C.ink,outline:'none',boxSizing:'border-box'}}/>
            </div>
            <div style={{display:'flex',gap:4,flexWrap:'wrap'}}>
              {[['','All'],['absent','Absent'],['late','Late'],['half-day','Half Day'],['leave','Leave']].map(([v,l])=>(
                <button key={v} onClick={()=>setStatusF(v)}
                  style={{padding:'6px 12px',borderRadius:100,fontSize:10,fontWeight:700,cursor:'pointer',border:`1px solid ${statusF===v?C.gold:C.border}`,background:statusF===v?C.goldPale:C.card,color:statusF===v?C.goldDeep:C.inkMid}}>
                  {l}
                </button>
              ))}
            </div>
            <div style={{display:'flex',borderRadius:12,overflow:'hidden',border:`1px solid ${C.border}`}}>
              {[['summary',<BarChart3 size={12} key="s"/>,'Summary'],['month',<Grid3X3 size={12} key="m"/>,'Month'],['day',<List size={12} key="d"/>,'Day List']].map(([v,icon,l])=>(
                <button key={v} onClick={()=>{ setView(v); setSelDate(null); setSelRecord(null); }}
                  style={{padding:'8px 12px',fontSize:11,border:'none',cursor:'pointer',background:view===v?C.gold:C.card,color:view===v?'#fff':C.inkMid,display:'flex',alignItems:'center',gap:5,whiteSpace:'nowrap'}}>
                  {icon}{l}
                </button>
              ))}
            </div>
            <button onClick={()=>fetchReport()} disabled={loading} style={{width:36,height:36,borderRadius:12,border:`1px solid ${C.border}`,background:C.card,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}>
              <RefreshCw size={13} style={{color:C.inkMid}} className={loading?'animate-spin':''}/>
            </button>
            <button onClick={exportCSV} style={{display:'flex',alignItems:'center',gap:6,padding:'8px 16px',borderRadius:12,border:'none',background:C.gold,color:'#fff',fontSize:11,fontWeight:700,cursor:'pointer'}}>
              <Download size={12}/> Export
            </button>
          </div>

          {loading?(
            <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:'80px 0',gap:12}}>
              <div style={{width:48,height:48,borderRadius:16,background:`linear-gradient(135deg,${C.gold},${C.goldLight})`,display:'flex',alignItems:'center',justifyContent:'center'}}>
                <Loader2 size={22} style={{color:'#fff'}} className="animate-spin"/>
              </div>
              <p style={{fontSize:13,color:C.inkLight}}>Loading attendance data…</p>
            </div>

          ):view==='summary'?(
            /* ── Summary cards ── */
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(300px,1fr))',gap:12}}>
              {summary.length===0?(
                <div style={{gridColumn:'1/-1',padding:'60px',textAlign:'center',background:C.card,borderRadius:16,border:`1px solid ${C.border}`}}>
                  <Users size={32} style={{color:C.border,margin:'0 auto 12px'}}/>
                  <p style={{color:C.inkLight}}>No attendance records for this period.</p>
                </div>
              ):summary.map((s,i)=>(
                <SummaryCard key={i} s={s} liveMap={liveMap}
                  onSelect={uid=>{ setStaffId(uid); setView('month'); setSelDate(null); setSelRecord(null); }}
                  onMark={userObj=>setMarkModal({staffUser:userObj,date:todayKey(),existing:null})}
                  onFloor={info=>setFloorModal(info)}
                  onDeductStaff={staffObj=>openDeduct(staffObj)}
                  active={String(staffId)===String(s.staff?._id)}
                />
              ))}
            </div>

          ):view==='month'?(
            /* ── Month calendar + DayPanel ── */
            <div className="att-split" style={{display:'grid',gridTemplateColumns:selDate?'1fr 340px':'1fr',gap:16,alignItems:'start'}}>
              <div>
                {staffId?(
                  <MonthCal records={records} year={year} month={month} selectedDate={selDate}
                    onDayClick={(key,rec)=>{ setSelDate(key); setSelRecord(rec||null); }}/>
                ):(
                  <div>
                    {/* When no staff selected, show clickable grouped list */}
                    <p style={{fontSize:12,color:C.inkMuted,marginBottom:12}}>
                      Select a staff member from the dropdown above to see their calendar, or click any row below.
                    </p>
                    {byDate.length===0?(
                      <div style={{padding:'60px',textAlign:'center',background:C.card,border:`1px solid ${C.border}`,borderRadius:16}}>
                        <Calendar size={28} style={{color:C.border,margin:'0 auto 12px'}}/><p style={{color:C.inkLight}}>No records found</p>
                      </div>
                    ):byDate.map(([ds,dayRecs])=>{
                      const dLabel=new Date(ds+'T12:00:00').toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long'});
                      const counts=dayRecs.reduce((acc,r)=>{ acc[r.status]=(acc[r.status]||0)+1; return acc; },{});
                      return (
                        <div key={ds} style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:18,overflow:'hidden',marginBottom:14}}>
                          <div style={{padding:'12px 18px',borderBottom:`1px solid ${C.border}`,background:C.cardAlt,display:'flex',alignItems:'center',justifyContent:'space-between',flexWrap:'wrap',gap:8}}>
                            <div style={{display:'flex',alignItems:'center',gap:10}}>
                              <Calendar size={13} style={{color:C.gold}}/>
                              <p style={{fontSize:13,fontWeight:700,color:C.ink}}>{dLabel}</p>
                            </div>
                            <div style={{display:'flex',gap:5,flexWrap:'wrap'}}>
                              {Object.entries(counts).map(([st,cnt])=>{ const cfg=ST[st]||ST.absent; return <span key={st} style={{fontSize:10,fontWeight:700,padding:'2px 8px',borderRadius:100,background:cfg.bg,border:`1px solid ${cfg.border}`,color:cfg.text}}>{cnt} {cfg.label}</span>; })}
                            </div>
                          </div>
                          <div style={{padding:'8px 12px',display:'flex',flexDirection:'column',gap:4}}>
                            {dayRecs.map(r=>{
                              const isAbs=['absent','half-day','late'].includes(r.status);
                              const isSel=selDate===ds&&selRecord?._id===r._id;
                              return (
                                <div key={r._id}
                                  onClick={()=>{ setSelDate(ds); setSelRecord(r); }}
                                  style={{display:'flex',alignItems:'center',gap:12,padding:'10px 14px',borderRadius:12,background:isSel?C.goldPale:C.card,border:`1px solid ${isSel?C.gold:C.border}`,cursor:'pointer',transition:'all 0.15s'}}>
                                  <div style={{width:34,height:34,borderRadius:11,background:`linear-gradient(135deg,${C.gold},${C.goldLight})`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:800,color:'#fff',flexShrink:0}}>
                                    {(r.staff?.name||'?')[0].toUpperCase()}
                                  </div>
                                  <div style={{flex:1,minWidth:0}}>
                                    <p style={{fontSize:13,fontWeight:700,color:C.ink}}>{r.staff?.name}</p>
                                    <p style={{fontSize:11,color:C.inkLight}}>
                                      {r.sessions?.length>0?`${fmtTime(r.sessions[0]?.clockIn)} – ${r.sessions.slice(-1)[0]?.clockOut?fmtTime(r.sessions.slice(-1)[0]?.clockOut):'Active'}`:r.status}
                                      {r.totalMinutes>0?` · ${fmtHM(r.totalMinutes)}`:''}
                                    </p>
                                  </div>
                                  <Pill status={r.status}/>
                                  {r.deduction>0&&<span style={{fontSize:10,fontWeight:700,color:C.red,padding:'2px 7px',borderRadius:8,background:C.redPale,border:`1px solid ${C.redBorder}`}}>−{fmtRs(r.deduction)}</span>}
                                  {isAbs&&(
                                    <button onClick={e=>{ e.stopPropagation(); openDeduct(r); }}
                                      style={{padding:'4px 10px',borderRadius:8,border:`1.5px solid ${C.redBorder}`,background:C.redPale,color:C.red,fontSize:10,fontWeight:700,cursor:'pointer',flexShrink:0}}>
                                      Deduct
                                    </button>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Day Panel — shows when any date/row is selected */}
              <AnimatePresence>
                {selDate&&(
                  <DayPanel
                    dateKey={selDate}
                    record={selRecord}
                    staffName={panelStaffName}
                    onClose={()=>{ setSelDate(null); setSelRecord(null); }}
                    onDeduct={rec=>openDeduct(rec)}
                    onRefresh={()=>fetchReport(true)}
                  />
                )}
              </AnimatePresence>
            </div>

          ):(
            /* ── Day list view ── */
            <div style={{display:'flex',flexDirection:'column',gap:4}}>
              {filtered.length===0?(
                <div style={{padding:'60px',textAlign:'center',background:C.card,border:`1px solid ${C.border}`,borderRadius:16}}>
                  <p style={{color:C.inkLight}}>No records found</p>
                </div>
              ):filtered.map(r=>{
                const ss=r.sessions||[],fi=ss[0]?.clockIn,lo=ss.filter(s=>s.clockOut).slice(-1)[0]?.clockOut;
                const isAbs=['absent','half-day','late'].includes(r.status);
                const ds=new Date(r.date).toISOString().split('T')[0];
                return (
                  <div key={r._id}
                    style={{display:'flex',alignItems:'center',gap:12,padding:'11px 16px',borderRadius:12,background:C.card,border:`1px solid ${C.border}`,cursor:'pointer',transition:'all 0.15s'}}
                    onClick={()=>{ setStaffId(String(r.staff?._id||r.staff)); setSelDate(ds); setSelRecord(r); setView('month'); }}
                    onMouseEnter={e=>e.currentTarget.style.background=C.cardAlt}
                    onMouseLeave={e=>e.currentTarget.style.background=C.card}>
                    <div style={{minWidth:52,textAlign:'center',flexShrink:0}}>
                      <p style={{fontSize:15,fontWeight:800,color:C.gold,fontFamily:"'Playfair Display',serif"}}>{new Date(ds+'T12:00:00').getDate()}</p>
                      <p style={{fontSize:9,fontWeight:700,color:C.inkLight,textTransform:'uppercase'}}>{new Date(ds+'T12:00:00').toLocaleDateString('en-IN',{weekday:'short',month:'short'})}</p>
                    </div>
                    <div style={{width:1,height:32,background:C.border,flexShrink:0}}/>
                    {!staffId&&(
                      <>
                        <div style={{width:32,height:32,borderRadius:10,background:`linear-gradient(135deg,${C.gold},${C.goldLight})`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:800,color:'#fff',flexShrink:0}}>
                          {(r.staff?.name||'?')[0].toUpperCase()}
                        </div>
                        <p style={{fontSize:12,fontWeight:700,color:C.ink,width:90,flexShrink:0,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{r.staff?.name}</p>
                      </>
                    )}
                    <Pill status={r.status}/>
                    <div style={{flex:1,display:'flex',alignItems:'center',gap:12,minWidth:0}}>
                      {fi&&<span style={{fontSize:11,color:C.inkMid,display:'flex',alignItems:'center',gap:4}}><LogIn size={10} style={{color:C.green}}/>{fmtTime(fi)}</span>}
                      {lo&&<span style={{fontSize:11,color:C.inkMid,display:'flex',alignItems:'center',gap:4}}><LogOut size={10} style={{color:C.red}}/>{fmtTime(lo)}</span>}
                      {r.totalMinutes>0&&<span style={{fontSize:11,fontWeight:700,color:C.gold}}>{fmtHM(r.totalMinutes)}</span>}
                    </div>
                    {r.deduction>0&&<span style={{fontSize:10,fontWeight:700,color:C.red,padding:'2px 7px',borderRadius:8,background:C.redPale,border:`1px solid ${C.redBorder}`}}>−{fmtRs(r.deduction)}</span>}
                    {isAbs&&(
                      <button onClick={e=>{ e.stopPropagation(); openDeduct(r); }}
                        style={{padding:'5px 10px',borderRadius:8,border:`1.5px solid ${C.redBorder}`,background:C.redPale,color:C.red,fontSize:10,fontWeight:700,cursor:'pointer',flexShrink:0}}>
                        Deduct
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </motion.div>
      )}
      </AnimatePresence>

      {/* ══ Modals ════════════════════════════════════════════════════════════ */}
      <AnimatePresence>
        {deductModal&&(
          <DeductModal
            record={deductModal.record}
            staffInfo={deductModal.staffInfo}
            onClose={()=>setDeductModal(null)}
            onSaved={()=>{ showToast('Deduction applied'); fetchReport(true); }}
          />
        )}
        {floorModal&&(
          <FloorModal
            member={floorModal}
            onClose={()=>setFloorModal(null)}
            onSaved={(uid,st)=>{
              setLiveStaff(prev=>prev.map(s=>String(s._id)===String(uid)?{...s,liveStatus:st}:s));
              setLiveMap(prev=>{ const m={...prev}; if(m[String(uid)]) m[String(uid)]={...m[String(uid)],liveStatus:st}; return m; });
              showToast(`Floor status → ${LIVE[st]?.label||st}`);
              setTimeout(fetchLive,1500); // re-sync after server confirms
            }}
          />
        )}
        {markModal&&(
          <MarkModal
            staffUser={markModal.staffUser}
            date={markModal.date}
            existing={markModal.existing}
            onClose={()=>setMarkModal(null)}
            onSaved={()=>{ showToast('Attendance saved'); loadToday(true); fetchReport(true); fetchLive(); }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}