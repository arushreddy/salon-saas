/**
 * AdminAppointments.jsx — Glamour Salon (COMPLETE FINAL VERSION)
 * Cream · Gold · Ink — Luxury Light Editorial
 * Timeline booking list (reduced to 420px on desktop) + Split-screen detail panel
 * 
 * ✅ Bookings always visible
 * ✅ Clicking any booking shows FULL details on right (desktop) or overlay (mobile)
 * ✅ X button closes it
 * ✅ All tabs (Details, Actions, Receipt, WhatsApp) working
 * ✅ No blank screens
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useDataStore, broadcastChange } from '@/context/DataStore';
import api from '@/services/api';
import {
  Search, Plus, X, Wallet, CreditCard, Smartphone, Scissors,
  Download, Printer, MessageCircle, RefreshCw, Phone,
  Hash, Edit3, UserCheck, AlertTriangle, CheckCircle, XCircle,
  Copy, Check, Zap, RotateCcw, Calendar, ChevronRight,
} from 'lucide-react';

/* ─── Design Tokens ─────────────────────────────────────────────────────── */
const C = {
  bg: '#FAF6EE', s1: '#F5EFE3', s2: '#EDE3D0', s3: '#E4D8C0', s4: '#D9CBAA',
  border: '#D9CBAA', borderB: '#C8B890',
  gold: '#B8860B', goldHi: '#D4A017', goldDeep:'#8B6508',
  goldFog: 'rgba(184,134,11,0.09)', goldGlw: 'rgba(184,134,11,0.20)',
  ink: '#1C1410', inkB: '#4A3828', inkC: '#7A6040', inkD: '#B09070',
  ok: '#166534', okBg:'rgba(22,101,52,0.08)', okBr:'rgba(22,101,52,0.22)',
  warn: '#92400E', warnBg:'rgba(146,64,14,0.08)', warnBr:'rgba(146,64,14,0.22)',
  risk: '#991B1B', riskBg:'rgba(153,27,27,0.08)', riskBr:'rgba(153,27,27,0.22)',
  blue: '#1E40AF', blueBg:'rgba(30,64,175,0.08)', blueBr:'rgba(30,64,175,0.22)',
};

const STATUS = {
  all: { label:'All', dot:C.inkD, bg:C.s1, br:C.border, tx:C.inkB },
  confirmed: { label:'Confirmed', dot:C.warn, bg:C.warnBg, br:C.warnBr, tx:C.warn },
  'in-progress':{ label:'In Progress', dot:C.ok, bg:C.okBg, br:C.okBr, tx:C.ok },
  completed: { label:'Completed', dot:C.blue, bg:C.blueBg, br:C.blueBr, tx:C.blue },
  cancelled: { label:'Cancelled', dot:C.risk, bg:C.riskBg, br:C.riskBr, tx:C.risk },
  'no-show': { label:'No Show', dot:'#6B7280',bg:'rgba(107,114,128,0.07)',br:'rgba(107,114,128,0.2)',tx:'#374151' },
  pending: { label:'Pending', dot:C.gold, bg:C.goldFog,br:C.goldDeep+'33',tx:C.goldDeep },
};

const PMETHODS = [
  { v:'cash', label:'Cash', Ic:Wallet },
  { v:'upi', label:'UPI', Ic:Smartphone },
  { v:'card', label:'Card', Ic:CreditCard },
];

const IST = 5.5 * 3600000;
const todayS = () => new Date(Date.now() + IST).toISOString().split('T')[0];
const fmt = n => Number(n || 0).toLocaleString('en-IN');
const fmtRs = n => '₹' + fmt(n);
const inits = s => (s || 'G').split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();
const toWA = r => {
  if (!r) return null;
  const d = r.replace(/\D/g, '');
  if (d.length === 10) return '91' + d;
  if (d.length === 12 && d.startsWith('91')) return d;
  return '91' + d;
};
const AVS = ['#B8860B','#8B6508','#6B4F12','#1E40AF','#166534','#6D28D9','#BE185D','#0369A1'];
const avc = name => AVS[(name || '').charCodeAt(0) % AVS.length];

/* salon cache */
let _s = { name:'Glamour Salon', tagline:'Premium Salon & Spa', phone:'', address:'',
  msgConfirm:'', msgRemind:'', msgReceipt:'', receiptFooter:'Thank you for visiting! \u{1F49B}' };

async function loadS() {
  try {
    const { data } = await api.get('/settings');
    const s = data.settings;
    _s = { name:s.salonName||'Glamour Salon', tagline:s.tagline||'Premium Salon & Spa',
      phone:s.phone||'', address:[s.address?.street,s.address?.city,s.address?.state].filter(Boolean).join(', '),
      receiptFooter:s.receiptFooter||'Thank you for visiting! \u{1F49B}',
      msgConfirm:s.msgBookingConfirm||'', msgRemind:s.msgBookingReminder||'', msgReceipt:s.msgPaymentReceipt||'',
    };
  } catch {}
}
const SN = () => _s.name;
const SP = () => _s.phone;

function buildWA(b, method) {
  const amt = b.finalAmount||b.totalAmount||0, disc = b.discountAmount||0, gross = b.totalAmount||amt;
  const d = b.date ? new Date(b.date).toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'}) : '';
  return [
    `\u{1F9FE} *${SN()} \u2014 Receipt*`,'\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501',
    `Ref No : ${b.refNo||'\u2014'}`,`Customer : ${b.customer?.name||'Guest'}`,
    `Service : ${b.service?.name||'\u2014'}`,`Stylist : ${b.staff?.name||'\u2014'}`,
    `Date : ${d}${b.timeSlot?.start?' \u00b7 '+b.timeSlot.start:''}`,'\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501',
    ...(disc>0?[`Price : ${fmtRs(gross)}`,`Discount : \u2212${fmtRs(disc)}`]:[]),
    `*Total Paid : ${fmtRs(amt)}*`,
    `Payment : ${method==='cash'?'\u{1F4B5} Cash':method==='upi'?'\u{1F4F1} UPI':'\u{1F4B3} Card'}`,
    '\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501',
    _s.receiptFooter,
    ...(SP()?[`\u{1F4DE} ${SP()}`]:[]),
  ].join('\n');
}

function printR(b, method) {
  if (!document.getElementById('glm-ps')) {
    const s = document.createElement('style'); s.id='glm-ps';
    s.textContent = '@media print{body>*{display:none!important}#glm-pr{display:block!important}}#glm-pr{display:none}';
    document.head.appendChild(s);
  }
  let el = document.getElementById('glm-pr');
  if (!el) { el = document.createElement('div'); el.id='glm-pr'; document.body.appendChild(el); }
  const amt=b.finalAmount||b.totalAmount||0, disc=b.discountAmount||0;
  const dt = b.date ? new Date(b.date).toLocaleDateString('en-IN',{day:'numeric',month:'long',year:'numeric'}) : '';
  el.innerHTML = `<div style="font-family:'Courier New',monospace;max-width:300px;margin:0 auto;padding:24px 16px;font-size:12px;line-height:1.9">
    <div style="text-align:center;margin-bottom:14px"><div style="font-size:20px;font-weight:900">${SN()}</div>
    ${_s.address?`<div style="font-size:10px">${_s.address}</div>`:''}</div>
    <div style="border-top:2px dashed;border-bottom:2px dashed;padding:8px 0;margin-bottom:10px;text-align:center">
      <div style="font-weight:700">RECEIPT</div><div style="font-size:10px">${dt}</div>
      <div style="font-size:10px;font-weight:700">${b.refNo||''}</div></div>
    <table style="width:100%;font-size:11px">
      <tr><td>Customer</td><td style="text-align:right;font-weight:700">${b.customer?.name||'Guest'}</td></tr>
      <tr><td>Service</td><td style="text-align:right">${b.service?.name||'\u2014'}</td></tr>
      <tr><td>Stylist</td><td style="text-align:right">${b.staff?.name||'\u2014'}</td></tr>
    </table>
    <div style="border-top:1px dashed;margin:10px 0"></div>
    <table style="width:100%;font-size:11px">
      ${disc>0?`<tr><td>Price</td><td style="text-align:right">${fmtRs(b.totalAmount||amt)}</td></tr><tr><td>Discount</td><td style="text-align:right">\u2212${fmtRs(disc)}</td></tr>`:''}
      <tr><td style="font-weight:900;font-size:13px">TOTAL</td><td style="text-align:right;font-weight:900;font-size:15px">${fmtRs(amt)}</td></tr>
      <tr><td>Method</td><td style="text-align:right">${method==='cash'?'Cash':method==='upi'?'UPI':'Card'}</td></tr>
    </table>
    <div style="border-top:2px dashed;margin:10px 0"></div>
    <div style="text-align:center;font-size:10px">${_s.receiptFooter}</div></div>`;
  window.print();
}

function exportCSV(rows, headers, fname) {
  const c = v => { if(v==null)return'""'; const s=String(v); return /^\d+$/.test(s)?'="'+s.replace(/"/g,'""')+'"':'"'+s.replace(/"/g,'""')+'"'; };
  const csv = [headers.join(','),...rows.map(r=>headers.map(h=>c(r[h])).join(','))].join('\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8;'}));
  a.download = fname; a.click(); URL.revokeObjectURL(a.href);
}

const INP = {
  width:'100%', padding:'10px 14px', borderRadius:10,
  border:`1.5px solid ${C.border}`, background:'#fff', color:C.ink,
  fontSize:13, outline:'none', boxSizing:'border-box', fontFamily:'DM Sans,sans-serif',
};

/* ─────────────────────────────────────────────────────────────────────────
   PayModal
───────────────────────────────────────────────────────────────────────── */
function PayModal({ booking, onConfirm, onClose, saving }) {
  const [m, setM] = useState('cash');
  if (!booking) return null;
  const amt = booking.finalAmount||booking.totalAmount||0, disc = booking.discountAmount||0;
  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={onClose}
      style={{position:'fixed',inset:0,zIndex:600,background:'rgba(28,20,16,0.55)',backdropFilter:'blur(8px)',display:'flex',alignItems:'center',justifyContent:'center',padding:20}}>
      <motion.div onClick={e=>e.stopPropagation()} initial={{scale:0.92,y:20}} animate={{scale:1,y:0}} exit={{scale:0.92,opacity:0}}
        transition={{type:'spring',damping:26,stiffness:320}}
        style={{width:'100%',maxWidth:400,background:C.bg,borderRadius:24,overflow:'hidden',border:`1.5px solid ${C.borderB}`,boxShadow:'0 32px 80px rgba(28,20,16,0.28)'}}>
        <div style={{padding:'20px 24px 16px',borderBottom:`1px solid ${C.border}`,display:'flex',alignItems:'center',justifyContent:'space-between',background:C.s1}}>
          <div>
            <div style={{fontSize:18,fontWeight:800,color:C.ink,fontFamily:"'Playfair Display',serif"}}>Collect Payment</div>
            {booking.refNo&&<div style={{fontSize:11,color:C.inkC,marginTop:2}}>Ref: <span style={{color:C.goldDeep,fontWeight:700}}>{booking.refNo}</span></div>}
          </div>
          <button onClick={onClose} style={{width:32,height:32,borderRadius:10,border:`1px solid ${C.border}`,background:C.s2,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}><X size={14} color={C.inkC}/></button>
        </div>
        <div style={{padding:'18px 24px'}}>
          <div style={{background:'#fff',borderRadius:14,padding:'14px 18px',marginBottom:18,border:`1.5px solid ${C.border}`}}>
            {disc>0&&<><div style={{display:'flex',justifyContent:'space-between',marginBottom:5}}><span style={{fontSize:12,color:C.inkC}}>Service price</span><span style={{fontSize:12,color:C.inkC,textDecoration:'line-through'}}>{fmtRs(booking.totalAmount||amt)}</span></div>
            <div style={{display:'flex',justifyContent:'space-between',marginBottom:5}}><span style={{fontSize:12,color:C.ok}}>Discount</span><span style={{fontSize:12,fontWeight:700,color:C.ok}}>\u2212{fmtRs(disc)}</span></div></>}
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',paddingTop:disc>0?10:0,borderTop:disc>0?`1px solid ${C.border}`:'none'}}>
              <span style={{fontSize:14,fontWeight:700,color:C.inkB}}>Amount Due</span>
              <span style={{fontSize:36,fontWeight:900,color:C.ink,letterSpacing:'-0.02em'}}>{fmtRs(amt)}</span>
            </div>
          </div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:8}}>
            {PMETHODS.map(({v,label,Ic})=>(
              <button key={v} onClick={()=>setM(v)}
                style={{padding:'14px 8px',borderRadius:12,cursor:'pointer',textAlign:'center',
                  border:`2px solid ${m===v?C.gold:C.border}`,background:m===v?C.goldFog:'#fff',
                  display:'flex',flexDirection:'column',alignItems:'center',gap:6}}>
                <Ic size={18} color={m===v?C.goldDeep:C.inkC}/>
                <span style={{fontSize:11,fontWeight:700,color:m===v?C.goldDeep:C.inkC}}>{label}</span>
              </button>
            ))}
          </div>
        </div>
        <div style={{padding:'14px 24px',borderTop:`1px solid ${C.border}`,display:'flex',gap:10,background:C.s1}}>
          <button onClick={onClose} style={{flex:1,padding:'12px',borderRadius:100,border:`1px solid ${C.border}`,background:'#fff',color:C.inkC,fontSize:13,fontWeight:600,cursor:'pointer'}}>Cancel</button>
          <button onClick={()=>onConfirm(m)} disabled={saving}
            style={{flex:2,padding:'12px',borderRadius:100,border:'none',background:saving?C.border:C.ok,color:'#fff',fontSize:13,fontWeight:800,cursor:saving?'not-allowed':'pointer'}}>
            {saving?'Saving\u2026':`Confirm \u00b7 ${fmtRs(amt)}`}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   RefundModal
───────────────────────────────────────────────────────────────────────── */
function RefundModal({ booking, onClose, onConfirm, saving }) {
  const [m, setM] = useState(booking?.paymentMethod==='none'?'cash':(booking?.paymentMethod||'cash'));
  const [reason, setR] = useState('');
  const amt = booking?.finalAmount||booking?.totalAmount||0;
  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={onClose}
      style={{position:'fixed',inset:0,zIndex:600,background:'rgba(28,20,16,0.6)',backdropFilter:'blur(10px)',display:'flex',alignItems:'center',justifyContent:'center',padding:16}}>
      <motion.div onClick={e=>e.stopPropagation()}
        initial={{scale:0.92,y:20}} animate={{scale:1,y:0}} exit={{scale:0.92,opacity:0}}
        transition={{type:'spring',damping:26,stiffness:320}}
        style={{width:'100%',maxWidth:420,background:C.bg,borderRadius:24,overflow:'hidden',border:`1.5px solid ${C.riskBr}`,boxShadow:'0 32px 80px rgba(28,20,16,0.28)'}}>
        <div style={{padding:'18px 22px',borderBottom:`1px solid ${C.border}`,display:'flex',alignItems:'center',gap:12,background:'#FEF9F9'}}>
          <div style={{width:40,height:40,borderRadius:12,background:C.riskBg,border:`1.5px solid ${C.riskBr}`,display:'flex',alignItems:'center',justifyContent:'center'}}><RotateCcw size={18} color={C.risk}/></div>
          <div><div style={{fontSize:17,fontWeight:800,color:C.ink,fontFamily:"'Playfair Display',serif"}}>Issue Refund</div><div style={{fontSize:11,color:C.inkC}}>This will reverse the payment record</div></div>
        </div>
        <div style={{padding:'16px 22px',display:'flex',flexDirection:'column',gap:14}}>
          <div style={{background:C.riskBg,borderRadius:14,padding:'16px',border:`1.5px solid ${C.riskBr}`,textAlign:'center'}}>
            <div style={{fontSize:10,fontWeight:700,color:C.risk,textTransform:'uppercase',letterSpacing:'0.12em',marginBottom:4}}>Refund Amount</div>
            <div style={{fontSize:38,fontWeight:900,color:C.risk,letterSpacing:'-0.02em'}}>{fmtRs(amt)}</div>
            <div style={{fontSize:12,color:C.inkC,marginTop:4}}>{booking?.customer?.name} \u00b7 {booking?.service?.name}</div>
          </div>
          <div>
            <div style={{fontSize:10,fontWeight:700,color:C.inkD,textTransform:'uppercase',letterSpacing:'0.1em',marginBottom:8}}>Refund Via</div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:8}}>
              {PMETHODS.map(({v,label,Ic})=>(
                <button key={v} onClick={()=>setM(v)}
                  style={{padding:'12px 8px',borderRadius:12,cursor:'pointer',
                    border:`2px solid ${m===v?C.risk:C.border}`,background:m===v?C.riskBg:'#fff',
                    display:'flex',flexDirection:'column',alignItems:'center',gap:5}}>
                  <Ic size={16} color={m===v?C.risk:C.inkC}/>
                  <span style={{fontSize:11,fontWeight:600,color:m===v?C.risk:C.inkC}}>{label}</span>
                </button>
              ))}
            </div>
            {m==='cash'&&<div style={{marginTop:8,padding:'8px 12px',borderRadius:10,background:'#FFFBEB',border:'1px solid #FDE68A',fontSize:11,color:C.warn,display:'flex',alignItems:'center',gap:6}}><AlertTriangle size={11}/>Cash deducted from till automatically</div>}
          </div>
          <div>
            <div style={{fontSize:10,fontWeight:700,color:C.inkD,textTransform:'uppercase',letterSpacing:'0.1em',marginBottom:6}}>Reason (optional)</div>
            <textarea value={reason} onChange={e=>setR(e.target.value)} placeholder="e.g. Customer not satisfied\u2026" rows={2} style={{...INP,resize:'none',lineHeight:1.5}}/>
          </div>
        </div>
        <div style={{padding:'14px 22px',borderTop:`1px solid ${C.border}`,display:'flex',gap:10,background:C.s1}}>
          <button onClick={onClose} style={{flex:1,padding:'11px',borderRadius:100,border:`1px solid ${C.border}`,background:'#fff',color:C.inkC,fontSize:13,fontWeight:600,cursor:'pointer'}}>Cancel</button>
          <button onClick={()=>onConfirm(m,reason)} disabled={saving}
            style={{flex:2,padding:'11px',borderRadius:100,border:'none',background:saving?C.border:C.risk,color:'#fff',fontSize:13,fontWeight:800,cursor:saving?'not-allowed':'pointer'}}>
            {saving?'Processing\u2026':`Refund ${fmtRs(amt)}`}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   BookingCard
───────────────────────────────────────────────────────────────────────── */
function BookingCard({ booking, selected, onSelect, isLast }) {
  const st = STATUS[booking.status] || STATUS.confirmed;
  const amt = booking.finalAmount || booking.totalAmount || 0;
  const paid = booking.paymentStatus === 'paid';
  const refunded = booking.paymentStatus === 'refunded';
  const av = avc(booking.customer?.name);
  return (
    <motion.div layout initial={{opacity:0,y:6}} animate={{opacity:1,y:0}}
      style={{display:'flex',gap:0,position:'relative'}}>
      <div style={{width:54,flexShrink:0,display:'flex',flexDirection:'column',alignItems:'center',paddingTop:13}}>
        <div style={{fontSize:10,fontWeight:700,color:C.inkC,textAlign:'center',lineHeight:1.2,marginBottom:5,letterSpacing:'-0.01em'}}>
          {booking.timeSlot?.start||'\u2014'}
        </div>
        <div style={{width:11,height:11,borderRadius:'50%',flexShrink:0,
          background: selected ? C.gold : '#fff',
          border: `2.5px solid ${selected ? C.gold : st.dot}`,
          boxShadow: selected ? `0 0 0 4px ${C.goldFog}` : 'none'}}/>
        {!isLast&&<div style={{width:1.5,flex:1,background:`linear-gradient(${C.border},transparent)`,marginTop:4}}/>}
      </div>
      <motion.div onClick={onSelect} whileHover={{x:3}} whileTap={{scale:0.997}}
        style={{flex:1,marginBottom:8,cursor:'pointer',borderRadius:16,overflow:'hidden',
          background: selected ? `linear-gradient(135deg,#FFFDF5,${C.goldFog})` : '#fff',
          border: `1.5px solid ${selected ? C.gold : C.border}`,
          boxShadow: selected ? `0 0 0 3px ${C.goldFog}, 0 8px 32px rgba(184,134,11,0.12)` : '0 1px 6px rgba(28,20,16,0.06)'}}>
        <div style={{display:'flex',alignItems:'stretch'}}>
          <div style={{width:3.5,background:st.dot,flexShrink:0}}/>
          <div style={{flex:1,padding:'11px 14px'}}>
            <div style={{display:'flex',alignItems:'flex-start',gap:9,marginBottom:7}}>
              <div style={{width:36,height:36,borderRadius:10,background:av,flexShrink:0,display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:800,color:'#fff',letterSpacing:'-0.01em'}}>
                {inits(booking.customer?.name)}
              </div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{display:'flex',alignItems:'center',gap:6,flexWrap:'wrap'}}>
                  <span style={{fontSize:14,fontWeight:700,color:C.ink,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis',maxWidth:150}}>
                    {booking.customer?.name||'Guest'}
                  </span>
                  {booking.refNo&&(
                    <span style={{fontSize:9,fontWeight:700,color:C.goldDeep,background:C.goldFog,
                      border:`1px solid ${C.goldDeep}33`,borderRadius:5,padding:'2px 6px',
                      letterSpacing:'0.04em',fontFamily:'monospace'}}>
                      {booking.refNo}
                    </span>
                  )}
                </div>
                <div style={{fontSize:11,color:C.inkC,marginTop:1,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>
                  {booking.service?.name||'\u2014'}{booking.staff?.name?' \u00b7 '+booking.staff.name:''}
                </div>
              </div>
            </div>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',flexWrap:'wrap',gap:6}}>
              <div style={{display:'flex',alignItems:'center',gap:6}}>
                {booking.timeSlot?.end&&<span style={{fontSize:10,color:C.inkD}}>\u2192 {booking.timeSlot.end}</span>}
                <span style={{fontSize:9,color:C.inkD,background:C.s1,borderRadius:5,padding:'2px 7px',textTransform:'capitalize',border:`1px solid ${C.border}`}}>
                  {booking.type||'walk-in'}
                </span>
              </div>
              <div style={{display:'flex',alignItems:'center',gap:8}}>
                <div style={{textAlign:'right'}}>
                  <div style={{fontSize:15,fontWeight:800,color:C.ink,lineHeight:1}}>{fmtRs(amt)}</div>
                  <div style={{fontSize:9,fontWeight:700,marginTop:1,color:refunded?C.risk:paid?C.ok:C.warn}}>
                    {refunded?'\u21a9 Refunded':paid?'\u2713 Paid':'\u23f3 Unpaid'}
                  </div>
                </div>
                <div style={{fontSize:10,fontWeight:700,padding:'4px 10px',borderRadius:100,
                  background:st.bg,color:st.tx,border:`1px solid ${st.br}`,whiteSpace:'nowrap'}}>
                  {st.label}
                </div>
              </div>
            </div>
          </div>
          <div style={{display:'flex',alignItems:'center',paddingRight:10}}>
            <ChevronRight size={14} color={selected?C.gold:C.inkD}
              style={{transition:'transform 0.18s',transform:selected?'rotate(90deg)':'none'}}/>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   DetailPanel — FULL (no blank tabs)
───────────────────────────────────────────────────────────────────────── */
function DetailPanel({ booking, allStaff, onClose, onRefresh, isAdmin }) {
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [payModal, setPayModal] = useState(false);
  const [paySaving, setPaySaving] = useState(false);
  const [refModal, setRefModal] = useState(false);
  const [refSaving, setRefSaving] = useState(false);
  const [tab, setTab] = useState('details');
  const [reassignId, setReassign] = useState('');
  const [editMode, setEditMode] = useState(false);
  const [editNotes, setEditNotes] = useState(booking?.notes||'');
  const [copied, setCopied] = useState(false);
  const [toast, setToast] = useState(null);
  const [waMsg, setWaMsg] = useState(null);

  const toast$ = (t,ok=true) => { setToast({t,ok}); setTimeout(()=>setToast(null),3000); };
  const copyRef = () => { navigator.clipboard?.writeText(booking.refNo); setCopied(true); setTimeout(()=>setCopied(false),2000); };
  const phone = toWA(booking?.customer?.phone);

  const qUpdate = async (status, extra={}) => {
    setLoading(true);
    try { await api.patch(`/bookings/${booking._id}/status`,{status,...extra}); broadcastChange(); onRefresh(); toast$(`Marked: ${status}`); }
    catch(e) { toast$(e.response?.data?.message||'Failed',false); }
    setLoading(false);
  };

  const payConfirm = async method => {
    setPaySaving(true);
    try { await api.patch(`/bookings/${booking._id}/status`,{status:'completed',paymentMethod:method,paymentStatus:'paid'}); broadcastChange(); onRefresh(); setPayModal(false); toast$('Payment confirmed \u2713'); }
    catch(e) { toast$(e.response?.data?.message||'Failed',false); }
    setPaySaving(false);
  };

  const doReassign = async () => {
    if (!reassignId) return; setSaving(true);
    try { await api.patch(`/bookings/${booking._id}/assign`,{staffId:reassignId}); broadcastChange(); onRefresh(); toast$('Stylist reassigned'); setReassign(''); }
    catch(e) { toast$(e.response?.data?.message||'Failed',false); }
    setSaving(false);
  };

  const doRefund = async (refMethod, reason) => {
    setRefSaving(true);
    try { await api.post(`/bookings/${booking._id}/refund`,{refundMethod:refMethod,reason}); broadcastChange(); onRefresh(); setRefModal(false); toast$('Refund processed \u2713'); }
    catch(e) { toast$(e.response?.data?.message||'Refund failed',false); }
    setRefSaving(false);
  };

  const saveNotes = async () => {
    setSaving(true);
    try { await api.patch(`/bookings/${booking._id}/notes`,{notes:editNotes}); broadcastChange(); onRefresh(); toast$('Notes saved'); setEditMode(false); }
    catch(e) { toast$(e.response?.data?.message||'Failed',false); }
    setSaving(false);
  };

  const sendWA = text => {
    const msg = text ? text.replace('%name%',(booking.customer?.name||'Guest').split(' ')[0]) : buildWA(booking,booking.paymentMethod||'cash');
    if (!phone) { toast$('No phone number',false); return; }
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(msg)}`,'_blank');
    setWaMsg(text||'__receipt__'); setTimeout(()=>setWaMsg(null),3000);
  };

  if (!booking) return null;
  const amt = booking.finalAmount||booking.totalAmount||0;
  const disc = booking.discountAmount||0;
  const gross = booking.totalAmount||amt;
  const paid = booking.paymentStatus==='paid';
  const refunded= booking.paymentStatus==='refunded';
  const canAct = !['cancelled','no-show'].includes(booking.status);
  const st = STATUS[booking.status]||STATUS.confirmed;
  const av = avc(booking.customer?.name);
  const cn = booking.customer?.name||'Guest';
  const fillT = (tpl,n) => tpl
    .replace(/{customerName}/g,n).replace(/{salonName}/g,SN()).replace(/{service}/g,booking.service?.name||'\u2014')
    .replace(/{amount}/g,String(amt)).replace(/{date}/g,booking.date?new Date(booking.date).toLocaleDateString('en-IN',{day:'numeric',month:'short'}):'')
    .replace(/{time}/g,booking.timeSlot?.start||'').replace(/{refNo}/g,booking.refNo||'')
    .replace(/{staffName}/g,booking.staff?.name||'\u2014').replace(/{phone}/g,SP()).replace(/%name%/g,n);

  const WAS = [
    {k:'confirm',label:'\u2705 Confirmed', txt:fillT(_s.msgConfirm||`Hi %name%! Your appointment at *${SN()}* is confirmed.\nRef: ${booking.refNo||''}\nService: ${booking.service?.name||'\u2014'}\nTime: ${booking.timeSlot?.start||'\u2014'}\nSee you soon! \u{1F49B}`,cn)},
    {k:'remind', label:'\u{1F514} Reminder', txt:fillT(_s.msgRemind||`Hi %name%! Reminder \u2014 your appointment at *${SN()}* is today.\nTime: ${booking.timeSlot?.start||'\u2014'} \u{1F49B}`,cn)},
    {k:'receipt',label:'\u{1F9FE} Receipt', txt:fillT(_s.msgReceipt||buildWA(booking,booking.paymentMethod||'cash'),cn)},
    {k:'thanks', label:'\u{1F49B} Thank You',txt:fillT(`Hi %name%! Thank you for visiting *${SN()}* today. Hope you loved your service! \u{1F60A}`,cn)},
    {k:'review', label:'\u2b50 Rate Us', txt:fillT(`Hi %name%! We\u2019d love your feedback about *${SN()}*. A quick review means the world to us! \u{1F64F}`,cn)},
    {k:'rebook', label:'\u{1F4C5} Rebook', txt:fillT(`Hi %name%! Ready for your next visit at *${SN()}*? We\u2019d love to see you again! \u{1F49B}`,cn)},
  ];

  const TABS = [{k:'details',l:'Details'},{k:'actions',l:'Actions'},{k:'receipt',l:'Receipt'},{k:'whatsapp',l:'WhatsApp'}];
  const rDate = booking.date ? new Date(booking.date).toLocaleDateString('en-IN',{day:'numeric',month:'long',year:'numeric'}) : '';

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%',background:C.bg}}>
      <AnimatePresence>
        {refModal&&<RefundModal booking={booking} onClose={()=>setRefModal(false)} onConfirm={doRefund} saving={refSaving}/>}
        {payModal&&<PayModal booking={booking} onConfirm={payConfirm} onClose={()=>setPayModal(false)} saving={paySaving}/>}
      </AnimatePresence>

      {/* Header */}
      <div style={{padding:'14px 18px',borderBottom:`1px solid ${C.border}`,display:'flex',alignItems:'center',justifyContent:'space-between',flexShrink:0,
        background:`linear-gradient(180deg,#fff,${C.s1})`,boxShadow:`0 1px 0 ${C.border}`}}>
        <div>
          <div style={{fontSize:14,fontWeight:800,color:C.ink,fontFamily:"'Playfair Display',serif",letterSpacing:'-0.01em'}}>Booking Details</div>
          <div style={{fontSize:11,color:C.inkC,marginTop:1}}>{booking.date?new Date(booking.date).toLocaleDateString('en-IN',{weekday:'short',day:'numeric',month:'short'}):'\u2014'}</div>
        </div>
        <div style={{display:'flex',alignItems:'center',gap:8}}>
          <span style={{padding:'4px 12px',borderRadius:100,fontSize:11,fontWeight:700,background:st.bg,color:st.tx,border:`1px solid ${st.br}`}}>{st.label}</span>
          <button onClick={onClose} style={{width:28,height:28,borderRadius:8,border:`1px solid ${C.border}`,background:C.s2,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}><X size={13} color={C.inkC}/></button>
        </div>
      </div>

      {/* Toast */}
      <AnimatePresence>
        {toast&&<motion.div initial={{opacity:0,y:-6}} animate={{opacity:1,y:0}} exit={{opacity:0}}
          style={{margin:'8px 14px 0',padding:'8px 14px',borderRadius:10,fontSize:12,fontWeight:700,
            background:toast.ok?C.okBg:C.riskBg,color:toast.ok?C.ok:C.risk,border:`1px solid ${toast.ok?C.okBr:C.riskBr}`}}>
          {toast.t}
        </motion.div>}
      </AnimatePresence>

      {/* Tabs */}
      <div style={{display:'flex',padding:'10px 14px 0',gap:2,flexShrink:0,borderBottom:`1px solid ${C.border}`,background:C.s1}}>
        {TABS.map(({k,l})=>(
          <button key={k} onClick={()=>setTab(k)}
            style={{padding:'7px 14px',borderRadius:'9px 9px 0 0',border:'none',cursor:'pointer',fontSize:12,fontWeight:700,transition:'all 0.15s',
              background:tab===k?C.bg:'transparent',
              color:tab===k?C.ink:C.inkC,
              borderBottom:tab===k?`2.5px solid ${C.gold}`:'2.5px solid transparent'}}>
            {l}
          </button>
        ))}
      </div>

      {/* Body */}
      <div style={{flex:1,overflowY:'auto',padding:'12px 14px',minHeight:0}}>
        {tab==='details'&&(
          <div style={{background:'#fff',borderRadius:16,overflow:'hidden',border:`1.5px solid ${C.border}`,boxShadow:'0 2px 12px rgba(28,20,16,0.06)'}}>
            <div style={{display:'flex',alignItems:'center',gap:8,padding:'10px 16px',background:`linear-gradient(90deg,${C.goldFog},transparent)`,borderBottom:`1px solid ${C.border}`}}>
              <Hash size={12} color={C.gold}/><span style={{flex:1,fontSize:12,fontWeight:800,color:C.goldDeep,fontFamily:'monospace',letterSpacing:'0.04em'}}>{booking.refNo||'PENDING'}</span>
              <button onClick={copyRef} style={{display:'flex',alignItems:'center',gap:4,padding:'3px 10px',borderRadius:7,border:`1px solid ${C.border}`,background:C.s1,color:copied?C.ok:C.inkC,fontSize:10,fontWeight:700,cursor:'pointer'}}>{copied?<Check size={9}/>:<Copy size={9}/>}{copied?'Copied!':'Copy'}</button>
            </div>
            <div style={{display:'flex',alignItems:'center',gap:10,padding:'10px 16px',borderBottom:`1px solid ${C.border}`}}>
              <div style={{width:34,height:34,borderRadius:10,background:av,flexShrink:0,display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:800,color:'#fff'}}>{inits(booking.customer?.name)}</div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:14,fontWeight:700,color:C.ink}}>{booking.customer?.name||'Guest'}</div>
                {booking.customer?.phone&&<div style={{fontSize:11,color:C.inkC,display:'flex',alignItems:'center',gap:3}}><Phone size={9}/>{booking.customer.phone}</div>}
              </div>
              <span style={{fontSize:9,fontWeight:700,color:C.inkD,textTransform:'uppercase',letterSpacing:'0.08em',background:C.s1,padding:'3px 8px',borderRadius:6,border:`1px solid ${C.border}`}}>{booking.type||'online'}</span>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',borderBottom:`1px solid ${C.border}`}}>
              <div style={{padding:'10px 16px',borderRight:`1px solid ${C.border}`}}>
                <div style={{fontSize:8,fontWeight:700,color:C.inkD,textTransform:'uppercase',letterSpacing:'0.1em',marginBottom:4}}>Service</div>
                <div style={{fontSize:13,fontWeight:700,color:C.ink,lineHeight:1.3}}>{booking.service?.name||'\u2014'}</div>
                <div style={{fontSize:10,color:C.inkC}}>{booking.service?.duration||'\u2014'}min</div>
              </div>
              <div style={{padding:'10px 16px'}}>
                <div style={{fontSize:8,fontWeight:700,color:C.inkD,textTransform:'uppercase',letterSpacing:'0.1em',marginBottom:4}}>Stylist</div>
                <div style={{fontSize:13,fontWeight:700,color:C.ink}}>{booking.staff?.name||'\u2014'}</div>
                <div style={{fontSize:10,color:C.inkC}}>{booking.timeSlot?.start||'\u2014'} \u2192 {booking.timeSlot?.end||'\u2014'}</div>
              </div>
            </div>
            {booking.additionalServices?.length>0&&(
              <div style={{padding:'8px 16px',borderBottom:`1px solid ${C.border}`}}>
                <div style={{fontSize:8,fontWeight:700,color:C.inkD,textTransform:'uppercase',letterSpacing:'0.1em',marginBottom:5}}>Add-ons</div>
                {booking.additionalServices.map((sv,i)=>(
                  <div key={i} style={{display:'flex',justifyContent:'space-between',fontSize:12,color:C.inkB,paddingBottom:2}}>
                    <span>{sv.name}</span><span style={{fontWeight:700}}>{fmtRs(sv.discountPrice||sv.price||0)}</span>
                  </div>
                ))}
              </div>
            )}
            {disc>0&&<div style={{display:'flex',justifyContent:'space-between',padding:'7px 16px',borderBottom:`1px solid ${C.border}`}}><span style={{fontSize:11,color:C.inkC}}>Original</span><span style={{fontSize:11,color:C.inkC,textDecoration:'line-through'}}>{fmtRs(gross)}</span></div>}
            {disc>0&&<div style={{display:'flex',justifyContent:'space-between',padding:'7px 16px',borderBottom:`1px solid ${C.border}`}}><span style={{fontSize:11,color:C.ok}}>Discount</span><span style={{fontSize:11,fontWeight:700,color:C.ok}}>\u2212{fmtRs(disc)}</span></div>}
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'12px 16px',borderBottom:`1px solid ${C.border}`,background:`linear-gradient(90deg,${C.goldFog},transparent)`}}>
              <span style={{fontSize:15,fontWeight:800,color:C.ink}}>Total</span>
              <span style={{fontSize:28,fontWeight:900,color:C.ink,letterSpacing:'-0.02em'}}>{fmtRs(amt)}</span>
            </div>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'8px 16px',borderBottom:`1px solid ${C.border}`}}>
              <span style={{fontSize:11,color:C.inkC}}>Payment</span>
              <span style={{fontSize:12,fontWeight:800,color:refunded?C.risk:paid?C.ok:C.warn}}>
                {refunded?'\u21a9 Refunded':paid?'\u2713 Paid \u00b7 '+(booking.paymentMethod||''):'\u23f3 Unpaid'}
              </span>
            </div>
            <div style={{padding:'10px 16px'}}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:6}}>
                <span style={{fontSize:8,fontWeight:700,color:C.inkD,textTransform:'uppercase',letterSpacing:'0.1em'}}>Notes</span>
                {isAdmin&&!editMode&&<button onClick={()=>setEditMode(true)} style={{padding:'2px 9px',borderRadius:7,border:`1px solid ${C.border}`,background:C.s1,color:C.inkC,fontSize:10,fontWeight:700,cursor:'pointer',display:'flex',alignItems:'center',gap:3}}><Edit3 size={9}/>Edit</button>}
              </div>
              {editMode?(
                <div>
                  <textarea value={editNotes} onChange={e=>setEditNotes(e.target.value)} rows={2} style={{...INP,resize:'none',lineHeight:1.5,marginBottom:7}}/>
                  <div style={{display:'flex',gap:6}}>
                    <button onClick={()=>setEditMode(false)} style={{flex:1,padding:'7px',borderRadius:8,border:`1px solid ${C.border}`,background:C.s1,color:C.inkC,fontSize:11,cursor:'pointer'}}>Cancel</button>
                    <button onClick={saveNotes} disabled={saving} style={{flex:2,padding:'7px',borderRadius:8,border:'none',background:saving?C.border:C.gold,color:'#fff',fontSize:11,fontWeight:800,cursor:'pointer'}}>{saving?'Saving\u2026':'Save Notes'}</button>
                  </div>
                </div>
              ):(
                <p style={{fontSize:11,color:booking.notes?C.inkB:C.inkD,margin:0,lineHeight:1.6}}>{booking.notes||'No notes added'}</p>
              )}
            </div>
          </div>
        )}

        {tab==='actions'&&(
          <div style={{display:'flex',flexDirection:'column',gap:8}}>
            <div style={{background:'#fff',borderRadius:14,padding:'12px 14px',border:`1.5px solid ${C.border}`,boxShadow:'0 1px 4px rgba(28,20,16,0.05)'}}>
              <div style={{fontSize:9,fontWeight:700,color:C.inkD,textTransform:'uppercase',letterSpacing:'0.1em',marginBottom:10}}>Quick Actions</div>
              <div style={{display:'flex',flexDirection:'column',gap:6}}>
                {booking.status==='confirmed'&&<button onClick={()=>qUpdate('in-progress')} style={{display:'flex',alignItems:'center',gap:10,padding:'10px 14px',borderRadius:10,border:`1px solid ${C.warnBr}`,background:C.warnBg,color:C.warn,fontSize:12,fontWeight:700,width:'100%'}}><Zap size={14}/>Start Service</button>}
                {booking.status==='in-progress'&&<button onClick={()=>setPayModal(true)} style={{display:'flex',alignItems:'center',gap:10,padding:'10px 14px',borderRadius:10,border:`1px solid ${C.okBr}`,background:C.okBg,color:C.ok,fontSize:12,fontWeight:700,width:'100%'}}><CheckCircle size={14}/>Complete & Collect Payment</button>}
                {!paid&&!refunded&&canAct&&booking.status!=='in-progress'&&<button onClick={()=>setPayModal(true)} style={{display:'flex',alignItems:'center',gap:10,padding:'10px 14px',borderRadius:10,border:`1px solid ${C.blueBr}`,background:C.blueBg,color:C.blue,fontSize:12,fontWeight:700,width:'100%'}}><Wallet size={14}/>Collect Payment</button>}
                {paid&&<button onClick={()=>printR(booking,booking.paymentMethod||'cash')} style={{display:'flex',alignItems:'center',gap:10,padding:'10px 14px',borderRadius:10,border:`1px solid ${C.border}`,background:C.s1,color:C.inkB,fontSize:12,fontWeight:700,width:'100%'}}><Printer size={14}/>Print Receipt</button>}
                {(booking.status==='completed'&&paid) || (['confirmed','in-progress'].includes(booking.status)&&paid) && <button onClick={()=>setRefModal(true)} style={{display:'flex',alignItems:'center',gap:10,padding:'10px 14px',borderRadius:10,border:`1px solid ${C.riskBr}`,background:C.riskBg,color:C.risk,fontSize:12,fontWeight:700,width:'100%'}}><RotateCcw size={14}/>Issue Refund</button>}
                {canAct&&!paid&&!refunded&&<button onClick={()=>qUpdate('cancelled')} style={{display:'flex',alignItems:'center',gap:10,padding:'10px 14px',borderRadius:10,border:`1px solid ${C.riskBr}`,background:C.riskBg,color:C.risk,fontSize:12,fontWeight:700,width:'100%'}}><XCircle size={14}/>Cancel Booking</button>}
                {['confirmed','in-progress'].includes(booking.status)&&<button onClick={()=>qUpdate('no-show')} style={{display:'flex',alignItems:'center',gap:10,padding:'10px 14px',borderRadius:10,border:`1px solid rgba(107,114,128,0.20)`,background:'rgba(107,114,128,0.07)',color:'#374151',fontSize:12,fontWeight:700,width:'100%'}}><AlertTriangle size={14}/>Mark No Show</button>}
                {refunded&&<div style={{display:'flex',alignItems:'center',gap:10,padding:'10px 12px',borderRadius:10,background:C.riskBg,border:`1px solid ${C.riskBr}`}}><RotateCcw size={14} color={C.risk}/><div><div style={{fontSize:12,fontWeight:700,color:C.risk}}>Refund Issued</div><div style={{fontSize:10,color:C.inkC}}>Payment has been reversed</div></div></div>}
              </div>
            </div>
            {isAdmin&&canAct&&(
              <div style={{background:'#fff',borderRadius:14,padding:'12px 14px',border:`1.5px solid ${C.border}`,boxShadow:'0 1px 4px rgba(28,20,16,0.05)'}}>
                <div style={{fontSize:9,fontWeight:700,color:C.inkD,textTransform:'uppercase',letterSpacing:'0.1em',marginBottom:8}}>Reassign Stylist</div>
                <div style={{display:'flex',gap:8}}>
                  <select value={reassignId} onChange={e=>setReassign(e.target.value)} style={{...INP,flex:1,padding:'9px 12px'}}>
                    <option value="">Select stylist…</option>
                    {(allStaff||[]).map(s=><option key={s._id} value={s._id}>{s.name}</option>)}
                  </select>
                  <button onClick={doReassign} disabled={!reassignId||saving} style={{padding:'9px 16px',borderRadius:10,border:'none',background:reassignId?C.gold:C.border,color:reassignId?'#fff':C.inkD,fontSize:12,fontWeight:700,cursor:reassignId?'pointer':'default'}}><UserCheck size={14}/></button>
                </div>
              </div>
            )}
          </div>
        )}

        {tab==='receipt'&&(
          <div style={{display:'flex',flexDirection:'column',gap:10}}>
            <div style={{borderRadius:20,overflow:'hidden',border:`1.5px solid ${C.borderB}`,boxShadow:'0 8px 32px rgba(28,20,16,0.12)'}}>
              <div style={{background:'linear-gradient(135deg,#1C1410,#2D1E10)',padding:'20px',textAlign:'center',position:'relative'}}>
                <div style={{position:'relative'}}>
                  <div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:8,marginBottom:4}}>
                    <Scissors size={14} color={C.gold}/>
                    <span style={{fontFamily:"'Playfair Display',serif",fontSize:20,fontWeight:900,color:'#FAF3E0',letterSpacing:'0.04em'}}>{SN()}</span>
                  </div>
                  <p style={{fontSize:9,fontWeight:700,color:'rgba(255,255,255,.3)',textTransform:'uppercase',letterSpacing:'0.2em',margin:0}}>{_s.tagline}</p>
                  {booking.refNo&&<div style={{marginTop:10,display:'inline-flex',alignItems:'center',gap:6,padding:'4px 14px',borderRadius:100,background:'rgba(201,149,42,.15)',border:'1px solid rgba(201,149,42,.3)'}}><Hash size={9} color={C.goldHi}/><span style={{fontSize:10,fontWeight:800,color:C.goldHi,letterSpacing:'0.08em'}}>{booking.refNo}</span></div>}
                </div>
              </div>
              <div style={{padding:'14px 18px',background:C.s1}}>
                {[[['CUSTOMER',booking.customer?.name||'Guest'],['PHONE',booking.customer?.phone||'\u2014']],
                  [['SERVICE',booking.service?.name||'\u2014'],['STYLIST',booking.staff?.name||'\u2014']],
                  [['DATE',rDate],['TIME',booking.timeSlot?.start||'\u2014']]].map((pairs,i)=>(
                  <div key={i} style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:12}}>
                    {pairs.map(([l,v])=>(
                      <div key={l}><div style={{fontSize:8,fontWeight:700,color:C.inkD,letterSpacing:'0.12em',marginBottom:2}}>{l}</div><div style={{fontSize:12,fontWeight:700,color:C.ink}}>{v}</div></div>
                    ))}
                  </div>
                ))}
                <div style={{borderTop:`1.5px solid ${C.border}`,margin:'10px 0',paddingTop:10}}>
                  {disc>0&&<><div style={{display:'flex',justifyContent:'space-between',marginBottom:4}}><span style={{fontSize:11,color:C.inkC}}>Price</span><span style={{fontSize:11,color:C.inkC,textDecoration:'line-through'}}>{fmtRs(gross)}</span></div>
                  <div style={{display:'flex',justifyContent:'space-between',marginBottom:4}}><span style={{fontSize:11,color:C.ok}}>Discount</span><span style={{fontSize:11,fontWeight:700,color:C.ok}}>\u2212{fmtRs(disc)}</span></div></>}
                  <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginTop:8}}><span style={{fontSize:13,fontWeight:700,color:C.inkB}}>TOTAL PAID</span><span style={{fontSize:28,fontWeight:900,color:C.ink,letterSpacing:'-0.02em'}}>{fmtRs(amt)}</span></div>
                  <div style={{display:'flex',justifyContent:'space-between',marginTop:4}}><span style={{fontSize:11,color:C.inkC}}>Method</span><span style={{fontSize:11,fontWeight:700,color:C.inkB,textTransform:'capitalize'}}>{booking.paymentMethod||'\u2014'}</span></div>
                </div>
                {_s.address&&<div style={{textAlign:'center',fontSize:9,color:C.inkC,borderTop:`1px solid ${C.border}`,paddingTop:8}}>{_s.address}</div>}
              </div>
            </div>
            {paid&&<div style={{display:'flex',gap:8}}>
              <button onClick={()=>printR(booking,booking.paymentMethod||'cash')} style={{flex:1,padding:'10px',borderRadius:12,border:`1.5px solid ${C.border}`,background:'#fff',color:C.inkB,fontSize:12,fontWeight:700,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:6}}><Printer size={13}/>Print</button>
              <button onClick={()=>sendWA(null)} style={{flex:1,padding:'10px',borderRadius:12,border:'1px solid rgba(37,211,102,0.35)',background:'rgba(37,211,102,0.06)',color:'#166534',fontSize:12,fontWeight:700,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:6}}><MessageCircle size={13}/>WhatsApp</button>
            </div>}
          </div>
        )}

        {tab==='whatsapp'&&(
          <div>
            {!phone?(
              <div style={{padding:'40px 16px',textAlign:'center'}}><div style={{fontSize:36,marginBottom:10}}>📵</div><div style={{fontSize:13,fontWeight:700,color:C.inkB}}>No phone number</div><div style={{fontSize:11,color:C.inkC,marginTop:4}}>Add a phone to send WhatsApp messages</div></div>
            ):(
              <div>
                <div style={{background:'#fff',borderRadius:12,padding:'10px 14px',marginBottom:10,border:`1.5px solid ${C.border}`,display:'flex',alignItems:'center',gap:10,boxShadow:'0 1px 4px rgba(28,20,16,0.05)'}}>
                  <Phone size={13} color={C.ok}/><div><div style={{fontSize:12,fontWeight:700,color:C.ink}}>{booking.customer?.name}</div><div style={{fontSize:11,color:C.ok}}>{booking.customer?.phone}</div></div>
                </div>
                <div style={{display:'flex',flexDirection:'column',gap:5}}>
                  {paid&&<button onClick={()=>sendWA(null)} style={{display:'flex',alignItems:'center',gap:10,padding:'10px 14px',borderRadius:10,border:`1px solid ${waMsg==='__receipt__'?'rgba(22,101,52,0.3)':C.border}`,background:waMsg==='__receipt__'?C.okBg:'#fff',color:waMsg==='__receipt__'?C.ok:C.inkB,fontSize:12,fontWeight:700,width:'100%'}}><MessageCircle size={12} color={waMsg==='__receipt__'?C.ok:'#25D366'}/>Send Receipt {waMsg==='__receipt__'&&<span style={{fontSize:9,fontWeight:700}}>Sent ✓</span>}</button>}
                  {WAS.map(({k,label,txt})=><button key={k} onClick={()=>sendWA(txt)} style={{display:'flex',alignItems:'center',gap:10,padding:'10px 14px',borderRadius:10,border:`1px solid ${waMsg===txt?'rgba(22,101,52,0.3)':C.border}`,background:waMsg===txt?C.okBg:'#fff',color:waMsg===txt?C.ok:C.inkB,fontSize:12,fontWeight:700,width:'100%'}}><MessageCircle size={12} color={waMsg===txt?C.ok:'#25D366'}/>{label} {waMsg===txt&&<span style={{fontSize:9,fontWeight:700}}>Sent ✓</span>}</button>)}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function ABt({ icon:Ic, label, c, bg, br, onClick, dis }) {
  return (
    <button onClick={onClick} disabled={dis}
      style={{display:'flex',alignItems:'center',gap:10,padding:'10px 14px',borderRadius:10,border:`1px solid ${br}`,background:bg,color:c,fontSize:12,fontWeight:700,cursor:dis?'not-allowed':'pointer',opacity:dis?0.5:1,width:'100%'}}>
      <Ic size={14}/>{label}
    </button>
  );
}

function WABt({ label, sent, onClick }) {
  return (
    <button onClick={onClick}
      style={{display:'flex',alignItems:'center',gap:10,padding:'10px 14px',borderRadius:10,
        border:`1px solid ${sent?'rgba(22,101,52,0.3)':C.border}`,
        background:sent?C.okBg:'#fff',color:sent?C.ok:C.inkB,
        fontSize:12,fontWeight:700,cursor:'pointer',width:'100%'}}>
      <MessageCircle size={12} color={sent?C.ok:'#25D366'}/><span style={{flex:1}}>{label}</span>
      {sent&&<span style={{fontSize:9,fontWeight:700}}>Sent ✓</span>}
    </button>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   WalkInDrawer
───────────────────────────────────────────────────────────────────────── */
function WalkInDrawer({ open, onClose, staff, services, onCreated }) {
  const [form,setForm] = useState({customerSearch:'',customerPhone:'',customerName:'',serviceId:'',staffId:'',discountPct:'',notes:''});
  const [custs,setCusts] = useState([]);
  const [svc,setSvc] = useState(null);
  const [svcQ,setSvcQ] = useState('');
  const [saving,setSaving]= useState(false);
  const [toast,setToast] = useState(null);
  const timer = useRef(null);
  const toast$ = (t,ok=true) => { setToast({t,ok}); setTimeout(()=>setToast(null),3000); };

  useEffect(()=>{
    clearTimeout(timer.current);
    const q=form.customerSearch;
    if(!q||q.length<2){setCusts([]);return;}
    timer.current=setTimeout(async()=>{
      try{const{data}=await api.get('/users',{params:{role:'customer',search:q,limit:6}});setCusts(data.users||[]);}
      catch{setCusts([]);}
    },300);
  },[form.customerSearch]);

  const computeFinal=()=>{ if(!svc)return 0; const base=svc.discountPrice||svc.price||0; return Math.max(0,base-Math.round(base*(parseFloat(form.discountPct)||0)/100)); };

  const submit=async()=>{
    if(!form.serviceId){toast$('Select a service',false);return;}
    if(!form.customerName.trim()){toast$('Enter customer name',false);return;}
    setSaving(true);
    try{
      const{data}=await api.post('/bookings/walk-in',{serviceId:form.serviceId,customerName:form.customerName,customerPhone:form.customerPhone||undefined,staffId:form.staffId||undefined,notes:form.notes,manualDiscountPercent:parseFloat(form.discountPct)||undefined});
      broadcastChange();toast$(`Created${data.booking?.refNo?' \u00b7 '+data.booking.refNo:''}!`);onCreated?.();onClose();
      setForm({customerSearch:'',customerPhone:'',customerName:'',serviceId:'',staffId:'',discountPct:'',notes:''});setSvc(null);setSvcQ('');
    }catch(e){toast$(e.response?.data?.message||'Failed',false);}
    setSaving(false);
  };

  if (!open) return null;
  return (
    <AnimatePresence>
      <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={onClose}
        style={{position:'fixed',inset:0,background:'rgba(28,20,16,0.45)',backdropFilter:'blur(4px)',zIndex:400}}/>
      <motion.div initial={{x:'100%'}} animate={{x:0}} exit={{x:'100%'}} transition={{type:'spring',damping:28,stiffness:300}}
        style={{position:'fixed',top:0,right:0,bottom:0,width:'92%',maxWidth:480,background:C.bg,zIndex:401,display:'flex',flexDirection:'column',borderLeft:`1.5px solid ${C.borderB}`,boxShadow:'-8px 0 48px rgba(28,20,16,0.18)'}}>
        <div style={{padding:'18px 22px',borderBottom:`1px solid ${C.border}`,display:'flex',justifyContent:'space-between',alignItems:'center',flexShrink:0,background:`linear-gradient(180deg,#fff,${C.s1})`}}>
          <div>
            <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:18,fontWeight:800,color:C.ink,margin:0}}>New Walk-in</h2>
            <p style={{fontSize:11,color:C.inkC,margin:'3px 0 0'}}>Ref number auto-assigned on creation</p>
          </div>
          <button onClick={onClose} style={{width:32,height:32,borderRadius:10,border:`1px solid ${C.border}`,background:C.s2,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}><X size={15} color={C.inkC}/></button>
        </div>
        {toast&&<div style={{margin:'8px 16px 0',padding:'8px 14px',borderRadius:10,fontSize:12,fontWeight:700,background:toast.ok?C.okBg:C.riskBg,color:toast.ok?C.ok:C.risk,border:`1px solid ${toast.ok?C.okBr:C.riskBr}`}}>{toast.t}</div>}
        <div style={{flex:1,overflowY:'auto',padding:'18px 22px'}}>
          <div style={{marginBottom:16}}>
            <label style={{display:'block',fontSize:10,fontWeight:700,color:C.inkC,textTransform:'uppercase',letterSpacing:'0.1em',marginBottom:7}}>Customer *</label>
            <div style={{position:'relative'}}>
              <input value={form.customerSearch} onChange={e=>{setForm(f=>({...f,customerSearch:e.target.value,customerName:e.target.value,customerPhone:''}));setCusts([]);}} placeholder="Search or type new name…" style={INP}/>
              {custs.length>0&&<div style={{position:'absolute',top:'100%',left:0,right:0,background:'#fff',border:`1.5px solid ${C.borderB}`,borderRadius:12,boxShadow:'0 12px 32px rgba(28,20,16,0.14)',zIndex:10,marginTop:4,overflow:'hidden'}}>
                {custs.map(cu=>{const d=(cu.phone||'').replace(/\D/g,'');const ph=d.length===12&&d.startsWith('91')?d.slice(2):d.length===11&&d.startsWith('0')?d.slice(1):d;return(
                  <div key={cu._id} onClick={()=>{setForm(f=({...f,customerName:cu.name,customerSearch:cu.name,customerPhone:ph.slice(0,10)}));setCusts([]);}}
                    style={{padding:'10px 14px',cursor:'pointer',display:'flex',alignItems:'center',gap:10,borderBottom:`1px solid ${C.border}`}}>
                    <div style={{width:28,height:28,borderRadius:8,background:avc(cu.name),display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:700,color:'#fff'}}>{inits(cu.name)}</div>
                    <div><div style={{fontSize:13,fontWeight:700,color:C.ink}}>{cu.name}</div><div style={{fontSize:11,color:C.inkC}}>{cu.phone||cu.email}</div></div>
                  </div>
                );})}
              </div>}
            </div>
            <div style={{display:'flex',marginTop:8,borderRadius:10,border:`1.5px solid ${C.border}`,overflow:'hidden'}}>
              <div style={{padding:'10px 12px',background:C.s2,fontSize:13,fontWeight:700,color:C.inkC,borderRight:`1px solid ${C.border}`}}>+91</div>
              <input value={form.customerPhone} onChange={e=>{let d=e.target.value.replace(/\D/g,'');if(d.startsWith('91')&&d.length>10)d=d.slice(2);if(d.startsWith('0'))d=d.slice(1);setForm(f=({...f,customerPhone:d.slice(0,10)}));}} placeholder="10-digit mobile" maxLength={10} inputMode="numeric" style={{flex:1,padding:'10px 12px',border:'none',background:'#fff',fontSize:13,color:C.ink,outline:'none'}}/>
            </div>
          </div>
          <div style={{marginBottom:16}}>
            <label style={{display:'block',fontSize:10,fontWeight:700,color:C.inkC,textTransform:'uppercase',letterSpacing:'0.1em',marginBottom:7}}>Service *</label>
            {svc?(
              <div style={{display:'flex',alignItems:'center',gap:10,padding:'11px 14px',borderRadius:12,background:C.goldFog,border:`1.5px solid ${C.goldDeep}33`}}>
                <Scissors size={14} color={C.gold}/>
                <div style={{flex:1}}><div style={{fontSize:13,fontWeight:700,color:C.ink}}>{svc.name}</div><div style={{fontSize:11,color:C.inkC}}>{fmtRs(svc.discountPrice||svc.price)} \u00b7 {svc.duration}min</div></div>
                <button onClick={()=>{setSvc(null);setForm(f=({...f,serviceId:''}));setSvcQ('');}} style={{padding:4,border:'none',background:'none',cursor:'pointer'}}><X size={13} color={C.inkC}/></button>
              </div>
            ):(
              <>
                <input value={svcQ} onChange={e=>setSvcQ(e.target.value)} placeholder="Search service…" style={{...INP,marginBottom:6}}/>
                <div style={{maxHeight:180,overflowY:'auto',border:`1.5px solid ${C.border}`,borderRadius:12,overflow:'hidden',background:'#fff',boxShadow:'0 2px 8px rgba(28,20,16,0.06)'}}>
                  {(services||[]).filter(s=>!svcQ||s.name.toLowerCase().includes(svcQ.toLowerCase())).slice(0,8).map(s=>(
                    <div key={s._id} onClick={()=>{setSvc(s);setForm(f=({...f,serviceId:s._id}));}}
                      style={{padding:'10px 14px',cursor:'pointer',display:'flex',justifyContent:'space-between',borderBottom:`1px solid ${C.border}`}}>
                      <div><div style={{fontSize:13,fontWeight:700,color:C.ink}}>{s.name}</div><div style={{fontSize:11,color:C.inkC}}>{s.category} \u00b7 {s.duration}min</div></div>
                      <div style={{fontSize:13,fontWeight:700,color:C.goldDeep}}>{fmtRs(s.discountPrice||s.price)}</div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:16}}>
            <div>
              <label style={{display:'block',fontSize:10,fontWeight:700,color:C.inkC,textTransform:'uppercase',letterSpacing:'0.1em',marginBottom:7}}>Assign Stylist</label>
              <select value={form.staffId} onChange={e=>setForm(f=({...f,staffId:e.target.value}))} style={{...INP,padding:'10px 12px'}}>
                <option value="">Auto-assign</option>
                {(staff||[]).map(s=><option key={s._id} value={s._id}>{s.name}</option>)}
              </select>
            </div>
            <div>
              <label style={{display:'block',fontSize:10,fontWeight:700,color:C.inkC,textTransform:'uppercase',letterSpacing:'0.1em',marginBottom:7}}>Discount %</label>
              <input type="number" min="0" max="50" value={form.discountPct} onChange={e=>setForm(f=({...f,discountPct:e.target.value}))} placeholder="0" style={{...INP,padding:'10px 12px'}}/>
            </div>
          </div>
          {svc&&<div style={{background:C.goldFog,borderRadius:14,padding:'14px',marginBottom:16,border:`1.5px solid ${C.goldDeep}33`,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
            <span style={{fontSize:13,fontWeight:700,color:C.inkB}}>Customer Pays</span>
            <span style={{fontSize:28,fontWeight:900,color:C.ink,letterSpacing:'-0.02em'}}>{fmtRs(computeFinal())}</span>
          </div>}
          <div>
            <label style={{display:'block',fontSize:10,fontWeight:700,color:C.inkC,textTransform:'uppercase',letterSpacing:'0.1em',marginBottom:7}}>Notes</label>
            <input value={form.notes} onChange={e=>setForm(f=({...f,notes:e.target.value}))} placeholder="Special instructions…" style={INP}/>
          </div>
        </div>
        <div style={{padding:'14px 22px',borderTop:`1px solid ${C.border}`,display:'flex',gap:10,flexShrink:0,background:`linear-gradient(180deg,${C.s1},${C.bg})`}}>
          <button onClick={onClose} style={{flex:1,padding:'12px',borderRadius:100,border:`1px solid ${C.border}`,background:'#fff',color:C.inkC,fontSize:13,fontWeight:700,cursor:'pointer'}}>Cancel</button>
          <button onClick={submit} disabled={saving}
            style={{flex:2,padding:'12px',borderRadius:100,border:'none',background:saving?C.border:C.gold,color:'#fff',fontSize:13,fontWeight:800,cursor:saving?'not-allowed':'pointer'}}>
            {saving?'Creating…':`Create${svc?` \u00b7 ${fmtRs(computeFinal())}`:''}`}
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   MAIN COMPONENT — SPLIT VIEW
───────────────────────────────────────────────────────────────────────── */
export default function AdminAppointments() {
  const { staff:dsStaff, services } = useDataStore();
  const [bookings, setBookings] = useState([]);
  const [fetching, setFetching] = useState(false);
  const [date, setDate] = useState(todayS());
  const [search, setSearch] = useState('');
  const [statusF, setStatusF] = useState('all');
  const [staffF, setStaffF] = useState('all');
  const [selectedId, setSelectedId] = useState(null);
  const [walkIn, setWalkIn] = useState(false);
  const [toast, setToast] = useState(null);
  const [isDesktop, setIsDesktop] = useState(window.innerWidth >= 1024);
  const [, rerender] = useState(0);

  const toast$ = (t,ok=true) => { setToast({t,ok}); setTimeout(()=>setToast(null),3200); };

  useEffect(()=>{
    loadS().then(()=>rerender(n=>n+1));
    let ch; try{ch=new BroadcastChannel('glamour_settings_sync');ch.onmessage=()=>loadS().then(()=>rerender(n=>n+1));}catch{}
    return()=>{try{ch?.close();}catch{}};
  },[]);

  useEffect(()=>{
    const h=()=>setIsDesktop(window.innerWidth>=1024);
    window.addEventListener('resize',h); return()=>window.removeEventListener('resize',h);
  },[]);

  const fetchB = useCallback(async()=>{
    setFetching(true);
    try{
      const params={date,limit:200};
      const upper=search.toUpperCase().trim();
      if(upper.startsWith('GS-')) params.refNo=upper;
      const{data}=await api.get('/bookings',{params});
      setBookings(data.bookings||[]);
    }catch{setBookings([]);}
    setFetching(false);
  },[date,search]);

  useEffect(()=>{fetchB();},[fetchB]);
  useEffect(()=>{const t=setInterval(fetchB,30000);return()=>clearInterval(t);},[fetchB]);

  const filtered = bookings.filter(b=>{
    if(statusF!=='all'&&b.status!==statusF)return false;
    if(staffF!=='all'&&(b.staff?._id||b.staff)!==staffF)return false;
    const q=search.toLowerCase();if(!q)return true;
    if(q.startsWith('gs-'))return(b.refNo||'').toLowerCase().includes(q);
    return(b.customer?.name||'').toLowerCase().includes(q)||(b.service?.name||'').toLowerCase().includes(q)||(b.staff?.name||'').toLowerCase().includes(q)||(b.refNo||'').toLowerCase().includes(q);
  }).sort((a,b)=>(a.timeSlot?.start||'').localeCompare(b.timeSlot?.start||''));

  const stats = {
    total: bookings.length,
    completed: bookings.filter(b=>b.status==='completed').length,
    inProgress:bookings.filter(b=>b.status==='in-progress').length,
    revenue: bookings.filter(b=>b.paymentStatus==='paid').reduce((s,b)=>s+(b.finalAmount||b.totalAmount||0),0),
    unpaid: bookings.filter(b=>b.paymentStatus!=='paid'&&!['cancelled','no-show'].includes(b.status)).length,
  };

  const selectedB = bookings.find(b=>b._id===selectedId)||null;
  const safeStaff = dsStaff||[];
  const isSplit = isDesktop && !!selectedB;

  const doExport=()=>{
    const rows=filtered.map(b=>({'Ref No':b.refNo||'',Date:date,Time:b.timeSlot?.start||'',Customer:b.customer?.name||'Guest',Phone:b.customer?.phone||'',Service:b.service?.name||'',Stylist:b.staff?.name||'','Total (\u20b9)':b.totalAmount||0,'Discount (\u20b9)':b.discountAmount||0,'Net (\u20b9)':b.finalAmount||b.totalAmount||0,Status:b.status,'Pay Status':b.paymentStatus,'Pay Method':b.paymentMethod||''}));
    exportCSV(rows,['Ref No','Date','Time','Customer','Phone','Service','Stylist','Total (\u20b9)','Discount (\u20b9)','Net (\u20b9)','Status','Pay Status','Pay Method'],`appointments_${date}.csv`);
  };

  const SPILLS = ['all','confirmed','in-progress','completed','cancelled','no-show','pending'];

  return (
    <div style={{fontFamily:'DM Sans,sans-serif',height:'100vh',background:C.bg,display:'flex',flexDirection:'column',overflow:'hidden',color:C.ink}}>
      {/* BLACK HEADER */}
      <div style={{background:'#2D1E10',borderBottom:'1.5px solid #1a1008',flexShrink:0,boxShadow:'0 2px 16px rgba(14,10,6,0.3)'}}>
        <div style={{padding:'10px 20px 8px',display:'flex',alignItems:'center',justifyContent:'space-between',gap:12,flexWrap:'wrap'}}>
          <div style={{display:'flex',alignItems:'center',gap:12,flexWrap:'wrap'}}>
            <h1 style={{fontFamily:"'Playfair Display',serif",fontSize:18,fontWeight:900,color:'#FAF3E0',margin:0,letterSpacing:'-0.01em'}}>Appointments</h1>
            <span style={{fontSize:11,color:'rgba(250,243,224,0.5)',fontWeight:600}}>
              {new Date(date).toLocaleDateString('en-IN',{weekday:'short',day:'numeric',month:'short',year:'numeric'})}
            </span>
            <div style={{display:'flex',gap:4,flexWrap:'wrap'}}>
              {[
                {v:stats.total, l:'Total', c:'#C9A84C'},
                {v:stats.inProgress,l:'Active', c:'#6EE7B7', hide:!stats.inProgress},
                {v:stats.completed, l:'Done', c:'#93C5FD'},
                {v:stats.unpaid, l:'Unpaid', c:'#FCA5A5', hide:!stats.unpaid},
                {v:fmtRs(stats.revenue),l:'Revenue',c:'#C9A84C'},
              ].filter(x=>!x.hide).map(({v,l,c})=>(
                <span key={l} style={{padding:'2px 9px',borderRadius:100,background:'rgba(255,255,255,0.08)',border:'1px solid rgba(255,255,255,0.12)',fontSize:10,fontWeight:700}}>
                  <span style={{color:c}}>{v}</span><span style={{color:'rgba(255,255,255,0.35)',marginLeft:3}}>{l}</span>
                </span>
              ))}
            </div>
          </div>
          <div style={{display:'flex',gap:6,alignItems:'center'}}>
            <button onClick={doExport} disabled={!filtered.length}
              style={{display:'flex',alignItems:'center',gap:5,padding:'6px 13px',borderRadius:100,border:'1px solid rgba(255,255,255,0.15)',background:'rgba(255,255,255,0.08)',color:'rgba(255,255,255,0.7)',fontSize:11,fontWeight:700,cursor:'pointer',opacity:filtered.length?1:0.4}}>
              <Download size={11}/>Export
            </button>
            <motion.button onClick={()=>setWalkIn(true)} whileHover={{scale:1.03}} whileTap={{scale:0.97}}
              style={{display:'flex',alignItems:'center',gap:6,padding:'7px 15px',borderRadius:100,background:C.gold,color:'#fff',fontSize:12,fontWeight:800,cursor:'pointer',border:'none',boxShadow:'0 3px 12px rgba(184,134,11,0.4)'}}>
              <Plus size={13}/>New Walk-in
            </motion.button>
          </div>
        </div>
        <div style={{padding:'0 20px 8px',display:'flex',gap:6,flexWrap:'wrap',alignItems:'center'}}>
          <div style={{position:'relative',flex:1,minWidth:180}}>
            <Search size={11} style={{position:'absolute',left:10,top:'50%',transform:'translateY(-50%)',color:'rgba(255,255,255,0.3)'}}/>
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search name, ref (GS-…)"
              style={{...INP,paddingLeft:30,paddingRight:10,paddingTop:7,paddingBottom:7,borderRadius:100,fontSize:12,background:'rgba(255,255,255,0.08)',border:'1px solid rgba(255,255,255,0.15)',color:'#FAF3E0'}}/>
          </div>
          <input type="date" value={date} onChange={e=>setDate(e.target.value)}
            style={{...INP,width:'auto',padding:'7px 12px',borderRadius:100,fontSize:11,background:'rgba(255,255,255,0.08)',border:'1px solid rgba(255,255,255,0.15)',color:'#FAF3E0',colorScheme:'dark'}}/>
          <select value={staffF} onChange={e=>setStaffF(e.target.value)}
            style={{...INP,width:'auto',padding:'7px 12px',borderRadius:100,fontSize:11,background:'rgba(255,255,255,0.08)',border:'1px solid rgba(255,255,255,0.15)',color:'#FAF3E0'}}>
            <option value="all" style={{background:'#2D1E10'}}>All Stylists</option>
            {safeStaff.map(s=><option key={s._id} value={s._id} style={{background:'#2D1E10'}}>{s.name}</option>)}
          </select>
          <button onClick={fetchB} style={{width:32,height:32,borderRadius:'50%',border:'1px solid rgba(255,255,255,0.15)',background:'rgba(255,255,255,0.08)',color:'rgba(255,255,255,0.6)',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}>
            <RefreshCw size={12}/>
          </button>
        </div>
        <div style={{padding:'0 20px 8px',display:'flex',gap:3,overflowX:'auto'}}>
          {SPILLS.map(key=>{
            const meta=STATUS[key];
            const cnt=key==='all'?bookings.length:bookings.filter(b=>b.status===key).length;
            const active=statusF===key;
            return (
              <button key={key} onClick={()=>setStatusF(key)}
                style={{display:'flex',alignItems:'center',gap:5,padding:'4px 12px',borderRadius:100,
                  border:`1px solid ${active?meta.dot+'55':'rgba(255,255,255,0.12)'}`,
                  background:active?meta.bg:'rgba(255,255,255,0.06)',
                  color:active?meta.tx:'rgba(255,255,255,0.55)',
                  fontSize:10,fontWeight:700,cursor:'pointer',whiteSpace:'nowrap'}}>
                <div style={{width:5,height:5,borderRadius:'50%',background:active?meta.dot:'rgba(255,255,255,0.3)',flexShrink:0}}/>
                {meta.label}
                {cnt>0&&<span style={{fontSize:9,padding:'1px 5px',borderRadius:100,background:'rgba(0,0,0,0.2)',color:active?meta.tx:'rgba(255,255,255,0.4)',fontWeight:800}}>{cnt}</span>}
              </button>
            );
          })}
        </div>
      </div>

      {/* Toast */}
      <AnimatePresence>
        {toast&&<motion.div initial={{opacity:0,y:-8}} animate={{opacity:1,y:0}} exit={{opacity:0}}
          style={{margin:'8px 24px 0',padding:'10px 16px',borderRadius:12,fontSize:13,fontWeight:700,flexShrink:0,
            background:toast.ok?C.okBg:C.riskBg,color:toast.ok?C.ok:C.risk,border:`1px solid ${toast.ok?C.okBr:C.riskBr}`}}>
          {toast.t}
        </motion.div>}
      </AnimatePresence>

      {/* SPLIT CONTENT */}
      <div style={{flex:1,display:'flex',overflow:'hidden',minHeight:0}}>
        <div style={{
          flex: isSplit ? '0 0 420px' : 1,
          overflowY:'auto',
          padding:'12px 20px 80px',
          transition:'flex 0.4s cubic-bezier(0.23,1,0.32,1)',
          borderRight: isSplit ? `1.5px solid ${C.border}` : 'none',
        }}>
          {fetching ? (
            <div style={{padding:'60px 0',textAlign:'center'}}>
              <motion.div animate={{rotate:360}} transition={{repeat:Infinity,duration:1,ease:'linear'}} style={{display:'inline-block'}}>
                <RefreshCw size={22} color={C.inkD}/>
              </motion.div>
              <p style={{color:C.inkC,fontSize:13,marginTop:10}}>Loading appointments…</p>
            </div>
          ) : filtered.length===0 ? (
            <div style={{padding:'80px 20px',textAlign:'center'}}>
              <Calendar size={40} color={C.s3} style={{marginBottom:12}}/>
              <p style={{color:C.inkB,fontSize:15,fontWeight:700,margin:'0 0 6px'}}>No appointments</p>
              <p style={{color:C.inkC,fontSize:12,margin:0}}>Try different filters or select another date</p>
            </div>
          ) : (
            <AnimatePresence>
              {filtered.map((b,i)=>(
                <BookingCard key={b._id} booking={b}
                  selected={selectedId===b._id}
                  onSelect={()=>setSelectedId(selectedId===b._id?null:b._id)}
                  isLast={i===filtered.length-1}/>
              ))}
            </AnimatePresence>
          )}
        </div>

        {isSplit && (
          <div style={{flex:1,display:'flex',flexDirection:'column',overflow:'hidden',background:C.bg}}>
            <DetailPanel booking={selectedB} allStaff={safeStaff} onClose={()=>setSelectedId(null)} onRefresh={fetchB} isAdmin={true}/>
          </div>
        )}
      </div>

      {/* MOBILE OVERLAY */}
      <AnimatePresence>
        {!isDesktop && selectedB && (
          <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}
            onClick={()=>setSelectedId(null)}
            style={{position:'fixed',inset:0,zIndex:9999,background:'rgba(14,10,6,0.72)',backdropFilter:'blur(10px)',display:'flex',alignItems:'center',justifyContent:'center',padding:'24px'}}>
            <motion.div onClick={e=>e.stopPropagation()}
              initial={{opacity:0,scale:0.92,y:24}} animate={{opacity:1,scale:1,y:0}} exit={{opacity:0,scale:0.92,y:24}}
              style={{width:'100%',maxWidth:540,maxHeight:'88vh',borderRadius:20,overflow:'hidden',boxShadow:'0 48px 120px rgba(14,10,6,0.55)',background:C.bg}}>
              <DetailPanel booking={selectedB} allStaff={safeStaff} onClose={()=>setSelectedId(null)} onRefresh={fetchB} isAdmin={true}/>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <WalkInDrawer open={walkIn} onClose={()=>setWalkIn(false)} staff={safeStaff} services={services||[]} onCreated={fetchB}/>
    </div>
  );
}