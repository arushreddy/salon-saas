// server/src/routes/public.routes.js
// No JWT required — salon resolved from X-Salon-Slug header or subdomain
const express = require('express');
const router  = express.Router();
const { resolveTenant, planGuard } = require('../middlewares/tenant.middleware');
const Service  = require('../models/Service');
const Staff    = require('../models/Staff');
const Salon    = require('../models/Salon');
const SalonSettings = require('../models/SalonSettings');
const Booking  = require('../models/Booking');
const User     = require('../models/User');
const { AppError } = require('../middlewares/errorHandler');

// All public routes resolve tenant first
router.use(resolveTenant);

// ── GET /api/public/salon-info ─────────────────────────────────────────────
// Returns public-facing salon details (name, tagline, logo, phone, address)
router.get('/salon-info', async (req, res, next) => {
  try {
    const [salon, settings] = await Promise.all([
      Salon.findById(req.salonId)
        .select('name slug logo phone email address plan features')
        .lean(),
      SalonSettings.findOne({ salonId: req.salonId })
        .select('salonName tagline phone email address logo openingTime closingTime')
        .lean(),
    ]);
    if (!salon) throw new AppError('Salon not found', 404);
    res.json({
      success: true,
      salon: {
        name:       settings?.salonName || salon.name,
        tagline:    settings?.tagline   || '',
        logo:       settings?.logo      || salon.logo || '',
        phone:      settings?.phone     || salon.phone || '',
        email:      salon.email || '',
        address:    salon.address || {},
        slug:       salon.slug,
        features:   salon.features,
        plan:       salon.plan,
      },
    });
  } catch (e) { next(e); }
});

// ── GET /api/public/services ───────────────────────────────────────────────
router.get('/services', planGuard('onlineBooking'), async (req, res, next) => {
  try {
    const services = await Service.find({ salonId: req.salonId, isActive: true })
      .select('name category price duration description')
      .sort({ category: 1, name: 1 })
      .lean();
    res.json({ success: true, services });
  } catch (e) { next(e); }
});

// ── GET /api/public/staff ──────────────────────────────────────────────────
router.get('/staff', planGuard('onlineBooking'), async (req, res, next) => {
  try {
    const staff = await Staff.find({ salonId: req.salonId, isActive: true })
      .select('name designation photo specialties')
      .lean();
    res.json({ success: true, staff });
  } catch (e) { next(e); }
});

// ── GET /api/public/timeslots ──────────────────────────────────────────────
// query: date, serviceId, staffId (optional)
router.get('/timeslots', planGuard('onlineBooking'), async (req, res, next) => {
  try {
    const { date, serviceId, staffId } = req.query;
    if (!date || !serviceId) throw new AppError('date and serviceId are required', 400);

    const service = await Service.findOne({ _id: serviceId, salonId: req.salonId }).lean();
    if (!service) throw new AppError('Service not found', 404);

    const addMins = (t, m) => {
      const [h, mn] = t.split(':').map(Number);
      const total = h * 60 + mn + m;
      return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
    };
    const overlap = (as, ae, bs, be) => as < be && ae > bs;
    const start = new Date(date); start.setHours(0,0,0,0);
    const end   = new Date(date); end.setHours(23,59,59,999);

    const filter = {
      salonId: req.salonId,
      date: { $gte: start, $lte: end },
      status: { $nin: ['cancelled', 'no-show'] },
    };
    if (staffId) filter.staff = staffId;

    const existing = await Booking.find(filter).lean();
    const staffCount = await Staff.countDocuments({ salonId: req.salonId, isActive: true });
    const maxPerSlot = staffId ? 1 : Math.max(1, staffCount);

    const allSlots = [];
    for (let h = 9; h < 21; h++)
      for (let m = 0; m < 60; m += 30)
        allSlots.push(`${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`);

    const now = new Date();
    const isToday = new Date(date).toDateString() === now.toDateString();

    const available = allSlots.filter(slot => {
      const slotEnd = addMins(slot, service.duration);
      if (slotEnd > '21:00') return false;
      if (isToday) {
        const nowStr = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
        if (slot <= nowStr) return false;
      }
      const blocked = existing.filter(b =>
        b.timeSlot?.start && overlap(slot, slotEnd, b.timeSlot.start, b.timeSlot.end)
      ).length;
      return blocked < maxPerSlot;
    });

    res.json({
      success: true,
      slots: available.map(s => {
        const slotEnd = addMins(s, service.duration);
        const [h] = s.split(':').map(Number);
        const dh  = h > 12 ? h - 12 : h === 0 ? 12 : h;
        return {
          start: s, end: slotEnd,
          display: `${dh}:${s.split(':')[1]} ${h >= 12 ? 'PM' : 'AM'}`,
        };
      }),
    });
  } catch (e) { next(e); }
});

// ── POST /api/public/book ──────────────────────────────────────────────────
// Creates a booking. Customer must be logged in (customerToken optional here).
// For Phase 5 we support guest bookings identified by phone.
router.post('/book', planGuard('onlineBooking'), async (req, res, next) => {
  try {
    const {
      serviceId, staffId, date, timeSlot,
      customerName, customerPhone, customerEmail, notes,
    } = req.body;

    if (!serviceId || !date || !timeSlot?.start || !customerName || !customerPhone)
      throw new AppError('serviceId, date, timeSlot, customerName and customerPhone are required', 400);

    const service = await Service.findOne({ _id: serviceId, salonId: req.salonId }).lean();
    if (!service) throw new AppError('Service not found', 404);

    // Find or create a customer user record
    let customer = await User.findOne({ phone: customerPhone, salonId: req.salonId, role: 'customer' });
    if (!customer) {
      customer = await User.create({
        name:     customerName,
        phone:    customerPhone,
        email:    customerEmail || '',
        role:     'customer',
        salonId:  req.salonId,
        password: customerPhone, // temp password = phone number
        isActive: true,
      });
    }

    const addMins = (t, m) => {
      const [h, mn] = t.split(':').map(Number);
      const total = h * 60 + mn + m;
      return `${String(Math.floor(total/60)).padStart(2,'0')}:${String(total%60).padStart(2,'0')}`;
    };

    const bookingDate = new Date(date);
    const refNo = `PB-${Date.now().toString(36).toUpperCase()}`;

    const booking = await Booking.create({
      salonId:     req.salonId,
      franchiseId: req.franchiseId || null,
      customer:    customer._id,
      service:     serviceId,
      staff:       staffId || null,
      date:        bookingDate,
      timeSlot: {
        start: timeSlot.start,
        end:   timeSlot.end || addMins(timeSlot.start, service.duration),
      },
      status:        'confirmed',
      source:        'online',
      notes:         notes || '',
      refNo,
      finalAmount:   service.price,
      paymentStatus: 'pending',
    });

    // Get salon admin phone for WhatsApp notification
    const salonSettings = await SalonSettings.findOne({ salonId: req.salonId })
      .select('phone phoneNumbers salonName')
      .lean();
    const adminPhone = salonSettings?.phone ||
      salonSettings?.phoneNumbers?.[0]?.number || '';

    res.status(201).json({
      success: true,
      message: 'Booking confirmed!',
      booking: {
        _id:             booking._id,
        refNo,
        service:         service.name,
        date,
        timeSlot:        booking.timeSlot,
        status:          'confirmed',
        customerPhone:   customerPhone,
        customerName,
        salonName:       salonSettings?.salonName || req.salonData?.name,
        salonAdminPhone: adminPhone,
        amount:          service.price,
      },
    });
  } catch (e) { next(e); }
});

// ── GET /api/public/bookings?phone=xxx ────────────────────────────────────
// Let customer check their booking status by phone
router.get('/bookings', planGuard('onlineBooking'), async (req, res, next) => {
  try {
    const { phone, refNo } = req.query;
    if (!phone && !refNo) throw new AppError('phone or refNo required', 400);

    const filter = { salonId: req.salonId };
    if (refNo) {
      filter.refNo = refNo.toUpperCase();
    } else {
      const customer = await User.findOne({ phone, salonId: req.salonId, role: 'customer' });
      if (!customer) return res.json({ success: true, bookings: [] });
      filter.customer = customer._id;
    }

    const bookings = await Booking.find(filter)
      .populate('service', 'name price duration')
      .populate('staff', 'name')
      .sort({ date: -1 })
      .limit(10)
      .lean();

    res.json({ success: true, bookings });
  } catch (e) { next(e); }
});

module.exports = router;