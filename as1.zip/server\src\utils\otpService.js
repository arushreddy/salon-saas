// server/src/utils/otpService.js
// Sends OTP via:
//   SMS   → Fast2SMS (India) — set FAST2SMS_API_KEY in .env
//   Email → Gmail SMTP via Nodemailer — set GMAIL_USER + GMAIL_APP_PASSWORD in .env
//
// Dev fallback: if no keys set, OTP is printed to server console only.

const crypto   = require('crypto');
const OTP      = require('../models/OTP');

// ── Generate a 6-digit OTP ─────────────────────────────────────────────────
const generateOTP = () => String(Math.floor(100000 + Math.random() * 900000));

// ── Send SMS via Fast2SMS ──────────────────────────────────────────────────
const sendSMS = async (phone, otp) => {
  const apiKey = process.env.FAST2SMS_API_KEY;

  if (!apiKey) {
    // Dev mode — log to console
    console.log(`\n[OTP DEV] SMS to ${phone}: ${otp}\n`);
    return true;
  }

  // Normalize phone — strip +91 prefix if present
  const mobile = String(phone).replace(/^\+?91/, '').replace(/\D/g, '');

  const res = await fetch('https://www.fast2sms.com/dev/bulkV2', {
    method: 'POST',
    headers: {
      authorization: apiKey,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      route:    'otp',
      variables_values: otp,
      numbers:  mobile,
    }),
  });

  const data = await res.json();
  if (!data.return) throw new Error(data.message || 'SMS failed');
  return true;
};

// ── Send Email via Nodemailer ──────────────────────────────────────────────
const sendEmail = async (email, otp, purpose) => {
  const user = process.env.GMAIL_USER;
  const pass = process.env.GMAIL_APP_PASSWORD;

  const subject = purpose === 'reset'
    ? 'Password Reset OTP — Glamour Salon'
    : 'Login OTP — Glamour Salon';

  const html = `
    <div style="font-family: Georgia, serif; max-width: 480px; margin: 0 auto; padding: 32px; background: #FDFAF5; border-radius: 16px; border: 1px solid #EDE3D0;">
      <div style="text-align: center; margin-bottom: 24px;">
        <h1 style="font-size: 28px; font-weight: 400; font-style: italic; color: #1A1208; margin: 0;">
          Glamour<span style="color: #B8860B;">.</span>
        </h1>
      </div>
      <h2 style="font-size: 18px; font-weight: 600; color: #1A1208; margin: 0 0 8px;">
        ${purpose === 'reset' ? 'Reset Your Password' : 'Your Login OTP'}
      </h2>
      <p style="color: #5C4A2A; font-size: 14px; margin: 0 0 24px;">
        ${purpose === 'reset'
          ? 'Use this OTP to reset your password. It expires in 10 minutes.'
          : 'Use this OTP to log in to your account. It expires in 10 minutes.'}
      </p>
      <div style="background: #FFF8E7; border: 2px solid #B8860B; border-radius: 12px; padding: 20px; text-align: center; margin-bottom: 24px;">
        <div style="font-size: 36px; font-weight: 800; letter-spacing: 12px; color: #B8860B; font-family: monospace;">
          ${otp}
        </div>
      </div>
      <p style="color: #9C8660; font-size: 12px; margin: 0;">
        If you didn't request this, please ignore this email. Do not share this OTP with anyone.
      </p>
    </div>
  `;

  if (!user || !pass) {
    // Dev mode — log to console
    console.log(`\n[OTP DEV] Email to ${email}: ${otp}\n`);
    return true;
  }

  const nodemailer = require('nodemailer');
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: { user, pass },
  });

  await transporter.sendMail({
    from:    `"Glamour Salon" <${user}>`,
    to:      email,
    subject,
    html,
  });

  return true;
};

// ── Main: create + send OTP ────────────────────────────────────────────────
// identifier: phone number or email address
// channel:    'phone' | 'email'
// purpose:    'login' | 'reset'
const createAndSendOTP = async (identifier, channel, purpose) => {
  // Invalidate any existing unused OTPs for this identifier+purpose
  await OTP.deleteMany({ identifier: identifier.toLowerCase(), purpose, used: false });

  const otp = generateOTP();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

  await OTP.create({
    identifier: identifier.toLowerCase(),
    channel,
    purpose,
    otp,
    expiresAt,
  });

  if (channel === 'phone') {
    await sendSMS(identifier, otp);
  } else {
    await sendEmail(identifier, otp, purpose);
  }

  return true;
};

// ── Verify OTP ─────────────────────────────────────────────────────────────
const verifyOTP = async (identifier, otp, purpose) => {
  const record = await OTP.findOne({
    identifier: identifier.toLowerCase(),
    purpose,
    used: false,
    expiresAt: { $gt: new Date() },
  });

  if (!record) return { valid: false, reason: 'OTP expired or not found' };

  // Increment attempts
  record.attempts += 1;

  if (record.attempts > 5) {
    await record.save();
    return { valid: false, reason: 'Too many incorrect attempts. Request a new OTP.' };
  }

  if (record.otp !== otp) {
    await record.save();
    return { valid: false, reason: `Incorrect OTP. ${5 - record.attempts} attempts left.` };
  }

  // Mark as used
  record.used = true;
  await record.save();

  return { valid: true };
};

module.exports = { createAndSendOTP, verifyOTP };