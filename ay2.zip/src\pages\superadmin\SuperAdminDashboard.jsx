import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import api from '@/services/api';
import {
  Building2, Users, ShieldAlert, ShieldCheck, TrendingUp,
  RefreshCw, Activity, Globe, Crown, ArrowRight, Zap,
  Clock, Star, BarChart3,
} from 'lucide-react';

// ─── Design Tokens ────────────────────────────────────────────────────────────
const C = {
  pageBg: '#F4EDE0', cardBg: '#FDFAF4',
  gold: '#B8860B', goldLight: '#DAA520', goldPale: '#FFF8E7',
  ink: '#1A1208', inkMid: '#5C4A2A', inkLight: '#9C8660',
  border: '#DFD0A8',
  green: '#15803D', greenPale: '#DCFCE7', greenBorder: '#86EFAC',
  red: '#991B1B', redPale: '#FEF2F2', redBorder: '#FECACA',
  purple: '#5B21B6', purplePale: '#F5F3FF', purpleBorder: '#DDD6FE',
  blue: '#1D4ED8', bluePale: '#EFF6FF', blueBorder: '#BFDBFE',
  teal: '#0F766E', tealPale: '#F0FDFA', tealBorder: '#99F6E4',
};

const PLAN_LABELS = { plan1: 'Basic', plan2: 'Online Booking', plan3: 'Franchise' };
const PLAN_COLORS = {
  plan1: { color: C.blue,   bg: C.bluePale,   border: C.blueBorder,   icon: Star   },
  plan2: { color: C.gold,   bg: C.goldPale,   border: C.border,       icon: Zap    },
  plan3: { color: C.purple, bg: C.purplePale, border: C.purpleBorder, icon: Crown  },
};

// ─── Stat Card ────────────────────────────────────────────────────────────────
const StatCard = ({ label, value, icon: Icon, color, pale, border, sub, onClick, delay = 0 }) => (
  <motion.div
    initial={{ opacity: 0, y: 16 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay, duration: 0.4 }}
    whileHover={{ y: -3, boxShadow: '0 8px 32px rgba(28,23,18,0.10)' }}
    onClick={onClick}
    style={{
      background: C.cardBg, borderRadius: 16, padding: '18px 20px',
      border: `1px solid ${border || C.border}`,
      boxShadow: '0 2px 12px rgba(28,23,18,0.05)',
      cursor: onClick ? 'pointer' : 'default',
    }}
  >
    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 12 }}>
      <div style={{
        width: 44, height: 44, borderRadius: 12, background: pale || C.goldPale,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon size={20} color={color || C.gold} />
      </div>
      {onClick && (
        <div style={{ padding: 6, borderRadius: 8, background: `${pale}80`, color: color }}>
          <ArrowRight size={13} />
        </div>
      )}
    </div>
    <div style={{ fontSize: 28, fontWeight: 700, color: C.ink, lineHeight: 1, marginBottom: 4 }}>
      {value ?? '—'}
    </div>
    <div style={{ fontSize: 12, color: C.inkLight }}>{label}</div>
    {sub && <div style={{ fontSize: 11, color: color, marginTop: 4, fontWeight: 500 }}>{sub}</div>}
  </motion.div>
);

// ─── Plan Card ────────────────────────────────────────────────────────────────
const PlanCard = ({ plan, count, total, delay = 0 }) => {
  const cfg = PLAN_COLORS[plan];
  const Icon = cfg.icon;
  const pct = total > 0 ? Math.round((count / total) * 100) : 0;
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay, duration: 0.35 }}
      style={{
        flex: 1, minWidth: 0, padding: '18px 20px', borderRadius: 14,
        background: cfg.bg, border: `1px solid ${cfg.border}`,
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
        <div style={{
          width: 28, height: 28, borderRadius: 8, background: `${cfg.color}18`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon size={14} color={cfg.color} />
        </div>
        <span style={{ fontSize: 11, fontWeight: 600, color: cfg.color, textTransform: 'uppercase', letterSpacing: '0.08em' }}>
          Plan {plan.slice(4)}
        </span>
      </div>
      <div style={{ fontSize: 30, fontWeight: 700, color: cfg.color, lineHeight: 1, marginBottom: 4 }}>
        {count || 0}
      </div>
      <div style={{ fontSize: 11, color: C.inkLight, marginBottom: 10 }}>{PLAN_LABELS[plan]}</div>
      {/* Progress bar */}
      <div style={{ height: 4, borderRadius: 4, background: `${cfg.color}20`, overflow: 'hidden' }}>
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ delay: delay + 0.3, duration: 0.6, ease: 'easeOut' }}
          style={{ height: '100%', borderRadius: 4, background: cfg.color }}
        />
      </div>
      <div style={{ fontSize: 10, color: cfg.color, marginTop: 5, fontWeight: 500 }}>{pct}% of all salons</div>
    </motion.div>
  );
};

// ─── Quick Action ─────────────────────────────────────────────────────────────
const QuickAction = ({ icon: Icon, label, desc, color, pale, onClick }) => (
  <motion.button
    whileHover={{ y: -2 }}
    whileTap={{ scale: 0.98 }}
    onClick={onClick}
    style={{
      flex: 1, minWidth: 140, display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
      gap: 8, padding: '16px 18px', borderRadius: 14, cursor: 'pointer',
      background: C.cardBg, border: `1px solid ${C.border}`,
      boxShadow: '0 2px 8px rgba(28,23,18,0.04)', textAlign: 'left',
    }}
  >
    <div style={{
      width: 36, height: 36, borderRadius: 10, background: pale,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <Icon size={17} color={color} />
    </div>
    <div>
      <div style={{ fontSize: 13, fontWeight: 600, color: C.ink }}>{label}</div>
      <div style={{ fontSize: 11, color: C.inkLight, marginTop: 2 }}>{desc}</div>
    </div>
  </motion.button>
);

// ─── Main Dashboard ───────────────────────────────────────────────────────────
const SuperAdminDashboard = () => {
  const navigate = useNavigate();
  const [stats, setStats]     = useState(null);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(null);

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/superadmin/stats');
      setStats(data.stats);
      setLastUpdated(new Date());
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const totalSalons = stats?.totalSalons || 0;
  const planTotal   = ['plan1','plan2','plan3'].reduce((s, k) => s + (stats?.planBreakdown?.[k] || 0), 0);

  return (
    <div style={{ maxWidth: 1100, margin: '0 auto', width: '100%' }}>
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        style={{
          display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
          marginBottom: 24, flexWrap: 'wrap', gap: 12,
        }}
      >
        <div>
          <h1 style={{
            fontFamily: 'Playfair Display, Georgia, serif', fontSize: 'clamp(20px, 4vw, 28px)',
            fontWeight: 600, color: C.ink, margin: 0,
          }}>
            Platform Overview
          </h1>
          <p style={{ fontSize: 13, color: C.inkLight, marginTop: 4 }}>
            Monitor all salons across your SaaS platform
            {lastUpdated && (
              <span style={{ marginLeft: 8, fontSize: 11, opacity: 0.7 }}>
                · Updated {lastUpdated.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
              </span>
            )}
          </p>
        </div>
        <button
          onClick={load}
          style={{
            display: 'flex', alignItems: 'center', gap: 6, padding: '8px 16px',
            borderRadius: 10, border: `1px solid ${C.border}`, background: C.cardBg,
            cursor: 'pointer', fontSize: 13, color: C.inkMid, flexShrink: 0,
          }}
        >
          <RefreshCw size={14} style={{ animation: loading ? 'spin 1s linear infinite' : 'none' }} />
          Refresh
        </button>
      </motion.div>

      {loading ? (
        <div style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center',
          justifyContent: 'center', padding: 80, gap: 16,
        }}>
          <div style={{
            width: 48, height: 48, borderRadius: '50%',
            border: `3px solid ${C.border}`, borderTopColor: C.purple,
            animation: 'spin 1s linear infinite',
          }} />
          <span style={{ fontSize: 13, color: C.inkLight }}>Loading platform data…</span>
        </div>
      ) : (
        <>
          {/* Stat Cards */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(min(220px, 100%), 1fr))',
            gap: 14, marginBottom: 24,
          }}>
            <StatCard
              label="Total Salons" value={stats?.totalSalons}
              icon={Building2} color={C.blue} pale={C.bluePale} border={C.blueBorder}
              sub="All registered salons"
              onClick={() => navigate('/superadmin/salons')} delay={0}
            />
            <StatCard
              label="Active Salons" value={stats?.activeSalons}
              icon={ShieldCheck} color={C.green} pale={C.greenPale} border={C.greenBorder}
              sub={`${totalSalons > 0 ? Math.round((stats?.activeSalons / totalSalons) * 100) : 0}% active rate`}
              onClick={() => navigate('/superadmin/salons?status=active')} delay={0.07}
            />
            <StatCard
              label="Suspended" value={stats?.suspendedSalons}
              icon={ShieldAlert} color={C.red} pale={C.redPale} border={C.redBorder}
              sub="Require attention"
              onClick={() => navigate('/superadmin/salons?status=suspended')} delay={0.14}
            />
            <StatCard
              label="Total Users" value={stats?.totalUsers}
              icon={Users} color={C.gold} pale={C.goldPale} border={C.border}
              sub="Across all salons"
              onClick={() => navigate('/superadmin/users')} delay={0.21}
            />
          </div>

          {/* Plan Breakdown */}
          {stats?.planBreakdown && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.28 }}
              style={{
                background: C.cardBg, borderRadius: 18, padding: '22px 24px',
                border: `1px solid ${C.border}`,
                boxShadow: '0 2px 12px rgba(28,23,18,0.05)', marginBottom: 20,
              }}
            >
              <div style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                marginBottom: 18, flexWrap: 'wrap', gap: 8,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{
                    width: 34, height: 34, borderRadius: 10, background: C.goldPale,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <BarChart3 size={16} color={C.gold} />
                  </div>
                  <div>
                    <h2 style={{ fontFamily: 'Playfair Display, Georgia, serif', fontSize: 16, fontWeight: 600, color: C.ink, margin: 0 }}>
                      Plan Distribution
                    </h2>
                    <p style={{ fontSize: 11, color: C.inkLight, margin: 0 }}>{planTotal} salons across all plans</p>
                  </div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
                {['plan1', 'plan2', 'plan3'].map((p, i) => (
                  <PlanCard
                    key={p} plan={p}
                    count={stats.planBreakdown[p] || 0}
                    total={planTotal}
                    delay={0.32 + i * 0.06}
                  />
                ))}
              </div>
            </motion.div>
          )}

          {/* Quick Actions */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.45 }}
          >
            <h2 style={{ fontFamily: 'Playfair Display, Georgia, serif', fontSize: 15, fontWeight: 600, color: C.ink, marginBottom: 12 }}>
              Quick Actions
            </h2>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
              <QuickAction
                icon={Building2} label="Add New Salon" desc="Onboard a new salon"
                color={C.blue} pale={C.bluePale}
                onClick={() => navigate('/superadmin/salons')}
              />
              <QuickAction
                icon={Users} label="Manage Users" desc="View & manage all users"
                color={C.purple} pale={C.purplePale}
                onClick={() => navigate('/superadmin/users')}
              />
              <QuickAction
                icon={Activity} label="Platform Health" desc="Monitor system status"
                color={C.teal} pale={C.tealPale}
                onClick={() => navigate('/superadmin/settings')}
              />
              <QuickAction
                icon={Globe} label="All Salons" desc="Browse salon directory"
                color={C.gold} pale={C.goldPale}
                onClick={() => navigate('/superadmin/salons')}
              />
            </div>
          </motion.div>

          {/* Summary Footer */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.55 }}
            style={{
              marginTop: 20, padding: '16px 20px', borderRadius: 14,
              background: `linear-gradient(135deg, ${C.purplePale}, ${C.bluePale})`,
              border: `1px solid ${C.purpleBorder}`,
              display: 'flex', alignItems: 'center', gap: 14, flexWrap: 'wrap',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <TrendingUp size={18} color={C.purple} />
              <span style={{ fontSize: 13, fontWeight: 600, color: C.purple }}>Platform Summary</span>
            </div>
            <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap' }}>
              {[
                { label: 'Inactive', value: (stats?.totalSalons || 0) - (stats?.activeSalons || 0) - (stats?.suspendedSalons || 0) },
                { label: 'Health', value: `${totalSalons > 0 ? Math.round((stats?.activeSalons / totalSalons) * 100) : 0}%` },
              ].map(item => (
                <div key={item.label} style={{ display: 'flex', gap: 5, alignItems: 'center' }}>
                  <span style={{ fontSize: 12, color: C.inkLight }}>{item.label}:</span>
                  <span style={{ fontSize: 13, fontWeight: 600, color: C.inkMid }}>{item.value}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </>
      )}

      <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
    </div>
  );
};

export default SuperAdminDashboard;
