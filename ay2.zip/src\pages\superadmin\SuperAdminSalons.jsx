import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import api from '@/services/api';
import {
  Building2, Search, Plus, ShieldAlert, ShieldCheck, X, Check,
  AlertTriangle, RefreshCw, ChevronLeft, ChevronRight, Copy,
  Timer, Edit3, Slash, Clock, CalendarDays, CalendarCheck, CalendarX,
  RotateCcw, Zap, Download, MessageSquare,
} from 'lucide-react';

/* ─── Design Tokens ──────────────────────────────────────────────────────── */
const C = {
  pageBg:'#F4EDE0', cardBg:'#FDFAF4', cardBg2:'#FAF7F0',
  gold:'#B8860B', goldLight:'#DAA520', goldPale:'#FFF8E7',
  ink:'#1A1208', inkMid:'#5C4A2A', inkLight:'#9C8660', border:'#DFD0A8',
  green:'#15803D', greenPale:'#DCFCE7', greenBorder:'#86EFAC',
  red:'#991B1B',   redPale:'#FEF2F2',   redBorder:'#FECACA',
  amber:'#92400E', amberPale:'#FFFBEB', amberBorder:'#FDE68A',
  blue:'#1D4ED8',  bluePale:'#EFF6FF',  blueBorder:'#BFDBFE',
  purple:'#5B21B6',purplePale:'#F5F3FF',purpleBorder:'#DDD6FE',
  teal:'#0F766E',  tealPale:'#F0FDFA',  tealBorder:'#99F6E4',
};

const PLAN_BADGE = {
  plan1:{ label:'Basic',     color:C.blue,   bg:C.bluePale,   border:C.blueBorder   },
  plan2:{ label:'Online',    color:C.gold,   bg:C.goldPale,   border:C.border       },
  plan3:{ label:'Franchise', color:C.purple, bg:C.purplePale, border:C.purpleBorder },
};

/* ─── Subscription Helpers ───────────────────────────────────────────────── */
const getSubStatus = (expiry) => {
  if (!expiry) return { label: 'No Expiry', color: C.inkLight, bg: '#F3F4F6', border: '#E5E7EB', icon: CalendarDays, urgent: false };
  const now  = new Date();
  const date = new Date(expiry);
  const diffDays = Math.ceil((date - now) / (1000 * 60 * 60 * 24));

  if (diffDays < 0)   return { label: 'Expired',       color: C.red,    bg: C.redPale,    border: C.redBorder,    icon: CalendarX,     urgent: true,  diffDays };
  if (diffDays <= 7)  return { label: `${diffDays}d left`, color: C.red,   bg: C.redPale,    border: C.redBorder,    icon: CalendarX,     urgent: true,  diffDays };
  if (diffDays <= 30) return { label: `${diffDays}d left`, color: C.amber, bg: C.amberPale,  border: C.amberBorder,  icon: CalendarDays,  urgent: false, diffDays };
  return { label: `${Math.ceil(diffDays/30)}mo left`,  color: C.teal,   bg: C.tealPale,   border: C.tealBorder,   icon: CalendarCheck, urgent: false, diffDays };
};

const fmtDate = (d) => d ? new Date(d).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' }) : '—';

/* ─── UI Primitives ──────────────────────────────────────────────────────── */
const Inp = ({ label, hint, ...p }) => (
  <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
    {label && (
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <label style={{ fontSize:12, fontWeight:500, color:C.inkMid }}>{label}</label>
        {hint && <span style={{ fontSize:11, color:C.inkLight }}>{hint}</span>}
      </div>
    )}
    <input {...p} style={{ padding:'9px 12px', borderRadius:9, fontSize:13,
      border:`1px solid ${C.border}`, background:'#fff', color:C.ink, outline:'none',
      width:'100%', boxSizing:'border-box', transition:'border-color 0.15s', ...(p.style||{}) }}
      onFocus={e=>e.target.style.borderColor='#B8860B'}
      onBlur={e=>e.target.style.borderColor=C.border}/>
  </div>
);

const Sel = ({ label, children, ...p }) => (
  <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
    {label && <label style={{ fontSize:12, fontWeight:500, color:C.inkMid }}>{label}</label>}
    <select {...p} style={{ padding:'9px 12px', borderRadius:9, fontSize:13,
      border:`1px solid ${C.border}`, background:'#fff', color:C.ink,
      outline:'none', width:'100%', boxSizing:'border-box' }}>{children}</select>
  </div>
);

const Tip = ({ label, children }) => {
  const [on, setOn] = useState(false);
  return (
    <div style={{ position:'relative', display:'inline-flex' }}
      onMouseEnter={()=>setOn(true)} onMouseLeave={()=>setOn(false)}>
      {children}
      <AnimatePresence>
        {on && (
          <motion.div initial={{ opacity:0, y:4 }} animate={{ opacity:1, y:0 }}
            exit={{ opacity:0 }} transition={{ duration:0.1 }}
            style={{ position:'absolute', bottom:'calc(100% + 6px)', left:'50%',
              transform:'translateX(-50%)', background:'#1A1208', color:'#fff',
              fontSize:11, fontWeight:500, padding:'4px 9px', borderRadius:7,
              whiteSpace:'nowrap', pointerEvents:'none', zIndex:99,
              boxShadow:'0 4px 14px rgba(0,0,0,0.18)' }}>
            {label}
            <div style={{ position:'absolute', top:'100%', left:'50%',
              transform:'translateX(-50%)', borderLeft:'5px solid transparent',
              borderRight:'5px solid transparent', borderTop:'5px solid #1A1208' }}/>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

/* ─── Subscription Section (reused in Create & Edit) ─────────────────────── */
const SubscriptionSection = ({ value, onChange }) => {
  // value = { mode: 'none'|'months'|'years'|'date', months, years, date }
  const set = (k, v) => onChange({ ...value, [k]: v });

  return (
    <div style={{ padding:'16px', borderRadius:13, background:C.tealPale, border:`1px solid ${C.tealBorder}` }}>
      <div style={{ display:'flex', alignItems:'center', gap:7, marginBottom:14 }}>
        <CalendarCheck size={15} color={C.teal}/>
        <span style={{ fontSize:13, fontWeight:600, color:C.teal }}>Subscription</span>
        <span style={{ fontSize:11, color:C.teal, opacity:0.65 }}>— how long access is granted</span>
      </div>

      {/* Mode selector */}
      <div style={{ display:'flex', gap:6, marginBottom:14, flexWrap:'wrap' }}>
        {[
          { id:'none',   label:'No Expiry' },
          { id:'months', label:'Months' },
          { id:'years',  label:'Years' },
          { id:'date',   label:'Set Date' },
        ].map(m => (
          <button key={m.id} onClick={()=>set('mode', m.id)}
            style={{ padding:'6px 14px', borderRadius:20, fontSize:12, fontWeight:600,
              cursor:'pointer', transition:'all 0.15s',
              background: value.mode===m.id ? C.teal : '#fff',
              color: value.mode===m.id ? '#fff' : C.inkMid,
              border:`1px solid ${value.mode===m.id ? C.teal : C.border}`,
              boxShadow: value.mode===m.id ? `0 3px 10px ${C.teal}40` : 'none' }}>
            {m.label}
          </button>
        ))}
      </div>

      {value.mode === 'months' && (
        <div>
          <div style={{ fontSize:11, fontWeight:600, color:C.inkLight, letterSpacing:'0.08em',
            textTransform:'uppercase', marginBottom:9 }}>Quick Presets</div>
          <div style={{ display:'flex', gap:7, flexWrap:'wrap', marginBottom:10 }}>
            {[1, 3, 6, 12, 18, 24].map(m => (
              <button key={m} onClick={()=>set('months', m)}
                style={{ padding:'6px 14px', borderRadius:20, fontSize:12, fontWeight:500,
                  cursor:'pointer', transition:'all 0.15s',
                  background: value.months===m ? C.teal : '#fff',
                  color: value.months===m ? '#fff' : C.inkMid,
                  border:`1px solid ${value.months===m ? C.teal : C.border}` }}>
                {m < 12 ? `${m}mo` : `${m/12}yr`}
              </button>
            ))}
          </div>
          <Inp label="Custom months" hint="1–120"
            type="number" min={1} max={120}
            value={value.months}
            onChange={e=>set('months', Math.min(120, Math.max(1, Number(e.target.value)||1)))}/>
          {value.months && (
            <div style={{ marginTop:8, fontSize:12, color:C.teal }}>
              ✓ Expires on: <strong>{fmtDate((() => { const d=new Date(); d.setMonth(d.getMonth()+value.months); return d; })())}</strong>
            </div>
          )}
        </div>
      )}

      {value.mode === 'years' && (
        <div>
          <div style={{ display:'flex', gap:7, flexWrap:'wrap', marginBottom:10 }}>
            {[1, 2, 3, 5].map(y => (
              <button key={y} onClick={()=>set('years', y)}
                style={{ padding:'6px 14px', borderRadius:20, fontSize:12, fontWeight:500,
                  cursor:'pointer', transition:'all 0.15s',
                  background: value.years===y ? C.teal : '#fff',
                  color: value.years===y ? '#fff' : C.inkMid,
                  border:`1px solid ${value.years===y ? C.teal : C.border}` }}>
                {y} yr
              </button>
            ))}
          </div>
          <Inp label="Custom years" hint="1–20"
            type="number" min={1} max={20}
            value={value.years}
            onChange={e=>set('years', Math.min(20, Math.max(1, Number(e.target.value)||1)))}/>
          {value.years && (
            <div style={{ marginTop:8, fontSize:12, color:C.teal }}>
              ✓ Expires on: <strong>{fmtDate((() => { const d=new Date(); d.setFullYear(d.getFullYear()+value.years); return d; })())}</strong>
            </div>
          )}
        </div>
      )}

      {value.mode === 'date' && (
        <Inp label="Expiry date" type="date"
          value={value.date}
          min={new Date().toISOString().split('T')[0]}
          onChange={e=>set('date', e.target.value)}/>
      )}

      {value.mode === 'none' && (
        <div style={{ fontSize:12, color:C.teal, display:'flex', alignItems:'center', gap:6 }}>
          <Zap size={13}/> Salon has unlimited access — no expiry set
        </div>
      )}
    </div>
  );
};

/* ─── Subscription Badge (table + cards) ─────────────────────────────────── */
const SubBadge = ({ expiry, onClick }) => {
  const st = getSubStatus(expiry);
  const Icon = st.icon;
  return (
    <button onClick={onClick}
      style={{ display:'inline-flex', alignItems:'center', gap:5, padding:'4px 10px',
        borderRadius:20, background:st.bg, border:`1px solid ${st.border}`,
        cursor: onClick ? 'pointer' : 'default', fontSize:11, fontWeight:600, color:st.color,
        transition:'all 0.15s', whiteSpace:'nowrap' }}
      onMouseEnter={e=>{ if(onClick){ e.currentTarget.style.opacity='0.82'; e.currentTarget.style.transform='translateY(-1px)'; } }}
      onMouseLeave={e=>{ e.currentTarget.style.opacity='1'; e.currentTarget.style.transform='none'; }}>
      <Icon size={10}/> {st.label}
    </button>
  );
};

/* ─── Renew Subscription Modal ───────────────────────────────────────────── */
const RenewModal = ({ salon, onClose, onSaved }) => {
  const [mode,   setMode]   = useState('months'); // 'months' | 'years' | 'date'
  const [months, setMonths] = useState(1);
  const [years,  setYears]  = useState(1);
  const [date,   setDate]   = useState('');
  const [saving, setSaving] = useState(false);
  const [err,    setErr]    = useState('');

  const currentExpiry = salon.subscriptionExpiry;
  const st = getSubStatus(currentExpiry);

  // Preview what the new expiry will be
  const previewExpiry = () => {
    const base = currentExpiry && new Date(currentExpiry) > new Date()
      ? new Date(currentExpiry) : new Date();
    if (mode === 'months') { const d=new Date(base); d.setMonth(d.getMonth()+months); return d; }
    if (mode === 'years')  { const d=new Date(base); d.setFullYear(d.getFullYear()+years); return d; }
    if (mode === 'date' && date) return new Date(date);
    return null;
  };

  const save = async () => {
    setErr(''); setSaving(true);
    try {
      const body = {};
      if (mode === 'months') body.months = months;
      if (mode === 'years')  body.years  = years;
      if (mode === 'date')   body.expiryDate = date;
      await api.post(`/superadmin/salons/${salon._id}/renew-subscription`, body);
      onSaved?.(); onClose();
    } catch(e) { setErr(e.response?.data?.message || 'Failed to renew'); }
    finally { setSaving(false); }
  };

  const newExpiry = previewExpiry();

  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(28,23,18,0.55)',
      backdropFilter:'blur(10px)', zIndex:100, display:'flex', alignItems:'center',
      justifyContent:'center', padding:16, boxSizing:'border-box' }}>
      <motion.div initial={{ opacity:0, scale:0.94, y:20 }}
        animate={{ opacity:1, scale:1, y:0 }} exit={{ opacity:0, scale:0.95 }}
        style={{ background:C.cardBg, borderRadius:22, width:'100%', maxWidth:460,
          boxShadow:'0 24px 64px rgba(28,23,18,0.22)', border:`1px solid ${C.tealBorder}` }}>

        {/* Header */}
        <div style={{ padding:'20px 24px 16px', borderBottom:`1px solid ${C.border}`,
          display:'flex', alignItems:'center', gap:12 }}>
          <div style={{ width:42, height:42, borderRadius:13, background:C.tealPale,
            display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0,
            border:`1px solid ${C.tealBorder}` }}>
            <RotateCcw size={19} color={C.teal}/>
          </div>
          <div style={{ flex:1, minWidth:0 }}>
            <h2 style={{ fontFamily:'Playfair Display, Georgia, serif', fontSize:17,
              fontWeight:600, color:C.ink, margin:0 }}>Renew Subscription</h2>
            <p style={{ fontSize:12, color:C.inkLight, margin:0, marginTop:2 }}>
              <strong style={{ color:C.inkMid }}>{salon.name}</strong>
            </p>
          </div>
          <button onClick={onClose} style={{ background:'none', border:'none',
            cursor:'pointer', color:C.inkLight, padding:4 }}><X size={16}/></button>
        </div>

        <div style={{ padding:'20px 24px', display:'flex', flexDirection:'column', gap:18 }}>

          {/* Current status banner */}
          <div style={{ padding:'14px 16px', borderRadius:13,
            background: st.urgent ? C.redPale : C.amberPale,
            border:`1px solid ${st.urgent ? C.redBorder : C.amberBorder}` }}>
            <div style={{ display:'flex', alignItems:'center', gap:8 }}>
              <CalendarDays size={16} color={st.urgent ? C.red : C.amber}/>
              <div>
                <div style={{ fontSize:13, fontWeight:600, color: st.urgent ? C.red : C.amber }}>
                  {currentExpiry ? `Current expiry: ${fmtDate(currentExpiry)}` : 'No expiry set'}
                </div>
                <div style={{ fontSize:11, color:C.inkMid, marginTop:2 }}>
                  {currentExpiry && new Date(currentExpiry) > new Date()
                    ? 'Renewal will extend from the current expiry date'
                    : 'Renewal will start from today'}
                </div>
              </div>
            </div>
          </div>

          {/* Mode tabs */}
          <div>
            <div style={{ fontSize:11, fontWeight:600, color:C.inkLight,
              letterSpacing:'0.08em', textTransform:'uppercase', marginBottom:10 }}>
              Add Time
            </div>
            <div style={{ display:'flex', gap:7 }}>
              {[
                { id:'months', label:'Months' },
                { id:'years',  label:'Years'  },
                { id:'date',   label:'Set Date' },
              ].map(m => (
                <button key={m.id} onClick={()=>setMode(m.id)}
                  style={{ flex:1, padding:'8px', borderRadius:10, fontSize:12, fontWeight:600,
                    cursor:'pointer', transition:'all 0.15s',
                    background: mode===m.id ? C.teal : 'transparent',
                    color: mode===m.id ? '#fff' : C.inkMid,
                    border:`1px solid ${mode===m.id ? C.teal : C.border}`,
                    boxShadow: mode===m.id ? `0 3px 10px ${C.teal}40` : 'none' }}>
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          {/* Month presets */}
          {mode === 'months' && (
            <div>
              <div style={{ display:'flex', gap:7, flexWrap:'wrap', marginBottom:12 }}>
                {[1, 3, 6, 12, 18, 24].map(m => (
                  <button key={m} onClick={()=>setMonths(m)}
                    style={{ padding:'6px 14px', borderRadius:20, fontSize:12, fontWeight:500,
                      cursor:'pointer', transition:'all 0.15s',
                      background: months===m ? C.teal : '#fff',
                      color: months===m ? '#fff' : C.inkMid,
                      border:`1px solid ${months===m ? C.teal : C.border}` }}>
                    {m < 12 ? `${m} mo` : `${m/12} yr`}
                  </button>
                ))}
              </div>
              <Inp label="Custom months" hint="1–120"
                type="number" min={1} max={120} value={months}
                onChange={e=>setMonths(Math.min(120, Math.max(1, Number(e.target.value)||1)))}/>
            </div>
          )}

          {/* Year presets */}
          {mode === 'years' && (
            <div>
              <div style={{ display:'flex', gap:7, flexWrap:'wrap', marginBottom:12 }}>
                {[1, 2, 3, 5].map(y => (
                  <button key={y} onClick={()=>setYears(y)}
                    style={{ padding:'6px 14px', borderRadius:20, fontSize:12, fontWeight:500,
                      cursor:'pointer', transition:'all 0.15s',
                      background: years===y ? C.teal : '#fff',
                      color: years===y ? '#fff' : C.inkMid,
                      border:`1px solid ${years===y ? C.teal : C.border}` }}>
                    {y} yr
                  </button>
                ))}
              </div>
              <Inp label="Custom years" hint="1–20"
                type="number" min={1} max={20} value={years}
                onChange={e=>setYears(Math.min(20, Math.max(1, Number(e.target.value)||1)))}/>
            </div>
          )}

          {/* Date picker */}
          {mode === 'date' && (
            <Inp label="Set expiry date directly" type="date"
              min={new Date().toISOString().split('T')[0]}
              value={date}
              onChange={e=>setDate(e.target.value)}/>
          )}

          {/* New expiry preview */}
          {newExpiry && (
            <div style={{ display:'flex', alignItems:'center', gap:10, padding:'14px 16px',
              borderRadius:13, background:`linear-gradient(135deg, ${C.tealPale}, ${C.tealBorder}20)`,
              border:`1px solid ${C.tealBorder}` }}>
              <CalendarCheck size={22} color={C.teal}/>
              <div>
                <div style={{ fontSize:11, color:C.teal, fontWeight:600, textTransform:'uppercase',
                  letterSpacing:'0.06em' }}>New Expiry</div>
                <div style={{ fontSize:18, fontWeight:700, color:C.teal, marginTop:2 }}>
                  {fmtDate(newExpiry)}
                </div>
              </div>
            </div>
          )}

          {err && (
            <div style={{ padding:'10px 14px', borderRadius:9, background:C.redPale,
              border:`1px solid ${C.redBorder}`, fontSize:13, color:C.red,
              display:'flex', gap:8, alignItems:'center' }}>
              <AlertTriangle size={14}/> {err}
            </div>
          )}
        </div>

        <div style={{ display:'flex', gap:10, padding:'16px 24px',
          borderTop:`1px solid ${C.border}`, justifyContent:'flex-end' }}>
          <button onClick={onClose}
            style={{ padding:'9px 18px', borderRadius:10, border:`1px solid ${C.border}`,
              background:'none', cursor:'pointer', fontSize:13, color:C.inkMid }}>
            Cancel
          </button>
          <button onClick={save} disabled={saving || (mode==='date' && !date)}
            style={{ padding:'9px 22px', borderRadius:10, fontSize:13, fontWeight:600,
              color:'#fff', border:'none',
              cursor:(saving||(mode==='date'&&!date)) ? 'not-allowed':'pointer',
              background:`linear-gradient(135deg, #0D9488, ${C.teal})`,
              boxShadow:`0 4px 14px ${C.teal}40`,
              opacity:(saving||(mode==='date'&&!date)) ? 0.6 : 1,
              display:'flex', alignItems:'center', gap:6 }}>
            {saving
              ? <><RefreshCw size={13} style={{ animation:'spin 1s linear infinite' }}/> Saving…</>
              : <><RotateCcw size={13}/> Renew</>}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

/* ─── Status Badge ───────────────────────────────────────────────────────── */
const StatusBadge = ({ s }) => {
  if (s.isSuspended) return (
    <span style={{ display:'inline-flex', alignItems:'center', gap:4, fontSize:11, fontWeight:600,
      padding:'3px 9px', borderRadius:20, background:C.redPale, color:C.red,
      border:`1px solid ${C.redBorder}`, whiteSpace:'nowrap' }}>
      <ShieldAlert size={9}/> Suspended
    </span>);
  if (!s.isActive) return (
    <span style={{ fontSize:11, fontWeight:600, padding:'3px 9px', borderRadius:20,
      background:'#F9FAFB', color:'#6B7280', border:'1px solid #E5E7EB', whiteSpace:'nowrap' }}>
      Inactive
    </span>);
  return (
    <span style={{ display:'inline-flex', alignItems:'center', gap:4, fontSize:11, fontWeight:600,
      padding:'3px 9px', borderRadius:20, background:C.greenPale, color:C.green,
      border:`1px solid ${C.greenBorder}`, whiteSpace:'nowrap' }}>
      <ShieldCheck size={9}/> Active
    </span>);
};

/* ─── Hover Action Bar ───────────────────────────────────────────────────── */
const HoverActions = ({ salon, visible, onSuspend, onUnsuspend, onEdit, onSession, onRenew, onWhatsApp }) => {
  const actions = salon.isSuspended ? [
    { icon:ShieldCheck,  label:'Reinstate',    color:C.green, pale:C.greenPale,  fn:()=>onUnsuspend(salon._id) },
    { icon:RotateCcw,    label:'Subscription', color:C.teal,  pale:C.tealPale,   fn:()=>onRenew(salon) },
    { icon:MessageSquare,label:'WhatsApp',     color:'#15803D',pale:'#E8FFF1',   fn:()=>onWhatsApp(salon) },
    { icon:Timer,        label:'Session',      color:C.purple,pale:C.purplePale, fn:()=>onSession(salon) },
    { icon:Edit3,        label:'Edit',         color:C.blue,  pale:C.bluePale,   fn:()=>onEdit(salon) },
    { icon:Copy,         label:'Copy Slug',    color:C.inkMid,pale:'#F3F4F6',    fn:()=>navigator.clipboard?.writeText(salon.slug) },
  ] : [
    { icon:ShieldAlert,  label:'Suspend',      color:C.red,   pale:C.redPale,    fn:()=>onSuspend(salon) },
    { icon:RotateCcw,    label:'Subscription', color:C.teal,  pale:C.tealPale,   fn:()=>onRenew(salon) },
    { icon:MessageSquare,label:'WhatsApp',     color:'#15803D',pale:'#E8FFF1',   fn:()=>onWhatsApp(salon) },
    { icon:Timer,        label:'Session',      color:C.purple,pale:C.purplePale, fn:()=>onSession(salon) },
    { icon:Edit3,        label:'Edit',         color:C.blue,  pale:C.bluePale,   fn:()=>onEdit(salon) },
    { icon:Copy,         label:'Copy Slug',    color:C.inkMid,pale:'#F3F4F6',    fn:()=>navigator.clipboard?.writeText(salon.slug) },
  ];
  return (
    <AnimatePresence>
      {visible && (
        <motion.div initial={{ opacity:0, x:12 }} animate={{ opacity:1, x:0 }}
          exit={{ opacity:0, x:8 }} transition={{ duration:0.16 }}
          style={{ display:'flex', alignItems:'center', gap:4 }}>
          {actions.map(({ icon:Icon, label, color, pale, fn }) => (
            <Tip key={label} label={label}>
              <button onClick={e=>{ e.stopPropagation(); fn(); }}
                style={{ width:32, height:32, borderRadius:9, border:'1px solid transparent',
                  background:'none', cursor:'pointer', display:'flex', alignItems:'center',
                  justifyContent:'center', color, transition:'all 0.14s' }}
                onMouseEnter={e=>{ e.currentTarget.style.background=pale; e.currentTarget.style.borderColor=`${color}35`; e.currentTarget.style.transform='translateY(-1px)'; }}
                onMouseLeave={e=>{ e.currentTarget.style.background='none'; e.currentTarget.style.borderColor='transparent'; e.currentTarget.style.transform='none'; }}>
                <Icon size={15}/>
              </button>
            </Tip>
          ))}
        </motion.div>
      )}
    </AnimatePresence>
  );
};

/* ─── Session Limit Modal ────────────────────────────────────────────────── */
const SessionModal = ({ salon, onClose, onSaved }) => {
  const [hours, setHours]   = useState(salon.sessionLimitHours ?? 24);
  const [saving, setSaving] = useState(false);
  const PRESETS = [1, 2, 4, 8, 12, 24, 48, 72];

  const save = async () => {
    setSaving(true);
    try {
      await api.patch(`/superadmin/salons/${salon._id}/settings`, { sessionLimitHours:Number(hours) });
      onSaved?.(); onClose();
    } catch(e) { console.error(e); }
    finally { setSaving(false); }
  };

  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(28,23,18,0.55)',
      backdropFilter:'blur(10px)', zIndex:100, display:'flex', alignItems:'center',
      justifyContent:'center', padding:16, boxSizing:'border-box' }}>
      <motion.div initial={{ opacity:0, scale:0.94, y:20 }}
        animate={{ opacity:1, scale:1, y:0 }} exit={{ opacity:0, scale:0.95 }}
        style={{ background:C.cardBg, borderRadius:22, width:'100%', maxWidth:420,
          boxShadow:'0 24px 64px rgba(28,23,18,0.22)', border:`1px solid ${C.purpleBorder}` }}>
        <div style={{ padding:'20px 24px 16px', borderBottom:`1px solid ${C.border}`,
          display:'flex', alignItems:'center', gap:12 }}>
          <div style={{ width:42, height:42, borderRadius:13, background:C.purplePale,
            display:'flex', alignItems:'center', justifyContent:'center',
            border:`1px solid ${C.purpleBorder}` }}>
            <Timer size={19} color={C.purple}/>
          </div>
          <div style={{ flex:1, minWidth:0 }}>
            <h2 style={{ fontFamily:'Playfair Display, Georgia, serif', fontSize:17,
              fontWeight:600, color:C.ink, margin:0 }}>Session Limit</h2>
            <p style={{ fontSize:12, color:C.inkLight, margin:0 }}>
              Auto-logout · <strong style={{ color:C.inkMid }}>{salon.name}</strong>
            </p>
          </div>
          <button onClick={onClose} style={{ background:'none', border:'none', cursor:'pointer', color:C.inkLight }}>
            <X size={16}/>
          </button>
        </div>
        <div style={{ padding:'20px 24px', display:'flex', flexDirection:'column', gap:18 }}>
          <div style={{ display:'flex', alignItems:'center', gap:16, padding:'16px 20px',
            borderRadius:14, background:`linear-gradient(135deg, ${C.purplePale}, ${C.purpleBorder}20)`,
            border:`1px solid ${C.purpleBorder}` }}>
            <Clock size={26} color={C.purple}/>
            <div>
              <div style={{ fontSize:32, fontWeight:700, color:C.purple, lineHeight:1 }}>
                {hours < 24 ? `${hours}h` : `${hours/24}d`}
              </div>
              <div style={{ fontSize:12, color:C.inkLight, marginTop:3 }}>
                Auto-logout after <strong style={{ color:C.inkMid }}>
                  {hours < 24 ? `${hours}h` : `${hours/24}d`}
                </strong> of inactivity
              </div>
            </div>
          </div>
          <div style={{ display:'flex', flexWrap:'wrap', gap:7 }}>
            {PRESETS.map(h => (
              <button key={h} onClick={()=>setHours(h)}
                style={{ padding:'6px 14px', borderRadius:20, fontSize:13, fontWeight:500,
                  cursor:'pointer', transition:'all 0.15s',
                  background: hours===h ? C.purple : 'transparent',
                  color: hours===h ? '#fff' : C.inkMid,
                  border:`1px solid ${hours===h ? C.purple : C.border}` }}>
                {h < 24 ? `${h}h` : `${h/24}d`}
              </button>
            ))}
          </div>
          <Inp label="Custom hours" hint="1–168 max"
            type="number" min={1} max={168} value={hours}
            onChange={e=>setHours(Math.min(168, Math.max(1, Number(e.target.value)||1)))}/>
        </div>
        <div style={{ display:'flex', gap:10, padding:'16px 24px',
          borderTop:`1px solid ${C.border}`, justifyContent:'flex-end' }}>
          <button onClick={onClose}
            style={{ padding:'9px 18px', borderRadius:10, border:`1px solid ${C.border}`,
              background:'none', cursor:'pointer', fontSize:13, color:C.inkMid }}>Cancel</button>
          <button onClick={save} disabled={saving}
            style={{ padding:'9px 22px', borderRadius:10, fontSize:13, fontWeight:600,
              color:'#fff', border:'none', cursor:saving?'not-allowed':'pointer',
              background:`linear-gradient(135deg, #7C3AED, ${C.purple})`,
              boxShadow:`0 4px 14px ${C.purple}40`, opacity:saving?0.7:1,
              display:'flex', alignItems:'center', gap:6 }}>
            {saving ? <RefreshCw size={13} style={{ animation:'spin 1s linear infinite' }}/> : <Check size={13}/>}
            {saving ? 'Saving…' : 'Save'}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

/* ─── Edit Modal ─────────────────────────────────────────────────────────── */
const EditModal = ({ salon, onClose, onSaved }) => {
  const [form, setForm] = useState({
    name: salon.name || '',
    plan: salon.plan || 'plan1',
    isActive: salon.isActive ?? true,
    sessionLimitHours: salon.sessionLimitHours ?? 24,
  });
  const [saving, setSaving] = useState(false);
  const [err,    setErr]    = useState('');
  const [showRenew, setShowRenew] = useState(false);
  const set = (k,v) => setForm(f=>({...f,[k]:v}));

  const subStatus = getSubStatus(salon.subscriptionExpiry);
  const SubIcon = subStatus.icon;

  const save = async () => {
    setErr(''); setSaving(true);
    try { await api.patch(`/superadmin/salons/${salon._id}`, form); onSaved?.(); onClose(); }
    catch(e) { setErr(e.response?.data?.message||'Failed to save'); }
    finally { setSaving(false); }
  };

  if (showRenew) return (
    <RenewModal salon={salon} onClose={()=>setShowRenew(false)} onSaved={()=>{ onSaved?.(); setShowRenew(false); }}/>
  );

  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(28,23,18,0.55)',
      backdropFilter:'blur(10px)', zIndex:100, display:'flex', alignItems:'center',
      justifyContent:'center', padding:16, boxSizing:'border-box' }}>
      <motion.div initial={{ opacity:0, scale:0.94, y:20 }}
        animate={{ opacity:1, scale:1, y:0 }} exit={{ opacity:0, scale:0.95 }}
        style={{ background:C.cardBg, borderRadius:22, width:'100%', maxWidth:460,
          maxHeight:'92vh', overflowY:'auto',
          boxShadow:'0 24px 64px rgba(28,23,18,0.22)', border:`1px solid ${C.border}` }}>
        <div style={{ padding:'20px 24px 16px', borderBottom:`1px solid ${C.border}`,
          display:'flex', alignItems:'center', gap:12,
          position:'sticky', top:0, background:C.cardBg, zIndex:1 }}>
          <div style={{ width:42, height:42, borderRadius:13, background:C.bluePale,
            display:'flex', alignItems:'center', justifyContent:'center',
            border:`1px solid ${C.blueBorder}` }}>
            <Edit3 size={18} color={C.blue}/>
          </div>
          <div style={{ flex:1, minWidth:0 }}>
            <h2 style={{ fontFamily:'Playfair Display, Georgia, serif', fontSize:17,
              fontWeight:600, color:C.ink, margin:0 }}>Edit Salon</h2>
            <p style={{ fontSize:12, color:C.inkLight, margin:0 }}>{salon.slug}</p>
          </div>
          <button onClick={onClose} style={{ background:'none', border:'none', cursor:'pointer', color:C.inkLight }}>
            <X size={16}/>
          </button>
        </div>

        <div style={{ padding:'20px 24px', display:'flex', flexDirection:'column', gap:14 }}>
          <Inp label="Salon Name" value={form.name} onChange={e=>set('name',e.target.value)}/>
          <Sel label="Plan" value={form.plan} onChange={e=>set('plan',e.target.value)}>
            <option value="plan1">Plan 1 — Basic</option>
            <option value="plan2">Plan 2 — Online Booking</option>
            <option value="plan3">Plan 3 — Franchise</option>
          </Sel>

          {/* Subscription panel */}
          <div style={{ padding:'14px 16px', borderRadius:13,
            background: subStatus.urgent ? C.redPale : C.tealPale,
            border:`1px solid ${subStatus.urgent ? C.redBorder : C.tealBorder}` }}>
            <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:10 }}>
              <SubIcon size={15} color={subStatus.color}/>
              <span style={{ fontSize:12, fontWeight:600, color:subStatus.color }}>Subscription</span>
            </div>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:10, flexWrap:'wrap' }}>
              <div>
                <div style={{ fontSize:13, fontWeight:600, color:C.ink }}>
                  {salon.subscriptionExpiry ? fmtDate(salon.subscriptionExpiry) : 'No expiry set'}
                </div>
                <div style={{ fontSize:11, color:subStatus.color, marginTop:2 }}>{subStatus.label}</div>
              </div>
              <button onClick={()=>setShowRenew(true)}
                style={{ padding:'7px 14px', borderRadius:9, fontSize:12, fontWeight:600,
                  cursor:'pointer', display:'flex', alignItems:'center', gap:6,
                  background:C.teal, color:'#fff', border:'none',
                  boxShadow:`0 3px 10px ${C.teal}40` }}>
                <RotateCcw size={12}/> Renew
              </button>
            </div>
          </div>

          {/* Session limit */}
          <div style={{ padding:'14px 16px', borderRadius:12, background:C.purplePale, border:`1px solid ${C.purpleBorder}` }}>
            <div style={{ display:'flex', alignItems:'center', gap:7, marginBottom:10 }}>
              <Timer size={14} color={C.purple}/>
              <span style={{ fontSize:12, fontWeight:600, color:C.purple }}>Session Timeout</span>
            </div>
            <div style={{ display:'flex', gap:7, flexWrap:'wrap' }}>
              {[1,4,8,12,24,48].map(h=>(
                <button key={h} onClick={()=>set('sessionLimitHours',h)}
                  style={{ padding:'5px 12px', borderRadius:20, fontSize:12, fontWeight:500,
                    cursor:'pointer', transition:'all 0.15s',
                    background: form.sessionLimitHours===h ? C.purple : '#fff',
                    color: form.sessionLimitHours===h ? '#fff' : C.inkMid,
                    border:`1px solid ${form.sessionLimitHours===h ? C.purple : C.border}` }}>
                  {h<24?`${h}h`:`${h/24}d`}
                </button>
              ))}
            </div>
          </div>

          {/* Active toggle */}
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between',
            padding:'12px 16px', borderRadius:12, background:C.cardBg2, border:`1px solid ${C.border}` }}>
            <div>
              <div style={{ fontSize:13, fontWeight:500, color:C.ink }}>Active Status</div>
              <div style={{ fontSize:11, color:C.inkLight, marginTop:2 }}>Allow users to log in</div>
            </div>
            <button onClick={()=>set('isActive',!form.isActive)}
              style={{ width:44, height:24, borderRadius:12, border:'none', cursor:'pointer',
                background:form.isActive ? C.green : '#D1D5DB', transition:'background 0.22s',
                position:'relative', flexShrink:0 }}>
              <div style={{ position:'absolute', top:2, width:20, height:20, borderRadius:'50%',
                background:'#fff', boxShadow:'0 1px 4px rgba(0,0,0,0.2)',
                transition:'left 0.22s', left: form.isActive ? 22 : 2 }}/>
            </button>
          </div>

          {err && (
            <div style={{ padding:'10px 14px', borderRadius:9, background:C.redPale,
              border:`1px solid ${C.redBorder}`, fontSize:13, color:C.red,
              display:'flex', gap:8, alignItems:'center' }}>
              <AlertTriangle size={14}/> {err}
            </div>
          )}
        </div>

        <div style={{ display:'flex', gap:10, padding:'16px 24px',
          borderTop:`1px solid ${C.border}`, justifyContent:'flex-end',
          position:'sticky', bottom:0, background:C.cardBg }}>
          <button onClick={onClose}
            style={{ padding:'9px 18px', borderRadius:10, border:`1px solid ${C.border}`,
              background:'none', cursor:'pointer', fontSize:13, color:C.inkMid }}>Cancel</button>
          <button onClick={save} disabled={saving}
            style={{ padding:'9px 22px', borderRadius:10, fontSize:13, fontWeight:600,
              color:'#fff', border:'none', cursor:saving?'not-allowed':'pointer',
              background:`linear-gradient(135deg, #3B82F6, ${C.blue})`,
              boxShadow:`0 4px 14px ${C.blue}40`, opacity:saving?0.7:1,
              display:'flex', alignItems:'center', gap:6 }}>
            {saving ? <RefreshCw size={13} style={{ animation:'spin 1s linear infinite' }}/> : <Check size={13}/>}
            {saving ? 'Saving…' : 'Save Changes'}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

/* ─── Create Salon Modal ─────────────────────────────────────────────────── */
const CreateModal = ({ onClose, onCreated }) => {
  const [form, setForm] = useState({
    name:'', slug:'', adminEmail:'', adminName:'', adminPhone:'',
    adminPassword:'', plan:'plan1', sessionLimitHours:24,
  });
  const [sub,    setSub]    = useState({ mode:'months', months:1, years:1, date:'' });
  const [saving, setSaving] = useState(false);
  const [err,    setErr]    = useState('');
  const set = (k,v) => setForm(f=>({...f,[k]:v}));
  const handleName = v => {
    set('name',v);
    set('slug', v.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,''));
  };

  const submit = async () => {
    setErr(''); setSaving(true);
    try {
      const body = { ...form };
      if (sub.mode === 'months') body.subscriptionMonths = sub.months;
      if (sub.mode === 'years')  body.subscriptionYears  = sub.years;
      if (sub.mode === 'date' && sub.date) body.subscriptionExpiry = sub.date;
      await api.post('/superadmin/salons', body);
      onCreated(); onClose();
    } catch(e) { setErr(e.response?.data?.message||'Failed to create salon'); }
    finally { setSaving(false); }
  };

  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(28,23,18,0.55)',
      backdropFilter:'blur(10px)', zIndex:100, display:'flex', alignItems:'center',
      justifyContent:'center', padding:16, boxSizing:'border-box' }}>
      <motion.div initial={{ opacity:0, scale:0.94, y:20 }}
        animate={{ opacity:1, scale:1, y:0 }} exit={{ opacity:0, scale:0.95 }}
        style={{ background:C.cardBg, borderRadius:22, width:'100%', maxWidth:500,
          maxHeight:'92vh', overflowY:'auto',
          boxShadow:'0 24px 64px rgba(28,23,18,0.22)', border:`1px solid ${C.border}` }}>

        <div style={{ padding:'20px 24px 16px', borderBottom:`1px solid ${C.border}`,
          display:'flex', alignItems:'center', justifyContent:'space-between',
          position:'sticky', top:0, background:C.cardBg, zIndex:1 }}>
          <h2 style={{ fontFamily:'Playfair Display, Georgia, serif', fontSize:18,
            fontWeight:600, color:C.ink, margin:0 }}>Create New Salon</h2>
          <button onClick={onClose} style={{ background:'none', border:'none', cursor:'pointer', color:C.inkLight }}>
            <X size={18}/>
          </button>
        </div>

        <div style={{ padding:'20px 24px', display:'flex', flexDirection:'column', gap:13 }}>

          {/* Salon basics */}
          <Inp label="Salon Name *" value={form.name} onChange={e=>handleName(e.target.value)} placeholder="Royal Cuts"/>
          <Inp label="Slug *" value={form.slug} onChange={e=>set('slug',e.target.value)} placeholder="royal-cuts"/>
          <Sel label="Plan" value={form.plan} onChange={e=>set('plan',e.target.value)}>
            <option value="plan1">Plan 1 — Basic</option>
            <option value="plan2">Plan 2 — Online Booking</option>
            <option value="plan3">Plan 3 — Franchise</option>
          </Sel>

          {/* Subscription */}
          <SubscriptionSection value={sub} onChange={setSub}/>

          {/* Session limit */}
          <div style={{ padding:'14px 16px', borderRadius:12, background:C.purplePale, border:`1px solid ${C.purpleBorder}` }}>
            <div style={{ display:'flex', alignItems:'center', gap:7, marginBottom:10 }}>
              <Timer size={14} color={C.purple}/>
              <span style={{ fontSize:12, fontWeight:600, color:C.purple }}>Session Timeout</span>
              <span style={{ fontSize:11, color:C.purple, opacity:0.7 }}>— auto-logout</span>
            </div>
            <div style={{ display:'flex', gap:7, flexWrap:'wrap' }}>
              {[1,4,8,12,24,48].map(h=>(
                <button key={h} onClick={()=>set('sessionLimitHours',h)}
                  style={{ padding:'5px 12px', borderRadius:20, fontSize:12, fontWeight:500,
                    cursor:'pointer', transition:'all 0.15s',
                    background: form.sessionLimitHours===h ? C.purple : '#fff',
                    color: form.sessionLimitHours===h ? '#fff' : C.inkMid,
                    border:`1px solid ${form.sessionLimitHours===h ? C.purple : C.border}` }}>
                  {h<24?`${h}h`:`${h/24}d`}
                </button>
              ))}
            </div>
          </div>

          {/* Admin account */}
          <div style={{ borderTop:`1px solid ${C.border}`, paddingTop:14 }}>
            <div style={{ fontSize:11, fontWeight:600, color:C.inkLight,
              letterSpacing:'0.1em', textTransform:'uppercase', marginBottom:12 }}>
              Admin Account
            </div>
            <div style={{ display:'flex', flexDirection:'column', gap:11 }}>
              <Inp label="Admin Email *" value={form.adminEmail} onChange={e=>set('adminEmail',e.target.value)} placeholder="admin@royalcuts.com" type="email"/>
              <Inp label="Admin Name" value={form.adminName} onChange={e=>set('adminName',e.target.value)} placeholder="John Doe"/>
              <Inp label="Admin Phone" value={form.adminPhone} onChange={e=>set('adminPhone',e.target.value)} placeholder="9876543210"/>
              <Inp label="Password *" value={form.adminPassword} onChange={e=>set('adminPassword',e.target.value)} placeholder="Min 8 characters" type="password"/>
            </div>
          </div>

          {err && (
            <div style={{ padding:'10px 14px', borderRadius:9, background:C.redPale,
              border:`1px solid ${C.redBorder}`, fontSize:13, color:C.red,
              display:'flex', gap:8, alignItems:'center' }}>
              <AlertTriangle size={14}/> {err}
            </div>
          )}
        </div>

        <div style={{ display:'flex', gap:10, padding:'16px 24px',
          borderTop:`1px solid ${C.border}`, justifyContent:'flex-end',
          position:'sticky', bottom:0, background:C.cardBg }}>
          <button onClick={onClose}
            style={{ padding:'9px 18px', borderRadius:10, border:`1px solid ${C.border}`,
              background:'none', cursor:'pointer', fontSize:13, color:C.inkMid }}>Cancel</button>
          <button onClick={submit} disabled={saving}
            style={{ padding:'9px 22px', borderRadius:10, fontSize:13, fontWeight:600,
              color:'#fff', border:'none', cursor:saving?'not-allowed':'pointer',
              background:`linear-gradient(135deg, ${C.goldLight}, ${C.gold})`,
              boxShadow:'0 4px 14px rgba(184,137,42,0.35)', opacity:saving?0.7:1,
              display:'flex', alignItems:'center', gap:6 }}>
            {saving ? <RefreshCw size={13} style={{ animation:'spin 1s linear infinite' }}/> : <Check size={13}/>}
            {saving ? 'Creating…' : 'Create Salon'}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

/* ─── Suspend Modal ──────────────────────────────────────────────────────── */
const SuspendModal = ({ salon, onClose, onDone }) => {
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);
  const submit = async () => {
    setSaving(true);
    try { await api.post(`/superadmin/salons/${salon._id}/suspend`, { reason }); onDone(); onClose(); }
    catch(e) { console.error(e); }
    finally { setSaving(false); }
  };
  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(28,23,18,0.55)',
      backdropFilter:'blur(10px)', zIndex:100, display:'flex', alignItems:'center',
      justifyContent:'center', padding:16, boxSizing:'border-box' }}>
      <motion.div initial={{ opacity:0, scale:0.94 }} animate={{ opacity:1, scale:1 }}
        exit={{ opacity:0, scale:0.95 }}
        style={{ background:C.cardBg, borderRadius:22, width:'100%', maxWidth:400,
          boxShadow:'0 24px 64px rgba(28,23,18,0.22)', border:`1px solid ${C.redBorder}` }}>
        <div style={{ padding:'20px 24px 16px', borderBottom:`1px solid ${C.border}`,
          display:'flex', alignItems:'center', gap:12 }}>
          <div style={{ width:42, height:42, borderRadius:13, background:C.redPale,
            display:'flex', alignItems:'center', justifyContent:'center', border:`1px solid ${C.redBorder}` }}>
            <ShieldAlert size={19} color={C.red}/>
          </div>
          <div style={{ flex:1 }}>
            <h2 style={{ fontFamily:'Playfair Display, Georgia, serif', fontSize:17,
              fontWeight:600, color:C.red, margin:0 }}>Suspend Salon</h2>
            <p style={{ fontSize:12, color:C.inkLight, margin:0 }}>{salon.name}</p>
          </div>
          <button onClick={onClose} style={{ background:'none', border:'none', cursor:'pointer', color:C.inkLight }}>
            <X size={16}/>
          </button>
        </div>
        <div style={{ padding:'20px 24px' }}>
          <p style={{ fontSize:13, color:C.inkMid, marginBottom:14, lineHeight:1.6 }}>
            All users at <strong>{salon.name}</strong> will be immediately logged out and blocked.
          </p>
          <textarea value={reason} onChange={e=>setReason(e.target.value)}
            placeholder="Reason for suspension (optional)…" rows={3}
            style={{ width:'100%', padding:'10px 12px', borderRadius:9, border:`1px solid ${C.border}`,
              fontSize:13, color:C.ink, resize:'vertical', outline:'none', boxSizing:'border-box' }}/>
        </div>
        <div style={{ display:'flex', gap:10, padding:'16px 24px',
          borderTop:`1px solid ${C.border}`, justifyContent:'flex-end' }}>
          <button onClick={onClose}
            style={{ padding:'9px 18px', borderRadius:10, border:`1px solid ${C.border}`,
              background:'none', cursor:'pointer', fontSize:13, color:C.inkMid }}>Cancel</button>
          <button onClick={submit} disabled={saving}
            style={{ padding:'9px 22px', borderRadius:10, background:C.red, border:'none',
              cursor:saving?'not-allowed':'pointer', fontSize:13, fontWeight:600, color:'#fff',
              opacity:saving?0.7:1, display:'flex', alignItems:'center', gap:6 }}>
            {saving ? <RefreshCw size={13} style={{ animation:'spin 1s linear infinite' }}/> : <Slash size={13}/>}
            {saving ? 'Suspending…' : 'Suspend'}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

/* ─── Mobile Salon Card ──────────────────────────────────────────────────── */
const SalonCard = ({ salon, onSuspend, onUnsuspend, onEdit, onSession, onRenew, i }) => {
  const plan    = PLAN_BADGE[salon.plan] || PLAN_BADGE.plan1;
  const sessionH = salon.sessionLimitHours ?? 24;
  const subSt   = getSubStatus(salon.subscriptionExpiry);
  const SubIcon = subSt.icon;

  return (
    <motion.div initial={{ opacity:0, y:10 }} animate={{ opacity:1, y:0 }}
      transition={{ delay:i*0.04 }}
      style={{ background:salon.isSuspended?C.redPale:C.cardBg,
        border:`1px solid ${salon.isSuspended?C.redBorder:C.border}`,
        borderRadius:16, padding:'16px', boxShadow:'0 2px 8px rgba(28,23,18,0.04)' }}>

      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:10 }}>
        <div style={{ minWidth:0 }}>
          <div style={{ fontWeight:600, fontSize:14, color:C.ink }}>{salon.name}</div>
          <code style={{ fontSize:11, color:C.inkLight, background:`${C.border}50`,
            padding:'1px 6px', borderRadius:4 }}>{salon.slug}</code>
        </div>
        <StatusBadge s={salon}/>
      </div>

      <div style={{ display:'flex', flexWrap:'wrap', gap:6, marginBottom:10 }}>
        <span style={{ fontSize:11, fontWeight:600, padding:'3px 9px', borderRadius:20,
          background:plan.bg, color:plan.color, border:`1px solid ${plan.border}` }}>
          {plan.label}
        </span>
        <span style={{ fontSize:11, padding:'3px 9px', borderRadius:20,
          background:C.purplePale, color:C.purple, border:`1px solid ${C.purpleBorder}`,
          display:'inline-flex', alignItems:'center', gap:4 }}>
          <Timer size={9}/> {sessionH<24?`${sessionH}h`:`${sessionH/24}d`}
        </span>
        <span style={{ fontSize:11, padding:'3px 9px', borderRadius:20,
          background:subSt.bg, color:subSt.color, border:`1px solid ${subSt.border}`,
          display:'inline-flex', alignItems:'center', gap:4 }}>
          <SubIcon size={9}/> {subSt.label}
        </span>
      </div>

      {salon.subscriptionExpiry && (
        <div style={{ fontSize:11, color:C.inkLight, marginBottom:10 }}>
          Expires: {fmtDate(salon.subscriptionExpiry)}
        </div>
      )}

      <div style={{ display:'flex', gap:7, flexWrap:'wrap' }}>
        {salon.isSuspended ? (
          <button onClick={()=>onUnsuspend(salon._id)}
            style={{ flex:1, minWidth:80, padding:'8px', borderRadius:9,
              border:`1px solid ${C.greenBorder}`, background:C.greenPale, cursor:'pointer',
              fontSize:12, fontWeight:600, color:C.green, display:'flex',
              alignItems:'center', justifyContent:'center', gap:5 }}>
            <ShieldCheck size={13}/> Reinstate
          </button>
        ) : (
          <button onClick={()=>onSuspend(salon)}
            style={{ flex:1, minWidth:80, padding:'8px', borderRadius:9,
              border:`1px solid ${C.redBorder}`, background:C.redPale, cursor:'pointer',
              fontSize:12, fontWeight:600, color:C.red, display:'flex',
              alignItems:'center', justifyContent:'center', gap:5 }}>
            <ShieldAlert size={13}/> Suspend
          </button>
        )}
        <button onClick={()=>onRenew(salon)}
          style={{ padding:'8px 12px', borderRadius:9, border:`1px solid ${C.tealBorder}`,
            background:C.tealPale, cursor:'pointer', color:C.teal,
            display:'flex', alignItems:'center', gap:5, fontSize:12, fontWeight:500 }}>
          <RotateCcw size={13}/> Renew
        </button>
        <button onClick={()=>onSession(salon)}
          style={{ padding:'8px 12px', borderRadius:9, border:`1px solid ${C.purpleBorder}`,
            background:C.purplePale, cursor:'pointer', color:C.purple,
            display:'flex', alignItems:'center', gap:5, fontSize:12, fontWeight:500 }}>
          <Timer size={13}/>
        </button>
        <button onClick={()=>onEdit(salon)}
          style={{ padding:'8px 12px', borderRadius:9, border:`1px solid ${C.blueBorder}`,
            background:C.bluePale, cursor:'pointer', color:C.blue,
            display:'flex', alignItems:'center', gap:5, fontSize:12, fontWeight:500 }}>
          <Edit3 size={13}/>
        </button>
      </div>
    </motion.div>
  );
};

/* ─── Export CSV ─────────────────────────────────────────────────────────── */
const exportSalonsCSV = (salons) => {
  const rows = [
    ['Name','Slug','Plan','Status','Admin Name','Admin Email','Admin Phone','Subscription Expiry','Session Limit (hrs)','Created'],
    ...salons.map(s => [
      s.name, s.slug, s.plan,
      s.isSuspended ? 'Suspended' : s.isActive ? 'Active' : 'Inactive',
      s.admin?.name  || '',
      s.admin?.email || '',
      s.admin?.phone || '',
      s.subscriptionExpiry ? new Date(s.subscriptionExpiry).toLocaleDateString('en-IN') : '',
      s.sessionLimitHours ?? 24,
      new Date(s.createdAt).toLocaleDateString('en-IN'),
    ]),
  ];
  const csv = rows.map(r =>
    r.map(c => /[,"\n]/.test(String(c)) ? `"${String(c).replace(/"/g,'""')}"` : c).join(',')
  ).join('\r\n');
  const url = URL.createObjectURL(new Blob(['\uFEFF' + csv], { type:'text/csv;charset=utf-8' }));
  const a = document.createElement('a');
  a.href = url; a.download = `salons_${new Date().toISOString().slice(0,10)}.csv`; a.click();
  URL.revokeObjectURL(url);
};

/* ─── Main Page ──────────────────────────────────────────────────────────── */
const SuperAdminSalons = () => {
  const navigate = useNavigate();
  const [salons,        setSalons]        = useState([]);
  const [total,         setTotal]         = useState(0);
  const [page,          setPage]          = useState(1);
  const [loading,       setLoading]       = useState(true);
  const [exporting,     setExporting]     = useState(false);
  const [search,        setSearch]        = useState('');
  const [planFilter,    setPlanFilter]    = useState('');
  const [statusFilter,  setStatusFilter]  = useState('');
  const [hoveredRow,    setHoveredRow]    = useState(null);
  const [showCreate,    setShowCreate]    = useState(false);
  const [suspendTarget, setSuspendTarget] = useState(null);
  const [editTarget,    setEditTarget]    = useState(null);
  const [sessionTarget, setSessionTarget] = useState(null);
  const [renewTarget,   setRenewTarget]   = useState(null);
  const LIMIT = 20;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const p = new URLSearchParams({ page, limit:LIMIT });
      if (search)       p.set('search', search);
      if (planFilter)   p.set('plan',   planFilter);
      if (statusFilter) p.set('status', statusFilter);
      const { data } = await api.get(`/superadmin/salons?${p}`);
      setSalons(data.salons);
      setTotal(data.pagination.total);
    } catch(e) { console.error(e); }
    finally { setLoading(false); }
  }, [page, search, planFilter, statusFilter]);

  useEffect(()=>{ load(); }, [load]);

  const exportAll = async () => {
    setExporting(true);
    try {
      // Fetch all pages for export
      const p = new URLSearchParams({ page:1, limit:1000 });
      if (search)       p.set('search', search);
      if (planFilter)   p.set('plan',   planFilter);
      if (statusFilter) p.set('status', statusFilter);
      const { data } = await api.get(`/superadmin/salons?${p}`);
      exportSalonsCSV(data.salons || []);
    } catch(e) { console.error(e); }
    finally { setExporting(false); }
  };

  const unsuspend = async (id) => {
    try { await api.post(`/superadmin/salons/${id}/unsuspend`); load(); }
    catch(e) { console.error(e); }
  };

  const pages = Math.ceil(total / LIMIT);

  return (
    <div style={{ maxWidth:1150, margin:'0 auto', width:'100%' }}>

      {/* Header */}
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between',
        marginBottom:22, flexWrap:'wrap', gap:12 }}>
        <div>
          <h1 style={{ fontFamily:'Playfair Display, Georgia, serif',
            fontSize:'clamp(20px,4vw,26px)', fontWeight:600, color:C.ink, margin:0 }}>
            Salons
          </h1>
          <p style={{ fontSize:13, color:C.inkLight, marginTop:3 }}>
            {total} total salons registered
          </p>
        </div>
        <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
          <button onClick={exportAll} disabled={exporting}
            style={{ display:'flex', alignItems:'center', gap:6, padding:'8px 14px',
              borderRadius:10, border:`1px solid ${C.border}`, background:C.cardBg,
              cursor:'pointer', fontSize:13, color:C.inkMid, whiteSpace:'nowrap' }}>
            <Download size={14}/> {exporting ? 'Exporting…' : 'Export CSV'}
          </button>
          <button onClick={()=>navigate('/superadmin/whatsapp')}
            style={{ display:'flex', alignItems:'center', gap:6, padding:'8px 14px',
              borderRadius:10, border:'1px solid #A7F3C1', background:'#E8FFF1',
              cursor:'pointer', fontSize:13, color:'#15803D', fontWeight:500, whiteSpace:'nowrap' }}>
            <MessageSquare size={14}/> WhatsApp
          </button>
          <button onClick={()=>setShowCreate(true)}
            style={{ display:'flex', alignItems:'center', gap:7, padding:'9px 18px',
              borderRadius:11, background:`linear-gradient(135deg, ${C.goldLight}, ${C.gold})`,
              border:'none', cursor:'pointer', fontSize:13, fontWeight:600, color:'#fff',
              boxShadow:'0 4px 14px rgba(184,137,42,0.3)', flexShrink:0, whiteSpace:'nowrap' }}>
            <Plus size={15}/> New Salon
          </button>
        </div>
      </div>

      {/* Filters */}
      <div style={{ display:'flex', gap:10, marginBottom:18, flexWrap:'wrap', alignItems:'center' }}>
        <div style={{ flex:'1 1 200px', minWidth:0, position:'relative' }}>
          <Search size={14} style={{ position:'absolute', left:10, top:'50%',
            transform:'translateY(-50%)', color:C.inkLight, pointerEvents:'none' }}/>
          <input value={search} onChange={e=>{ setSearch(e.target.value); setPage(1); }}
            placeholder="Search name, slug or email…"
            style={{ width:'100%', padding:'9px 12px 9px 32px', borderRadius:10,
              border:`1px solid ${C.border}`, background:C.cardBg, fontSize:13,
              color:C.ink, outline:'none', boxSizing:'border-box' }}/>
        </div>
        <select value={planFilter} onChange={e=>{ setPlanFilter(e.target.value); setPage(1); }}
          style={{ padding:'9px 12px', borderRadius:10, border:`1px solid ${C.border}`,
            background:C.cardBg, fontSize:13, color:C.ink, outline:'none' }}>
          <option value="">All Plans</option>
          <option value="plan1">Plan 1 · Basic</option>
          <option value="plan2">Plan 2 · Online</option>
          <option value="plan3">Plan 3 · Franchise</option>
        </select>
        <select value={statusFilter} onChange={e=>{ setStatusFilter(e.target.value); setPage(1); }}
          style={{ padding:'9px 12px', borderRadius:10, border:`1px solid ${C.border}`,
            background:C.cardBg, fontSize:13, color:C.ink, outline:'none' }}>
          <option value="">All Status</option>
          <option value="active">Active</option>
          <option value="suspended">Suspended</option>
          <option value="inactive">Inactive</option>
        </select>
        <button onClick={load}
          style={{ padding:'9px 14px', borderRadius:10, border:`1px solid ${C.border}`,
            background:C.cardBg, cursor:'pointer', display:'flex',
            alignItems:'center', gap:5, color:C.inkMid, flexShrink:0 }}>
          <RefreshCw size={13} style={{ animation:loading?'spin 1s linear infinite':'none' }}/>
        </button>
      </div>

      {/* Desktop Table */}
      <div className="sa-desktop-table"
        style={{ background:C.cardBg, borderRadius:16, border:`1px solid ${C.border}`,
          overflow:'hidden', boxShadow:'0 2px 16px rgba(28,23,18,0.06)' }}>
        {loading ? (
          <div style={{ textAlign:'center', padding:60, color:C.inkLight }}>
            <RefreshCw size={26} style={{ animation:'spin 1s linear infinite', opacity:0.35 }}/>
            <p style={{ marginTop:12, fontSize:13 }}>Loading salons…</p>
          </div>
        ) : salons.length === 0 ? (
          <div style={{ textAlign:'center', padding:64, color:C.inkLight }}>
            <Building2 size={38} style={{ opacity:0.2, marginBottom:12 }}/>
            <p style={{ fontSize:14 }}>No salons found</p>
          </div>
        ) : (
          <div style={{ overflowX:'auto', WebkitOverflowScrolling:'touch' }}>
            <table style={{ width:'100%', borderCollapse:'collapse', minWidth:800 }}>
              <thead>
                <tr style={{ borderBottom:`1px solid ${C.border}`, background:'#FAFAF7' }}>
                  {['Salon','Slug','Plan','Subscription','Session','Admin','Status',''].map(h=>(
                    <th key={h} style={{ padding:'11px 14px', textAlign:'left',
                      fontSize:10.5, fontWeight:600, color:C.inkLight,
                      letterSpacing:'0.08em', textTransform:'uppercase', whiteSpace:'nowrap' }}>
                      {h==='Session'      ? <span style={{ display:'inline-flex', alignItems:'center', gap:4 }}><Timer size={11}/> {h}</span>
                      : h==='Subscription'? <span style={{ display:'inline-flex', alignItems:'center', gap:4 }}><CalendarCheck size={11}/> {h}</span>
                      : h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {salons.map((s, i) => {
                  const plan     = PLAN_BADGE[s.plan] || PLAN_BADGE.plan1;
                  const hovered  = hoveredRow === s._id;
                  const sessionH = s.sessionLimitHours ?? 24;
                  return (
                    <tr key={s._id}
                      onMouseEnter={()=>setHoveredRow(s._id)}
                      onMouseLeave={()=>setHoveredRow(null)}
                      style={{
                        borderBottom: i < salons.length-1 ? `1px solid ${C.border}` : 'none',
                        background: s.isSuspended
                          ? `${C.redPale}50`
                          : hovered ? '#F8F5EE' : 'transparent',
                        transition:'background 0.15s',
                      }}>

                      <td style={{ padding:'12px 14px' }}>
                        <div style={{ fontWeight:600, fontSize:13, color:C.ink }}>{s.name}</div>
                        {s.email && <div style={{ fontSize:11, color:C.inkLight, marginTop:1 }}>{s.email}</div>}
                      </td>

                      <td style={{ padding:'12px 14px' }}>
                        <code style={{ fontSize:12, fontFamily:'monospace', color:C.inkMid,
                          background:`${C.border}55`, padding:'2px 7px', borderRadius:5 }}>
                          {s.slug}
                        </code>
                      </td>

                      <td style={{ padding:'12px 14px' }}>
                        <span style={{ fontSize:11, fontWeight:600, padding:'3px 9px', borderRadius:20,
                          background:plan.bg, color:plan.color, border:`1px solid ${plan.border}`,
                          whiteSpace:'nowrap' }}>
                          {plan.label}
                        </span>
                      </td>

                      {/* Subscription column */}
                      <td style={{ padding:'12px 14px' }}>
                        <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
                          <SubBadge expiry={s.subscriptionExpiry} onClick={()=>setRenewTarget(s)}/>
                          {s.subscriptionExpiry && (
                            <div style={{ fontSize:10, color:C.inkLight }}>
                              {fmtDate(s.subscriptionExpiry)}
                            </div>
                          )}
                        </div>
                      </td>

                      {/* Session */}
                      <td style={{ padding:'12px 14px' }}>
                        <button onClick={()=>setSessionTarget(s)}
                          style={{ display:'inline-flex', alignItems:'center', gap:5, padding:'4px 10px',
                            borderRadius:20, background:C.purplePale, border:`1px solid ${C.purpleBorder}`,
                            cursor:'pointer', fontSize:11, fontWeight:600, color:C.purple,
                            whiteSpace:'nowrap', transition:'all 0.15s' }}
                          onMouseEnter={e=>{ e.currentTarget.style.background=`${C.purple}18`; e.currentTarget.style.transform='translateY(-1px)'; }}
                          onMouseLeave={e=>{ e.currentTarget.style.background=C.purplePale; e.currentTarget.style.transform='none'; }}>
                          <Timer size={10}/>
                          {sessionH < 24 ? `${sessionH}h` : `${sessionH/24}d`}
                        </button>
                      </td>

                      <td style={{ padding:'12px 14px' }}>
                        <div style={{ fontSize:13, color:C.inkMid }}>{s.admin?.name || '—'}</div>
                        <div style={{ fontSize:11, color:C.inkLight }}>{s.admin?.email || ''}</div>
                      </td>

                      <td style={{ padding:'12px 14px' }}>
                        <StatusBadge s={s}/>
                      </td>

                      <td style={{ padding:'10px 14px', width:190, whiteSpace:'nowrap' }}>
                        <HoverActions
                          salon={s} visible={hovered}
                          onSuspend={salon=>setSuspendTarget(salon)}
                          onUnsuspend={id=>unsuspend(id)}
                          onEdit={salon=>setEditTarget(salon)}
                          onSession={salon=>setSessionTarget(salon)}
                          onRenew={salon=>setRenewTarget(salon)}
                          onWhatsApp={salon=>navigate('/superadmin/whatsapp')}
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Mobile Cards */}
      <div className="sa-mobile-cards">
        {loading ? (
          <div style={{ textAlign:'center', padding:48, color:C.inkLight }}>
            <RefreshCw size={24} style={{ animation:'spin 1s linear infinite', opacity:0.35 }}/>
          </div>
        ) : salons.length === 0 ? (
          <div style={{ textAlign:'center', padding:48, color:C.inkLight }}>
            <Building2 size={32} style={{ opacity:0.2, marginBottom:12 }}/><p>No salons found</p>
          </div>
        ) : (
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            {salons.map((s,i)=>(
              <SalonCard key={s._id} salon={s} i={i}
                onSuspend={salon=>setSuspendTarget(salon)}
                onUnsuspend={id=>unsuspend(id)}
                onEdit={salon=>setEditTarget(salon)}
                onSession={salon=>setSessionTarget(salon)}
                onRenew={salon=>setRenewTarget(salon)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Pagination */}
      {pages > 1 && (
        <div style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:10, marginTop:20 }}>
          <button onClick={()=>setPage(p=>Math.max(1,p-1))} disabled={page===1}
            style={{ padding:'7px 12px', borderRadius:8, border:`1px solid ${C.border}`,
              background:C.cardBg, cursor:page===1?'not-allowed':'pointer',
              color:C.inkMid, opacity:page===1?0.4:1 }}>
            <ChevronLeft size={14}/>
          </button>
          <span style={{ fontSize:13, color:C.inkMid }}>Page {page} of {pages}</span>
          <button onClick={()=>setPage(p=>Math.min(pages,p+1))} disabled={page===pages}
            style={{ padding:'7px 12px', borderRadius:8, border:`1px solid ${C.border}`,
              background:C.cardBg, cursor:page===pages?'not-allowed':'pointer',
              color:C.inkMid, opacity:page===pages?0.4:1 }}>
            <ChevronRight size={14}/>
          </button>
        </div>
      )}

      {/* Modals */}
      <AnimatePresence>
        {showCreate    && <CreateModal   onClose={()=>setShowCreate(false)}    onCreated={load}/>}
        {suspendTarget && <SuspendModal  salon={suspendTarget} onClose={()=>setSuspendTarget(null)} onDone={load}/>}
        {editTarget    && <EditModal     salon={editTarget}    onClose={()=>setEditTarget(null)}    onSaved={load}/>}
        {sessionTarget && <SessionModal  salon={sessionTarget} onClose={()=>setSessionTarget(null)} onSaved={load}/>}
        {renewTarget   && <RenewModal    salon={renewTarget}   onClose={()=>setRenewTarget(null)}   onSaved={load}/>}
      </AnimatePresence>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg) } }
        .sa-desktop-table { display: block; }
        .sa-mobile-cards  { display: none;  }
        @media (max-width: 640px) {
          .sa-desktop-table { display: none;  }
          .sa-mobile-cards  { display: block; }
        }
      `}</style>
    </div>
  );
};

export default SuperAdminSalons;