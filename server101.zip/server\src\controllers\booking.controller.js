const Booking  = require('../models/Booking');
const Service  = require('../models/Service');
const User     = require('../models/User');
const Coupon   = require('../models/Coupon');
const { AppError } = require('../middlewares/errorHandler');

const generateTimeSlots = (startHour = 9, endHour = 21, intervalMinutes = 30) => {
  const slots = [];
  for (let h = startHour; h < endHour; h++) {
    for (let m = 0; m < 60; m += intervalMinutes) {
      slots.push(`${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}`);
    }
  }
  return slots;
};

const addMinutesToTime = (timeStr, minutes) => {
  const [h, m]  = timeStr.split(':').map(Number);
  const total   = h * 60 + m + minutes;
  return `${Math.floor(total/60).toString().padStart(2,'0')}:${(total%60).toString().padStart(2,'0')}`;
};

const timesOverlap = (s1, e1, s2, e2) => s1 < e2 && s2 < e1;

const getMaxPerSlot = async (tenantId) => {
  const count = await User.countDocuments({ tenantId, role: 'staff', isActive: true });
  return count > 0 ? count : 3;
};

// GET /api/bookings/available-slots
const getAvailableSlots = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { date, serviceId, staffId } = req.query;
    if (!date || !serviceId) throw new AppError('Date and service are required', 400);

    const service = await Service.findOne({ _id: serviceId, tenantId });
    if (!service) throw new AppError('Service not found', 404);

    const dayStart = new Date(date); dayStart.setHours(0,0,0,0);
    const dayEnd   = new Date(date); dayEnd.setHours(23,59,59,999);

    const filter = { tenantId, date: { $gte: dayStart, $lte: dayEnd }, status: { $nin: ['cancelled','no-show'] } };
    if (staffId) filter.staff = staffId;

    const existingBookings = await Booking.find(filter);
    const maxPerSlot       = staffId ? 1 : await getMaxPerSlot(tenantId);
    const allSlots         = generateTimeSlots(9, 21, 30);
    const duration         = service.duration;

    const availableSlots = allSlots.filter(slotStart => {
      const slotEnd = addMinutesToTime(slotStart, duration);
      if (slotEnd > '21:00') return false;

      const now = new Date();
      const bookingDate = new Date(date);
      if (bookingDate.toDateString() === now.toDateString() &&
          slotStart <= `${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}`) return false;

      const overlapCount = existingBookings.filter(b => timesOverlap(slotStart, slotEnd, b.timeSlot.start, b.timeSlot.end)).length;
      return overlapCount < maxPerSlot;
    });

    const formattedSlots = availableSlots.map(slot => {
      const endTime = addMinutesToTime(slot, duration);
      const [h] = slot.split(':').map(Number);
      const period = h >= 12 ? 'PM' : 'AM';
      const display = `${h > 12 ? h-12 : h === 0 ? 12 : h}:${slot.split(':')[1]} ${period}`;
      return { start: slot, end: endTime, display };
    });

    res.status(200).json({ success: true, slots: formattedSlots });
  } catch (error) { next(error); }
};

// POST /api/bookings/walk-in — Receptionist/Admin creates walk-in booking
const createWalkInBooking = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { customerId, serviceId, staffId, date, timeSlot, paymentMethod, notes, couponCode } = req.body;

    if (!customerId || !serviceId || !date || !timeSlot) {
      throw new AppError('Customer, service, date and time slot are required', 400);
    }

    const service = await Service.findOne({ _id: serviceId, tenantId });
    if (!service) throw new AppError('Service not found', 404);

    const customer = await User.findOne({ _id: customerId, tenantId });
    if (!customer) throw new AppError('Customer not found', 404);

    let discountAmount = 0;
    let couponApplied  = null;
    if (couponCode) {
      const coupon = await Coupon.findOne({ tenantId, code: couponCode.toUpperCase(), isActive: true });
      if (coupon) {
        const now = new Date();
        if ((!coupon.validUntil || now <= coupon.validUntil) && (coupon.maxUses === 0 || coupon.usedCount < coupon.maxUses)) {
          if (service.price >= coupon.minOrderValue) {
            discountAmount = coupon.discountType === 'percentage'
              ? (service.price * coupon.discountValue / 100)
              : coupon.discountValue;
            discountAmount = Math.min(discountAmount, service.price);
            couponApplied  = coupon._id;
            await Coupon.findByIdAndUpdate(coupon._id, { $inc: { usedCount: 1 } });
          }
        }
      }
    }

    const finalAmount = service.price - discountAmount;

    const booking = await Booking.create({
      tenantId,
      customer:      customerId,
      service:       serviceId,
      staff:         staffId || null,
      date:          new Date(date),
      timeSlot,
      type:          'walk-in',
      totalAmount:   service.price,
      discountAmount,
      finalAmount,
      paymentMethod: paymentMethod || 'cash',
      paymentStatus: paymentMethod && paymentMethod !== 'none' ? 'paid' : 'pending',
      notes:         notes || '',
      status:        'confirmed',
    });

    const populated = await Booking.findById(booking._id)
      .populate('customer', 'name phone email')
      .populate('service',  'name category price duration')
      .populate('staff',    'name');

    res.status(201).json({ success: true, message: 'Walk-in booking created', booking: populated });
  } catch (error) { next(error); }
};

// POST /api/bookings — Customer/online booking (only for standard+ plan)
const createBooking = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { serviceId, staffId, date, timeSlot, couponCode, notes } = req.body;
    const customerId = req.user.userId;

    if (!serviceId || !date || !timeSlot) throw new AppError('Service, date and time slot are required', 400);

    const service = await Service.findOne({ _id: serviceId, tenantId });
    if (!service) throw new AppError('Service not found', 404);

    let discountAmount = 0;
    if (couponCode) {
      const coupon = await Coupon.findOne({ tenantId, code: couponCode.toUpperCase(), isActive: true });
      if (coupon && service.price >= coupon.minOrderValue) {
        discountAmount = coupon.discountType === 'percentage'
          ? (service.price * coupon.discountValue / 100) : coupon.discountValue;
        discountAmount = Math.min(discountAmount, service.price);
        await Coupon.findByIdAndUpdate(coupon._id, { $inc: { usedCount: 1 } });
      }
    }

    const booking = await Booking.create({
      tenantId,
      customer:      customerId,
      service:       serviceId,
      staff:         staffId || null,
      date:          new Date(date),
      timeSlot,
      type:          'online',
      totalAmount:   service.price,
      discountAmount,
      finalAmount:   service.price - discountAmount,
      notes:         notes || '',
      status:        'confirmed',
    });

    const populated = await Booking.findById(booking._id)
      .populate('service', 'name category price duration')
      .populate('staff', 'name');

    res.status(201).json({ success: true, message: 'Booking confirmed', booking: populated });
  } catch (error) { next(error); }
};

// GET /api/bookings
const getBookings = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { status, date, staffId, page = 1, limit = 20, search } = req.query;

    const filter = { tenantId };
    if (status)  filter.status  = status;
    if (staffId) filter.staff   = staffId;
    if (date) {
      const d = new Date(date); d.setHours(0,0,0,0);
      const e = new Date(date); e.setHours(23,59,59,999);
      filter.date = { $gte: d, $lte: e };
    }

    // staff only see their bookings
    if (req.user.role === 'staff') filter.staff = req.user.userId;

    const [bookings, total] = await Promise.all([
      Booking.find(filter)
        .populate('customer', 'name phone email')
        .populate('service',  'name category price duration')
        .populate('staff',    'name')
        .sort({ date: -1, 'timeSlot.start': 1 })
        .skip((Number(page)-1) * Number(limit))
        .limit(Number(limit)),
      Booking.countDocuments(filter),
    ]);

    res.status(200).json({ success: true, bookings, total, page: Number(page), pages: Math.ceil(total/limit) });
  } catch (error) { next(error); }
};

// PATCH /api/bookings/:id/status
const updateBookingStatus = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const { status, cancelReason, paymentMethod, paymentStatus } = req.body;

    const booking = await Booking.findOne({ _id: req.params.id, tenantId });
    if (!booking) throw new AppError('Booking not found', 404);

    booking.status = status;
    if (status === 'cancelled')  { booking.cancelledAt = new Date(); booking.cancelReason = cancelReason || ''; }
    if (status === 'completed')  { booking.completedAt = new Date(); }
    if (paymentMethod) booking.paymentMethod = paymentMethod;
    if (paymentStatus) booking.paymentStatus = paymentStatus;

    await booking.save();

    res.status(200).json({ success: true, message: `Booking ${status}`, booking });
  } catch (error) { next(error); }
};

// GET /api/bookings/today/stats
const getTodayStats = async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const today    = new Date(); today.setHours(0,0,0,0);
    const tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate()+1);
    const dateRange = { $gte: today, $lt: tomorrow };

    const [total, confirmed, completed, cancelled, revenue] = await Promise.all([
      Booking.countDocuments({ tenantId, date: dateRange }),
      Booking.countDocuments({ tenantId, date: dateRange, status: 'confirmed' }),
      Booking.countDocuments({ tenantId, date: dateRange, status: 'completed' }),
      Booking.countDocuments({ tenantId, date: dateRange, status: 'cancelled' }),
      Booking.aggregate([
        { $match: { tenantId: new (require('mongoose').Types.ObjectId)(tenantId), date: dateRange, status: 'completed', paymentStatus: 'paid' } },
        { $group: { _id: null, total: { $sum: '$finalAmount' } } }
      ]),
    ]);

    res.status(200).json({ success: true, stats: { total, confirmed, completed, cancelled, revenue: revenue[0]?.total || 0 } });
  } catch (error) { next(error); }
};

module.exports = { getAvailableSlots, createBooking, createWalkInBooking, getBookings, updateBookingStatus, getTodayStats };
