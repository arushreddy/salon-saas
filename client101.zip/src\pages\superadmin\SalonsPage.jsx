import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSA } from '../../context/SuperAdminContext';

const STATUS_COLORS = {
  active:    'bg-green-500/15 text-green-400 border-green-500/30',
  trial:     'bg-blue-500/15 text-blue-400 border-blue-500/30',
  expired:   'bg-red-500/15 text-red-400 border-red-500/30',
  suspended: 'bg-orange-500/15 text-orange-400 border-orange-500/30',
  cancelled: 'bg-slate-600/15 text-slate-400 border-slate-600/30',
};

export default function SalonsPage() {
  const { get, patch, post } = useSA();
  const navigate = useNavigate();

  const [tenants, setTenants]   = useState([]);
  const [total, setTotal]       = useState(0);
  const [page, setPage]         = useState(1);
  const [loading, setLoading]   = useState(false);
  const [search, setSearch]     = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [planFilter, setPlanFilter]     = useState('');
  const [actionLoading, setActionLoading] = useState({});

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await get('/', { search, status: statusFilter, plan: planFilter, page, limit: 15 });
      setTenants(res.data.data);
      setTotal(res.data.total);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [search, statusFilter, planFilter, page]);

  useEffect(() => { load(); }, [load]);

  const toggleAccess = async (id, e) => {
    e.stopPropagation();
    setActionLoading(p => ({ ...p, [id]: true }));
    try {
      await patch(`/${id}/toggle-access`);
      load();
    } finally { setActionLoading(p => ({ ...p, [id]: false })); }
  };

  const sendWA = async (id, type, e) => {
    e.stopPropagation();
    try {
      await post(`/${id}/whatsapp`, { type });
      alert('WhatsApp message sent!');
    } catch (err) { alert(err.response?.data?.message || 'Failed to send'); }
  };

  const daysLeftBadge = (t) => {
    const sub = t.subscription;
    if (!sub) return null;
    const end = sub.status === 'trial' ? sub.trialEndsAt : sub.endDate;
    if (!end) return null;
    const days = Math.ceil((new Date(end) - new Date()) / 86400000);
    if (days < 0) return <span className="text-xs text-red-400">Expired</span>;
    if (days <= 7) return <span className="text-xs text-yellow-400 font-semibold">{days}d left ⚠️</span>;
    return <span className="text-xs text-slate-400">{days} days</span>;
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-white">Salons</h1>
          <p className="text-slate-400 text-sm">{total} total salons registered</p>
        </div>
        <button
          onClick={() => navigate('/superadmin/salons/new')}
          className="bg-purple-600 hover:bg-purple-500 text-white text-sm font-semibold px-4 py-2 rounded-xl transition-colors"
        >
          + Add Salon
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <input
          value={search}
          onChange={e => { setSearch(e.target.value); setPage(1); }}
          placeholder="Search by name, phone, email…"
          className="flex-1 min-w-48 bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
        />
        <select
          value={statusFilter}
          onChange={e => { setStatusFilter(e.target.value); setPage(1); }}
          className="bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-purple-500"
        >
          <option value="">All Status</option>
          <option value="active">Active</option>
          <option value="trial">Trial</option>
          <option value="expired">Expired</option>
          <option value="suspended">Suspended</option>
        </select>
        <select
          value={planFilter}
          onChange={e => { setPlanFilter(e.target.value); setPage(1); }}
          className="bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-purple-500"
        >
          <option value="">All Plans</option>
          <option value="basic">Basic</option>
          <option value="standard">Standard</option>
          <option value="premium">Premium</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-48">
            <div className="w-7 h-7 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-slate-800">
                <tr className="text-slate-500 text-left text-xs uppercase tracking-wide">
                  <th className="px-5 py-3 font-medium">Salon</th>
                  <th className="px-4 py-3 font-medium">Owner / Phone</th>
                  <th className="px-4 py-3 font-medium">Plan</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">Validity</th>
                  <th className="px-4 py-3 font-medium">Staff</th>
                  <th className="px-4 py-3 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {tenants.map(t => (
                  <tr key={t._id}
                      onClick={() => navigate(`/superadmin/salons/${t._id}`)}
                      className="border-b border-slate-800/50 hover:bg-slate-800/40 cursor-pointer transition-colors">
                    <td className="px-5 py-3">
                      <p className="text-white font-medium">{t.salonName}</p>
                      <p className="text-slate-500 text-xs">{t.email}</p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-slate-300">{t.ownerName}</p>
                      <p className="text-slate-500 text-xs">{t.phone}</p>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs capitalize bg-purple-600/20 text-purple-400 px-2 py-0.5 rounded-full">
                        {t.subscription?.plan || '—'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full border capitalize ${STATUS_COLORS[t.subscription?.status] || 'bg-slate-700 text-slate-400 border-slate-600'}`}>
                        {t.isActive === false ? 'suspended' : (t.subscription?.status || '—')}
                      </span>
                    </td>
                    <td className="px-4 py-3">{daysLeftBadge(t)}</td>
                    <td className="px-4 py-3 text-slate-400">{t.liveStaffCount ?? 0}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
                        {/* Toggle access */}
                        <button
                          onClick={e => toggleAccess(t._id, e)}
                          disabled={actionLoading[t._id]}
                          title={t.isActive ? 'Suspend' : 'Reactivate'}
                          className={`p-1.5 rounded-lg text-xs transition-colors ${t.isActive ? 'bg-orange-500/10 text-orange-400 hover:bg-orange-500/20' : 'bg-green-500/10 text-green-400 hover:bg-green-500/20'}`}
                        >
                          {t.isActive ? '⛔' : '✅'}
                        </button>
                        {/* WhatsApp */}
                        <button
                          onClick={e => sendWA(t._id, 'activation', e)}
                          title="Send WhatsApp"
                          className="p-1.5 rounded-lg text-xs bg-green-500/10 text-green-400 hover:bg-green-500/20 transition-colors"
                        >
                          💬
                        </button>
                        {/* Detail */}
                        <button
                          onClick={e => { e.stopPropagation(); navigate(`/superadmin/salons/${t._id}`); }}
                          title="View Details"
                          className="p-1.5 rounded-lg text-xs bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 transition-colors"
                        >
                          👁
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {tenants.length === 0 && (
                  <tr><td colSpan={7} className="text-center py-12 text-slate-500">No salons found</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {total > 15 && (
          <div className="flex items-center justify-between px-5 py-3 border-t border-slate-800">
            <span className="text-slate-500 text-sm">{total} salons</span>
            <div className="flex gap-2">
              <button disabled={page <= 1} onClick={() => setPage(p => p - 1)}
                className="text-sm px-3 py-1 rounded-lg bg-slate-800 text-slate-300 disabled:opacity-40 hover:bg-slate-700">
                ← Prev
              </button>
              <span className="text-slate-400 text-sm px-2">Page {page}</span>
              <button disabled={page * 15 >= total} onClick={() => setPage(p => p + 1)}
                className="text-sm px-3 py-1 rounded-lg bg-slate-800 text-slate-300 disabled:opacity-40 hover:bg-slate-700">
                Next →
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
