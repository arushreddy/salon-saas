import { useState, useEffect } from 'react';
import { useSA } from '../../context/SuperAdminContext';

export default function ReportsPage() {
  const { get, post } = useSA();
  const [data, setData]   = useState(null);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);

  useEffect(() => {
    get('/report').then(r => setData(r.data.data)).finally(() => setLoading(false));
  }, []);

  const bulkRemind = async () => {
    setSending(true);
    try {
      const r = await post('/whatsapp/bulk', { type: 'warning' });
      alert(`Sent: ${r.data.sent}, Failed: ${r.data.failed}`);
    } finally { setSending(false); }
  };

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin"/>
    </div>
  );

  const s = data?.summary || {};
  const months = data?.monthlyRevenue || [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-white">Reports</h1>
          <p className="text-slate-400 text-sm">Subscription & revenue analytics</p>
        </div>
        <button onClick={bulkRemind} disabled={sending}
          className="bg-green-700 hover:bg-green-600 disabled:opacity-50 text-white text-sm font-medium px-4 py-2 rounded-xl">
          {sending ? 'Sending…' : '💬 Bulk Expiry Reminder'}
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: 'Active',       value: s.active,       color: 'text-green-400'  },
          { label: 'Trial',        value: s.trial,        color: 'text-blue-400'   },
          { label: 'Expired',      value: s.expired,      color: 'text-red-400'    },
          { label: 'Suspended',    value: s.suspended,    color: 'text-orange-400' },
          { label: 'Expiring 7d',  value: s.expiringIn7,  color: 'text-yellow-400' },
          { label: 'Expiring 30d', value: s.expiringIn30, color: 'text-amber-400'  },
        ].map(c => (
          <div key={c.label} className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-center">
            <p className="text-slate-400 text-xs">{c.label}</p>
            <p className={`text-2xl font-bold mt-1 ${c.color}`}>{c.value ?? 0}</p>
          </div>
        ))}
      </div>

      {/* Monthly Revenue */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
        <h2 className="text-white font-semibold mb-5">Monthly Revenue (last 6 months)</h2>
        {months.length === 0
          ? <p className="text-slate-500 text-sm">No payment data yet.</p>
          : (
          <div className="space-y-3">
            {[...months].reverse().map((m) => {
              const maxRev = Math.max(...months.map(x => x.revenue), 1);
              const pct    = Math.round((m.revenue / maxRev) * 100);
              const label  = new Date(m._id.year, m._id.month - 1).toLocaleString('en-IN', { month: 'short', year: 'numeric' });
              return (
                <div key={`${m._id.year}-${m._id.month}`} className="flex items-center gap-4">
                  <span className="text-slate-400 text-sm w-20 text-right">{label}</span>
                  <div className="flex-1 h-7 bg-slate-800 rounded-lg overflow-hidden">
                    <div className="h-full bg-purple-600 rounded-lg transition-all flex items-center px-3"
                         style={{ width: `${pct}%` }}>
                      <span className="text-white text-xs font-medium whitespace-nowrap">₹{m.revenue.toLocaleString('en-IN')}</span>
                    </div>
                  </div>
                  <span className="text-slate-500 text-xs w-12">{m.count} sales</span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Plan stats */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
        <h2 className="text-white font-semibold mb-4">Plan Performance</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="text-slate-500 text-xs border-b border-slate-800">
              <th className="pb-2 text-left font-medium">Plan</th>
              <th className="pb-2 text-right font-medium">Salons</th>
              <th className="pb-2 text-right font-medium">Revenue</th>
            </tr></thead>
            <tbody>
              {(data?.planStats || []).map(p => (
                <tr key={p._id} className="border-b border-slate-800/50">
                  <td className="py-3 capitalize">
                    <span className={`px-2 py-0.5 rounded-full text-xs ${p._id === 'premium' ? 'bg-yellow-500/20 text-yellow-400' : p._id === 'standard' ? 'bg-purple-500/20 text-purple-400' : 'bg-blue-500/20 text-blue-400'}`}>
                      {p._id || 'none'}
                    </span>
                  </td>
                  <td className="py-3 text-right text-slate-300">{p.count}</td>
                  <td className="py-3 text-right text-green-400 font-semibold">₹{(p.revenue || 0).toLocaleString('en-IN')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Expiring soon list */}
      {data?.expiringIn7?.length > 0 && (
        <div className="bg-yellow-500/5 border border-yellow-500/20 rounded-2xl p-6">
          <h2 className="text-yellow-400 font-semibold mb-4">⚠️ Expiring in 7 Days ({data.expiringIn7.length})</h2>
          <div className="space-y-2">
            {data.expiringIn7.map(t => (
              <div key={t._id} className="flex items-center justify-between bg-slate-900/60 rounded-xl px-4 py-3">
                <div>
                  <p className="text-white text-sm font-medium">{t.salonName}</p>
                  <p className="text-slate-400 text-xs">{t.ownerName} · {t.phone}</p>
                </div>
                <div className="text-right">
                  <p className="text-yellow-400 text-sm font-medium">
                    {new Date(t.subscription?.endDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}
                  </p>
                  <p className="text-slate-500 text-xs capitalize">{t.subscription?.plan}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
