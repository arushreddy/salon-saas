import { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';

const SuperAdminContext = createContext(null);

const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export function SuperAdminProvider({ children }) {
  const [token, setToken]   = useState(() => localStorage.getItem('sa_token'));
  const [loading, setLoading] = useState(false);

  const authHeader = () => ({ headers: { Authorization: `Bearer ${token}` } });

  const login = async (email, password) => {
    const { data } = await axios.post(`${API}/superadmin/login`, { email, password });
    localStorage.setItem('sa_token', data.token);
    setToken(data.token);
    return data;
  };

  const logout = () => {
    localStorage.removeItem('sa_token');
    setToken(null);
  };

  // API helpers
  const get    = (url, params = {}) => axios.get(`${API}/superadmin${url}`,    { ...authHeader(), params });
  const post   = (url, body = {})   => axios.post(`${API}/superadmin${url}`,   body, authHeader());
  const put    = (url, body = {})   => axios.put(`${API}/superadmin${url}`,    body, authHeader());
  const patch  = (url, body = {})   => axios.patch(`${API}/superadmin${url}`,  body, authHeader());
  const del    = (url)              => axios.delete(`${API}/superadmin${url}`,  authHeader());

  return (
    <SuperAdminContext.Provider value={{ token, loading, setLoading, login, logout, get, post, put, patch, del }}>
      {children}
    </SuperAdminContext.Provider>
  );
}

export const useSA = () => useContext(SuperAdminContext);
