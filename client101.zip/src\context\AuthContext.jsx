import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import api from '@/services/api';

const AuthContext = createContext(null);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser]       = useState(null);
  const [loading, setLoading] = useState(true);
  const [subscriptionExpired, setSubscriptionExpired] = useState(false);

  const fetchUser = useCallback(async () => {
    try {
      const token = localStorage.getItem('accessToken');
      if (!token) { setLoading(false); return; }
      const { data } = await api.get('/auth/me');
      setUser(data.user);
    } catch (error) {
      if (error.response?.status === 402) {
        setSubscriptionExpired(true);
      }
      localStorage.removeItem('accessToken');
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchUser(); }, [fetchUser]);

  const login = async (email, password) => {
    const { data } = await api.post('/auth/login', { email, password });
    localStorage.setItem('accessToken', data.accessToken);
    setUser(data.user);
    setSubscriptionExpired(false);
    return data;
  };

  const logout = async () => {
    try { await api.post('/auth/logout'); } catch (_) {}
    finally {
      localStorage.removeItem('accessToken');
      setUser(null);
      setSubscriptionExpired(false);
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      loading,
      subscriptionExpired,
      login,
      logout,
      fetchUser,
      isAuthenticated:  !!user,
      isAdmin:          user?.role === 'admin',
      isStaff:          user?.role === 'staff',
      isReceptionist:   user?.role === 'receptionist',
      isCustomer:       user?.role === 'customer',
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
