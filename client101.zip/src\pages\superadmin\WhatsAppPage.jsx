import { useState } from 'react';
import { useSA } from '../../context/SuperAdminContext';

export default function WhatsAppPage() {
  const { post } = useSA();
  const [type, setType]           = useState('warning');
  const [customMsg, setCustomMsg] = useState('');
  const [result, setResult]       = useState(null);
  const [loading, setLoading]     = useState(false);

  const send = async () => {
    setLoading(true);
    setResult(null);
    try {
      const r = await post('/whatsapp/bulk', { type, customMessage: customMsg });
      setResult(r.data);
    } catch (e) {
      setResult({ error: e.response?.data?.message || 'Failed' });
    } finally { setLoading(false); }
  };

  const msgPreviews = {
    activation: `✅ *Salon Name* – Subscription Activated!\n\nHello Owner,\n\nYour BASIC plan is now active.\n📅 Valid till: DD Mon YYYY\n\nLogin: https://yourdomain.com/login`,
    warning:    `⚠️ *Salon Name* – Subscription Expiring Soon!\n\nHello Owner,\n\nYour subscription expires in *7 day(s)*.\n\nRenew now: https://yourdomain.com/renew`,
    expired:    `🚫 *Salon Name* – Subscription Expired\n\nHello Owner,\n\nYour subscription has expired. Access suspended.\n\nContact: +91XXXXXXXXXX`,
    suspended:  `⛔ *Salon Name* – Account Suspended\n\nHello Owner,\n\nYour account has been suspended. Contact support.`,
    custom:     customMsg || '(Your custom message here)',
  };

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h1 className="text-xl font-bold text-white">WhatsApp Broadcast</h1>
        <p className="text-slate-400 text-sm mt-0.5">Send bulk messages to all salon owners</p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
        <div>
          <label className="text-slate-400 text-xs mb-2 block font-medium uppercase tracking-wide">Message Type</label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { val: 'activation', label: '✅ Activation',       desc: 'Subscription activated' },
              { val: 'warning',    label: '⚠️ Expiry Warning',   desc: 'Expiring within 7 days' },
              { val: 'expired',    label: '🚫 Expired Notice',   desc: 'Subscription expired' },
              { val: 'custom',     label: '💬 Custom',           desc: 'Your own message' },
            ].map(opt => (
              <button key={opt.val} onClick={() => setType(opt.val)}
                className={`text-left p-3 rounded-xl border transition-colors ${type === opt.val ? 'border-purple-500 bg-purple-600/15' : 'border-slate-700 bg-slate-800 hover:border-slate-600'}`}>
                <p className={`text-sm font-medium ${type === opt.val ? 'text-purple-300' : 'text-slate-300'}`}>{opt.label}</p>
                <p className="text-slate-500 text-xs mt-0.5">{opt.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {type === 'custom' && (
          <div>
            <label className="text-slate-400 text-xs mb-1 block">Custom Message</label>
            <textarea rows={4} value={customMsg} onChange={e => setCustomMsg(e.target.value)}
              placeholder="Enter your message…"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500 resize-none"/>
          </div>
        )}

        {/* Preview */}
        <div>
          <label className="text-slate-400 text-xs mb-2 block font-medium uppercase tracking-wide">Message Preview</label>
          <div className="bg-slate-800 rounded-xl p-4">
            <pre className="text-slate-300 text-xs whitespace-pre-wrap font-sans leading-relaxed">
              {msgPreviews[type]}
            </pre>
          </div>
        </div>

        <button onClick={send} disabled={loading || (type === 'custom' && !customMsg)}
          className="w-full bg-green-700 hover:bg-green-600 disabled:opacity-50 text-white font-semibold py-2.5 rounded-xl text-sm transition-colors">
          {loading ? 'Sending…' : `📤 Send to All Salons`}
        </button>

        {result && !result.error && (
          <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-4 text-sm">
            <p className="text-green-400 font-medium">Broadcast complete!</p>
            <p className="text-slate-400 mt-1">✓ Sent: <strong className="text-white">{result.sent}</strong> &nbsp;✗ Failed: <strong className="text-white">{result.failed}</strong> &nbsp;Total: {result.total}</p>
          </div>
        )}
        {result?.error && (
          <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 text-sm text-red-400">
            {result.error}
          </div>
        )}
      </div>

      {/* Info box */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-sm text-slate-400">
        <h3 className="text-slate-300 font-medium mb-2">How WhatsApp notifications work</h3>
        <ul className="space-y-1.5">
          <li>• Set <code className="text-purple-400 bg-slate-800 px-1 rounded">WHATSAPP_PROVIDER</code> in .env to <code className="text-purple-400 bg-slate-800 px-1 rounded">twilio</code>, <code className="text-purple-400 bg-slate-800 px-1 rounded">meta</code>, or <code className="text-purple-400 bg-slate-800 px-1 rounded">log</code></li>
          <li>• The daily cron job automatically sends 7-day warnings and expiry notices</li>
          <li>• Messages include the salon's name and owner name dynamically</li>
          <li>• Use the individual salon page to send targeted messages</li>
        </ul>
      </div>
    </div>
  );
}
