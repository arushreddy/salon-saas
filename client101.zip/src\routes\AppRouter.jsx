import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { SuperAdminProvider } from '@/context/SuperAdminContext';

import RootLayout    from '@/layouts/RootLayout';
import AdminLayout   from '@/layouts/AdminLayout';
import StaffLayout   from '@/layouts/StaffLayout';
import SuperAdminLayout from '@/layouts/SuperAdminLayout';
import ProtectedRoute from '@/components/ProtectedRoute';

import Home  from '@/pages/Home';
import Login from '@/pages/Login';

// Super Admin pages
import SuperAdminLogin     from '@/pages/superadmin/SuperAdminLogin';
import SuperAdminDashboard from '@/pages/superadmin/SuperAdminDashboard';
import SalonsPage          from '@/pages/superadmin/SalonsPage';
import SalonDetail         from '@/pages/superadmin/SalonDetail';
import AddSalon            from '@/pages/superadmin/AddSalon';
import ReportsPage         from '@/pages/superadmin/ReportsPage';
import WhatsAppPage        from '@/pages/superadmin/WhatsAppPage';

// Admin pages
import AdminDashboard  from '@/pages/admin/AdminDashboard';
import AdminServices   from '@/pages/admin/AdminServices';
import AdminStaff      from '@/pages/admin/AdminStaff';
import AdminCustomers  from '@/pages/admin/AdminCustomers';
import AdminBookings   from '@/pages/admin/AdminBookings';
import AdminAttendance from '@/pages/admin/AdminAttendance';
import AdminInventory  from '@/pages/admin/AdminInventory';
import AdminInvoices   from '@/pages/admin/AdminInvoices';
import AdminCoupons    from '@/pages/admin/AdminCoupons';
import AdminPayments   from '@/pages/admin/AdminPayments';
import AdminSettings   from '@/pages/admin/AdminSettings';
import AdminAnalytics  from '@/pages/admin/AdminAnalytics';
import SetupWizard     from '@/pages/admin/SetupWizard';

// Staff + Receptionist pages
import StaffHome            from '@/pages/staff/StaffHome';
import StaffHistory         from '@/pages/staff/StaffHistory';
import StaffSalary          from '@/pages/staff/StaffSalary';
import StaffAttendance      from '@/pages/staff/StaffAttendance';
import StaffNotifications   from '@/pages/staff/StaffNotifications';
import ReceptionistPanel    from '@/pages/staff/ReceptionistPanel';
import ReceptionistDashboard    from '@/pages/receptionist/ReceptionistDashboard';
import ReceptionistAppointments from '@/pages/receptionist/ReceptionistAppointments';
import ReceptionistCustomers    from '@/pages/receptionist/ReceptionistCustomers';
import ReceptionistInventory    from '@/pages/receptionist/ReceptionistInventory';
import ReceptionistStaff        from '@/pages/receptionist/ReceptionistStaff';
import ReceptionistCash         from '@/pages/receptionist/ReceptionistCash';

const StaffOrReceptionistHome = () => {
  const { user } = useAuth();
  if (user?.role === 'receptionist') return <ReceptionistDashboard />;
  return <StaffHome />;
};

const AppRouter = () => {
  return (
    <BrowserRouter>
      <Routes>

        {/* ── Super Admin (separate context, separate layout) ─────────────── */}
        <Route path="/superadmin/login" element={<SuperAdminProvider><SuperAdminLogin /></SuperAdminProvider>} />
        <Route path="/superadmin" element={<SuperAdminProvider><SuperAdminLayout /></SuperAdminProvider>}>
          <Route index                element={<Navigate to="dashboard" replace />} />
          <Route path="dashboard"     element={<SuperAdminDashboard />} />
          <Route path="salons"        element={<SalonsPage />} />
          <Route path="salons/new"    element={<AddSalon />} />
          <Route path="salons/:id"    element={<SalonDetail />} />
          <Route path="report"        element={<ReportsPage />} />
          <Route path="whatsapp"      element={<WhatsAppPage />} />
        </Route>

        {/* ── Setup wizard ────────────────────────────────────────────────── */}
        <Route path="/setup" element={<ProtectedRoute allowedRoles={['admin']}><SetupWizard /></ProtectedRoute>} />

        {/* ── Public ──────────────────────────────────────────────────────── */}
        <Route element={<RootLayout />}>
          <Route path="/" element={<Home />} />
        </Route>
        <Route path="/login" element={<Login />} />

        {/* ── Admin ────────────────────────────────────────────────────────── */}
        <Route path="/admin" element={<ProtectedRoute allowedRoles={['admin']}><AdminLayout /></ProtectedRoute>}>
          <Route index               element={<AdminDashboard />} />
          <Route path="appointments" element={<AdminBookings />} />
          <Route path="attendance"   element={<AdminAttendance />} />
          <Route path="services"     element={<AdminServices />} />
          <Route path="staff"        element={<AdminStaff />} />
          <Route path="customers"    element={<AdminCustomers />} />
          <Route path="payments"     element={<AdminPayments />} />
          <Route path="inventory"    element={<AdminInventory />} />
          <Route path="invoices"     element={<AdminInvoices />} />
          <Route path="coupons"      element={<AdminCoupons />} />
          <Route path="analytics"    element={<AdminAnalytics />} />
          <Route path="settings"     element={<AdminSettings />} />
        </Route>

        {/* ── Staff & Receptionist ─────────────────────────────────────────── */}
        <Route path="/staff" element={<ProtectedRoute allowedRoles={['staff','receptionist']}><StaffLayout /></ProtectedRoute>}>
          <Route index                element={<StaffOrReceptionistHome />} />
          <Route path="history"       element={<StaffHistory />} />
          <Route path="salary"        element={<StaffSalary />} />
          <Route path="attendance"    element={<StaffAttendance />} />
          <Route path="notifications" element={<StaffNotifications />} />
          <Route path="reception"     element={<ProtectedRoute allowedRoles={['receptionist']}><ReceptionistPanel /></ProtectedRoute>} />
          <Route path="appointments"  element={<ProtectedRoute allowedRoles={['receptionist']}><ReceptionistAppointments /></ProtectedRoute>} />
          <Route path="customers"     element={<ProtectedRoute allowedRoles={['receptionist']}><ReceptionistCustomers /></ProtectedRoute>} />
          <Route path="inventory"     element={<ProtectedRoute allowedRoles={['receptionist']}><ReceptionistInventory /></ProtectedRoute>} />
          <Route path="staff-status"  element={<ProtectedRoute allowedRoles={['receptionist']}><ReceptionistStaff /></ProtectedRoute>} />
          <Route path="cash"          element={<ProtectedRoute allowedRoles={['receptionist']}><ReceptionistCash /></ProtectedRoute>} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
};

export default AppRouter;
