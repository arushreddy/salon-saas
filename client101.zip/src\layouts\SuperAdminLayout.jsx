import { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useSA } from '../context/SuperAdminContext';

const navItems = [
  { to: '/superadmin/dashboard', icon: '📊', label: 'Dashboard' },
  { to: '/superadmin/salons',    icon: '💇', label: 'Salons' },
  { to: '/superadmin/report',    icon: '📈', label: 'Reports' },
  { to: '/superadmin/whatsapp',  icon: '💬', label: 'WhatsApp' },
];

export default function SuperAdminLayout() {
  const { logout, token } = useSA();
  const navigate = useNavigate();
  const [sideOpen, setSideOpen] = useState(true);

  if (!token) { navigate('/superadmin/login'); return null; }

  const handleLogout = () => { logout(); navigate('/superadmin/login'); };

  return (
    <div className="min-h-screen bg-slate-950 flex">
      {/* Sidebar */}
      <aside className={`${sideOpen ? 'w-60' : 'w-16'} bg-slate-900 border-r border-slate-800 flex flex-col transition-all duration-200 flex-shrink-0`}>
        {/* Logo */}
        <div className="h-16 flex items-center px-4 border-b border-slate-800 gap-3">
          <div className="w-8 h-8 rounded-lg bg-purple-600 flex items-center justify-center flex-shrink-0">
            <span className="text-white text-sm font-bold">SA</span>
          </div>
          {sideOpen && <span className="text-white font-semibold text-sm truncate">Super Admin</span>}
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 px-2 space-y-1">
          {navItems.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-colors ${
                  isActive ? 'bg-purple-600/20 text-purple-400' : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`
              }
            >
              <span className="text-base flex-shrink-0">{item.icon}</span>
              {sideOpen && <span>{item.label}</span>}
            </NavLink>
          ))}
        </nav>

        {/* Bottom */}
        <div className="p-3 border-t border-slate-800">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
          >
            <span className="text-base flex-shrink-0">🚪</span>
            {sideOpen && <span>Logout</span>}
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Topbar */}
        <header className="h-16 bg-slate-900 border-b border-slate-800 flex items-center px-6 gap-4 flex-shrink-0">
          <button onClick={() => setSideOpen(!sideOpen)} className="text-slate-400 hover:text-white">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16"/>
            </svg>
          </button>
          <span className="text-slate-200 font-medium text-sm flex-1">Salon SaaS · Control Panel</span>
          <span className="text-xs bg-purple-600/20 text-purple-400 px-3 py-1 rounded-full">Super Admin</span>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
