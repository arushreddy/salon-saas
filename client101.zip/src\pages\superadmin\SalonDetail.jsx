import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useSA } from '../../context/SuperAdminContext';

export default function SalonDetail() {
  const { id } = useParams();
  const { get, put, post, patch, del } = useSA();
  const navigate = useNavigate();

  const [tenant, setTenant]   = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab]         = useState('overview');
  const [saving, setSaving]   = useState(false);
  const [msg, setMsg]         = useState('');

  // Subscription form
  const [subForm, setSubForm] = useState({
    plan: 'basic', durationDays: 30,
    paymentAmount: '', paymentMethod: 'cash', paymentReference: '', notes: ''
  });

  // Edit form
  const [editForm, setEditForm] = useState({});

  // WA form
  const [waType, setWaType]         = useState('activation');
  const [customMsg, setCustomMsg]   = useState('');
  const [newPassword, setNewPassword] = useState('');

  const load = async () => {
    try {
      const r = await get(`/${id}`);
      setTenant(r.data.data);
      setEditForm({
        salonName: r.data.data.salonName,
        ownerName: r.data.data.ownerName,
        phone:     r.data.data.phone,
        whatsapp:  r.data.data.whatsapp || '',
        'address.city':    r.data.data.address?.city || '',
        'address.state':   r.data.data.address?.state || '',
        'address.pincode': r.data.data.address?.pincode || '',
        accessNotes: r.data.data.accessNotes || '',
      });
      setSubForm(p => ({ ...p, plan: r.data.data.subscription?.plan || 'basic' }));
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [id]);

  const flash = (m) => { setMsg(m); setTimeout(() => setMsg(''), 3000); };

  const activateSub = async () => {
    setSaving(true);
    try {
      await post(`/${id}/activate`, subForm);
      flash('✅ Subscription activated!');
      load();
    } catch (e) { flash('❌ ' + (e.response?.data?.message || 'Error')); }
    finally { setSaving(false); }
  };

  const toggleAccess = async () => {
    await patch(`/${id}/toggle-access`);
    load();
  };

  const saveEdit = async () => {
    setSaving(true);
    const body = {
      salonName: editForm.salonName,
      ownerName: editForm.ownerName,
      phone:     editForm.phone,
      whatsapp:  editForm.whatsapp,
      address:   { city: editForm['address.city'], state: editForm['address.state'], pincode: editForm['address.pincode'] },
      accessNotes: editForm.accessNotes,
    };
    try {
      await put(`/${id}`, body);
      flash('✅ Updated!');
      load();
    } catch (e) { flash('❌ ' + (e.response?.data?.message || 'Error')); }
    finally { setSaving(false); }
  };

  const sendWA = async () => {
    try {
      await post(`/${id}/whatsapp`, { type: waType, customMessage: customMsg });
      flash('✅ WhatsApp sent!');
    } catch (e) { flash('❌ ' + (e.response?.data?.message || 'Send failed')); }
  };

  const resetPwd = async () => {
    if (!newPassword || newPassword.length < 6) return flash('❌ Min 6 chars');
    try {
      await patch(`/${id}/reset-password`, { newPassword });
      flash('✅ Password reset!');
      setNewPassword('');
    } catch (e) { flash('❌ Error'); }
  };

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin"/>
    </div>
  );
  if (!tenant) return <div className="text-slate-400 p-8">Tenant not found</div>;

  const sub  = tenant.subscription || {};
  const daysLeft = (() => {
    const end = sub.status === 'trial' ? sub.trialEndsAt : sub.endDate;
    if (!end) return null;
    return Math.ceil((new Date(end) - new Date()) / 86400000);
  })();

  const statusColor = {
    active: 'text-green-400', trial: 'text-blue-400',
    expired: 'text-red-400', suspended: 'text-orange-400',
  };

  return (
    <div className="space-y-5 max-w-5xl">
      {/* Breadcrumb + header */}
      <div className="flex items-start gap-4">
        <button onClick={() => navigate('/superadmin/salons')} className="text-slate-400 hover:text-white mt-1">←</button>
        <div className="flex-1">
          <h1 className="text-xl font-bold text-white">{tenant.salonName}</h1>
          <p className="text-slate-400 text-sm">{tenant.ownerName} · {tenant.email} · {tenant.phone}</p>
        </div>
        <div className="flex items-center gap-2">
          <span className={`text-sm capitalize font-semibold ${statusColor[tenant.isActive ? sub.status : 'suspended'] || 'text-slate-400'}`}>
            {tenant.isActive ? sub.status : 'suspended'}
          </span>
          <button
            onClick={toggleAccess}
            className={`text-sm px-3 py-1.5 rounded-xl font-medium transition-colors ${tenant.isActive ? 'bg-red-500/10 text-red-400 hover:bg-red-500/20' : 'bg-green-500/10 text-green-400 hover:bg-green-500/20'}`}
          >
            {tenant.isActive ? 'Suspend' : 'Reactivate'}
          </button>
        </div>
      </div>

      {/* Flash message */}
      {msg && (
        <div className={`px-4 py-3 rounded-xl text-sm ${msg.startsWith('✅') ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
          {msg}
        </div>
      )}

      {/* Quick stats bar */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: 'Plan',       value: <span className="capitalize">{sub.plan || '—'}</span> },
          { label: 'Days Left',  value: daysLeft !== null ? (daysLeft > 0 ? `${daysLeft}d` : 'Expired') : '—' },
          { label: 'Staff',      value: tenant.liveStaffCount ?? 0 },
          { label: 'Since',      value: new Date(tenant.createdAt).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'2-digit' }) },
        ].map(s => (
          <div key={s.label} className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-center">
            <p className="text-slate-400 text-xs">{s.label}</p>
            <p className="text-white font-bold text-lg mt-0.5">{s.value}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1 w-fit">
        {['overview', 'subscription', 'whatsapp', 'security'].map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-1.5 rounded-lg text-sm capitalize transition-colors ${tab === t ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'}`}>
            {t}
          </button>
        ))}
      </div>

      {/* Tab: Overview / Edit */}
      {tab === 'overview' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="text-white font-semibold">Salon Information</h2>
          <div className="grid grid-cols-2 gap-4">
            {[
              ['Salon Name', 'salonName'],
              ['Owner Name', 'ownerName'],
              ['Phone', 'phone'],
              ['WhatsApp', 'whatsapp'],
              ['City', 'address.city'],
              ['State', 'address.state'],
              ['Pincode', 'address.pincode'],
            ].map(([label, key]) => (
              <div key={key}>
                <label className="text-slate-400 text-xs mb-1 block">{label}</label>
                <input
                  value={editForm[key] || ''}
                  onChange={e => setEditForm(p => ({ ...p, [key]: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500"
                />
              </div>
            ))}
            <div className="col-span-2">
              <label className="text-slate-400 text-xs mb-1 block">Internal Notes</label>
              <textarea
                rows={2}
                value={editForm.accessNotes || ''}
                onChange={e => setEditForm(p => ({ ...p, accessNotes: e.target.value }))}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500 resize-none"
              />
            </div>
          </div>
          <button onClick={saveEdit} disabled={saving}
            className="bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white text-sm font-semibold px-5 py-2 rounded-xl">
            {saving ? 'Saving…' : 'Save Changes'}
          </button>

          {/* Payment history */}
          {sub.payments?.length > 0 && (
            <div className="mt-6">
              <h3 className="text-white font-medium mb-3">Payment History</h3>
              <table className="w-full text-sm">
                <thead><tr className="text-slate-500 text-xs border-b border-slate-800">
                  <th className="pb-2 text-left font-medium">Amount</th>
                  <th className="pb-2 text-left font-medium">Method</th>
                  <th className="pb-2 text-left font-medium">Reference</th>
                  <th className="pb-2 text-left font-medium">Date</th>
                </tr></thead>
                <tbody>
                  {sub.payments.map((p, i) => (
                    <tr key={i} className="border-b border-slate-800/50">
                      <td className="py-2 text-green-400 font-semibold">₹{p.amount}</td>
                      <td className="py-2 text-slate-300 capitalize">{p.method}</td>
                      <td className="py-2 text-slate-400">{p.reference || '—'}</td>
                      <td className="py-2 text-slate-400 text-xs">{new Date(p.paidAt).toLocaleDateString('en-IN')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Tab: Subscription */}
      {tab === 'subscription' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
          <h2 className="text-white font-semibold">Activate / Renew Subscription</h2>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-slate-400 text-xs mb-1 block">Plan</label>
              <select value={subForm.plan} onChange={e => setSubForm(p => ({ ...p, plan: e.target.value }))}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500">
                <option value="basic">Basic (Admin + Staff + Receptionist)</option>
                <option value="standard">Standard (+ User Booking Panel)</option>
                <option value="premium">Premium (+ Analytics + Multi-branch)</option>
              </select>
            </div>
            <div>
              <label className="text-slate-400 text-xs mb-1 block">Duration (days)</label>
              <input type="number" min={1} value={subForm.durationDays}
                onChange={e => setSubForm(p => ({ ...p, durationDays: Number(e.target.value) }))}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500" />
            </div>
            <div>
              <label className="text-slate-400 text-xs mb-1 block">Payment Amount (₹)</label>
              <input type="number" value={subForm.paymentAmount}
                onChange={e => setSubForm(p => ({ ...p, paymentAmount: e.target.value }))}
                placeholder="0 for free / manual"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500" />
            </div>
            <div>
              <label className="text-slate-400 text-xs mb-1 block">Payment Method</label>
              <select value={subForm.paymentMethod} onChange={e => setSubForm(p => ({ ...p, paymentMethod: e.target.value }))}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500">
                <option value="cash">Cash</option>
                <option value="upi">UPI</option>
                <option value="bank_transfer">Bank Transfer</option>
                <option value="card">Card</option>
              </select>
            </div>
            <div>
              <label className="text-slate-400 text-xs mb-1 block">Reference / UTR</label>
              <input value={subForm.paymentReference}
                onChange={e => setSubForm(p => ({ ...p, paymentReference: e.target.value }))}
                placeholder="Transaction ID"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500" />
            </div>
            <div>
              <label className="text-slate-400 text-xs mb-1 block">Notes</label>
              <input value={subForm.notes} onChange={e => setSubForm(p => ({ ...p, notes: e.target.value }))}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500" />
            </div>
          </div>

          {/* Preview */}
          <div className="bg-slate-800/50 rounded-xl p-4 text-sm">
            <p className="text-slate-300">
              This will activate <strong className="text-white capitalize">{subForm.plan}</strong> plan for{' '}
              <strong className="text-white">{subForm.durationDays} days</strong> starting today.
            </p>
            <p className="text-slate-400 mt-1">
              Expires: <strong className="text-white">
                {new Date(Date.now() + subForm.durationDays * 86400000).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
              </strong>
            </p>
            <p className="text-slate-500 text-xs mt-2">
              ✓ A WhatsApp activation message will be sent automatically.
            </p>
          </div>

          <button onClick={activateSub} disabled={saving}
            className="bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-semibold px-6 py-2.5 rounded-xl text-sm">
            {saving ? 'Activating…' : 'Activate Subscription'}
          </button>
        </div>
      )}

      {/* Tab: WhatsApp */}
      {tab === 'whatsapp' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
          <h2 className="text-white font-semibold">Send WhatsApp Message</h2>
          <p className="text-slate-400 text-sm">
            Sending to: <strong className="text-white">{tenant.whatsapp || tenant.phone}</strong>
          </p>
          <div>
            <label className="text-slate-400 text-xs mb-1 block">Message Type</label>
            <select value={waType} onChange={e => setWaType(e.target.value)}
              className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500 w-full max-w-xs">
              <option value="activation">✅ Subscription Activated</option>
              <option value="warning">⚠️ Expiry Warning</option>
              <option value="expired">🚫 Subscription Expired</option>
              <option value="suspended">⛔ Account Suspended</option>
              <option value="custom">💬 Custom Message</option>
            </select>
          </div>
          {waType === 'custom' && (
            <div>
              <label className="text-slate-400 text-xs mb-1 block">Custom Message</label>
              <textarea rows={4} value={customMsg} onChange={e => setCustomMsg(e.target.value)}
                placeholder="Type your message…"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500 resize-none"/>
            </div>
          )}
          <button onClick={sendWA}
            className="bg-green-600 hover:bg-green-500 text-white text-sm font-semibold px-5 py-2 rounded-xl">
            Send WhatsApp 💬
          </button>

          {/* Notification log */}
          <div className="mt-4 border-t border-slate-800 pt-4">
            <h3 className="text-slate-300 text-sm font-medium mb-2">Notification Status</h3>
            <div className="space-y-1.5 text-sm">
              {[
                ['Activation sent',     tenant.notifications?.activationSent],
                ['7-day warning sent',  tenant.notifications?.expiryWarningSent],
                ['Expiry notice sent',  tenant.notifications?.expiredSent],
              ].map(([label, sent]) => (
                <div key={label} className="flex items-center gap-2">
                  <span className={sent ? 'text-green-400' : 'text-slate-600'}>{sent ? '✓' : '○'}</span>
                  <span className={sent ? 'text-slate-300' : 'text-slate-500'}>{label}</span>
                </div>
              ))}
              {tenant.notifications?.lastNotifiedAt && (
                <p className="text-slate-500 text-xs mt-2">
                  Last notified: {new Date(tenant.notifications.lastNotifiedAt).toLocaleString('en-IN')}
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Tab: Security */}
      {tab === 'security' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
          <h2 className="text-white font-semibold">Reset Admin Password</h2>
          <p className="text-slate-400 text-sm">This resets the login password for <strong className="text-white">{tenant.email}</strong></p>
          <div className="max-w-sm">
            <label className="text-slate-400 text-xs mb-1 block">New Password</label>
            <input type="text" value={newPassword} onChange={e => setNewPassword(e.target.value)}
              placeholder="Min 6 characters"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500 mb-3"/>
            <button onClick={resetPwd}
              className="bg-orange-600 hover:bg-orange-500 text-white text-sm font-semibold px-5 py-2 rounded-xl">
              Reset Password
            </button>
          </div>
          <div className="border-t border-slate-800 pt-5 mt-5">
            <h3 className="text-red-400 font-medium text-sm mb-2">Danger Zone</h3>
            <button
              onClick={async () => {
                if (confirm(`Cancel ${tenant.salonName}? This suspends all access.`)) {
                  await del(`/${id}`);
                  navigate('/superadmin/salons');
                }
              }}
              className="bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 text-sm px-4 py-2 rounded-xl"
            >
              Cancel / Delete Tenant
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
