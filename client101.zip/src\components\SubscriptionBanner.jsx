import { useState, useEffect, useCallback } from 'react';
import { AlertTriangle, Clock, CheckCircle, XCircle, Crown, ChevronRight } from 'lucide-react';
import api from '@/services/api';

// Plan badge colors
const PLAN_COLORS = {
  basic:    { bg: 'rgba(107,114,128,0.12)', text: '#374151', border: 'rgba(107,114,128,0.25)' },
  standard: { bg: 'rgba(59,130,246,0.10)',  text: '#1D4ED8', border: 'rgba(59,130,246,0.25)' },
  premium:  { bg: 'rgba(184,137,42,0.12)',  text: '#92400E', border: 'rgba(184,137,42,0.30)' },
};

// State-based banner styles
const STATES = {
  trial:   { bg: 'rgba(59,130,246,0.07)',  border: 'rgba(59,130,246,0.20)',  icon: Clock,         iconColor: '#2563EB' },
  warning: { bg: 'rgba(234,179,8,0.08)',   border: 'rgba(234,179,8,0.28)',   icon: AlertTriangle, iconColor: '#CA8A04' },
  expired: { bg: 'rgba(220,38,38,0.07)',   border: 'rgba(220,38,38,0.22)',   icon: XCircle,       iconColor: '#DC2626' },
  active:  { bg: 'rgba(34,197,94,0.06)',   border: 'rgba(34,197,94,0.18)',   icon: CheckCircle,   iconColor: '#16A34A' },
};

const planLabel = (p) => (p || 'basic').charAt(0).toUpperCase() + (p || 'basic').slice(1);

export default function SubscriptionBanner() {
  const [status, setStatus]     = useState(null);
  const [loading, setLoading]   = useState(true);
  const [dismissed, setDismissed] = useState(false);

  const fetch = useCallback(async () => {
    try {
      const { data } = await api.get('/subscription/status');
      if (data.success) setStatus(data.status);
    } catch (_) {}
    finally { setLoading(false); }
  }, []);

  useEffect(() => {
    fetch();
    // Refresh every 5 minutes so a mid-session expiry shows up
    const interval = setInterval(fetch, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [fetch]);

  if (loading || !status) return null;

  // Determine which state to show
  let stateKey = 'active';
  if (status.isExpired)   stateKey = 'expired';
  else if (status.isWarning) stateKey = 'warning';
  else if (status.isTrial)   stateKey = 'trial';

  // Only show banner if something needs attention (warning, trial, expired)
  // For a clean active subscription hide it unless user hasn't dismissed
  const shouldShow = stateKey !== 'active' || !dismissed;
  if (!shouldShow) return null;

  // For fully active non-warning — show a minimal pill instead of a full bar
  if (stateKey === 'active') {
    const plan = status.plan || 'basic';
    const pc   = PLAN_COLORS[plan] || PLAN_COLORS.basic;
    return (
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '6px 20px',
        background: pc.bg,
        borderBottom: `1px solid ${pc.border}`,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {plan === 'premium' && <Crown size={13} color='#B8860B' />}
          <span style={{ fontSize: 11, fontWeight: 600, color: pc.text, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
            {planLabel(plan)} Plan
          </span>
          {status.daysLeft !== null && (
            <span style={{ fontSize: 11, color: '#6B7280' }}>
              · Renews in {status.daysLeft} day{status.daysLeft !== 1 ? 's' : ''}
            </span>
          )}
        </div>
        <button onClick={() => setDismissed(true)} style={{ background:'none', border:'none', cursor:'pointer', color:'#9CA3AF', fontSize: 13, padding: '0 2px' }}>✕</button>
      </div>
    );
  }

  const st   = STATES[stateKey];
  const Icon = st.icon;

  const getMessage = () => {
    const days = status.daysLeft;
    const end  = status.endDate ? new Date(status.endDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '';

    if (stateKey === 'expired') return { title: 'Subscription Expired', body: `Your ${planLabel(status.plan)} plan expired${end ? ` on ${end}` : ''}. Contact your provider to renew.` };
    if (stateKey === 'warning') return { title: `Expiring in ${days} day${days !== 1 ? 's' : ''}`, body: `Your ${planLabel(status.plan)} plan expires on ${end}. Contact your provider to renew.` };
    if (stateKey === 'trial')   return { title: `Trial — ${days !== null ? `${days} day${days !== 1 ? 's' : ''} left` : 'Active'}`, body: `You are on a free trial of the ${planLabel(status.plan)} plan${end ? `, ending ${end}` : ''}.` };
    return { title: '', body: '' };
  };

  const { title, body } = getMessage();

  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8,
      padding: '8px 20px',
      background: st.bg,
      borderBottom: `1px solid ${st.border}`,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <Icon size={15} color={st.iconColor} />
        <div>
          <span style={{ fontSize: 12, fontWeight: 700, color: '#1F2937' }}>{title}</span>
          {' '}
          <span style={{ fontSize: 11, color: '#4B5563' }}>{body}</span>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        {/* Plan badge */}
        {(() => {
          const plan = status.plan || 'basic';
          const pc   = PLAN_COLORS[plan] || PLAN_COLORS.basic;
          return (
            <span style={{
              fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.07em',
              padding: '2px 9px', borderRadius: 20,
              background: pc.bg, color: pc.text, border: `1px solid ${pc.border}`,
            }}>
              {planLabel(plan)}
            </span>
          );
        })()}

        {stateKey !== 'active' && (
          <button
            onClick={() => setDismissed(true)}
            style={{ background:'none', border:'none', cursor:'pointer', color:'#9CA3AF', fontSize: 13, padding: '0 2px' }}
          >✕</button>
        )}
      </div>
    </div>
  );
}
