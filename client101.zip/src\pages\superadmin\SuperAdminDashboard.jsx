import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSA } from '../../context/SuperAdminContext';

const StatCard = ({ label, value, icon, color, sub }) => (
  <div className={`bg-slate-900 border border-slate-800 rounded-2xl p-5`}>
    <div className="flex items-start justify-between">
      <div>
        <p className="text-slate-400 text-xs font-medium uppercase tracking-wide">{label}</p>
        <p className={`text-3xl font-bold mt-1 ${color}`}>{value ?? '—'}</p>
        {sub && <p className="text-slate-500 text-xs mt-1">{sub}</p>}
      </div>
      <span className="text-2xl">{icon}</span>
    </div>
  </div>
);

export default function SuperAdminDashboard() {
  const { get } = useSA();
  const navigate = useNavigate();
  const [data, setData]     = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    get('/dashboard')
      .then(r => setData(r.data.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  const c = data?.counts || {};
  const fmt = (n) => new Intl.NumberFormat('en-IN').format(n || 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-white">Dashboard</h1>
          <p className="text-slate-400 text-sm mt-0.5">Overview of all salon subscriptions</p>
        </div>
        <button
          onClick={() => navigate('/superadmin/salons/new')}
          className="bg-purple-600 hover:bg-purple-500 text-white text-sm font-medium px-4 py-2 rounded-xl transition-colors"
        >
          + Add Salon
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard label="Total Salons"    value={c.totalTenants}   icon="💇" color="text-white"         />
        <StatCard label="Active"          value={c.activeTenants}  icon="✅" color="text-green-400"     />
        <StatCard label="Trial"           value={c.trialTenants}   icon="🆓" color="text-blue-400"      />
        <StatCard label="Expired"         value={c.expiredTenants} icon="⏰" color="text-red-400"       />
        <StatCard label="Suspended"       value={c.suspendedTenants}icon="⛔"color="text-orange-400"   />
        <StatCard label="Expiring 7 days" value={c.expiringSoon}   icon="⚠️" color="text-yellow-400"    />
      </div>

      {/* Revenue + Plan breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
          <h2 className="text-white font-semibold mb-4">Total Revenue</h2>
          <p className="text-4xl font-bold text-purple-400">₹{fmt(data?.totalRevenue)}</p>
          <p className="text-slate-500 text-sm mt-1">All-time subscription payments</p>
        </div>

        {/* Plan Breakdown */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
          <h2 className="text-white font-semibold mb-4">Plan Breakdown</h2>
          {['basic', 'standard', 'premium'].map(plan => {
            const count = data?.planBreakdown?.[plan] || 0;
            const total = c.totalTenants || 1;
            const pct   = Math.round((count / total) * 100);
            const colors = { basic: 'bg-blue-500', standard: 'bg-purple-500', premium: 'bg-yellow-500' };
            return (
              <div key={plan} className="mb-3">
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-300 capitalize">{plan}</span>
                  <span className="text-slate-400">{count} salons</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full">
                  <div className={`h-2 ${colors[plan]} rounded-full transition-all`} style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Tenants */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-white font-semibold">Recently Added</h2>
          <button onClick={() => navigate('/superadmin/salons')} className="text-purple-400 text-sm hover:underline">View all →</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-slate-500 text-left border-b border-slate-800">
                <th className="pb-2 font-medium">Salon</th>
                <th className="pb-2 font-medium">Owner</th>
                <th className="pb-2 font-medium">Plan</th>
                <th className="pb-2 font-medium">Status</th>
                <th className="pb-2 font-medium">Added</th>
              </tr>
            </thead>
            <tbody>
              {(data?.recentTenants || []).map(t => (
                <tr key={t._id} className="border-b border-slate-800/50 hover:bg-slate-800/30 cursor-pointer"
                    onClick={() => navigate(`/superadmin/salons/${t._id}`)}>
                  <td className="py-3 text-white font-medium">{t.salonName}</td>
                  <td className="py-3 text-slate-300">{t.ownerName}</td>
                  <td className="py-3">
                    <span className="capitalize text-xs bg-purple-600/20 text-purple-400 px-2 py-0.5 rounded-full">
                      {t.subscription?.plan || '—'}
                    </span>
                  </td>
                  <td className="py-3">
                    <StatusBadge status={t.subscription?.status} />
                  </td>
                  <td className="py-3 text-slate-400 text-xs">
                    {new Date(t.createdAt).toLocaleDateString('en-IN')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }) {
  const map = {
    active:    'bg-green-500/20 text-green-400',
    trial:     'bg-blue-500/20 text-blue-400',
    expired:   'bg-red-500/20 text-red-400',
    suspended: 'bg-orange-500/20 text-orange-400',
    cancelled: 'bg-slate-600/20 text-slate-400',
  };
  return (
    <span className={`text-xs px-2 py-0.5 rounded-full capitalize ${map[status] || 'bg-slate-700 text-slate-400'}`}>
      {status || 'unknown'}
    </span>
  );
}
