import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSA } from '../../context/SuperAdminContext';

export default function AddSalon() {
  const { post } = useSA();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    salonName: '', ownerName: '', email: '',
    phone: '', whatsapp: '',
    'address.city': '', 'address.state': '', 'address.pincode': '',
    adminPassword: '', plan: 'basic', trialDays: 14,
  });
  const [saving, setSaving] = useState(false);
  const [error, setError]   = useState('');

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const handleSubmit = async () => {
    setError('');
    if (!form.salonName || !form.ownerName || !form.email || !form.phone || !form.adminPassword) {
      return setError('All required fields must be filled.');
    }
    setSaving(true);
    try {
      await post('/', {
        salonName:     form.salonName,
        ownerName:     form.ownerName,
        email:         form.email,
        phone:         form.phone,
        whatsapp:      form.whatsapp || form.phone,
        address:       { city: form['address.city'], state: form['address.state'], pincode: form['address.pincode'] },
        adminPassword: form.adminPassword,
        plan:          form.plan,
        trialDays:     Number(form.trialDays),
      });
      navigate('/superadmin/salons');
    } catch (e) {
      setError(e.response?.data?.message || 'Failed to create salon');
    } finally { setSaving(false); }
  };

  return (
    <div className="max-w-2xl space-y-5">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="text-slate-400 hover:text-white">←</button>
        <div>
          <h1 className="text-xl font-bold text-white">Add New Salon</h1>
          <p className="text-slate-400 text-sm">Creates the salon + admin account + starts trial</p>
        </div>
      </div>

      {error && <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3 text-red-400 text-sm">{error}</div>}

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
        <h2 className="text-slate-300 font-medium text-sm uppercase tracking-wide">Salon & Owner Info</h2>
        <div className="grid grid-cols-2 gap-4">
          {[
            ['Salon Name *',  'salonName',       'text',  'Glow Beauty Salon'],
            ['Owner Name *',  'ownerName',        'text',  'Priya Sharma'],
            ['Email *',       'email',            'email', 'owner@salon.com'],
            ['Phone *',       'phone',            'tel',   '9876543210'],
            ['WhatsApp',      'whatsapp',         'tel',   'Same as phone if blank'],
            ['City',          'address.city',     'text',  'Hyderabad'],
            ['State',         'address.state',    'text',  'Telangana'],
            ['Pincode',       'address.pincode',  'text',  '500001'],
          ].map(([label, key, type, placeholder]) => (
            <div key={key}>
              <label className="text-slate-400 text-xs mb-1 block">{label}</label>
              <input type={type} value={form[key]} placeholder={placeholder}
                onChange={e => set(key, e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-purple-500"/>
            </div>
          ))}
        </div>

        <h2 className="text-slate-300 font-medium text-sm uppercase tracking-wide pt-2">Access & Subscription</h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-slate-400 text-xs mb-1 block">Admin Login Password *</label>
            <input type="text" value={form.adminPassword} onChange={e => set('adminPassword', e.target.value)}
              placeholder="Set initial password"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-purple-500"/>
          </div>
          <div>
            <label className="text-slate-400 text-xs mb-1 block">Starting Plan</label>
            <select value={form.plan} onChange={e => set('plan', e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500">
              <option value="basic">Basic (Admin + Staff + Receptionist)</option>
              <option value="standard">Standard (+ User Booking)</option>
              <option value="premium">Premium (+ Analytics + Multi-branch)</option>
            </select>
          </div>
          <div>
            <label className="text-slate-400 text-xs mb-1 block">Trial Period (days)</label>
            <input type="number" min={1} value={form.trialDays} onChange={e => set('trialDays', e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500"/>
          </div>
        </div>

        {/* Summary box */}
        <div className="bg-purple-900/20 border border-purple-500/20 rounded-xl p-4 text-sm text-slate-300">
          <p>🎯 <strong className="text-white">{form.salonName || 'Salon'}</strong> will start on <strong className="text-white capitalize">{form.plan}</strong> trial for <strong className="text-white">{form.trialDays} days</strong>.</p>
          <p className="text-slate-400 mt-1">💬 A WhatsApp welcome message will be sent to <strong className="text-white">{form.whatsapp || form.phone || 'the provided number'}</strong>.</p>
          {form.plan === 'basic' && <p className="text-yellow-400/80 text-xs mt-1.5">⚡ Basic plan — no user booking panel. Admin + Staff + Receptionist only.</p>}
        </div>

        <div className="flex gap-3">
          <button onClick={handleSubmit} disabled={saving}
            className="bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-semibold px-6 py-2.5 rounded-xl text-sm">
            {saving ? 'Creating…' : 'Create Salon & Start Trial'}
          </button>
          <button onClick={() => navigate(-1)} className="text-slate-400 hover:text-white text-sm px-4 py-2.5">
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
