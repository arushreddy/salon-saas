const express = require('express');
const router = express.Router();
const {
  getAllProducts,
  createProduct,
  updateProduct,
  updateStock,
  deleteProduct,
} = require('../controllers/inventory.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');

// Receptionist can view inventory and use (deduct) stock
router.get('/',            protect, authorize('admin', 'receptionist'), getAllProducts);
router.patch('/:id/stock', protect, authorize('admin', 'receptionist'), updateStock);

// Admin-only: create, edit, delete
router.post('/',    protect, authorize('admin'), createProduct);
router.put('/:id',  protect, authorize('admin'), updateProduct);
router.delete('/:id', protect, authorize('admin'), deleteProduct);

module.exports = router;