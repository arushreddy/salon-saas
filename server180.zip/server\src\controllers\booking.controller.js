const Booking    = require('../models/Booking');
const Service    = require('../models/Service');
const User       = require('../models/User');
const Staff      = require('../models/Staff');
const Attendance = require('../models/Attendance');
const Coupon     = require('../models/Coupon');
const Payment    = require('../models/Payment');
const { AppError } = require('../middlewares/errorHandler');

// ── Schema field check ────────────────────────────────────────────────────
const HAS_STAFF_MEMBERS = !!require('../models/Booking').schema.path('staffMembers');

// ── IST helpers ────────────────────────────────────────────────────────────
const IST_OFFSET = 5.5 * 60 * 60 * 1000;
const todayIST   = () => new Date(Date.now() + IST_OFFSET).toISOString().split('T')[0];
const istMidnight = d => new Date(d + 'T00:00:00.000Z');
const istEndOfDay = d => new Date(d + 'T23:59:59.999Z');

// ── Slot helpers ───────────────────────────────────────────────────────────
const addMins = (t, mins) => {
  const [h,m] = t.split(':').map(Number);
  const total  = h*60+m+mins;
  return `${Math.floor(total/60).toString().padStart(2,'0')}:${(total%60).toString().padStart(2,'0')}`;
};
const overlap = (s1,e1,s2,e2) => s1<e2 && s2<e1;

// ── GET /bookings/staff-availability ─────────────────────────────────────
// FREE  = active staff + no in-progress booking right now
// BUSY  = has an in-progress booking right now
// NOT-AVAILABLE = on weekly-off OR explicitly marked absent/leave today
const getStaffAvailability = async (req, res, next) => {
  try {
    const todayStr = todayIST();
    // Day name using IST noon to avoid DST edge cases
    const dayName  = new Date(todayStr + 'T06:00:00.000Z')
      .toLocaleDateString('en-US', { weekday:'long' }).toLowerCase();

    const staffUsers    = await User.find({ role:'staff', isActive:true }, 'name phone');
    const staffProfiles = await Staff.find({ user:{ $in:staffUsers.map(u=>u._id) } });

    // Attendance records for today — stored by attendance.controller as UTC midnight
    // We query a wide window to catch both IST and UTC interpretations
    const windowStart = new Date(todayStr + 'T00:00:00.000Z');
    windowStart.setTime(windowStart.getTime() - IST_OFFSET);   // minus 5:30
    const windowEnd   = new Date(todayStr + 'T23:59:59.999Z');

    const attendances = await Attendance.find({
      staff: { $in: staffUsers.map(u=>u._id) },
      date:  { $gte: windowStart, $lte: windowEnd },
    });

    // In-progress bookings — only within last 24h window so stale/orphaned
    // in-progress records don't permanently lock staff as "busy"
    const staleGuard = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const activeBookings = await Booking.find({
      status: 'in-progress',
      staff:  { $in: staffUsers.map(u=>u._id) },
      date:   { $gte: staleGuard },   // ignore orphaned in-progress from past days
    });

    const busySet  = new Set(activeBookings.map(b=>b.staff?.toString()).filter(Boolean));
    const absentSet = new Set(
      attendances.filter(a=>['absent','leave','holiday'].includes(a.status)).map(a=>a.staff?.toString())
    );
    // Staff who have an OPEN clock-in session today — they physically showed up
    // even if it's their weekly off, so treat them as present/free
    const clockedInSet = new Set(
      attendances
        .filter(a => a.sessions?.some(s => s.clockIn && !s.clockOut))
        .map(a => a.staff?.toString())
    );

    const result = staffUsers.map(u => {
      const uid      = u._id.toString();
      const profile  = staffProfiles.find(p=>p.user?.toString()===uid);
      const isWeeklyOff        = profile?.schedule?.weeklyOff?.includes(dayName);
      const isExplicitlyAbsent = absentSet.has(uid);
      const isClockedIn        = clockedInSet.has(uid);
      const isBusy             = busySet.has(uid);

      let availability;
      // If staff physically clocked in today, they're present regardless of schedule
      if (isClockedIn) {
        availability = isBusy ? 'busy' : 'free';
      } else if (isWeeklyOff || isExplicitlyAbsent) {
        availability = 'not-available';
      } else if (isBusy) {
        availability = 'busy';
      } else {
        availability = 'free';   // default — show as available for walk-ins
      }

      // Find the active booking for busy staff
      const activeBooking = activeBookings.find(b=>b.staff?.toString()===uid);

      return {
        _id:           u._id,
        name:          u.name,
        phone:         u.phone,
        designation:   profile?.designation || '',
        specializations: profile?.specializations || [],
        availability,
        currentBookingId: activeBooking?._id || null,
      };
    });

    res.status(200).json({ success:true, staff:result });
  } catch(e) { next(e); }
};

// ── GET /bookings/available-slots ─────────────────────────────────────────
const getAvailableSlots = async (req, res, next) => {
  try {
    const { date, serviceId, staffId } = req.query;
    if (!date || !serviceId) throw new AppError('Date and service required', 400);

    const service = await Service.findById(serviceId);
    if (!service) throw new AppError('Service not found', 404);

    const filter = {
      date:   { $gte:istMidnight(date), $lte:istEndOfDay(date) },
      status: { $nin:['cancelled','no-show'] },
    };
    if (staffId) filter.staff = staffId;

    const existing   = await Booking.find(filter);
    const maxPerSlot = staffId ? 1 : Math.max(1, await User.countDocuments({role:'staff',isActive:true}));
    const allSlots   = [];
    for (let h=9; h<21; h++)
      for (let m=0; m<60; m+=30)
        allSlots.push(`${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}`);

    const available = allSlots.filter(slotStart => {
      const slotEnd = addMins(slotStart, service.duration);
      if (slotEnd > '21:00') return false;
      const now  = new Date();
      const bDate = new Date(date);
      if (bDate.toDateString()===now.toDateString()) {
        const nowStr = `${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}`;
        if (slotStart <= nowStr) return false;
      }
      return existing.filter(b=>overlap(slotStart,slotEnd,b.timeSlot.start,b.timeSlot.end)).length < maxPerSlot;
    });

    const [h0] = available[0]?.split(':').map(Number)||[9];
    res.status(200).json({
      success:true, slots: available.map(s=>{
        const end   = addMins(s, service.duration);
        const [h]   = s.split(':').map(Number);
        const dh    = h>12?h-12:h===0?12:h;
        return { start:s, end, display:`${dh}:${s.split(':')[1]} ${h>=12?'PM':'AM'}` };
      }),
    });
  } catch(e) { next(e); }
};

// ── POST /bookings (online / admin-scheduled) ─────────────────────────────
const createBooking = async (req, res, next) => {
  try {
    const { serviceId, staffId, staffIds, date, timeSlot, notes, couponCode,
            customerId: bodyCustomerId, customerName, customerPhone } = req.body;
    if (!serviceId||!date||!timeSlot?.start) throw new AppError('Service, date, time required', 400);

    const service = await Service.findById(serviceId);
    if (!service||!service.isActive) throw new AppError('Service not found', 404);

    // ── Resolve customer ──
    // Admins/receptionists may create bookings on behalf of a customer
    let resolvedCustomerId = req.user.userId;
    if (['admin','receptionist'].includes(req.user.role)) {
      if (bodyCustomerId) {
        resolvedCustomerId = bodyCustomerId;
      } else if (customerPhone || customerName) {
        let cust = customerPhone ? await User.findOne({ phone: customerPhone }) : null;
        if (!cust && customerName) {
          const sPhone = customerPhone && customerPhone.length === 10 ? customerPhone : undefined;
          cust = await User.create({
            name: customerName.trim(),
            email: `sched_${Date.now()}_${Math.random().toString(36).slice(2,6)}@salon.temp`,
            ...(sPhone ? {phone: sPhone} : {}),
            password: 'scheduled_' + Date.now(),
            role: 'customer',
          });
        }
        if (cust) resolvedCustomerId = cust._id;
      }
    }

    // ── Multi-staff support ──
    const allStaffIds = staffIds?.length ? staffIds : (staffId ? [staffId] : []);
    const primaryStaffId = allStaffIds[0] || null;

    const endTime  = addMins(timeSlot.start, service.duration);
    const existing = await Booking.find({
      date:   { $gte:istMidnight(date), $lte:istEndOfDay(date) },
      status: { $nin:['cancelled','no-show'] },
      ...(primaryStaffId ? {staff:primaryStaffId} : {}),
    });
    const max = primaryStaffId ? 1 : Math.max(1, await User.countDocuments({role:'staff',isActive:true}));
    if (existing.filter(b=>overlap(timeSlot.start,endTime,b.timeSlot.start,b.timeSlot.end)).length >= max)
      throw new AppError('Slot fully booked', 409);

    let discountAmount = service.discountPrice ? service.price-service.discountPrice : 0;
    let finalAmount    = service.discountPrice || service.price;
    let appliedCoupon  = null;
    if (couponCode) {
      const coupon = await Coupon.findOne({code:couponCode.toUpperCase(),isActive:true});
      if (coupon?.isValid().valid && service.price>=(coupon.minOrderAmount||0)) {
        const disc = coupon.calculateDiscount(service.price);
        discountAmount+=disc; finalAmount-=disc;
        appliedCoupon=coupon.code; coupon.usedCount++; await coupon.save();
      }
    }

    const booking = await Booking.create({
      customer: resolvedCustomerId,
      service: serviceId,
      staff: primaryStaffId,
      ...(HAS_STAFF_MEMBERS ? {staffMembers: allStaffIds} : {}),
      date:istMidnight(date), timeSlot:{start:timeSlot.start,end:endTime},
      totalAmount:service.price, discountAmount, finalAmount, couponCode:appliedCoupon,
      notes:notes||'',
      type: ['admin','receptionist'].includes(req.user.role) ? 'walk-in' : 'online',
      status:'confirmed',
      paymentStatus:'pending', paymentMethod:'none',
    });
    await Service.findByIdAndUpdate(serviceId, { $inc:{popularity:1} });
    const pop = await Booking.findById(booking._id)
      .populate('service','name category duration price')
      .populate('additionalServices','name category duration price discountPrice')
      .populate('customer','name email phone')
      .populate('staff','name')
      ;
    res.status(201).json({ success:true, message:'Booking confirmed!', booking:pop });
  } catch(e) {
    console.error('❌ createWalkInBooking ERROR:', e.message);
    if (e.errors) console.error('   Validation:', JSON.stringify(e.errors,null,2));
    next(e);
  }
};

// ── POST /bookings/walk-in ─────────────────────────────────────────────────
const createWalkInBooking = async (req, res, next) => {
  try {
    const { customerName, customerPhone, serviceId, serviceIds, staffId, staffIds,
            notes, couponCode, manualDiscountPercent,
            scheduledDate, scheduledTime } = req.body;

    // Support both single serviceId (legacy) and serviceIds array
    const allServiceIds = serviceIds?.length ? serviceIds : [serviceId];
    if (!allServiceIds[0]) throw new AppError('Service required', 400);

    const services = await Promise.all(allServiceIds.map(id => Service.findById(id)));
    if (services.some(s => !s)) throw new AppError('One or more services not found', 404);

    const primaryService = services[0];

    // ── Multi-staff support ──
    const allStaffIds = staffIds?.length ? staffIds : (staffId ? [staffId] : []);
    const primaryStaffId = allStaffIds[0] || null;

    let customer;
    if (customerPhone) customer = await User.findOne({phone:customerPhone});
    if (!customer && customerName) {
      const phone = customerPhone && customerPhone.length === 10 ? customerPhone : undefined;
      // Retry with unique email if there's a duplicate key collision
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          customer = await User.create({
            name: customerName.trim(),
            email: `wi_${Date.now()}_${Math.random().toString(36).slice(2,8)}@salon.temp`,
            ...(phone ? {phone} : {}),
            password: 'walkin_' + Date.now(),
            role: 'customer',
          });
          break; // success
        } catch(e) {
          if (e.code !== 11000 || attempt === 2) throw e; // rethrow if not duplicate or exhausted
        }
      }
    }
    // If still no customer (no name provided), fallback to logged-in user
    if (!customer) customer = { _id: req.user.userId };

    const now       = new Date();
    const curTime   = scheduledTime || `${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}`;
    // Total duration = sum of all service durations
    const totalDuration = services.reduce((sum, s) => sum + (s.duration || 0), 0);
    const endTime   = addMins(curTime, totalDuration || primaryService.duration);
    const useDate   = scheduledDate || todayIST();

    // Total base price = sum of all services (use discountPrice if set)
    const rawTotal     = services.reduce((sum, s) => sum + (s.price || 0), 0);
    let totalAmount    = rawTotal;
    let discountAmount = services.reduce((sum, s) => sum + (s.discountPrice ? s.price - s.discountPrice : 0), 0);
    let finalAmount    = services.reduce((sum, s) => sum + (s.discountPrice || s.price), 0);
    let appliedCoupon  = null;

    if (couponCode) {
      const coupon = await Coupon.findOne({code:couponCode.toUpperCase(),isActive:true});
      if (coupon?.isValid().valid && finalAmount>=(coupon.minOrderAmount||0)) {
        const disc = coupon.calculateDiscount(finalAmount);
        discountAmount+=disc; finalAmount-=disc;
        appliedCoupon=coupon.code; coupon.usedCount++; await coupon.save();
      }
    }
    if (manualDiscountPercent && Number(manualDiscountPercent)>0) {
      const pct = Math.min(50, Math.max(0, Number(manualDiscountPercent)));
      const d   = Math.round(finalAmount*pct/100);
      discountAmount+=d; finalAmount-=d;
    }

    const bookingData = {
      customer: customer._id || req.user.userId,
      service: allServiceIds[0],
      additionalServices: allServiceIds.slice(1),
      staff: primaryStaffId || undefined,
      date: istMidnight(useDate),
      timeSlot: { start: curTime, end: endTime },
      totalAmount: Number(totalAmount) || 0,
      discountAmount: Number(discountAmount) || 0,
      finalAmount: Number(finalAmount) || 0,
      notes: notes || '',
      type: 'walk-in',
      status: 'confirmed',
      paymentStatus: 'pending',
      paymentMethod: ['cash','upi','card'].includes(req.body.paymentMethod) ? req.body.paymentMethod : 'cash',
    };
    if (HAS_STAFF_MEMBERS) bookingData.staffMembers = allStaffIds;
    // Only add couponCode if the field exists in schema
    if (Booking.schema.path('couponCode')) bookingData.couponCode = appliedCoupon || '';

    let booking;
    try {
      booking = await Booking.create(bookingData);
    } catch(createErr) {
      console.error('❌ Booking.create FAILED:', createErr.message);
      if (createErr.errors) {
        Object.entries(createErr.errors).forEach(([k,v]) => console.error('  Field error:', k, '->', v.message));
      }
      if (createErr.code) console.error('  DB code:', createErr.code, createErr.keyValue);
      throw new AppError('Booking save failed: ' + createErr.message, 500);
    }

    // Bump popularity for all services
    await Promise.all(allServiceIds.map(id => Service.findByIdAndUpdate(id, { $inc:{popularity:1} })));

    const pop = await Booking.findById(booking._id)
      .populate('service','name category duration price discountPrice')
      .populate('additionalServices','name category duration price discountPrice')
      .populate('customer','name phone')
      .populate('staff','name')
      ;
    res.status(201).json({ success:true, message:'Walk-in created!', booking:pop });
  } catch(e) {
    console.error('❌ createWalkInBooking ERROR:', e.message);
    if (e.errors) console.error('   Validation:', JSON.stringify(Object.fromEntries(Object.entries(e.errors).map(([k,v])=>[k,v.message])),null,2));
    if (e.code) console.error('   Code:', e.code, e.keyValue);
    next(e);
  }
};

// ── GET /bookings ──────────────────────────────────────────────────────────
const getBookings = async (req, res, next) => {
  try {
    const { status, date, startDate, endDate, type, refNo, page=1, limit=200 } = req.query;
    const filter = {};
    if (req.user.role==='customer') filter.customer = req.user.userId;
    else if (req.user.role==='staff') filter.staff = req.user.userId;
    if (status)    filter.status = status;
    if (type)      filter.type   = type;
    // Search by refNo (case-insensitive, partial match)
    if (refNo)     filter.refNo  = { $regex: refNo.trim(), $options: 'i' };
    if (date) {
      // Cover the full IST day:
      // Some bookings saved as UTC midnight (00:00Z), others as actual time.
      // Query from start of that calendar day UTC (covers midnight-stored records)
      // to end of next UTC day (covers late IST bookings stored as UTC timestamp).
      const dayStart = new Date(date + 'T00:00:00.000Z');
      const dayEnd   = new Date(date + 'T23:59:59.999Z');
      filter.date   = { $gte: dayStart, $lte: dayEnd };
    }
    else if (startDate && endDate)
                   filter.date   = { $gte:istMidnight(startDate), $lte:istEndOfDay(endDate) };

    const bookings = await Booking.find(filter)
      .populate('service','name category duration price discountPrice')
      .populate('additionalServices','name category duration price discountPrice')
      .populate('customer','name email phone')
      .populate('staff','name')
            .sort({date:1,'timeSlot.start':1})
      .skip((page-1)*limit).limit(parseInt(limit));

    const total = await Booking.countDocuments(filter);
    res.status(200).json({ success:true, bookings, pagination:{total,page:parseInt(page),pages:Math.ceil(total/limit)} });
  } catch(e) { next(e); }
};

// ── PATCH /bookings/:id/assign ─────────────────────────────────────────────
const assignStaff = async (req, res, next) => {
  try {
    const { staffId } = req.body;
    const booking = await Booking.findById(req.params.id);
    if (!booking) throw new AppError('Booking not found', 404);
    booking.staff = staffId || null;
    await booking.save();
    const pop = await Booking.findById(booking._id)
      .populate('service','name category duration price')
      .populate('additionalServices','name category duration price discountPrice')
      .populate('customer','name email phone')
      .populate('staff','name');
    res.status(200).json({ success:true, message:'Staff assigned', booking:pop });
  } catch(e) { next(e); }
};

// ── PATCH /bookings/:id/status ─────────────────────────────────────────────
const updateBookingStatus = async (req, res, next) => {
  try {
    const { status, paymentMethod, paymentStatus, cancelReason } = req.body;
    const booking = await Booking.findById(req.params.id);
    if (!booking) throw new AppError('Booking not found', 404);

    if (req.user.role==='staff') {
      if (booking.staff?.toString()!==req.user.userId) throw new AppError('Not your booking', 403);
      if (!['in-progress','completed'].includes(status)) throw new AppError('Staff can only start or complete', 403);
    }
    if (req.user.role==='customer') {
      if (booking.customer.toString()!==req.user.userId) throw new AppError('Not authorized', 403);
      if (status!=='cancelled') throw new AppError('Customers can only cancel', 403);
    }

    const wasAlreadyCompleted = booking.status === 'completed';
    booking.status = status;
    if (status==='cancelled') { booking.cancelledAt=new Date(); booking.cancelReason=cancelReason||''; }
    if (status==='completed' && !wasAlreadyCompleted) booking.completedAt = new Date();
    if (paymentMethod) booking.paymentMethod = paymentMethod;
    if (paymentStatus) booking.paymentStatus = paymentStatus;
    await booking.save();

    // Only increment stats on FIRST completion (not when admin verifies payment on already-completed)
    if (status==='completed' && !wasAlreadyCompleted && booking.staff) {
      await Staff.findOneAndUpdate({ user:booking.staff }, {
        $inc:{ totalServicesCompleted:1, totalRevenueGenerated:booking.finalAmount }
      });
    }

    const pop = await Booking.findById(booking._id)
      .populate('service','name category duration price')
      .populate('additionalServices','name category duration price discountPrice')
      .populate('customer','name email phone')
      .populate('staff','name');
    res.status(200).json({ success:true, message:`Status updated to ${status}`, booking:pop });
  } catch(e) { next(e); }
};

// ── PATCH /bookings/:id/verify-payment ─────────────────────────────────────
// Dedicated payment verification endpoint — only updates payment fields
const verifyPaymentDirect = async (req, res, next) => {
  try {
    const { method, notes } = req.body;
    if (!method) throw new AppError('Payment method required', 400);

    const booking = await Booking.findById(req.params.id);
    if (!booking) throw new AppError('Booking not found', 404);
    if (booking.paymentStatus === 'paid') {
      return res.status(200).json({ success:true, message:'Already paid', booking });
    }

    booking.paymentMethod  = method;
    booking.paymentStatus  = 'paid';
    await booking.save();

    // Create payment record
    await Payment.create({
      booking:    booking._id,
      customer:   booking.customer,
      amount:     booking.finalAmount,
      method,
      status:     'completed',
      notes:      notes||'',
      collectedBy: req.user.userId,
    }).catch(() => {}); // non-fatal

    const pop = await Booking.findById(booking._id)
      .populate('service','name category duration price')
      .populate('additionalServices','name category duration price discountPrice')
      .populate('customer','name email phone')
      .populate('staff','name');
    res.status(200).json({ success:true, message:'Payment verified!', booking:pop });
  } catch(e) { next(e); }
};

// ── GET /bookings/today/stats ──────────────────────────────────────────────
const getTodayStats = async (req, res, next) => {
  try {
    const todayStr   = todayIST();
    const dateFilter = { date:{ $gte:istMidnight(todayStr), $lte:istEndOfDay(todayStr) } };
    const [total,confirmed,inProgress,completed,cancelled] = await Promise.all([
      Booking.countDocuments(dateFilter),
      Booking.countDocuments({...dateFilter,status:'confirmed'}),
      Booking.countDocuments({...dateFilter,status:'in-progress'}),
      Booking.countDocuments({...dateFilter,status:'completed'}),
      Booking.countDocuments({...dateFilter,status:'cancelled'}),
    ]);
    const [rev, pending] = await Promise.all([
      Booking.aggregate([{$match:{...dateFilter,paymentStatus:'paid'}},{$group:{_id:null,total:{$sum:'$finalAmount'}}}]),
      Booking.aggregate([{$match:{...dateFilter,status:'completed',paymentStatus:{$in:['pending','partial']}}},{$group:{_id:null,total:{$sum:'$finalAmount'},count:{$sum:1}}}]),
    ]);
    res.status(200).json({ success:true, stats:{
      total, confirmed, inProgress, completed, cancelled,
      todayRevenue:    rev[0]?.total||0,
      pendingPayment:  pending[0]?.total||0,
      pendingPayCount: pending[0]?.count||0,
    }});
  } catch(e) { next(e); }
};

// ── POST /bookings/:id/refund ──────────────────────────────────────────────
// Issues a refund for a paid booking.
// - Marks paymentStatus = 'refunded' on the booking
// - Updates the Payment record
// - If refundMethod === 'cash', creates a CashTransaction debit (money out of till)
// - Reverses staff.totalRevenueGenerated for completed bookings
const processRefund = async (req, res, next) => {
  try {
    const CashTransaction = require('../models/CashTransaction');
    const { refundMethod = 'cash', reason = '', amount } = req.body;

    const booking = await Booking.findById(req.params.id)
      .populate('service',   'name')
      .populate('customer',  'name phone');
    if (!booking)                            throw new AppError('Booking not found', 404);
    if (booking.paymentStatus !== 'paid')   throw new AppError('Booking must be paid before issuing a refund', 400);

    const refundAmt = Math.round(amount || booking.finalAmount || 0);

    // 1. Mark booking paymentStatus as refunded
    booking.paymentStatus = 'refunded';
    await booking.save();

    // 2. Update the Payment record (non-fatal if missing)
    await Payment.findOneAndUpdate(
      { booking: booking._id, status: 'completed' },
      { status: 'refunded', refundAmount: refundAmt, refundReason: reason, refundedAt: new Date() }
    ).catch(() => {});

    // 3. If cash refund → create a CashTransaction debit so the till reflects outflow
    if (refundMethod === 'cash') {
      const IST_OFF = 5.5 * 60 * 60 * 1000;
      const nowIST  = new Date(Date.now() + IST_OFF);
      const dateStr = nowIST.toISOString().split('T')[0];
      const timeStr = nowIST.toTimeString().slice(0, 5);
      await CashTransaction.create({
        type:      'adjustment',
        amount:    refundAmt,
        sign:      '-',
        note:      `Refund — ${booking.customer?.name || 'Customer'} · ${booking.service?.name || 'Service'} · ${booking.refNo || ''}${reason ? ' · ' + reason : ''}`,
        date:      dateStr,
        time:      timeStr,
        createdBy: req.user._id,
      }).catch(() => {});
    }

    // 4. Reverse staff revenue stats (only for completed bookings)
    if (booking.staff && booking.status === 'completed' && refundAmt > 0) {
      await Staff.findOneAndUpdate(
        { user: booking.staff },
        { $inc: { totalRevenueGenerated: -refundAmt } }
      ).catch(() => {});
    }

    const pop = await Booking.findById(booking._id)
      .populate('service',            'name category duration price')
      .populate('additionalServices', 'name category duration price discountPrice')
      .populate('customer',           'name email phone')
      .populate('staff',              'name');

    res.status(200).json({
      success: true,
      message: `Refund of ₹${refundAmt} processed via ${refundMethod}`,
      booking: pop,
    });
  } catch (e) { next(e); }
};

// ── PATCH /bookings/:id/notes ──────────────────────────────────────────────
const patchBookingNotes = async (req, res, next) => {
  try {
    const { notes } = req.body;
    const booking = await Booking.findById(req.params.id);
    if (!booking) throw new AppError('Booking not found', 404);
    booking.notes = notes ?? booking.notes;
    await booking.save();
    res.status(200).json({ success: true, message: 'Notes updated', booking });
  } catch (e) { next(e); }
};

module.exports = {
  getStaffAvailability, getAvailableSlots,
  createBooking, createWalkInBooking,
  getBookings, assignStaff, updateBookingStatus, verifyPaymentDirect,
  getTodayStats, processRefund, patchBookingNotes,
};