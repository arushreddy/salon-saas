const express = require('express');
const router  = express.Router();
const {
  clockIn, clockOut,
  getMyAttendance, getTodayAttendance,
  markAttendance, getAttendanceReport, getStaffList,
  applyDeduction,                                      // ← was missing
} = require('../controllers/attendance.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');

router.post('/clock-in',  protect, authorize('staff','receptionist'), clockIn);
router.post('/clock-out', protect, authorize('staff','receptionist'), clockOut);
router.get('/my',         protect, getMyAttendance);

// Receptionist needs to view and mark attendance
router.get('/today',      protect, authorize('admin','receptionist'), getTodayAttendance);
router.get('/report',     protect, authorize('admin','receptionist'), getAttendanceReport);
router.get('/staff-list', protect, authorize('admin','receptionist'), getStaffList);
router.post('/mark',      protect, authorize('admin','receptionist'), markAttendance);

// Salary deduction from attendance (admin only)
router.post('/deduction', protect, authorize('admin'), applyDeduction);  // ← was missing

module.exports = router;