const express    = require('express');
const router     = express.Router();
const {
  generateInvoice,
  getAllInvoices,
  searchByRef,
  getSince,
} = require('../controllers/invoice.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');

// All routes require auth
router.use(protect);

// GET /invoices/search?refNo=GLM-xxx  — search by booking ref no
router.get('/search', authorize('admin','receptionist'), searchByRef);

// GET /invoices/since/:timestamp      — delta poll for sync
router.get('/since/:timestamp', authorize('admin','receptionist'), getSince);

// GET /invoices                       — paginated list with filters
router.get('/', authorize('admin','receptionist'), getAllInvoices);

// GET /invoices/:bookingId            — single invoice (customers see own)
router.get('/:bookingId', generateInvoice);

module.exports = router;