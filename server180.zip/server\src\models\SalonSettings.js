// src/models/SalonSettings.js — v2 (expanded for full owner control)
const mongoose = require('mongoose');

const salonSettingsSchema = new mongoose.Schema({

  // ── Identity ────────────────────────────────────────────────────────────
  salonName:  { type:String, default:'Glamour Salon' },
  tagline:    { type:String, default:'Premium Salon Experience' },
  phone:      { type:String, default:'' },
  email:      { type:String, default:'' },
  website:    { type:String, default:'' },
  upiId:      { type:String, default:'' },
  gstNumber:  { type:String, default:'' },
  address: {
    street:  { type:String, default:'' },
    city:    { type:String, default:'' },
    state:   { type:String, default:'' },
    pincode: { type:String, default:'' },
  },

  // ── Operating Hours ──────────────────────────────────────────────────────
  operatingHours: {
    openTime:     { type:String, default:'09:00' },
    closeTime:    { type:String, default:'21:00' },
    slotInterval: { type:Number, default:30 },
    breakStart:   { type:String, default:'' },
    breakEnd:     { type:String, default:'' },
  },
  weeklySchedule: {
    monday:    { isOpen:{type:Boolean,default:true},  open:{type:String,default:'09:00'}, close:{type:String,default:'21:00'} },
    tuesday:   { isOpen:{type:Boolean,default:true},  open:{type:String,default:'09:00'}, close:{type:String,default:'21:00'} },
    wednesday: { isOpen:{type:Boolean,default:true},  open:{type:String,default:'09:00'}, close:{type:String,default:'21:00'} },
    thursday:  { isOpen:{type:Boolean,default:true},  open:{type:String,default:'09:00'}, close:{type:String,default:'21:00'} },
    friday:    { isOpen:{type:Boolean,default:true},  open:{type:String,default:'09:00'}, close:{type:String,default:'21:00'} },
    saturday:  { isOpen:{type:Boolean,default:true},  open:{type:String,default:'10:00'}, close:{type:String,default:'22:00'} },
    sunday:    { isOpen:{type:Boolean,default:true},  open:{type:String,default:'10:00'}, close:{type:String,default:'18:00'} },
  },

  // ── Booking Rules ────────────────────────────────────────────────────────
  maxAdvanceBookingDays: { type:Number, default:30 },
  cancellationHours:     { type:Number, default:2  },
  maxBookingsPerSlot:    { type:Number, default:1  },
  bookingConfirmMode:    { type:String, default:'auto', enum:['auto','manual'] },
  walkInEnabled:         { type:Boolean, default:true  },
  onlineBookingEnabled:  { type:Boolean, default:true  },
  requirePhoneVerify:    { type:Boolean, default:false },

  // ── Payments ─────────────────────────────────────────────────────────────
  payment: {
    razorpayEnabled:   { type:Boolean, default:false },
    razorpayKeyId:     { type:String,  default:'' },
    razorpayKeySecret: { type:String,  default:'' },
    payAtSalonEnabled: { type:Boolean, default:true  },
    acceptCash:        { type:Boolean, default:true  },
    acceptUPI:         { type:Boolean, default:true  },
    acceptCard:        { type:Boolean, default:true  },
  },

  // ── Billing & Tax ────────────────────────────────────────────────────────
  taxRate:           { type:Number,  default:18  },
  currency:          { type:String,  default:'INR' },
  showGSTOnReceipt:  { type:Boolean, default:true  },
  printReceiptAuto:  { type:Boolean, default:false },
  receiptHeader:     { type:String,  default:'Thank you for visiting!' },
  receiptFooter:     { type:String,  default:'Follow us for offers & updates.' },
  billing: {
    maxDiscountPercent:    { type:Number,  default:10,   min:0, max:100 },
    allowStaffDiscount:    { type:Boolean, default:true  },
    loyaltyPointsPerRupee: { type:Number,  default:1     },
  },

  // ── Loyalty Tiers ────────────────────────────────────────────────────────
  bronzeThreshold:   { type:Number, default:0     },
  silverThreshold:   { type:Number, default:5000  },
  goldThreshold:     { type:Number, default:15000 },
  platinumThreshold: { type:Number, default:50000 },

  // ── Staff Policies ───────────────────────────────────────────────────────
  defaultCommission:           { type:Number,  default:20  },
  lateThresholdMins:           { type:Number,  default:15  },
  workingDaysPerMonth:         { type:Number,  default:26  },
  maxAdvancePerStaff:          { type:Number,  default:5000},
  staffCanViewOtherBookings:   { type:Boolean, default:false },
  staffCanEditProfile:         { type:Boolean, default:false },
  staffCanSeeCustomerPhone:    { type:Boolean, default:false },

  // ── Inventory ────────────────────────────────────────────────────────────
  lowStockThreshold:      { type:Number,  default:5  },
  criticalStockThreshold: { type:Number,  default:2  },
  inventoryAlertEnabled:  { type:Boolean, default:true  },
  deductStockOnBooking:   { type:Boolean, default:false },

  // ── Security & Access ────────────────────────────────────────────────────
  receptionistCanViewRevenue:     { type:Boolean, default:false },
  receptionistCanDeleteBookings:  { type:Boolean, default:false },
  receptionistCanEditPrices:      { type:Boolean, default:false },
  sessionTimeoutMins:             { type:Number,  default:60    },
  adminPIN:                       { type:String,  default:''    },

  // ── Message Templates ────────────────────────────────────────────────────
  // Variables: {salonName} {customerName} {service} {amount} {date} {time} {refNo} {staffName} {phone} {address}
  msgBookingConfirm:   { type:String, default:'' },
  msgBookingReminder:  { type:String, default:'' },
  msgPaymentReceipt:   { type:String, default:'' },
  msgCancellation:     { type:String, default:'' },

  // ── Display (legacy / theme) ──────────────────────────────────────────────
  theme: {
    primaryColor:    { type:String, default:'#C9A96E' },
    accentColor:     { type:String, default:'#2C2C2C' },
    backgroundColor: { type:String, default:'#FAF7F2' },
  },

}, { timestamps:true });

module.exports = mongoose.model('SalonSettings', salonSettingsSchema);