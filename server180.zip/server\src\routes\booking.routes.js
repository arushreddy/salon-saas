const express = require('express');
const router  = express.Router();
const {
  getStaffAvailability, getAvailableSlots,
  createBooking, createWalkInBooking,
  getBookings, assignStaff, updateBookingStatus, verifyPaymentDirect,
  getTodayStats, processRefund, patchBookingNotes,
} = require('../controllers/booking.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');

// Static routes BEFORE /:id
router.get('/staff-availability', protect, authorize('admin','receptionist','staff'), getStaffAvailability);
router.get('/available-slots',    protect, getAvailableSlots);
router.get('/today/stats',        protect, authorize('admin','receptionist','staff'), getTodayStats);
router.get('/',                   protect, getBookings);

// walk-in BEFORE generic POST /
router.post('/walk-in', protect, authorize('admin','receptionist','staff'), createWalkInBooking);
router.post('/',        protect, createBooking);

// ID-based routes
router.patch('/:id/assign',          protect, authorize('admin','receptionist'), assignStaff);
router.patch('/:id/verify-payment',  protect, authorize('admin','receptionist'), verifyPaymentDirect);
router.patch('/:id/status',          protect, updateBookingStatus);
router.patch('/:id/notes',           protect, authorize('admin','receptionist'), patchBookingNotes);
router.post('/:id/refund',           protect, authorize('admin'), processRefund);

module.exports = router;