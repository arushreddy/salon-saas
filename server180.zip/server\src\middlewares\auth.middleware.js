const { verifyAccessToken } = require('../utils/token');
const { AppError } = require('./errorHandler');
const SalonSettings = require('../models/SalonSettings');

const protect = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new AppError('Access denied. No token provided.', 401);
    }

    const token = authHeader.split(' ')[1];
    const decoded = verifyAccessToken(token);

    req.user = {
      userId: decoded.userId,
      role: decoded.role,
    };

    next();
  } catch (error) {
    console.error('Token error:', error.message);  // Added for explicit logging (helps debug 401s)
    if (error.name === 'JsonWebTokenError' || error.name === 'TokenExpiredError') {
      return next(new AppError('Invalid or expired token', 401));
    }
    next(error);
  }
};

const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      throw new AppError('You do not have permission to perform this action', 403);
    }
    next();
  };
};

// Dynamic permission check against SalonSettings.permissions
// Usage: router.get('/something', protect, checkPermission('canViewInventory'), handler)
const checkPermission = (permKey) => {
  return async (req, res, next) => {
    try {
      // Admin always has all permissions
      if (req.user.role === 'admin') return next();

      const settings = await SalonSettings.findOne().lean();
      const rolePerms = settings?.permissions?.[req.user.role];

      if (!rolePerms || rolePerms[permKey] === false) {
        return next(new AppError(`Permission denied: ${permKey} is not enabled for your role`, 403));
      }
      next();
    } catch (e) {
      next(e);
    }
  };
};

module.exports = { protect, authorize, checkPermission };