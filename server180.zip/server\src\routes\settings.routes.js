// src/routes/settings.routes.js — v2
const express = require('express');
const router  = express.Router();
const { getSettings, updateSettings, getPublicSettings } = require('../controllers/settings.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');

router.get('/public', getPublicSettings);                          // no auth — for customer booking page
router.get('/',       protect, getSettings);                       // any logged-in user
router.put('/',       protect, authorize('admin'), updateSettings); // admin only

module.exports = router;