const express = require('express');
const router  = express.Router();
const {
  addStaff, getAllStaff, getAvailableStaff, getStaffById,getMyProfile,
  updateStaff, patchStaff, deleteStaff, getStaffPerformance,
  recordSalaryPayment, getSalaryHistory, getMySalary, getMyEarnings,
  getLiveStaffStatus, setFloorStatus,
} = require('../controllers/staff.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');

// ── Static "my" routes — MUST be before /:id ─────────────────────────────
router.get('/my/earnings', protect, authorize('admin','staff','receptionist'), getMyEarnings);
router.get('/my/salary',   protect, authorize('admin','staff','receptionist'), getMySalary);

// ── Lists ─────────────────────────────────────────────────────────────────
router.get('/',            protect, getAllStaff);
router.get('/available',   protect, getAvailableStaff);
router.get('/live-status', protect, authorize('admin','receptionist'), getLiveStaffStatus);
router.get('/me', protect, authorize('admin','staff','receptionist'), getMyProfile);

// ── Single staff ──────────────────────────────────────────────────────────
router.get('/:id',                 protect, getStaffById);
router.get('/:id/performance',     protect, authorize('admin'), getStaffPerformance);
router.get('/:id/salary-history',  protect, authorize('admin','staff'), getSalaryHistory);

// ── Receptionist floor-status toggle ─────────────────────────────────────
router.patch('/:id/floor-status', protect, authorize('admin','receptionist'), setFloorStatus);

// ── Admin mutations ───────────────────────────────────────────────────────
router.post('/',                   protect, authorize('admin'), addStaff);
router.put('/:id',                 protect, authorize('admin'), updateStaff);
router.patch('/:id',               protect, authorize('admin'), patchStaff);
router.delete('/:id',              protect, authorize('admin'), deleteStaff);
router.post('/:id/salary-payment', protect, authorize('admin'), recordSalaryPayment);

module.exports = router;